--
-- PostgreSQL database dump
--

\restrict RAIoH2o1jmM8wzmXpFTMHqGQhVaiq6sKwIuTOk9ibgERgQg2sw5VZCnzgSIzeq8

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.9 (Ubuntu 17.9-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP EVENT TRIGGER IF EXISTS "pgrst_drop_watch";
DROP EVENT TRIGGER IF EXISTS "pgrst_ddl_watch";
DROP EVENT TRIGGER IF EXISTS "issue_pg_net_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_graphql_access";
DROP EVENT TRIGGER IF EXISTS "issue_pg_cron_access";
DROP EVENT TRIGGER IF EXISTS "issue_graphql_placeholder";
DROP PUBLICATION IF EXISTS "supabase_realtime_messages_publication";
DROP PUBLICATION IF EXISTS "supabase_realtime";
DROP POLICY IF EXISTS "Authenticated users can insert activity logs" ON "public"."activity_logs";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."settings";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."phancong";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."namhoc";
DROP POLICY IF EXISTS "Allow public update access" ON "public"."doanvien";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."settings";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."phancong";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."namhoc";
DROP POLICY IF EXISTS "Allow public read access" ON "public"."doanvien";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."settings";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."phancong";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."namhoc";
DROP POLICY IF EXISTS "Allow public insert access" ON "public"."doanvien";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."tuanhoc";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."tieuchitd";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."taikhoan";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."settings";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."qlchidoan";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."phancong";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."namhoc";
DROP POLICY IF EXISTS "Allow public delete access" ON "public"."doanvien";
DROP POLICY IF EXISTS "Admins can view all activity logs" ON "public"."activity_logs";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_upload_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_bucket_id_fkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_bucketId_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_oauth_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_flow_state_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_sso_provider_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_client_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_user_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_auth_factor_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_fkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_user_id_fkey";
DROP TRIGGER IF EXISTS "update_objects_updated_at" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_objects_delete" ON "storage"."objects";
DROP TRIGGER IF EXISTS "protect_buckets_delete" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "enforce_bucket_name_length_trigger" ON "storage"."buckets";
DROP TRIGGER IF EXISTS "tr_check_filters" ON "realtime"."subscription";
DROP INDEX IF EXISTS "storage"."vector_indexes_name_bucket_id_idx";
DROP INDEX IF EXISTS "storage"."name_prefix_search";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name_lower";
DROP INDEX IF EXISTS "storage"."idx_objects_bucket_id_name";
DROP INDEX IF EXISTS "storage"."idx_multipart_uploads_list";
DROP INDEX IF EXISTS "storage"."buckets_analytics_unique_name_idx";
DROP INDEX IF EXISTS "storage"."bucketid_objname";
DROP INDEX IF EXISTS "storage"."bname";
DROP INDEX IF EXISTS "realtime"."subscription_subscription_id_entity_filters_action_filter_key";
DROP INDEX IF EXISTS "realtime"."messages_inserted_at_topic_index";
DROP INDEX IF EXISTS "realtime"."ix_realtime_subscription_entity";
DROP INDEX IF EXISTS "public"."idx_activity_logs_user_id";
DROP INDEX IF EXISTS "public"."idx_activity_logs_created_at";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_credentials_credential_id_key";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_user_id_idx";
DROP INDEX IF EXISTS "auth"."webauthn_challenges_expires_at_idx";
DROP INDEX IF EXISTS "auth"."users_is_anonymous_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_idx";
DROP INDEX IF EXISTS "auth"."users_instance_id_email_idx";
DROP INDEX IF EXISTS "auth"."users_email_partial_key";
DROP INDEX IF EXISTS "auth"."user_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."unique_phone_factor_per_user";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_pattern_idx";
DROP INDEX IF EXISTS "auth"."sso_providers_resource_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."sso_domains_domain_idx";
DROP INDEX IF EXISTS "auth"."sessions_user_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_oauth_client_id_idx";
DROP INDEX IF EXISTS "auth"."sessions_not_after_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_for_email_idx";
DROP INDEX IF EXISTS "auth"."saml_relay_states_created_at_idx";
DROP INDEX IF EXISTS "auth"."saml_providers_sso_provider_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_updated_at_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_session_id_revoked_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_parent_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_user_id_idx";
DROP INDEX IF EXISTS "auth"."refresh_tokens_instance_id_idx";
DROP INDEX IF EXISTS "auth"."recovery_token_idx";
DROP INDEX IF EXISTS "auth"."reauthentication_token_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_user_id_token_type_key";
DROP INDEX IF EXISTS "auth"."one_time_tokens_token_hash_hash_idx";
DROP INDEX IF EXISTS "auth"."one_time_tokens_relates_to_hash_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_user_order_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_user_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_consents_active_client_idx";
DROP INDEX IF EXISTS "auth"."oauth_clients_deleted_at_idx";
DROP INDEX IF EXISTS "auth"."oauth_auth_pending_exp_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_id_idx";
DROP INDEX IF EXISTS "auth"."mfa_factors_user_friendly_name_unique";
DROP INDEX IF EXISTS "auth"."mfa_challenge_created_at_idx";
DROP INDEX IF EXISTS "auth"."idx_user_id_auth_method";
DROP INDEX IF EXISTS "auth"."idx_oauth_client_states_created_at";
DROP INDEX IF EXISTS "auth"."idx_auth_code";
DROP INDEX IF EXISTS "auth"."identities_user_id_idx";
DROP INDEX IF EXISTS "auth"."identities_email_idx";
DROP INDEX IF EXISTS "auth"."flow_state_created_at_idx";
DROP INDEX IF EXISTS "auth"."factor_id_created_at_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_new_idx";
DROP INDEX IF EXISTS "auth"."email_change_token_current_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_provider_type_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_identifier_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_enabled_idx";
DROP INDEX IF EXISTS "auth"."custom_oauth_providers_created_at_idx";
DROP INDEX IF EXISTS "auth"."confirmation_token_idx";
DROP INDEX IF EXISTS "auth"."audit_logs_instance_id_idx";
ALTER TABLE IF EXISTS ONLY "storage"."vector_indexes" DROP CONSTRAINT IF EXISTS "vector_indexes_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."s3_multipart_uploads_parts" DROP CONSTRAINT IF EXISTS "s3_multipart_uploads_parts_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."objects" DROP CONSTRAINT IF EXISTS "objects_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."migrations" DROP CONSTRAINT IF EXISTS "migrations_name_key";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_vectors" DROP CONSTRAINT IF EXISTS "buckets_vectors_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets" DROP CONSTRAINT IF EXISTS "buckets_pkey";
ALTER TABLE IF EXISTS ONLY "storage"."buckets_analytics" DROP CONSTRAINT IF EXISTS "buckets_analytics_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."subscription" DROP CONSTRAINT IF EXISTS "pk_subscription";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_04_03" DROP CONSTRAINT IF EXISTS "messages_2026_04_03_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_04_02" DROP CONSTRAINT IF EXISTS "messages_2026_04_02_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_04_01" DROP CONSTRAINT IF EXISTS "messages_2026_04_01_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_03_31" DROP CONSTRAINT IF EXISTS "messages_2026_03_31_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_03_30" DROP CONSTRAINT IF EXISTS "messages_2026_03_30_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_03_29" DROP CONSTRAINT IF EXISTS "messages_2026_03_29_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages_2026_03_28" DROP CONSTRAINT IF EXISTS "messages_2026_03_28_pkey";
ALTER TABLE IF EXISTS ONLY "realtime"."messages" DROP CONSTRAINT IF EXISTS "messages_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tuanhoc" DROP CONSTRAINT IF EXISTS "tuanhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_pkey";
ALTER TABLE IF EXISTS ONLY "public"."tieuchitd" DROP CONSTRAINT IF EXISTS "tieuchitd_matieuchi_namhoc_hocky_unique";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_username_key";
ALTER TABLE IF EXISTS ONLY "public"."taikhoan" DROP CONSTRAINT IF EXISTS "taikhoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."settings" DROP CONSTRAINT IF EXISTS "settings_pkey";
ALTER TABLE IF EXISTS ONLY "public"."qlchidoan" DROP CONSTRAINT IF EXISTS "qlchidoan_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_pkey";
ALTER TABLE IF EXISTS ONLY "public"."phanquyen" DROP CONSTRAINT IF EXISTS "phanquyen_doi_tuong_tab_namhoc_unique";
ALTER TABLE IF EXISTS ONLY "public"."phancong" DROP CONSTRAINT IF EXISTS "phancong_pkey";
ALTER TABLE IF EXISTS ONLY "public"."namhoc" DROP CONSTRAINT IF EXISTS "namhoc_pkey";
ALTER TABLE IF EXISTS ONLY "public"."doanvien" DROP CONSTRAINT IF EXISTS "doanvien_pkey";
ALTER TABLE IF EXISTS ONLY "public"."chamdiem" DROP CONSTRAINT IF EXISTS "chamdiem_pkey2";
ALTER TABLE IF EXISTS ONLY "public"."activity_logs" DROP CONSTRAINT IF EXISTS "activity_logs_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_credentials" DROP CONSTRAINT IF EXISTS "webauthn_credentials_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."webauthn_challenges" DROP CONSTRAINT IF EXISTS "webauthn_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."users" DROP CONSTRAINT IF EXISTS "users_phone_key";
ALTER TABLE IF EXISTS ONLY "auth"."sso_providers" DROP CONSTRAINT IF EXISTS "sso_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sso_domains" DROP CONSTRAINT IF EXISTS "sso_domains_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."sessions" DROP CONSTRAINT IF EXISTS "sessions_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."schema_migrations" DROP CONSTRAINT IF EXISTS "schema_migrations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_relay_states" DROP CONSTRAINT IF EXISTS "saml_relay_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."saml_providers" DROP CONSTRAINT IF EXISTS "saml_providers_entity_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_token_unique";
ALTER TABLE IF EXISTS ONLY "auth"."refresh_tokens" DROP CONSTRAINT IF EXISTS "refresh_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."one_time_tokens" DROP CONSTRAINT IF EXISTS "one_time_tokens_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_user_client_unique";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_consents" DROP CONSTRAINT IF EXISTS "oauth_consents_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_clients" DROP CONSTRAINT IF EXISTS "oauth_clients_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_client_states" DROP CONSTRAINT IF EXISTS "oauth_client_states_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_id_key";
ALTER TABLE IF EXISTS ONLY "auth"."oauth_authorizations" DROP CONSTRAINT IF EXISTS "oauth_authorizations_authorization_code_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_factors" DROP CONSTRAINT IF EXISTS "mfa_factors_last_challenged_at_key";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_challenges" DROP CONSTRAINT IF EXISTS "mfa_challenges_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "mfa_amr_claims_session_id_authentication_method_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."instances" DROP CONSTRAINT IF EXISTS "instances_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_provider_id_provider_unique";
ALTER TABLE IF EXISTS ONLY "auth"."identities" DROP CONSTRAINT IF EXISTS "identities_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."flow_state" DROP CONSTRAINT IF EXISTS "flow_state_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."custom_oauth_providers" DROP CONSTRAINT IF EXISTS "custom_oauth_providers_identifier_key";
ALTER TABLE IF EXISTS ONLY "auth"."audit_log_entries" DROP CONSTRAINT IF EXISTS "audit_log_entries_pkey";
ALTER TABLE IF EXISTS ONLY "auth"."mfa_amr_claims" DROP CONSTRAINT IF EXISTS "amr_id_pk";
ALTER TABLE IF EXISTS "auth"."refresh_tokens" ALTER COLUMN "id" DROP DEFAULT;
DROP TABLE IF EXISTS "storage"."vector_indexes";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads_parts";
DROP TABLE IF EXISTS "storage"."s3_multipart_uploads";
DROP TABLE IF EXISTS "storage"."objects";
DROP TABLE IF EXISTS "storage"."migrations";
DROP TABLE IF EXISTS "storage"."buckets_vectors";
DROP TABLE IF EXISTS "storage"."buckets_analytics";
DROP TABLE IF EXISTS "storage"."buckets";
DROP TABLE IF EXISTS "realtime"."subscription";
DROP TABLE IF EXISTS "realtime"."schema_migrations";
DROP TABLE IF EXISTS "realtime"."messages_2026_04_03";
DROP TABLE IF EXISTS "realtime"."messages_2026_04_02";
DROP TABLE IF EXISTS "realtime"."messages_2026_04_01";
DROP TABLE IF EXISTS "realtime"."messages_2026_03_31";
DROP TABLE IF EXISTS "realtime"."messages_2026_03_30";
DROP TABLE IF EXISTS "realtime"."messages_2026_03_29";
DROP TABLE IF EXISTS "realtime"."messages_2026_03_28";
DROP TABLE IF EXISTS "realtime"."messages";
DROP TABLE IF EXISTS "public"."tuanhoc";
DROP TABLE IF EXISTS "public"."tieuchitd";
DROP TABLE IF EXISTS "public"."taikhoan";
DROP TABLE IF EXISTS "public"."settings";
DROP TABLE IF EXISTS "public"."qlchidoan";
DROP TABLE IF EXISTS "public"."phanquyen";
DROP TABLE IF EXISTS "public"."phancong";
DROP TABLE IF EXISTS "public"."namhoc";
DROP TABLE IF EXISTS "public"."doanvien";
DROP TABLE IF EXISTS "public"."chamdiem";
DROP TABLE IF EXISTS "public"."activity_logs";
DROP TABLE IF EXISTS "auth"."webauthn_credentials";
DROP TABLE IF EXISTS "auth"."webauthn_challenges";
DROP TABLE IF EXISTS "auth"."users";
DROP TABLE IF EXISTS "auth"."sso_providers";
DROP TABLE IF EXISTS "auth"."sso_domains";
DROP TABLE IF EXISTS "auth"."sessions";
DROP TABLE IF EXISTS "auth"."schema_migrations";
DROP TABLE IF EXISTS "auth"."saml_relay_states";
DROP TABLE IF EXISTS "auth"."saml_providers";
DROP SEQUENCE IF EXISTS "auth"."refresh_tokens_id_seq";
DROP TABLE IF EXISTS "auth"."refresh_tokens";
DROP TABLE IF EXISTS "auth"."one_time_tokens";
DROP TABLE IF EXISTS "auth"."oauth_consents";
DROP TABLE IF EXISTS "auth"."oauth_clients";
DROP TABLE IF EXISTS "auth"."oauth_client_states";
DROP TABLE IF EXISTS "auth"."oauth_authorizations";
DROP TABLE IF EXISTS "auth"."mfa_factors";
DROP TABLE IF EXISTS "auth"."mfa_challenges";
DROP TABLE IF EXISTS "auth"."mfa_amr_claims";
DROP TABLE IF EXISTS "auth"."instances";
DROP TABLE IF EXISTS "auth"."identities";
DROP TABLE IF EXISTS "auth"."flow_state";
DROP TABLE IF EXISTS "auth"."custom_oauth_providers";
DROP TABLE IF EXISTS "auth"."audit_log_entries";
DROP FUNCTION IF EXISTS "storage"."update_updated_at_column"();
DROP FUNCTION IF EXISTS "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text");
DROP FUNCTION IF EXISTS "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text");
DROP FUNCTION IF EXISTS "storage"."protect_delete"();
DROP FUNCTION IF EXISTS "storage"."operation"();
DROP FUNCTION IF EXISTS "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text");
DROP FUNCTION IF EXISTS "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text");
DROP FUNCTION IF EXISTS "storage"."get_size_by_bucket"();
DROP FUNCTION IF EXISTS "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text");
DROP FUNCTION IF EXISTS "storage"."foldername"("name" "text");
DROP FUNCTION IF EXISTS "storage"."filename"("name" "text");
DROP FUNCTION IF EXISTS "storage"."extension"("name" "text");
DROP FUNCTION IF EXISTS "storage"."enforce_bucket_name_length"();
DROP FUNCTION IF EXISTS "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb");
DROP FUNCTION IF EXISTS "realtime"."topic"();
DROP FUNCTION IF EXISTS "realtime"."to_regrole"("role_name" "text");
DROP FUNCTION IF EXISTS "realtime"."subscription_check_filters"();
DROP FUNCTION IF EXISTS "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean);
DROP FUNCTION IF EXISTS "realtime"."quote_wal2json"("entity" "regclass");
DROP FUNCTION IF EXISTS "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]);
DROP FUNCTION IF EXISTS "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text");
DROP FUNCTION IF EXISTS "realtime"."cast"("val" "text", "type_" "regtype");
DROP FUNCTION IF EXISTS "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]);
DROP FUNCTION IF EXISTS "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text");
DROP FUNCTION IF EXISTS "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer);
DROP FUNCTION IF EXISTS "pgbouncer"."get_auth"("p_usename" "text");
DROP FUNCTION IF EXISTS "extensions"."set_graphql_placeholder"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_drop_watch"();
DROP FUNCTION IF EXISTS "extensions"."pgrst_ddl_watch"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_net_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_graphql_access"();
DROP FUNCTION IF EXISTS "extensions"."grant_pg_cron_access"();
DROP FUNCTION IF EXISTS "auth"."uid"();
DROP FUNCTION IF EXISTS "auth"."role"();
DROP FUNCTION IF EXISTS "auth"."jwt"();
DROP FUNCTION IF EXISTS "auth"."email"();
DROP TYPE IF EXISTS "storage"."buckettype";
DROP TYPE IF EXISTS "realtime"."wal_rls";
DROP TYPE IF EXISTS "realtime"."wal_column";
DROP TYPE IF EXISTS "realtime"."user_defined_filter";
DROP TYPE IF EXISTS "realtime"."equality_op";
DROP TYPE IF EXISTS "realtime"."action";
DROP TYPE IF EXISTS "auth"."one_time_token_type";
DROP TYPE IF EXISTS "auth"."oauth_response_type";
DROP TYPE IF EXISTS "auth"."oauth_registration_type";
DROP TYPE IF EXISTS "auth"."oauth_client_type";
DROP TYPE IF EXISTS "auth"."oauth_authorization_status";
DROP TYPE IF EXISTS "auth"."factor_type";
DROP TYPE IF EXISTS "auth"."factor_status";
DROP TYPE IF EXISTS "auth"."code_challenge_method";
DROP TYPE IF EXISTS "auth"."aal_level";
DROP EXTENSION IF EXISTS "uuid-ossp";
DROP EXTENSION IF EXISTS "supabase_vault";
DROP EXTENSION IF EXISTS "pgcrypto";
DROP EXTENSION IF EXISTS "pg_stat_statements";
DROP EXTENSION IF EXISTS "pg_graphql";
DROP SCHEMA IF EXISTS "vault";
DROP SCHEMA IF EXISTS "storage";
DROP SCHEMA IF EXISTS "realtime";
DROP SCHEMA IF EXISTS "pgbouncer";
DROP SCHEMA IF EXISTS "graphql_public";
DROP SCHEMA IF EXISTS "graphql";
DROP SCHEMA IF EXISTS "extensions";
DROP SCHEMA IF EXISTS "auth";
--
-- Name: auth; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "auth";


ALTER SCHEMA "auth" OWNER TO "supabase_admin";

--
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA "extensions";


ALTER SCHEMA "extensions" OWNER TO "postgres";

--
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql";


ALTER SCHEMA "graphql" OWNER TO "supabase_admin";

--
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "graphql_public";


ALTER SCHEMA "graphql_public" OWNER TO "supabase_admin";

--
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: pgbouncer
--

CREATE SCHEMA "pgbouncer";


ALTER SCHEMA "pgbouncer" OWNER TO "pgbouncer";

--
-- Name: SCHEMA "public"; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA "public" IS 'standard public schema';


--
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "realtime";


ALTER SCHEMA "realtime" OWNER TO "supabase_admin";

--
-- Name: storage; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "storage";


ALTER SCHEMA "storage" OWNER TO "supabase_admin";

--
-- Name: vault; Type: SCHEMA; Schema: -; Owner: supabase_admin
--

CREATE SCHEMA "vault";


ALTER SCHEMA "vault" OWNER TO "supabase_admin";

--
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_graphql" WITH SCHEMA "graphql";


--
-- Name: EXTENSION "pg_graphql"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_graphql" IS 'pg_graphql: GraphQL support';


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pg_stat_statements"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pg_stat_statements" IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "pgcrypto"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "pgcrypto" IS 'cryptographic functions';


--
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";


--
-- Name: EXTENSION "supabase_vault"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "supabase_vault" IS 'Supabase Vault Extension';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."aal_level" AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


ALTER TYPE "auth"."aal_level" OWNER TO "supabase_auth_admin";

--
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."code_challenge_method" AS ENUM (
    's256',
    'plain'
);


ALTER TYPE "auth"."code_challenge_method" OWNER TO "supabase_auth_admin";

--
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_status" AS ENUM (
    'unverified',
    'verified'
);


ALTER TYPE "auth"."factor_status" OWNER TO "supabase_auth_admin";

--
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."factor_type" AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


ALTER TYPE "auth"."factor_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_authorization_status; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_authorization_status" AS ENUM (
    'pending',
    'approved',
    'denied',
    'expired'
);


ALTER TYPE "auth"."oauth_authorization_status" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_client_type" AS ENUM (
    'public',
    'confidential'
);


ALTER TYPE "auth"."oauth_client_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_registration_type" AS ENUM (
    'dynamic',
    'manual'
);


ALTER TYPE "auth"."oauth_registration_type" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_response_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."oauth_response_type" AS ENUM (
    'code'
);


ALTER TYPE "auth"."oauth_response_type" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TYPE "auth"."one_time_token_type" AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


ALTER TYPE "auth"."one_time_token_type" OWNER TO "supabase_auth_admin";

--
-- Name: action; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."action" AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


ALTER TYPE "realtime"."action" OWNER TO "supabase_admin";

--
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."equality_op" AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


ALTER TYPE "realtime"."equality_op" OWNER TO "supabase_admin";

--
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."user_defined_filter" AS (
	"column_name" "text",
	"op" "realtime"."equality_op",
	"value" "text"
);


ALTER TYPE "realtime"."user_defined_filter" OWNER TO "supabase_admin";

--
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_column" AS (
	"name" "text",
	"type_name" "text",
	"type_oid" "oid",
	"value" "jsonb",
	"is_pkey" boolean,
	"is_selectable" boolean
);


ALTER TYPE "realtime"."wal_column" OWNER TO "supabase_admin";

--
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: supabase_admin
--

CREATE TYPE "realtime"."wal_rls" AS (
	"wal" "jsonb",
	"is_rls_enabled" boolean,
	"subscription_ids" "uuid"[],
	"errors" "text"[]
);


ALTER TYPE "realtime"."wal_rls" OWNER TO "supabase_admin";

--
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TYPE "storage"."buckettype" AS ENUM (
    'STANDARD',
    'ANALYTICS',
    'VECTOR'
);


ALTER TYPE "storage"."buckettype" OWNER TO "supabase_storage_admin";

--
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."email"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


ALTER FUNCTION "auth"."email"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "email"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."email"() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."jwt"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


ALTER FUNCTION "auth"."jwt"() OWNER TO "supabase_auth_admin";

--
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."role"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


ALTER FUNCTION "auth"."role"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "role"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."role"() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: supabase_auth_admin
--

CREATE FUNCTION "auth"."uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


ALTER FUNCTION "auth"."uid"() OWNER TO "supabase_auth_admin";

--
-- Name: FUNCTION "uid"(); Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON FUNCTION "auth"."uid"() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_cron_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_cron_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_cron_access"() IS 'Grants access to pg_cron';


--
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_graphql_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


ALTER FUNCTION "extensions"."grant_pg_graphql_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_graphql_access"() IS 'Grants access to pg_graphql';


--
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."grant_pg_net_access"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


ALTER FUNCTION "extensions"."grant_pg_net_access"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "grant_pg_net_access"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."grant_pg_net_access"() IS 'Grants access to pg_net';


--
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_ddl_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_ddl_watch"() OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."pgrst_drop_watch"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


ALTER FUNCTION "extensions"."pgrst_drop_watch"() OWNER TO "supabase_admin";

--
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: supabase_admin
--

CREATE FUNCTION "extensions"."set_graphql_placeholder"() RETURNS "event_trigger"
    LANGUAGE "plpgsql"
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


ALTER FUNCTION "extensions"."set_graphql_placeholder"() OWNER TO "supabase_admin";

--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: COMMENT; Schema: extensions; Owner: supabase_admin
--

COMMENT ON FUNCTION "extensions"."set_graphql_placeholder"() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- Name: get_auth("text"); Type: FUNCTION; Schema: pgbouncer; Owner: supabase_admin
--

CREATE FUNCTION "pgbouncer"."get_auth"("p_usename" "text") RETURNS TABLE("username" "text", "password" "text")
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO ''
    AS $_$
  BEGIN
      RAISE DEBUG 'PgBouncer auth request: %', p_usename;

      RETURN QUERY
      SELECT
          rolname::text,
          CASE WHEN rolvaliduntil < now()
              THEN null
              ELSE rolpassword::text
          END
      FROM pg_authid
      WHERE rolname=$1 and rolcanlogin;
  END;
  $_$;


ALTER FUNCTION "pgbouncer"."get_auth"("p_usename" "text") OWNER TO "supabase_admin";

--
-- Name: apply_rls("jsonb", integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer DEFAULT (1024 * 1024)) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "plpgsql"
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_
        -- Filter by action early - only get subscriptions interested in this action
        -- action_filter column can be: '*' (all), 'INSERT', 'UPDATE', or 'DELETE'
        and (subs.action_filter = '*' or subs.action_filter = action::text);

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


ALTER FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: broadcast_changes("text", "text", "text", "text", "text", "record", "record", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text" DEFAULT 'ROW'::"text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


ALTER FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") OWNER TO "supabase_admin";

--
-- Name: build_prepared_statement_sql("text", "regclass", "realtime"."wal_column"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) RETURNS "text"
    LANGUAGE "sql"
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


ALTER FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) OWNER TO "supabase_admin";

--
-- Name: cast("text", "regtype"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") RETURNS "jsonb"
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
declare
  res jsonb;
begin
  if type_::text = 'bytea' then
    return to_jsonb(val);
  end if;
  execute format('select to_jsonb(%L::'|| type_::text || ')', val) into res;
  return res;
end
$$;


ALTER FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") OWNER TO "supabase_admin";

--
-- Name: check_equality_op("realtime"."equality_op", "regtype", "text", "text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") RETURNS boolean
    LANGUAGE "plpgsql" IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


ALTER FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") OWNER TO "supabase_admin";

--
-- Name: is_visible_through_filters("realtime"."wal_column"[], "realtime"."user_defined_filter"[]); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) RETURNS boolean
    LANGUAGE "sql" IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


ALTER FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) OWNER TO "supabase_admin";

--
-- Name: list_changes("name", "name", integer, integer); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) RETURNS SETOF "realtime"."wal_rls"
    LANGUAGE "sql"
    SET "log_min_messages" TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


ALTER FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) OWNER TO "supabase_admin";

--
-- Name: quote_wal2json("regclass"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."quote_wal2json"("entity" "regclass") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


ALTER FUNCTION "realtime"."quote_wal2json"("entity" "regclass") OWNER TO "supabase_admin";

--
-- Name: send("jsonb", "text", "text", boolean); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean DEFAULT true) RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
  generated_id uuid;
  final_payload jsonb;
BEGIN
  BEGIN
    -- Generate a new UUID for the id
    generated_id := gen_random_uuid();

    -- Check if payload has an 'id' key, if not, add the generated UUID
    IF payload ? 'id' THEN
      final_payload := payload;
    ELSE
      final_payload := jsonb_set(payload, '{id}', to_jsonb(generated_id));
    END IF;

    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (id, payload, event, topic, private, extension)
    VALUES (generated_id, final_payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


ALTER FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) OWNER TO "supabase_admin";

--
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."subscription_check_filters"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


ALTER FUNCTION "realtime"."subscription_check_filters"() OWNER TO "supabase_admin";

--
-- Name: to_regrole("text"); Type: FUNCTION; Schema: realtime; Owner: supabase_admin
--

CREATE FUNCTION "realtime"."to_regrole"("role_name" "text") RETURNS "regrole"
    LANGUAGE "sql" IMMUTABLE
    AS $$ select role_name::regrole $$;


ALTER FUNCTION "realtime"."to_regrole"("role_name" "text") OWNER TO "supabase_admin";

--
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE FUNCTION "realtime"."topic"() RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


ALTER FUNCTION "realtime"."topic"() OWNER TO "supabase_realtime_admin";

--
-- Name: can_insert_object("text", "text", "uuid", "jsonb"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


ALTER FUNCTION "storage"."can_insert_object"("bucketid" "text", "name" "text", "owner" "uuid", "metadata" "jsonb") OWNER TO "supabase_storage_admin";

--
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."enforce_bucket_name_length"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


ALTER FUNCTION "storage"."enforce_bucket_name_length"() OWNER TO "supabase_storage_admin";

--
-- Name: extension("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."extension"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
_filename text;
BEGIN
	select string_to_array(name, '/') into _parts;
	select _parts[array_length(_parts,1)] into _filename;
	-- @todo return the last part instead of 2
	return reverse(split_part(reverse(_filename), '.', 1));
END
$$;


ALTER FUNCTION "storage"."extension"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: filename("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."filename"("name" "text") RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


ALTER FUNCTION "storage"."filename"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: foldername("text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."foldername"("name" "text") RETURNS "text"[]
    LANGUAGE "plpgsql"
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[1:array_length(_parts,1)-1];
END
$$;


ALTER FUNCTION "storage"."foldername"("name" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_common_prefix("text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") RETURNS "text"
    LANGUAGE "sql" IMMUTABLE
    AS $$
SELECT CASE
    WHEN position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)) > 0
    THEN left(p_key, length(p_prefix) + position(p_delimiter IN substring(p_key FROM length(p_prefix) + 1)))
    ELSE NULL
END;
$$;


ALTER FUNCTION "storage"."get_common_prefix"("p_key" "text", "p_prefix" "text", "p_delimiter" "text") OWNER TO "supabase_storage_admin";

--
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."get_size_by_bucket"() RETURNS TABLE("size" bigint, "bucket_id" "text")
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::int) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


ALTER FUNCTION "storage"."get_size_by_bucket"() OWNER TO "supabase_storage_admin";

--
-- Name: list_multipart_uploads_with_delimiter("text", "text", "text", integer, "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "next_key_token" "text" DEFAULT ''::"text", "next_upload_token" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "id" "text", "created_at" timestamp with time zone)
    LANGUAGE "plpgsql"
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


ALTER FUNCTION "storage"."list_multipart_uploads_with_delimiter"("bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "next_key_token" "text", "next_upload_token" "text") OWNER TO "supabase_storage_admin";

--
-- Name: list_objects_with_delimiter("text", "text", "text", integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer DEFAULT 100, "start_after" "text" DEFAULT ''::"text", "next_token" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "metadata" "jsonb", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone)
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;

    -- Configuration
    v_is_asc BOOLEAN;
    v_prefix TEXT;
    v_start TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_is_asc := lower(coalesce(sort_order, 'asc')) = 'asc';
    v_prefix := coalesce(prefix_param, '');
    v_start := CASE WHEN coalesce(next_token, '') <> '' THEN next_token ELSE coalesce(start_after, '') END;
    v_file_batch_size := LEAST(GREATEST(max_keys * 2, 100), 1000);

    -- Calculate upper bound for prefix filtering (bytewise, using COLLATE "C")
    IF v_prefix = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix, 1) = delimiter_param THEN
        v_upper_bound := left(v_prefix, -1) || chr(ascii(delimiter_param) + 1);
    ELSE
        v_upper_bound := left(v_prefix, -1) || chr(ascii(right(v_prefix, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'AND o.name COLLATE "C" < $3 ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" >= $2 ' ||
                'ORDER BY o.name COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'AND o.name COLLATE "C" >= $3 ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND o.name COLLATE "C" < $2 ' ||
                'ORDER BY o.name COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- ========================================================================
    -- SEEK INITIALIZATION: Determine starting position
    -- ========================================================================
    IF v_start = '' THEN
        IF v_is_asc THEN
            v_next_seek := v_prefix;
        ELSE
            -- DESC without cursor: find the last item in range
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_next_seek FROM storage.objects o
                WHERE o.bucket_id = _bucket_id
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;

            IF v_next_seek IS NOT NULL THEN
                v_next_seek := v_next_seek || delimiter_param;
            ELSE
                RETURN;
            END IF;
        END IF;
    ELSE
        -- Cursor provided: determine if it refers to a folder or leaf
        IF EXISTS (
            SELECT 1 FROM storage.objects o
            WHERE o.bucket_id = _bucket_id
              AND o.name COLLATE "C" LIKE v_start || delimiter_param || '%'
            LIMIT 1
        ) THEN
            -- Cursor refers to a folder
            IF v_is_asc THEN
                v_next_seek := v_start || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_start || delimiter_param;
            END IF;
        ELSE
            -- Cursor refers to a leaf object
            IF v_is_asc THEN
                v_next_seek := v_start || delimiter_param;
            ELSE
                v_next_seek := v_start;
            END IF;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= max_keys;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek AND o.name COLLATE "C" < v_upper_bound
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" >= v_next_seek
                ORDER BY o.name COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek AND o.name COLLATE "C" >= v_prefix
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = _bucket_id AND o.name COLLATE "C" < v_next_seek
                ORDER BY o.name COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(v_peek_name, v_prefix, delimiter_param);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Emit and skip to next folder (no heap access needed)
            name := rtrim(v_common_prefix, delimiter_param);
            id := NULL;
            updated_at := NULL;
            created_at := NULL;
            last_accessed_at := NULL;
            metadata := NULL;
            RETURN NEXT;
            v_count := v_count + 1;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := left(v_common_prefix, -1) || chr(ascii(delimiter_param) + 1);
            ELSE
                v_next_seek := v_common_prefix;
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query USING _bucket_id, v_next_seek,
                CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix) ELSE v_prefix END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(v_current.name, v_prefix, delimiter_param);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := v_current.name;
                    EXIT;
                END IF;

                -- Emit file
                name := v_current.name;
                id := v_current.id;
                updated_at := v_current.updated_at;
                created_at := v_current.created_at;
                last_accessed_at := v_current.last_accessed_at;
                metadata := v_current.metadata;
                RETURN NEXT;
                v_count := v_count + 1;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := v_current.name || delimiter_param;
                ELSE
                    v_next_seek := v_current.name;
                END IF;

                EXIT WHEN v_count >= max_keys;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."list_objects_with_delimiter"("_bucket_id" "text", "prefix_param" "text", "delimiter_param" "text", "max_keys" integer, "start_after" "text", "next_token" "text", "sort_order" "text") OWNER TO "supabase_storage_admin";

--
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."operation"() RETURNS "text"
    LANGUAGE "plpgsql" STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


ALTER FUNCTION "storage"."operation"() OWNER TO "supabase_storage_admin";

--
-- Name: protect_delete(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."protect_delete"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    -- Check if storage.allow_delete_query is set to 'true'
    IF COALESCE(current_setting('storage.allow_delete_query', true), 'false') != 'true' THEN
        RAISE EXCEPTION 'Direct deletion from storage tables is not allowed. Use the Storage API instead.'
            USING HINT = 'This prevents accidental data loss from orphaned objects.',
                  ERRCODE = '42501';
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION "storage"."protect_delete"() OWNER TO "supabase_storage_admin";

--
-- Name: search("text", "text", integer, integer, integer, "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "offsets" integer DEFAULT 0, "search" "text" DEFAULT ''::"text", "sortcolumn" "text" DEFAULT 'name'::"text", "sortorder" "text" DEFAULT 'asc'::"text") RETURNS TABLE("name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_peek_name TEXT;
    v_current RECORD;
    v_common_prefix TEXT;
    v_delimiter CONSTANT TEXT := '/';

    -- Configuration
    v_limit INT;
    v_prefix TEXT;
    v_prefix_lower TEXT;
    v_is_asc BOOLEAN;
    v_order_by TEXT;
    v_sort_order TEXT;
    v_upper_bound TEXT;
    v_file_batch_size INT;

    -- Dynamic SQL for batch query only
    v_batch_query TEXT;

    -- Seek state
    v_next_seek TEXT;
    v_count INT := 0;
    v_skipped INT := 0;
BEGIN
    -- ========================================================================
    -- INITIALIZATION
    -- ========================================================================
    v_limit := LEAST(coalesce(limits, 100), 1500);
    v_prefix := coalesce(prefix, '') || coalesce(search, '');
    v_prefix_lower := lower(v_prefix);
    v_is_asc := lower(coalesce(sortorder, 'asc')) = 'asc';
    v_file_batch_size := LEAST(GREATEST(v_limit * 2, 100), 1000);

    -- Validate sort column
    CASE lower(coalesce(sortcolumn, 'name'))
        WHEN 'name' THEN v_order_by := 'name';
        WHEN 'updated_at' THEN v_order_by := 'updated_at';
        WHEN 'created_at' THEN v_order_by := 'created_at';
        WHEN 'last_accessed_at' THEN v_order_by := 'last_accessed_at';
        ELSE v_order_by := 'name';
    END CASE;

    v_sort_order := CASE WHEN v_is_asc THEN 'asc' ELSE 'desc' END;

    -- ========================================================================
    -- NON-NAME SORTING: Use path_tokens approach (unchanged)
    -- ========================================================================
    IF v_order_by != 'name' THEN
        RETURN QUERY EXECUTE format(
            $sql$
            WITH folders AS (
                SELECT path_tokens[$1] AS folder
                FROM storage.objects
                WHERE objects.name ILIKE $2 || '%%'
                  AND bucket_id = $3
                  AND array_length(objects.path_tokens, 1) <> $1
                GROUP BY folder
                ORDER BY folder %s
            )
            (SELECT folder AS "name",
                   NULL::uuid AS id,
                   NULL::timestamptz AS updated_at,
                   NULL::timestamptz AS created_at,
                   NULL::timestamptz AS last_accessed_at,
                   NULL::jsonb AS metadata FROM folders)
            UNION ALL
            (SELECT path_tokens[$1] AS "name",
                   id, updated_at, created_at, last_accessed_at, metadata
             FROM storage.objects
             WHERE objects.name ILIKE $2 || '%%'
               AND bucket_id = $3
               AND array_length(objects.path_tokens, 1) = $1
             ORDER BY %I %s)
            LIMIT $4 OFFSET $5
            $sql$, v_sort_order, v_order_by, v_sort_order
        ) USING levels, v_prefix, bucketname, v_limit, offsets;
        RETURN;
    END IF;

    -- ========================================================================
    -- NAME SORTING: Hybrid skip-scan with batch optimization
    -- ========================================================================

    -- Calculate upper bound for prefix filtering
    IF v_prefix_lower = '' THEN
        v_upper_bound := NULL;
    ELSIF right(v_prefix_lower, 1) = v_delimiter THEN
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(v_delimiter) + 1);
    ELSE
        v_upper_bound := left(v_prefix_lower, -1) || chr(ascii(right(v_prefix_lower, 1)) + 1);
    END IF;

    -- Build batch query (dynamic SQL - called infrequently, amortized over many rows)
    IF v_is_asc THEN
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'AND lower(o.name) COLLATE "C" < $3 ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" >= $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" ASC LIMIT $4';
        END IF;
    ELSE
        IF v_upper_bound IS NOT NULL THEN
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'AND lower(o.name) COLLATE "C" >= $3 ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        ELSE
            v_batch_query := 'SELECT o.name, o.id, o.updated_at, o.created_at, o.last_accessed_at, o.metadata ' ||
                'FROM storage.objects o WHERE o.bucket_id = $1 AND lower(o.name) COLLATE "C" < $2 ' ||
                'ORDER BY lower(o.name) COLLATE "C" DESC LIMIT $4';
        END IF;
    END IF;

    -- Initialize seek position
    IF v_is_asc THEN
        v_next_seek := v_prefix_lower;
    ELSE
        -- DESC: find the last item in range first (static SQL)
        IF v_upper_bound IS NOT NULL THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower AND lower(o.name) COLLATE "C" < v_upper_bound
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSIF v_prefix_lower <> '' THEN
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_prefix_lower
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        ELSE
            SELECT o.name INTO v_peek_name FROM storage.objects o
            WHERE o.bucket_id = bucketname
            ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
        END IF;

        IF v_peek_name IS NOT NULL THEN
            v_next_seek := lower(v_peek_name) || v_delimiter;
        ELSE
            RETURN;
        END IF;
    END IF;

    -- ========================================================================
    -- MAIN LOOP: Hybrid peek-then-batch algorithm
    -- Uses STATIC SQL for peek (hot path) and DYNAMIC SQL for batch
    -- ========================================================================
    LOOP
        EXIT WHEN v_count >= v_limit;

        -- STEP 1: PEEK using STATIC SQL (plan cached, very fast)
        IF v_is_asc THEN
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek AND lower(o.name) COLLATE "C" < v_upper_bound
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" >= v_next_seek
                ORDER BY lower(o.name) COLLATE "C" ASC LIMIT 1;
            END IF;
        ELSE
            IF v_upper_bound IS NOT NULL THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSIF v_prefix_lower <> '' THEN
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek AND lower(o.name) COLLATE "C" >= v_prefix_lower
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            ELSE
                SELECT o.name INTO v_peek_name FROM storage.objects o
                WHERE o.bucket_id = bucketname AND lower(o.name) COLLATE "C" < v_next_seek
                ORDER BY lower(o.name) COLLATE "C" DESC LIMIT 1;
            END IF;
        END IF;

        EXIT WHEN v_peek_name IS NULL;

        -- STEP 2: Check if this is a FOLDER or FILE
        v_common_prefix := storage.get_common_prefix(lower(v_peek_name), v_prefix_lower, v_delimiter);

        IF v_common_prefix IS NOT NULL THEN
            -- FOLDER: Handle offset, emit if needed, skip to next folder
            IF v_skipped < offsets THEN
                v_skipped := v_skipped + 1;
            ELSE
                name := split_part(rtrim(storage.get_common_prefix(v_peek_name, v_prefix, v_delimiter), v_delimiter), v_delimiter, levels);
                id := NULL;
                updated_at := NULL;
                created_at := NULL;
                last_accessed_at := NULL;
                metadata := NULL;
                RETURN NEXT;
                v_count := v_count + 1;
            END IF;

            -- Advance seek past the folder range
            IF v_is_asc THEN
                v_next_seek := lower(left(v_common_prefix, -1)) || chr(ascii(v_delimiter) + 1);
            ELSE
                v_next_seek := lower(v_common_prefix);
            END IF;
        ELSE
            -- FILE: Batch fetch using DYNAMIC SQL (overhead amortized over many rows)
            -- For ASC: upper_bound is the exclusive upper limit (< condition)
            -- For DESC: prefix_lower is the inclusive lower limit (>= condition)
            FOR v_current IN EXECUTE v_batch_query
                USING bucketname, v_next_seek,
                    CASE WHEN v_is_asc THEN COALESCE(v_upper_bound, v_prefix_lower) ELSE v_prefix_lower END, v_file_batch_size
            LOOP
                v_common_prefix := storage.get_common_prefix(lower(v_current.name), v_prefix_lower, v_delimiter);

                IF v_common_prefix IS NOT NULL THEN
                    -- Hit a folder: exit batch, let peek handle it
                    v_next_seek := lower(v_current.name);
                    EXIT;
                END IF;

                -- Handle offset skipping
                IF v_skipped < offsets THEN
                    v_skipped := v_skipped + 1;
                ELSE
                    -- Emit file
                    name := split_part(v_current.name, v_delimiter, levels);
                    id := v_current.id;
                    updated_at := v_current.updated_at;
                    created_at := v_current.created_at;
                    last_accessed_at := v_current.last_accessed_at;
                    metadata := v_current.metadata;
                    RETURN NEXT;
                    v_count := v_count + 1;
                END IF;

                -- Advance seek past this file
                IF v_is_asc THEN
                    v_next_seek := lower(v_current.name) || v_delimiter;
                ELSE
                    v_next_seek := lower(v_current.name);
                END IF;

                EXIT WHEN v_count >= v_limit;
            END LOOP;
        END IF;
    END LOOP;
END;
$_$;


ALTER FUNCTION "storage"."search"("prefix" "text", "bucketname" "text", "limits" integer, "levels" integer, "offsets" integer, "search" "text", "sortcolumn" "text", "sortorder" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_by_timestamp("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $_$
DECLARE
    v_cursor_op text;
    v_query text;
    v_prefix text;
BEGIN
    v_prefix := coalesce(p_prefix, '');

    IF p_sort_order = 'asc' THEN
        v_cursor_op := '>';
    ELSE
        v_cursor_op := '<';
    END IF;

    v_query := format($sql$
        WITH raw_objects AS (
            SELECT
                o.name AS obj_name,
                o.id AS obj_id,
                o.updated_at AS obj_updated_at,
                o.created_at AS obj_created_at,
                o.last_accessed_at AS obj_last_accessed_at,
                o.metadata AS obj_metadata,
                storage.get_common_prefix(o.name, $1, '/') AS common_prefix
            FROM storage.objects o
            WHERE o.bucket_id = $2
              AND o.name COLLATE "C" LIKE $1 || '%%'
        ),
        -- Aggregate common prefixes (folders)
        -- Both created_at and updated_at use MIN(obj_created_at) to match the old prefixes table behavior
        aggregated_prefixes AS (
            SELECT
                rtrim(common_prefix, '/') AS name,
                NULL::uuid AS id,
                MIN(obj_created_at) AS updated_at,
                MIN(obj_created_at) AS created_at,
                NULL::timestamptz AS last_accessed_at,
                NULL::jsonb AS metadata,
                TRUE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NOT NULL
            GROUP BY common_prefix
        ),
        leaf_objects AS (
            SELECT
                obj_name AS name,
                obj_id AS id,
                obj_updated_at AS updated_at,
                obj_created_at AS created_at,
                obj_last_accessed_at AS last_accessed_at,
                obj_metadata AS metadata,
                FALSE AS is_prefix
            FROM raw_objects
            WHERE common_prefix IS NULL
        ),
        combined AS (
            SELECT * FROM aggregated_prefixes
            UNION ALL
            SELECT * FROM leaf_objects
        ),
        filtered AS (
            SELECT *
            FROM combined
            WHERE (
                $5 = ''
                OR ROW(
                    date_trunc('milliseconds', %I),
                    name COLLATE "C"
                ) %s ROW(
                    COALESCE(NULLIF($6, '')::timestamptz, 'epoch'::timestamptz),
                    $5
                )
            )
        )
        SELECT
            split_part(name, '/', $3) AS key,
            name,
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
        FROM filtered
        ORDER BY
            COALESCE(date_trunc('milliseconds', %I), 'epoch'::timestamptz) %s,
            name COLLATE "C" %s
        LIMIT $4
    $sql$,
        p_sort_column,
        v_cursor_op,
        p_sort_column,
        p_sort_order,
        p_sort_order
    );

    RETURN QUERY EXECUTE v_query
    USING v_prefix, p_bucket_id, p_level, p_limit, p_start_after, p_sort_column_after;
END;
$_$;


ALTER FUNCTION "storage"."search_by_timestamp"("p_prefix" "text", "p_bucket_id" "text", "p_limit" integer, "p_level" integer, "p_start_after" "text", "p_sort_order" "text", "p_sort_column" "text", "p_sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: search_v2("text", "text", integer, integer, "text", "text", "text", "text"); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer DEFAULT 100, "levels" integer DEFAULT 1, "start_after" "text" DEFAULT ''::"text", "sort_order" "text" DEFAULT 'asc'::"text", "sort_column" "text" DEFAULT 'name'::"text", "sort_column_after" "text" DEFAULT ''::"text") RETURNS TABLE("key" "text", "name" "text", "id" "uuid", "updated_at" timestamp with time zone, "created_at" timestamp with time zone, "last_accessed_at" timestamp with time zone, "metadata" "jsonb")
    LANGUAGE "plpgsql" STABLE
    AS $$
DECLARE
    v_sort_col text;
    v_sort_ord text;
    v_limit int;
BEGIN
    -- Cap limit to maximum of 1500 records
    v_limit := LEAST(coalesce(limits, 100), 1500);

    -- Validate and normalize sort_order
    v_sort_ord := lower(coalesce(sort_order, 'asc'));
    IF v_sort_ord NOT IN ('asc', 'desc') THEN
        v_sort_ord := 'asc';
    END IF;

    -- Validate and normalize sort_column
    v_sort_col := lower(coalesce(sort_column, 'name'));
    IF v_sort_col NOT IN ('name', 'updated_at', 'created_at') THEN
        v_sort_col := 'name';
    END IF;

    -- Route to appropriate implementation
    IF v_sort_col = 'name' THEN
        -- Use list_objects_with_delimiter for name sorting (most efficient: O(k * log n))
        RETURN QUERY
        SELECT
            split_part(l.name, '/', levels) AS key,
            l.name AS name,
            l.id,
            l.updated_at,
            l.created_at,
            l.last_accessed_at,
            l.metadata
        FROM storage.list_objects_with_delimiter(
            bucket_name,
            coalesce(prefix, ''),
            '/',
            v_limit,
            start_after,
            '',
            v_sort_ord
        ) l;
    ELSE
        -- Use aggregation approach for timestamp sorting
        -- Not efficient for large datasets but supports correct pagination
        RETURN QUERY SELECT * FROM storage.search_by_timestamp(
            prefix, bucket_name, v_limit, levels, start_after,
            v_sort_ord, v_sort_col, sort_column_after
        );
    END IF;
END;
$$;


ALTER FUNCTION "storage"."search_v2"("prefix" "text", "bucket_name" "text", "limits" integer, "levels" integer, "start_after" "text", "sort_order" "text", "sort_column" "text", "sort_column_after" "text") OWNER TO "supabase_storage_admin";

--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: supabase_storage_admin
--

CREATE FUNCTION "storage"."update_updated_at_column"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


ALTER FUNCTION "storage"."update_updated_at_column"() OWNER TO "supabase_storage_admin";

SET default_tablespace = '';

SET default_table_access_method = "heap";

--
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."audit_log_entries" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "payload" json,
    "created_at" timestamp with time zone,
    "ip_address" character varying(64) DEFAULT ''::character varying NOT NULL
);


ALTER TABLE "auth"."audit_log_entries" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "audit_log_entries"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."audit_log_entries" IS 'Auth: Audit trail for user actions.';


--
-- Name: custom_oauth_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."custom_oauth_providers" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "provider_type" "text" NOT NULL,
    "identifier" "text" NOT NULL,
    "name" "text" NOT NULL,
    "client_id" "text" NOT NULL,
    "client_secret" "text" NOT NULL,
    "acceptable_client_ids" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "scopes" "text"[] DEFAULT '{}'::"text"[] NOT NULL,
    "pkce_enabled" boolean DEFAULT true NOT NULL,
    "attribute_mapping" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "authorization_params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "enabled" boolean DEFAULT true NOT NULL,
    "email_optional" boolean DEFAULT false NOT NULL,
    "issuer" "text",
    "discovery_url" "text",
    "skip_nonce_check" boolean DEFAULT false NOT NULL,
    "cached_discovery" "jsonb",
    "discovery_cached_at" timestamp with time zone,
    "authorization_url" "text",
    "token_url" "text",
    "userinfo_url" "text",
    "jwks_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "custom_oauth_providers_authorization_url_https" CHECK ((("authorization_url" IS NULL) OR ("authorization_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_authorization_url_length" CHECK ((("authorization_url" IS NULL) OR ("char_length"("authorization_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_client_id_length" CHECK ((("char_length"("client_id") >= 1) AND ("char_length"("client_id") <= 512))),
    CONSTRAINT "custom_oauth_providers_discovery_url_length" CHECK ((("discovery_url" IS NULL) OR ("char_length"("discovery_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_identifier_format" CHECK (("identifier" ~ '^[a-z0-9][a-z0-9:-]{0,48}[a-z0-9]$'::"text")),
    CONSTRAINT "custom_oauth_providers_issuer_length" CHECK ((("issuer" IS NULL) OR (("char_length"("issuer") >= 1) AND ("char_length"("issuer") <= 2048)))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_https" CHECK ((("jwks_uri" IS NULL) OR ("jwks_uri" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_jwks_uri_length" CHECK ((("jwks_uri" IS NULL) OR ("char_length"("jwks_uri") <= 2048))),
    CONSTRAINT "custom_oauth_providers_name_length" CHECK ((("char_length"("name") >= 1) AND ("char_length"("name") <= 100))),
    CONSTRAINT "custom_oauth_providers_oauth2_requires_endpoints" CHECK ((("provider_type" <> 'oauth2'::"text") OR (("authorization_url" IS NOT NULL) AND ("token_url" IS NOT NULL) AND ("userinfo_url" IS NOT NULL)))),
    CONSTRAINT "custom_oauth_providers_oidc_discovery_url_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("discovery_url" IS NULL) OR ("discovery_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_issuer_https" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NULL) OR ("issuer" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_oidc_requires_issuer" CHECK ((("provider_type" <> 'oidc'::"text") OR ("issuer" IS NOT NULL))),
    CONSTRAINT "custom_oauth_providers_provider_type_check" CHECK (("provider_type" = ANY (ARRAY['oauth2'::"text", 'oidc'::"text"]))),
    CONSTRAINT "custom_oauth_providers_token_url_https" CHECK ((("token_url" IS NULL) OR ("token_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_token_url_length" CHECK ((("token_url" IS NULL) OR ("char_length"("token_url") <= 2048))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_https" CHECK ((("userinfo_url" IS NULL) OR ("userinfo_url" ~~ 'https://%'::"text"))),
    CONSTRAINT "custom_oauth_providers_userinfo_url_length" CHECK ((("userinfo_url" IS NULL) OR ("char_length"("userinfo_url") <= 2048)))
);


ALTER TABLE "auth"."custom_oauth_providers" OWNER TO "supabase_auth_admin";

--
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."flow_state" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid",
    "auth_code" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "code_challenge" "text",
    "provider_type" "text" NOT NULL,
    "provider_access_token" "text",
    "provider_refresh_token" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "authentication_method" "text" NOT NULL,
    "auth_code_issued_at" timestamp with time zone,
    "invite_token" "text",
    "referrer" "text",
    "oauth_client_state_id" "uuid",
    "linking_target_id" "uuid",
    "email_optional" boolean DEFAULT false NOT NULL
);


ALTER TABLE "auth"."flow_state" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "flow_state"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."flow_state" IS 'Stores metadata for all OAuth/SSO login flows';


--
-- Name: identities; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."identities" (
    "provider_id" "text" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "identity_data" "jsonb" NOT NULL,
    "provider" "text" NOT NULL,
    "last_sign_in_at" timestamp with time zone,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "email" "text" GENERATED ALWAYS AS ("lower"(("identity_data" ->> 'email'::"text"))) STORED,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "auth"."identities" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "identities"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."identities" IS 'Auth: Stores identities associated to a user.';


--
-- Name: COLUMN "identities"."email"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."identities"."email" IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- Name: instances; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."instances" (
    "id" "uuid" NOT NULL,
    "uuid" "uuid",
    "raw_base_config" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone
);


ALTER TABLE "auth"."instances" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "instances"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."instances" IS 'Auth: Manages users across multiple sites.';


--
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_amr_claims" (
    "session_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "authentication_method" "text" NOT NULL,
    "id" "uuid" NOT NULL
);


ALTER TABLE "auth"."mfa_amr_claims" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_amr_claims"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_amr_claims" IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_challenges" (
    "id" "uuid" NOT NULL,
    "factor_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "verified_at" timestamp with time zone,
    "ip_address" "inet" NOT NULL,
    "otp_code" "text",
    "web_authn_session_data" "jsonb"
);


ALTER TABLE "auth"."mfa_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_challenges"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_challenges" IS 'auth: stores metadata about challenge requests made';


--
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."mfa_factors" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "friendly_name" "text",
    "factor_type" "auth"."factor_type" NOT NULL,
    "status" "auth"."factor_status" NOT NULL,
    "created_at" timestamp with time zone NOT NULL,
    "updated_at" timestamp with time zone NOT NULL,
    "secret" "text",
    "phone" "text",
    "last_challenged_at" timestamp with time zone,
    "web_authn_credential" "jsonb",
    "web_authn_aaguid" "uuid",
    "last_webauthn_challenge_data" "jsonb"
);


ALTER TABLE "auth"."mfa_factors" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "mfa_factors"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."mfa_factors" IS 'auth: stores metadata about factors';


--
-- Name: COLUMN "mfa_factors"."last_webauthn_challenge_data"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."mfa_factors"."last_webauthn_challenge_data" IS 'Stores the latest WebAuthn challenge data including attestation/assertion for customer verification';


--
-- Name: oauth_authorizations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_authorizations" (
    "id" "uuid" NOT NULL,
    "authorization_id" "text" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "user_id" "uuid",
    "redirect_uri" "text" NOT NULL,
    "scope" "text" NOT NULL,
    "state" "text",
    "resource" "text",
    "code_challenge" "text",
    "code_challenge_method" "auth"."code_challenge_method",
    "response_type" "auth"."oauth_response_type" DEFAULT 'code'::"auth"."oauth_response_type" NOT NULL,
    "status" "auth"."oauth_authorization_status" DEFAULT 'pending'::"auth"."oauth_authorization_status" NOT NULL,
    "authorization_code" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '00:03:00'::interval) NOT NULL,
    "approved_at" timestamp with time zone,
    "nonce" "text",
    CONSTRAINT "oauth_authorizations_authorization_code_length" CHECK (("char_length"("authorization_code") <= 255)),
    CONSTRAINT "oauth_authorizations_code_challenge_length" CHECK (("char_length"("code_challenge") <= 128)),
    CONSTRAINT "oauth_authorizations_expires_at_future" CHECK (("expires_at" > "created_at")),
    CONSTRAINT "oauth_authorizations_nonce_length" CHECK (("char_length"("nonce") <= 255)),
    CONSTRAINT "oauth_authorizations_redirect_uri_length" CHECK (("char_length"("redirect_uri") <= 2048)),
    CONSTRAINT "oauth_authorizations_resource_length" CHECK (("char_length"("resource") <= 2048)),
    CONSTRAINT "oauth_authorizations_scope_length" CHECK (("char_length"("scope") <= 4096)),
    CONSTRAINT "oauth_authorizations_state_length" CHECK (("char_length"("state") <= 4096))
);


ALTER TABLE "auth"."oauth_authorizations" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_client_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_client_states" (
    "id" "uuid" NOT NULL,
    "provider_type" "text" NOT NULL,
    "code_verifier" "text",
    "created_at" timestamp with time zone NOT NULL
);


ALTER TABLE "auth"."oauth_client_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "oauth_client_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."oauth_client_states" IS 'Stores OAuth states for third-party provider authentication flows where Supabase acts as the OAuth client.';


--
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_clients" (
    "id" "uuid" NOT NULL,
    "client_secret_hash" "text",
    "registration_type" "auth"."oauth_registration_type" NOT NULL,
    "redirect_uris" "text" NOT NULL,
    "grant_types" "text" NOT NULL,
    "client_name" "text",
    "client_uri" "text",
    "logo_uri" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "deleted_at" timestamp with time zone,
    "client_type" "auth"."oauth_client_type" DEFAULT 'confidential'::"auth"."oauth_client_type" NOT NULL,
    "token_endpoint_auth_method" "text" NOT NULL,
    CONSTRAINT "oauth_clients_client_name_length" CHECK (("char_length"("client_name") <= 1024)),
    CONSTRAINT "oauth_clients_client_uri_length" CHECK (("char_length"("client_uri") <= 2048)),
    CONSTRAINT "oauth_clients_logo_uri_length" CHECK (("char_length"("logo_uri") <= 2048)),
    CONSTRAINT "oauth_clients_token_endpoint_auth_method_check" CHECK (("token_endpoint_auth_method" = ANY (ARRAY['client_secret_basic'::"text", 'client_secret_post'::"text", 'none'::"text"])))
);


ALTER TABLE "auth"."oauth_clients" OWNER TO "supabase_auth_admin";

--
-- Name: oauth_consents; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."oauth_consents" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "client_id" "uuid" NOT NULL,
    "scopes" "text" NOT NULL,
    "granted_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "revoked_at" timestamp with time zone,
    CONSTRAINT "oauth_consents_revoked_after_granted" CHECK ((("revoked_at" IS NULL) OR ("revoked_at" >= "granted_at"))),
    CONSTRAINT "oauth_consents_scopes_length" CHECK (("char_length"("scopes") <= 2048)),
    CONSTRAINT "oauth_consents_scopes_not_empty" CHECK (("char_length"(TRIM(BOTH FROM "scopes")) > 0))
);


ALTER TABLE "auth"."oauth_consents" OWNER TO "supabase_auth_admin";

--
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."one_time_tokens" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "token_type" "auth"."one_time_token_type" NOT NULL,
    "token_hash" "text" NOT NULL,
    "relates_to" "text" NOT NULL,
    "created_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "one_time_tokens_token_hash_check" CHECK (("char_length"("token_hash") > 0))
);


ALTER TABLE "auth"."one_time_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."refresh_tokens" (
    "instance_id" "uuid",
    "id" bigint NOT NULL,
    "token" character varying(255),
    "user_id" character varying(255),
    "revoked" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "parent" character varying(255),
    "session_id" "uuid"
);


ALTER TABLE "auth"."refresh_tokens" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "refresh_tokens"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."refresh_tokens" IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: supabase_auth_admin
--

CREATE SEQUENCE "auth"."refresh_tokens_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNER TO "supabase_auth_admin";

--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: supabase_auth_admin
--

ALTER SEQUENCE "auth"."refresh_tokens_id_seq" OWNED BY "auth"."refresh_tokens"."id";


--
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_providers" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "entity_id" "text" NOT NULL,
    "metadata_xml" "text" NOT NULL,
    "metadata_url" "text",
    "attribute_mapping" "jsonb",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "name_id_format" "text",
    CONSTRAINT "entity_id not empty" CHECK (("char_length"("entity_id") > 0)),
    CONSTRAINT "metadata_url not empty" CHECK ((("metadata_url" = NULL::"text") OR ("char_length"("metadata_url") > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK (("char_length"("metadata_xml") > 0))
);


ALTER TABLE "auth"."saml_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_providers" IS 'Auth: Manages SAML Identity Provider connections.';


--
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."saml_relay_states" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "request_id" "text" NOT NULL,
    "for_email" "text",
    "redirect_to" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "flow_state_id" "uuid",
    CONSTRAINT "request_id not empty" CHECK (("char_length"("request_id") > 0))
);


ALTER TABLE "auth"."saml_relay_states" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "saml_relay_states"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."saml_relay_states" IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."schema_migrations" (
    "version" character varying(255) NOT NULL
);


ALTER TABLE "auth"."schema_migrations" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "schema_migrations"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."schema_migrations" IS 'Auth: Manages updates to the auth system.';


--
-- Name: sessions; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sessions" (
    "id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "factor_id" "uuid",
    "aal" "auth"."aal_level",
    "not_after" timestamp with time zone,
    "refreshed_at" timestamp without time zone,
    "user_agent" "text",
    "ip" "inet",
    "tag" "text",
    "oauth_client_id" "uuid",
    "refresh_token_hmac_key" "text",
    "refresh_token_counter" bigint,
    "scopes" "text",
    CONSTRAINT "sessions_scopes_length" CHECK (("char_length"("scopes") <= 4096))
);


ALTER TABLE "auth"."sessions" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sessions"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sessions" IS 'Auth: Stores session data associated to a user.';


--
-- Name: COLUMN "sessions"."not_after"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."not_after" IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- Name: COLUMN "sessions"."refresh_token_hmac_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_hmac_key" IS 'Holds a HMAC-SHA256 key used to sign refresh tokens for this session.';


--
-- Name: COLUMN "sessions"."refresh_token_counter"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sessions"."refresh_token_counter" IS 'Holds the ID (counter) of the last issued refresh token.';


--
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_domains" (
    "id" "uuid" NOT NULL,
    "sso_provider_id" "uuid" NOT NULL,
    "domain" "text" NOT NULL,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK (("char_length"("domain") > 0))
);


ALTER TABLE "auth"."sso_domains" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_domains"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_domains" IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."sso_providers" (
    "id" "uuid" NOT NULL,
    "resource_id" "text",
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "disabled" boolean,
    CONSTRAINT "resource_id not empty" CHECK ((("resource_id" = NULL::"text") OR ("char_length"("resource_id") > 0)))
);


ALTER TABLE "auth"."sso_providers" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "sso_providers"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."sso_providers" IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- Name: COLUMN "sso_providers"."resource_id"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."sso_providers"."resource_id" IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- Name: users; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."users" (
    "instance_id" "uuid",
    "id" "uuid" NOT NULL,
    "aud" character varying(255),
    "role" character varying(255),
    "email" character varying(255),
    "encrypted_password" character varying(255),
    "email_confirmed_at" timestamp with time zone,
    "invited_at" timestamp with time zone,
    "confirmation_token" character varying(255),
    "confirmation_sent_at" timestamp with time zone,
    "recovery_token" character varying(255),
    "recovery_sent_at" timestamp with time zone,
    "email_change_token_new" character varying(255),
    "email_change" character varying(255),
    "email_change_sent_at" timestamp with time zone,
    "last_sign_in_at" timestamp with time zone,
    "raw_app_meta_data" "jsonb",
    "raw_user_meta_data" "jsonb",
    "is_super_admin" boolean,
    "created_at" timestamp with time zone,
    "updated_at" timestamp with time zone,
    "phone" "text" DEFAULT NULL::character varying,
    "phone_confirmed_at" timestamp with time zone,
    "phone_change" "text" DEFAULT ''::character varying,
    "phone_change_token" character varying(255) DEFAULT ''::character varying,
    "phone_change_sent_at" timestamp with time zone,
    "confirmed_at" timestamp with time zone GENERATED ALWAYS AS (LEAST("email_confirmed_at", "phone_confirmed_at")) STORED,
    "email_change_token_current" character varying(255) DEFAULT ''::character varying,
    "email_change_confirm_status" smallint DEFAULT 0,
    "banned_until" timestamp with time zone,
    "reauthentication_token" character varying(255) DEFAULT ''::character varying,
    "reauthentication_sent_at" timestamp with time zone,
    "is_sso_user" boolean DEFAULT false NOT NULL,
    "deleted_at" timestamp with time zone,
    "is_anonymous" boolean DEFAULT false NOT NULL,
    CONSTRAINT "users_email_change_confirm_status_check" CHECK ((("email_change_confirm_status" >= 0) AND ("email_change_confirm_status" <= 2)))
);


ALTER TABLE "auth"."users" OWNER TO "supabase_auth_admin";

--
-- Name: TABLE "users"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON TABLE "auth"."users" IS 'Auth: Stores user login data within a secure schema.';


--
-- Name: COLUMN "users"."is_sso_user"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON COLUMN "auth"."users"."is_sso_user" IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- Name: webauthn_challenges; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_challenges" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid",
    "challenge_type" "text" NOT NULL,
    "session_data" "jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone NOT NULL,
    CONSTRAINT "webauthn_challenges_challenge_type_check" CHECK (("challenge_type" = ANY (ARRAY['signup'::"text", 'registration'::"text", 'authentication'::"text"])))
);


ALTER TABLE "auth"."webauthn_challenges" OWNER TO "supabase_auth_admin";

--
-- Name: webauthn_credentials; Type: TABLE; Schema: auth; Owner: supabase_auth_admin
--

CREATE TABLE "auth"."webauthn_credentials" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "credential_id" "bytea" NOT NULL,
    "public_key" "bytea" NOT NULL,
    "attestation_type" "text" DEFAULT ''::"text" NOT NULL,
    "aaguid" "uuid",
    "sign_count" bigint DEFAULT 0 NOT NULL,
    "transports" "jsonb" DEFAULT '[]'::"jsonb" NOT NULL,
    "backup_eligible" boolean DEFAULT false NOT NULL,
    "backed_up" boolean DEFAULT false NOT NULL,
    "friendly_name" "text" DEFAULT ''::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "last_used_at" timestamp with time zone
);


ALTER TABLE "auth"."webauthn_credentials" OWNER TO "supabase_auth_admin";

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."activity_logs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "username" "text" NOT NULL,
    "full_name" "text" NOT NULL,
    "tab_name" "text" NOT NULL,
    "table_name" "text" NOT NULL,
    "action_type" "text" NOT NULL,
    "description" "text" NOT NULL,
    "old_data" "jsonb",
    "new_data" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."activity_logs" OWNER TO "postgres";

--
-- Name: chamdiem; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."chamdiem" (
    "id" "text" DEFAULT ("gen_random_uuid"())::"text" NOT NULL,
    "namhoc" "text",
    "hocky" "text",
    "tuan" "text",
    "thu" "text",
    "ngay" "text",
    "lopcham" "text",
    "chamlop" "text",
    "doanvienid" "text",
    "hotendoanvien" "text",
    "matieuchi" "text",
    "tentieuchi" "text",
    "loaitieuchi" "text",
    "diemtru" numeric DEFAULT 0,
    "diemcong" numeric DEFAULT 0,
    "ghichu" "text",
    "nguoicham" "text",
    "updatedat" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."chamdiem" OWNER TO "postgres";

--
-- Name: doanvien; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."doanvien" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hoTen" "text" NOT NULL,
    "ngaySinh" "text",
    "gioiTinh" "text",
    "danToc" "text",
    "doiTuong" "text",
    "doanVien" boolean DEFAULT false,
    "chiDoan" "text" NOT NULL,
    "ngayVaoDoan" "text",
    "sdt" "text",
    "thongTinThem" "text",
    "updatedAt" timestamp with time zone DEFAULT "now"(),
    "namHoc" "text",
    "hocKy" "text",
    "diaChi" "text"
);


ALTER TABLE "public"."doanvien" OWNER TO "postgres";

--
-- Name: namhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."namhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenNamHoc" "text" NOT NULL,
    "tenHocKy" "text" NOT NULL,
    "isDefault" boolean DEFAULT false,
    "isLocked" boolean DEFAULT false,
    "updatedAt" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."namhoc" OWNER TO "postgres";

--
-- Name: phancong; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phancong" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "hocKy" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "lopCham" "text" NOT NULL,
    "chamLop" "text" NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT "now"(),
    "namHoc" "text"
);


ALTER TABLE "public"."phancong" OWNER TO "postgres";

--
-- Name: phanquyen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."phanquyen" (
    "id" bigint NOT NULL,
    "doi_tuong" character varying(50) NOT NULL,
    "tab_chuc_nang" character varying(100) NOT NULL,
    "quyen_xem" boolean DEFAULT false,
    "quyen_them" boolean DEFAULT false,
    "quyen_sua" boolean DEFAULT false,
    "quyen_xoa" boolean DEFAULT false,
    "quyen_chi_doan_phu_trach" boolean DEFAULT false,
    "ngay_cap_nhat" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "nam_hoc" "text",
    "quyen_xem_tat_ca_chi_doan" boolean DEFAULT false
);


ALTER TABLE "public"."phanquyen" OWNER TO "postgres";

--
-- Name: TABLE "phanquyen"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE "public"."phanquyen" IS 'Bảng cấu hình phân quyền động cho hệ thống';


--
-- Name: COLUMN "phanquyen"."doi_tuong"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."doi_tuong" IS 'Vai trò của người dùng (Admin, BTV, BCH, BT, DV)';


--
-- Name: COLUMN "phanquyen"."tab_chuc_nang"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."tab_chuc_nang" IS 'Mã tab chức năng trên giao diện';


--
-- Name: COLUMN "phanquyen"."quyen_chi_doan_phu_trach"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "public"."phanquyen"."quyen_chi_doan_phu_trach" IS 'Giới hạn phạm vi dữ liệu chỉ trong chi đoàn của user';


--
-- Name: phanquyen_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phanquyen" ALTER COLUMN "id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."phanquyen_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: qlchidoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."qlchidoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "tenchidoan" "text" NOT NULL,
    "buoiHoc" "text",
    "ban" "text",
    "doanvien" integer DEFAULT 0,
    "thanhnien" integer DEFAULT 0,
    "tongso" integer DEFAULT 0,
    "phonghoc" "text",
    "bithu" "text",
    "thongtinthem" "text",
    "namHoc" "text" NOT NULL,
    "updatedAt" timestamp with time zone DEFAULT "now"(),
    "hocKy" "text"
);


ALTER TABLE "public"."qlchidoan" OWNER TO "postgres";

--
-- Name: settings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."settings" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "title1" "text",
    "title2" "text",
    "diemSan" numeric,
    "aiPromptTemplate" "text",
    "geminiapikey" "text",
    "backupinterval" integer DEFAULT 0,
    "lastbackupat" "text"
);


ALTER TABLE "public"."settings" OWNER TO "postgres";

--
-- Name: taikhoan; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."taikhoan" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "username" "text" NOT NULL,
    "password" "text" NOT NULL,
    "fullName" "text" NOT NULL,
    "role" "text" NOT NULL,
    "chiDoan" "text",
    "updatedAt" timestamp with time zone DEFAULT "now"(),
    "namHoc" "text"
);


ALTER TABLE "public"."taikhoan" OWNER TO "postgres";

--
-- Name: tieuchitd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tieuchitd" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "maTieuChi" "text" NOT NULL,
    "tenTieuChi" "text" NOT NULL,
    "moTa" "text",
    "loaiTieuChi" "text",
    "diemTru" numeric DEFAULT 0,
    "diemCong" numeric DEFAULT 0,
    "ghiChu" "text",
    "updatedAt" timestamp with time zone DEFAULT "now"(),
    "hocKy" "text",
    "namHoc" "text"
);


ALTER TABLE "public"."tieuchitd" OWNER TO "postgres";

--
-- Name: tuanhoc; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "public"."tuanhoc" (
    "id" "uuid" DEFAULT "extensions"."uuid_generate_v4"() NOT NULL,
    "namHoc" "text" NOT NULL,
    "hocKy" "text" NOT NULL,
    "tuan" "text" NOT NULL,
    "tuNgay" "text",
    "denNgay" "text",
    "isDefault" boolean DEFAULT false,
    "isLocked" boolean DEFAULT false,
    "updatedAt" timestamp with time zone DEFAULT "now"()
);


ALTER TABLE "public"."tuanhoc" OWNER TO "postgres";

--
-- Name: messages; Type: TABLE; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE TABLE "realtime"."messages" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
)
PARTITION BY RANGE ("inserted_at");


ALTER TABLE "realtime"."messages" OWNER TO "supabase_realtime_admin";

--
-- Name: messages_2026_03_28; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_03_28" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_03_28" OWNER TO "supabase_admin";

--
-- Name: messages_2026_03_29; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_03_29" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_03_29" OWNER TO "supabase_admin";

--
-- Name: messages_2026_03_30; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_03_30" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_03_30" OWNER TO "supabase_admin";

--
-- Name: messages_2026_03_31; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_03_31" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_03_31" OWNER TO "supabase_admin";

--
-- Name: messages_2026_04_01; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_04_01" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_04_01" OWNER TO "supabase_admin";

--
-- Name: messages_2026_04_02; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_04_02" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_04_02" OWNER TO "supabase_admin";

--
-- Name: messages_2026_04_03; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."messages_2026_04_03" (
    "topic" "text" NOT NULL,
    "extension" "text" NOT NULL,
    "payload" "jsonb",
    "event" "text",
    "private" boolean DEFAULT false,
    "updated_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "inserted_at" timestamp without time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL
);


ALTER TABLE "realtime"."messages_2026_04_03" OWNER TO "supabase_admin";

--
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."schema_migrations" (
    "version" bigint NOT NULL,
    "inserted_at" timestamp(0) without time zone
);


ALTER TABLE "realtime"."schema_migrations" OWNER TO "supabase_admin";

--
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: supabase_admin
--

CREATE TABLE "realtime"."subscription" (
    "id" bigint NOT NULL,
    "subscription_id" "uuid" NOT NULL,
    "entity" "regclass" NOT NULL,
    "filters" "realtime"."user_defined_filter"[] DEFAULT '{}'::"realtime"."user_defined_filter"[] NOT NULL,
    "claims" "jsonb" NOT NULL,
    "claims_role" "regrole" GENERATED ALWAYS AS ("realtime"."to_regrole"(("claims" ->> 'role'::"text"))) STORED NOT NULL,
    "created_at" timestamp without time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "action_filter" "text" DEFAULT '*'::"text",
    CONSTRAINT "subscription_action_filter_check" CHECK (("action_filter" = ANY (ARRAY['*'::"text", 'INSERT'::"text", 'UPDATE'::"text", 'DELETE'::"text"])))
);


ALTER TABLE "realtime"."subscription" OWNER TO "supabase_admin";

--
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE "realtime"."subscription" ALTER COLUMN "id" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME "realtime"."subscription_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: buckets; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets" (
    "id" "text" NOT NULL,
    "name" "text" NOT NULL,
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "public" boolean DEFAULT false,
    "avif_autodetection" boolean DEFAULT false,
    "file_size_limit" bigint,
    "allowed_mime_types" "text"[],
    "owner_id" "text",
    "type" "storage"."buckettype" DEFAULT 'STANDARD'::"storage"."buckettype" NOT NULL
);


ALTER TABLE "storage"."buckets" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "buckets"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."buckets"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_analytics" (
    "name" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'ANALYTICS'::"storage"."buckettype" NOT NULL,
    "format" "text" DEFAULT 'ICEBERG'::"text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "deleted_at" timestamp with time zone
);


ALTER TABLE "storage"."buckets_analytics" OWNER TO "supabase_storage_admin";

--
-- Name: buckets_vectors; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."buckets_vectors" (
    "id" "text" NOT NULL,
    "type" "storage"."buckettype" DEFAULT 'VECTOR'::"storage"."buckettype" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."buckets_vectors" OWNER TO "supabase_storage_admin";

--
-- Name: migrations; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."migrations" (
    "id" integer NOT NULL,
    "name" character varying(100) NOT NULL,
    "hash" character varying(40) NOT NULL,
    "executed_at" timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE "storage"."migrations" OWNER TO "supabase_storage_admin";

--
-- Name: objects; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."objects" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "bucket_id" "text",
    "name" "text",
    "owner" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"(),
    "updated_at" timestamp with time zone DEFAULT "now"(),
    "last_accessed_at" timestamp with time zone DEFAULT "now"(),
    "metadata" "jsonb",
    "path_tokens" "text"[] GENERATED ALWAYS AS ("string_to_array"("name", '/'::"text")) STORED,
    "version" "text",
    "owner_id" "text",
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."objects" OWNER TO "supabase_storage_admin";

--
-- Name: COLUMN "objects"."owner"; Type: COMMENT; Schema: storage; Owner: supabase_storage_admin
--

COMMENT ON COLUMN "storage"."objects"."owner" IS 'Field is deprecated, use owner_id instead';


--
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads" (
    "id" "text" NOT NULL,
    "in_progress_size" bigint DEFAULT 0 NOT NULL,
    "upload_signature" "text" NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "version" "text" NOT NULL,
    "owner_id" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "user_metadata" "jsonb"
);


ALTER TABLE "storage"."s3_multipart_uploads" OWNER TO "supabase_storage_admin";

--
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."s3_multipart_uploads_parts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "upload_id" "text" NOT NULL,
    "size" bigint DEFAULT 0 NOT NULL,
    "part_number" integer NOT NULL,
    "bucket_id" "text" NOT NULL,
    "key" "text" NOT NULL COLLATE "pg_catalog"."C",
    "etag" "text" NOT NULL,
    "owner_id" "text",
    "version" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."s3_multipart_uploads_parts" OWNER TO "supabase_storage_admin";

--
-- Name: vector_indexes; Type: TABLE; Schema: storage; Owner: supabase_storage_admin
--

CREATE TABLE "storage"."vector_indexes" (
    "id" "text" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL COLLATE "pg_catalog"."C",
    "bucket_id" "text" NOT NULL,
    "data_type" "text" NOT NULL,
    "dimension" integer NOT NULL,
    "distance_metric" "text" NOT NULL,
    "metadata_configuration" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "storage"."vector_indexes" OWNER TO "supabase_storage_admin";

--
-- Name: messages_2026_03_28; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_03_28" FOR VALUES FROM ('2026-03-28 00:00:00') TO ('2026-03-29 00:00:00');


--
-- Name: messages_2026_03_29; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_03_29" FOR VALUES FROM ('2026-03-29 00:00:00') TO ('2026-03-30 00:00:00');


--
-- Name: messages_2026_03_30; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_03_30" FOR VALUES FROM ('2026-03-30 00:00:00') TO ('2026-03-31 00:00:00');


--
-- Name: messages_2026_03_31; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_03_31" FOR VALUES FROM ('2026-03-31 00:00:00') TO ('2026-04-01 00:00:00');


--
-- Name: messages_2026_04_01; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_04_01" FOR VALUES FROM ('2026-04-01 00:00:00') TO ('2026-04-02 00:00:00');


--
-- Name: messages_2026_04_02; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_04_02" FOR VALUES FROM ('2026-04-02 00:00:00') TO ('2026-04-03 00:00:00');


--
-- Name: messages_2026_04_03; Type: TABLE ATTACH; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages" ATTACH PARTITION "realtime"."messages_2026_04_03" FOR VALUES FROM ('2026-04-03 00:00:00') TO ('2026-04-04 00:00:00');


--
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens" ALTER COLUMN "id" SET DEFAULT "nextval"('"auth"."refresh_tokens_id_seq"'::"regclass");


--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."schema_migrations" ("version") FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
20250804100000
20250901200500
20250903112500
20250904133000
20250925093508
20251007112900
20251104100000
20251111201300
20251201000000
20260115000000
20260121000000
20260219120000
20260302000000
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."activity_logs" ("id", "user_id", "username", "full_name", "tab_name", "table_name", "action_type", "description", "old_data", "new_data", "created_at") FROM stdin;
\.


--
-- Data for Name: chamdiem; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."chamdiem" ("id", "namhoc", "hocky", "tuan", "thu", "ngay", "lopcham", "chamlop", "doanvienid", "hotendoanvien", "matieuchi", "tentieuchi", "loaitieuchi", "diemtru", "diemcong", "ghichu", "nguoicham", "updatedat") FROM stdin;
da7d25ca-e9df-4674-aeec-587ece13e1cc	2025-2026	HK2	27	Thứ 4	2026-03-23	10A2	11C2	a6c87c09-4491-4694-8fc1-5d40824e661b	Trần Gia Phát	TC46	Mang ĐT lên trường	Vi phạm	30	0	Sử dụng Đt trong thi GHK2, bị lập BB	Hồ Hữu Thế - QT	2026-03-26 06:55:25.552+00
de674f67-a13e-4c17-b869-aaba3facbdbc	2025-2026	HK2	27	Thứ 4	2026-03-23	11C6	12B4	ebbd3731-9f01-47ca-bb5f-4993539aa4ca	Mai Thị Yến Nhi	TC46	Mang ĐT lên trường	Vi phạm	30	0	Sử dụng Đt trong thi GHK2, bị lập BB	Hồ Hữu Thế - QT	2026-03-26 06:55:36.173+00
75c7ca9c-f9b3-4887-bc14-fd56073c36b4	2025-2026	HK2	27	Thứ 4	2026-03-23	10A2	11C2	2ad8ba7d-2776-48e7-9f12-473d1b0932d4	Trần Nguyên Tuấn	TC46	Mang ĐT lên trường	Vi phạm	30	0	Sử dụng Đt trong thi GHK2, bị lập BB	Hồ Hữu Thế - QT	2026-03-26 06:56:05.42+00
db7aa269-4586-497e-909d-33b20b1eae5a	2025-2026	HK2	27	Thứ 5	2026-03-26	11C1	10A7	141be337-7bb7-4d92-bd8e-21330ef7702f	Tập thể 10A7	TC39	Lớp không tham gia trực 15p	Vi phạm	2	0		Hồ Hữu Thế - QT	2026-03-26 07:08:13.769+00
ec0d29af-35ed-49f2-9c55-d91fc903ac6f	2025-2026	HK2	27	Thứ 5	2026-03-26	10A10	10A5	65560ab5-035b-496a-9133-a50d9bf0a0d0	Tập thể 10A5	TC40	Đi chấm trễ	Vi phạm	2	0		10A10	2026-03-26 12:10:19.954+00
27771fd0-6c42-45ff-8a18-a476ca2eb682	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	6f06a0f9-d009-4090-8049-dc32c3f3a07c	Phạm Thị Như Ngọc	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:20:47.704+00
22c93242-0cd3-4bb2-8d1b-cd9f4723542f	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	d9ba578d-620d-440e-a811-ae60582078e9	Phan Quốc Vương	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:21:09.209+00
d250fefb-85dc-4c56-8057-14ea3f355f8b	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	e5b57e59-0507-465e-84b6-01313157d8eb	Rơ Mah Kiệt	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:21:22.251+00
11dc33a1-1e5d-47b2-a9e5-d15c8cd7dd02	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	e9ec14d0-c297-4bc9-8c0f-cfc7ca120a70	Rơ Mah Xâm	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:21:38.645+00
6d44834d-1296-4214-b8c9-72b14d337589	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	c714c574-cb27-4cc8-ac81-f2da791c3816	Kpuih Trực	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:21:57.953+00
ac717b62-e63e-485b-a2d9-4da6cd7d602a	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	905ccb7f-b98f-459d-b287-6e1cebd633f0	Rơ Châm Thảo My	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:22:14.128+00
273ee24d-d49b-4e6a-86aa-6a80a5a0f3fc	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	bb25bc9d-8436-454d-8258-c55afeb98b01	Phạm Sỹ Hoàng Long	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:22:30.736+00
8da63b97-ab9e-4b04-b0e1-1034ed0b4143	2025-2026	HK2	27	Thứ 5	2026-03-26	11C4	10A10	702a03a5-1641-41ba-821f-7c0c4eb6e46b	Ngô Trí Quân	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-26 12:24:36.667+00
ae0561f5-049b-45a7-86b7-a5d3f7ff2f22	2025-2026	HK2	27	Thứ 5	2026-03-24	11C3	10A9	ce7b2908-1bb8-47d1-84ae-8d094b7f950c	Phan Đình Tùng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-26 13:16:46.87+00
83d23826-d720-4d31-a9d5-47714dfffb30	2025-2026	HK2	27	Thứ 5	2026-03-24	11C3	10A9	753fe8e5-5cbc-4e9c-9264-5b6f65ab1f3e	Rơ Lan Kim A	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-26 13:17:14.62+00
4e999d54-fcad-41d1-aed2-d6e77f95913c	2025-2026	HK2	27	Thứ 5	2026-03-24	11C3	10A9	8c9ecfb1-967c-453b-908e-6209993dcc3e	Rơ Lan H’ Nasi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-26 13:17:36.531+00
17c660d2-9b7a-48d5-b3d1-434d77811e85	2025-2026	HK2	1	Thứ 2	2026-03-16	11C1	11C6	69ab4b72-d5d5-4f65-913a-f6959db00247	Nguyễn Văn A 6	VP5	VP5	Vi phạm	5	0		Quản trị HT	2026-03-21 14:07:32.02+00
bca72607-cde3-4045-970f-c3fe444f1b74	2025-2026	HK2	1	Thứ 2	2026-03-16	11C6	11C1	3c6184c3-cbb8-4eb3-8ecf-f7899764f462	Nguyễn Văn A 1	VP7	VP7	Thành tích	0	5		Quản trị HT	2026-03-21 14:07:53.379+00
03f443dd-071f-468c-955d-6b459d53a287	2025-2026	HK2	27	Thứ 5	2026-03-26	11C1	10A7			TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C1	2026-03-26 06:35:42.936+00
f4099479-5f08-4cb4-a6e4-853633fa10b5	2025-2026	HK2	27	Thứ 4	2026-03-23	12B5	11C10	50517434-db92-4415-86fe-330f5067431d	Nguyễn Trọng Tâm	TC46	Mang ĐT lên trường	Vi phạm	30	0	Thi GHK2 mang Đt lên trường, bị mất	Hồ Hữu Thế - QT	2026-03-26 06:55:01.239+00
504029a5-4122-4c57-acbb-4fcd6f536047	2025-2026	HK2	27	Thứ 4	2026-03-23	12B2	11C7	de58d862-f04b-4552-a136-416efbac62b0	Cù Ngọc Sáng	TC46	Mang ĐT lên trường	Vi phạm	30	0	Sử dụng Đt trong thi GHK2, bị lập BB	Hồ Hữu Thế - QT	2026-03-26 06:55:07.495+00
54bc10dd-fa2f-425e-bbd9-d1851899706a	2025-2026	HK2	27	Thứ 4	2026-03-23	12B6	11C11	835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	TC46	Mang ĐT lên trường	Vi phạm	30	0	Thi GHK2 mang ĐT lên trường, bị mất	Hồ Hữu Thế - QT	2026-03-26 06:55:13.583+00
c1e6437d-0e0e-4f05-8051-50a35ee896c8	2025-2026	HK2	27	Thứ 5	2026-03-24	12B6	11C11	835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B6	2026-03-26 13:26:40.79+00
00d88623-c84d-428e-aa44-baa1070f5402	2025-2026	HK2	27	Thứ 5	2026-03-24	12B6	11C11	30a8b007-0db3-4a1d-a56c-713af0dd6f6d	Phạm Nguyễn Hoàng Linh	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B6	2026-03-26 13:27:22.324+00
8c9693ab-61f7-49a2-b548-8ff7c1aff377	2025-2026	HK2	27	Thứ 5	2026-03-24	12B6	11C11	bf28accd-a226-49f7-8715-c05bf8857353	Đậu Quang Thỏa Hiệp	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B6	2026-03-26 13:27:41.882+00
6785c5df-d070-4836-92bc-2b1f4480b97e	2025-2026	HK2	27	Thứ 5	2026-03-26	12B9	12B2	ac26f03f-6aa3-4169-886a-ecf60ff9cd07	Lê Thành Danh	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B9	2026-03-26 13:35:05.57+00
c4c3e01f-58c2-43d4-9ec8-316f1ecf5d14	2025-2026	HK2	27	Thứ 5	2026-03-25	10A1	11C1	fae31961-3ea6-4f8c-9889-99836f82663c	Phan Thị Yến	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A1	2026-03-26 14:06:23.711+00
10a1ba66-7e01-4143-a0ae-06f833aa888b	2025-2026	HK2	27	Thứ 5	2026-03-25	10A1	11C1	e11a1aa2-b221-4dcc-bb4e-baa788094843	Lê Thị Ánh Hồng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A1	2026-03-26 14:07:38.332+00
3f799552-c1b1-4ff9-b168-34199581cd66	2025-2026	HK2	27	Thứ 5	2026-03-25	10A1	11C1	561aebed-c038-4fad-92a5-6f41f830d9de	Nguyễn Thị Hoài Ân	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A1	2026-03-26 14:08:02.897+00
2dc42119-40f4-44d8-8ae0-bc2b9b8890a2	2025-2026	HK2	27	Thứ 5	2026-03-24	11C5	10A11	8b711101-381f-4ab5-82a1-f136830840c4	Rơ Lan A Khiển	TC08	Sai đồng phục	Vi phạm	5	0		11C5	2026-03-26 14:34:42.254+00
ce70776c-37e6-4676-acb7-4895359bffc5	2025-2026	HK2	27	Thứ 4	2026-03-23	11C5	10A11	46d7d6b2-ae19-4f9f-956a-8c35c52d6b84	Nguyễn Hữu Huy	TC28	Học sinh vứt rác không đúng qui định 	Vi phạm	10	0		11C5	2026-03-26 14:36:06.326+00
af147312-787e-4e25-a675-701193223813	2025-2026	HK2	27	Thứ 4	2026-03-23	11C5	10A11	53d800b8-60af-4182-803f-7c1df4727525	Bùi Sinh Thái	TC28	Học sinh vứt rác không đúng qui định 	Vi phạm	10	0		11C5	2026-03-26 14:39:00.403+00
5c456d58-89d4-4df1-99f5-6984ca1fea51	2025-2026	HK2	27	Thứ 4	2026-03-23	11C5	10A11	17a1717c-3d99-4605-aa90-835c2045326b	Lê Thế Quý	TC28	Học sinh vứt rác không đúng qui định 	Vi phạm	10	0		11C5	2026-03-26 14:39:31.034+00
f7f533d3-7f80-40b4-b443-5409f1ddedeb	2025-2026	HK2	27	Thứ 5	2026-03-26	12B10	12B3	7ff4fd75-482d-4ecd-a3c2-21f399e2c004	Nguyễn Hà Anh	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B10	2026-03-26 14:57:32.852+00
faec6fcb-eef5-4fc9-8057-f6fb6364ab7a	2025-2026	HK2	27	Thứ 5	2026-03-26	12B10	12B3	bf8ff2b8-31d1-4e45-88e4-2c5a5b64956e	Trần Minh Thư	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B10	2026-03-26 14:58:08.773+00
8e578592-8a73-4a88-9bd2-fa6ba1752f32	2025-2026	HK2	27	Thứ 5	2026-03-26	11C12	12B10	4e74b97f-7e2a-4e78-bdf6-3760ef88ac4e	Kpuih H' Diệu	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C12	2026-03-27 00:05:24.447+00
9563ede6-ad6e-4f98-bcfc-8f04a79e1977	2025-2026	HK2	27	Thứ 5	2026-03-26	11C12	12B10	7def4cfc-11ef-4778-a941-99d5a5000b60	Nguyễn Công Hiếu	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C12	2026-03-27 00:05:37.627+00
52daf655-aedf-445a-8e75-72cfbabd1794	2025-2026	HK2	27	Thứ 6	2026-03-27	11C12	12B10	5d442b14-0bc4-4e4f-878b-bce8bd8a9e64	Rơ Mah H' Diệu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C12	2026-03-27 00:07:51.483+00
f0f1cd42-9e1b-46d0-9383-b09f9be0fbb2	2025-2026	HK2	27	Thứ 6	2026-03-27	11C12	12B10	2915eda8-3f13-4d03-8b84-08198b41e52f	Trịnh Hoàng Long	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C12	2026-03-27 00:08:34.357+00
6398dbda-4c76-489d-bf58-30b0b74fc242	2025-2026	HK2	27	Thứ 6	2026-03-27	11C12	12B10	ec737772-c13d-4b58-b705-1b4a5e6e80a1	Lê Khanh	TC11	Đi dép lê	Vi phạm	5	0		11C12	2026-03-27 00:12:54.898+00
fd525ecc-fa59-4d60-bd0e-81ddace0386b	2025-2026	HK2	27	Thứ 5	2026-03-26	11C12	12B10	4b463588-7bd1-45ae-b554-3c5b195ea877	Lê Thị Thúy Kiều	TC01	Đi học muộn	Vi phạm	2	0		11C12	2026-03-27 01:24:52.105+00
717c567a-f405-40f2-8c98-a5cdf28deba5	2025-2026	HK2	27	Thứ 5	2026-03-24	11C9	12B7	77033a63-6963-49f8-8036-a3cba878d51e	Vũ Thu Ly	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C9	2026-03-27 04:39:27.455+00
a5f41f3a-cd11-44f1-af60-5b1a8a4caaae	2025-2026	HK2	27	Thứ 6	2026-03-25	11C9	12B7	77033a63-6963-49f8-8036-a3cba878d51e	Vũ Thu Ly	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C9	2026-03-27 04:40:13.779+00
3d87f1f7-78e1-4b81-9c40-8f0a5d99d761	2025-2026	HK2	27	Thứ 6	2026-03-27	12B9	12B2	ac26f03f-6aa3-4169-886a-ecf60ff9cd07	Lê Thành Danh	TC01	Đi học muộn	Vi phạm	2	0		12B9	2026-03-27 04:59:15.693+00
91c449c4-3f7a-45c1-b1e7-240f6f9d8677	2025-2026	HK2	27	Thứ 6	2026-03-27	12B6	11C11	2f26724f-0e53-4b43-82f9-ca2d6f87f06d	Đoàn Ngô Vũ Luân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-27 10:05:48.316+00
40293f16-41ec-4ab0-b18a-a2997e83a655	2025-2026	HK2	27	Thứ 6	2026-03-27	12B6	11C11	4e128bd3-0d5b-4e47-a6d1-95db4b8ae83f	Cao Thái Sơn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-27 10:06:17.173+00
59a10706-2d9f-4595-b235-f8f967e43b5f	2025-2026	HK2	27	Thứ 6	2026-03-27	12B6	11C11	a3b4c2d8-b70b-464a-8282-c77ad9e70605	Kpuih H' Ngát	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-27 10:06:33.845+00
e6236217-7855-472e-915c-0aad689f951e	2025-2026	HK2	27	Thứ 6	2026-03-27	12B6	11C11	835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-27 10:07:19.246+00
ec06755e-421a-41ed-8f77-ccfb65682266	2025-2026	HK2	27	Thứ 6	2026-03-27	12B6	11C11	30a8b007-0db3-4a1d-a56c-713af0dd6f6d	Phạm Nguyễn Hoàng Linh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-27 10:07:51.531+00
62d282ed-e8fa-4291-9320-8633ec76e35a	2025-2026	HK2	27	Thứ 6	2026-03-25	11C4	10A10	6f06a0f9-d009-4090-8049-dc32c3f3a07c	Phạm Thị Như Ngọc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C4	2026-03-27 11:55:47.708+00
f3384be1-aacd-4bb5-97d7-228e8f0773b4	2025-2026	HK2	27	Thứ 6	2026-03-25	11C4	10A10	d0364fbd-f5f0-4ee1-b259-db4b795707ad	Nguyễn Hoàng Bảo Ngọc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C4	2026-03-27 11:57:28.869+00
961ee121-b508-4959-b9ea-aeef140d51fb	2025-2026	HK2	27	Thứ 6	2026-03-27	11C3	10A9	8e925e67-2d7d-4f06-a279-021264e559d6	Phan Lê Quốc Huy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C3	2026-03-27 12:23:05.329+00
2e159f97-9af5-480d-838a-969c2228eb54	2025-2026	HK2	27	Thứ 6	2026-03-27	11C3	10A9	d48bcd7f-4adc-409c-a0d4-054cdf29788f	Rơ Lan H' Thư	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C3	2026-03-27 12:23:30.928+00
854a555c-d196-42ac-9402-5aaf066993dc	2025-2026	HK2	27	Thứ 5	2026-03-26	11C10	12B8	0d12676f-06e1-41a6-8496-55d4f5a1d418	Nguyễn Thu Hiền	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C10	2026-03-27 12:43:01.891+00
a56ea221-bc2d-4966-ba62-85ddd82a0ed2	2025-2026	HK2	27	Thứ 5	2026-03-24	12B3	11C8	494ece49-4327-40c5-885c-e0b1c3e636d2	Phạm Đức Bin	TC08	Sai đồng phục	Vi phạm	5	0		12B3	2026-03-27 12:43:06.884+00
d21cfd96-a6ad-4905-8e20-e44f71a10d21	2025-2026	HK2	27	Thứ 5	2026-03-26	11C10	12B8	0b51473e-4c9e-4db2-93a6-f852b71e180b	Nguyễn Ngọc Mai	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C10	2026-03-27 12:43:22.033+00
eff56daa-efcf-4b2a-89a0-ce007eef8b87	2025-2026	HK2	27	Thứ 5	2026-03-24	12B3	11C8	fa3c23b5-70f6-426c-98e9-6e4c49b51325	Rơ Lan Lâm	TC08	Sai đồng phục	Vi phạm	5	0		12B3	2026-03-27 12:43:25.163+00
55461cfc-d3b7-4313-b574-a8f0aeae9b81	2025-2026	HK2	27	Thứ 5	2026-03-26	11C10	12B8	17c0731b-2f8b-4f2b-95e6-873e94a4dca0	Lê Nguyễn Thảo Vy	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C10	2026-03-27 12:43:37.903+00
50822f42-b17d-4353-85a2-768b5a67ef61	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	edb2c247-8cf0-4a3d-a803-c9e1fbcc2da1	Rơ Mah H' Quỳnh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:44:50.709+00
f2d39d95-544e-420a-82ce-b5c22deac680	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	80ea8573-9dfe-4540-bb09-5aefd89dc5a3	Rơ Lan H Khâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:45:10.267+00
476d3e59-4300-4542-b8ca-816cc41d5455	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	e75b87f9-ee4b-41e3-a76f-b5c4227f3cf7	Nguyễn Thị Bích Vân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:45:15.858+00
bc64cd3d-44ef-42b3-9df3-c2c24b8e827c	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	80d0b73a-bb20-456b-81f8-a9e9ce236ae0	Trần Tố Uyên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:45:40.231+00
dca2e976-86e1-4b64-bd09-442a38927e84	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	c286c4bc-ce2b-4176-9a80-7ca0a3c9223b	Thái Hoàng Mỹ Uyên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:45:48.515+00
93f77957-33c3-4c4f-9b34-bcaa8302df15	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	eb0cc01b-e7f7-488f-99a6-2c640cafc2b7	Trương Thị Hoài Thương	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:45:58.762+00
9a7894c8-d9e5-4867-89e9-50d1dbee427f	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	45ffe0e0-7031-4734-b848-4a1e36fcff45	Nguyễn Công Danh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:46:11.033+00
7a02215f-d6b7-4a17-87b9-d3a821e15515	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	0b51473e-4c9e-4db2-93a6-f852b71e180b	Nguyễn Ngọc Mai	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:46:15.6+00
a539e884-bb80-49fa-9994-b85851184a95	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	5c75cd61-6999-44fa-81a4-14a12adb9fd8	Rơ Mah H’ Trang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:46:52.12+00
72c92a00-ecf5-4d53-89e2-846546ee15c4	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	cf5e3e39-f305-4365-b972-811829ec9fff	Kpuih Ngân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:47:07.574+00
09512db4-d8e5-41a2-bd5b-14e1f843f419	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	17c0731b-2f8b-4f2b-95e6-873e94a4dca0	Lê Nguyễn Thảo Vy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:46:35.471+00
2ecfb43f-afce-4932-ae83-71280158ff83	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	494ece49-4327-40c5-885c-e0b1c3e636d2	Phạm Đức Bin	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:46:37.367+00
a63dd448-eeeb-43c6-bf4c-884385012c05	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	f913e407-a879-4bd6-b492-ff93a0675db1	Lê Minh Hiệp	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-27 12:48:49.974+00
6b97dd16-eef3-4a58-bd58-7c1da121f066	2025-2026	HK2	27	Thứ 6	2026-03-27	11C10	12B8	8e239664-a6fa-4cd9-8f03-ba74607678d4	Nguyễn Văn Sỹ	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C10	2026-03-27 12:49:17.594+00
3d92663c-d7bc-4ee4-b67c-6dcb1ec97dba	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	5b727795-d975-41cc-8854-ee5a186cac6e	Hồ Văn An	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:50:01.351+00
8014d58a-697a-4bce-a893-d2d93fa555cd	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	522e7e6c-82c8-4dd3-9c0f-bbd2bbb7c1ae	Nguyễn Văn Cường	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:50:24.8+00
f1f7c7f9-5338-4264-a60e-3a27bea499b5	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	5609c740-ff28-4573-9637-39ea8d9a1733	Trần Gia Hưng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:50:45.378+00
6e26aea7-d427-4d23-97b6-75d04a10ef66	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	60509c94-6d43-4f23-ae58-067e6f4f787a	Châu Thanh Hoàng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:50:56.233+00
ac74759b-fc83-475e-81ed-b86afadb6378	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	a109f481-e19a-4375-a321-897acf8974c7	Rơ Mah Luy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:51:19.372+00
8bd796ab-fded-4ff5-bd1b-fac073dd48ff	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	7994dab9-614a-4f9d-ae27-c76996ac0a34	Rơ Mah Dấu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:51:41.9+00
f8c70563-b6a4-442a-aca6-731fbca0a618	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	93fe0665-7970-46b9-9e71-4dbaeee859cc	Đỗ Quỳnh Tố Như	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:52:01.15+00
8506abbd-3bc6-4e4c-8441-8afd7fc3d454	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	df73b4e5-693a-497f-aceb-90b67fc6836f	Lê Thị Hồng Nhung	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:52:16.42+00
fb34d405-5417-42fa-8444-dd892b983937	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	dcf6f56c-49ce-4852-a8ff-94e848e5cc0d	Bùi Đức Tài	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:52:28.799+00
47084b22-befb-4ca3-9614-205839998510	2025-2026	HK2	27	Thứ 6	2026-03-25	11C11	12B9	a12f298d-0116-4768-adbf-796de7a08268	Trần Đức Tài	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C11	2026-03-27 12:52:45.594+00
d6ee6ff4-d079-4804-8073-cb04fdff11f7	2025-2026	HK2	27	Thứ 7	2026-03-21	10A3	11C3	367a4cd3-520e-4afc-8fea-c7806a7f9091	Bùi Thị Yến Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A3	2026-03-27 13:15:44.181+00
eb52dadc-a693-4965-9a05-34038a281c05	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	25808d2f-e5f8-4e3e-afd1-6b8c4555390e	Nguyễn Ngọc Tiên Nhi	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:16:14.643+00
0e4a043b-99f8-4c72-8131-ec11777c6465	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:16:41.432+00
2f35420b-46d5-440d-ae32-08b56d57f84f	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:17:09.226+00
356e25dd-2ad2-42f1-a8b3-dd035230a5a7	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:17:27.729+00
8fcb078f-a19c-42df-9286-f80e90769ad7	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:18:00.011+00
958f42cb-011a-44df-afa9-45cbc4bd3c73	2025-2026	HK2	27	Thứ 6	2026-03-25	10A8	10A3	e62b9ede-80c6-49f9-8e2d-9b7fdcc21bdb	Võ Ngọc Minh Trâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		10A8	2026-03-27 13:22:41.894+00
d48af648-d98d-42aa-90e3-ed8ea0a81558	2025-2026	HK2	27	Thứ 6	2026-03-25	10A8	10A3	b159d678-8ef4-437f-8eae-4d5cf5cc2310	Võ Thị Anh Thơ	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		10A8	2026-03-27 13:23:03.017+00
f30ba225-41ab-45fa-a6aa-fa3e8ef9f644	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	982edc30-d71e-45de-b860-2dbd2a26e4d7	Trịnh Quốc Quân	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:23:39.79+00
f2ddc9bd-fbd2-47cb-9e2e-1a6cec3b69ef	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:23:54.688+00
aa090c2e-ba85-4b35-ac83-bde2b8986716	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:24:17.231+00
6b194ae5-2cbb-499b-ac18-5935bb7e0ef4	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	440b60d2-0be6-401a-9ca6-03787396db35	Nguyễn Văn Tài	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:24:40.098+00
af134449-20dd-43bc-9e9c-6fbb86717951	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B5	2026-03-27 13:25:09.432+00
9ada3fc9-b2d2-4063-99d9-7abc671f36fc	2025-2026	HK2	27	Thứ 5	2026-03-24	12B5	11C10	04eccc7d-8439-421e-aee8-ab07b4dec31b	Vũ Quốc Huy	TC07	Không bảng tên	Vi phạm	5	0		12B5	2026-03-27 13:25:45.824+00
257759ba-8109-4643-871e-b1206a71f49b	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:27:33.658+00
25355c3a-89e6-485c-a194-e2531cc734ee	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:28:36.792+00
10581766-cf7f-4164-84d2-2c78c3170bf1	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:29:14.933+00
35992aed-b54c-4f48-a237-d4f1b73d3713	2025-2026	HK2	27	Thứ 6	2026-03-27	11C8	12B6	3465251d-593b-4694-af6d-652ab1ac0eb2	NGUYỄN NGỌC BẢO HÂN	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:32:18.016+00
a05757af-10c7-477d-a6e9-a63b36c428c7	2025-2026	HK2	27	Thứ 5	2026-03-26	11C8	12B6	c044cdb7-4422-4911-b004-86e9b4560331	TRẦN MINH HIẾU	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C8	2026-03-27 13:32:22.741+00
e8e912f8-f34a-49a7-ad94-ed9a2281e80c	2025-2026	HK2	27	Thứ 6	2026-03-27	11C8	12B6	821fef90-4bc7-4f69-b846-882c8cd6f482	Hồ Hữu Lộc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:32:09.72+00
92023ac5-12b9-467a-96d0-3199c588f8a1	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	c34ec979-147f-4a00-bbdd-8efb79f1efb2	Rơ Mah H' Hyưng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:31:12.24+00
87b14983-e0ec-474b-986e-c2da448f80e2	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	25808d2f-e5f8-4e3e-afd1-6b8c4555390e	Nguyễn Ngọc Tiên Nhi	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:31:24.837+00
573197cc-0c44-431b-b0f6-2b1331a3f545	2025-2026	HK2	27	Thứ 6	2026-03-27	11C8	12B6	0b5bbf91-ab2f-46ab-8421-0d9387503c27	PHAN ANH TÚ	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:31:48.554+00
631201f3-f6f0-4f77-b9ec-bc76a42dd0c2	2025-2026	HK2	27	Thứ 6	2026-03-27	11C8	12B6	8f0539ce-d58e-4666-9a06-e3c024654752	TRƯƠNG ÁI MỸ TIÊN	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:31:57.369+00
f81adc1a-c99f-47ff-b6f6-b1cf7e5a1ed9	2025-2026	HK2	27	Thứ 6	2026-03-25	11C8	12B6	b92386ce-aa6d-4aa2-867f-b2a4671c8481	QUÁCH ĐỨC THỊNH	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:32:02.91+00
267dad54-f782-464a-86be-b6a740938c52	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	982edc30-d71e-45de-b860-2dbd2a26e4d7	Trịnh Quốc Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:32:04.989+00
e5882f55-d1e8-4253-9398-81f204028e55	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:32:22.377+00
87689106-e293-491c-9728-5dc6561f6ec8	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:31:47.466+00
b32a7ef6-b243-407c-b773-cad78f927296	2025-2026	HK2	27	Thứ 6	2026-03-27	11C8	12B6	c044cdb7-4422-4911-b004-86e9b4560331	TRẦN MINH HIẾU	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C8	2026-03-27 13:32:14.514+00
bb4f518e-deec-4c0a-b7f1-576efc95594b	2025-2026	HK2	27	Thứ 5	2026-03-26	11C8	12B6	3465251d-593b-4694-af6d-652ab1ac0eb2	NGUYỄN NGỌC BẢO HÂN	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		11C8	2026-03-27 13:33:08.628+00
a4049905-b796-4d81-8032-d03707db7bbe	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	faffb8ff-2084-4fc2-a189-0a15a0e0c058	Đoàn Trần Anh Thư	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:33:12.515+00
99ed63d2-6f21-4050-ad10-5c00ab7109fc	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:33:26.705+00
88f372bf-09e2-4f15-a680-6dc0735322cd	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	4187fc2a-ecb1-4b47-8d0d-818f132cf4a9	Kpuih H' Tinh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:33:47.692+00
d794f4e1-c1ee-45f5-8b5c-5c26d2a60464	2025-2026	HK2	27	Thứ 6	2026-03-25	12B5	11C10	146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B5	2026-03-27 13:34:04.575+00
84b541b1-18d6-40bf-b50d-89deefbb6a9b	2025-2026	HK2	27	Thứ 6	2026-03-27	12B10	12B3	7ff4fd75-482d-4ecd-a3c2-21f399e2c004	Nguyễn Hà Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B10	2026-03-27 13:41:35.872+00
55f0dbc3-d5c9-489e-be7e-2a84a7e7c974	2025-2026	HK2	27	Thứ 6	2026-03-27	12B10	12B3	4513cbe1-3f68-47c2-accc-350504325682	Nguyễn Khắc Hùng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B10	2026-03-27 13:41:56.186+00
80d31d5e-59d1-4e35-b5ec-8e1588fb2a74	2025-2026	HK2	27	Thứ 6	2026-03-27	12B10	12B3	6dbb142e-17ee-475c-8346-fbe6c5cac59b	Dương Công Huy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B10	2026-03-27 13:42:16.27+00
167dad32-3fa7-4620-a12a-0559dd8f2190	2025-2026	HK2	27	Thứ 6	2026-03-27	12B10	12B3	8cdbe5ad-9a05-4f45-ab11-fa6f756d0674	Lý Trâm Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B10	2026-03-27 13:42:47.365+00
4a2e4f7c-f727-45bb-ba94-dbc995ccf127	2025-2026	HK2	27	Thứ 6	2026-03-27	12B10	12B3	8cdbe5ad-9a05-4f45-ab11-fa6f756d0674	Lý Trâm Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B10	2026-03-27 13:42:48.386+00
9ae13583-3234-4b72-bcc1-f16c96c5df68	2025-2026	HK2	27	Thứ 5	2026-03-26	11C2	10A8	e82bd0e6-4828-441c-9285-150405ae12e0	Lường Thị Kiều Oanh	TC10	Không quai dép	Vi phạm	5	0		11C2	2026-03-27 14:10:27.068+00
28193b3c-fe75-4a2a-ad1f-7bff0a5b09b8	2025-2026	HK2	27	Thứ 5	2026-03-26	11C2	10A8	a23ccfd6-a018-4fdb-b28e-f22020c8b4d0	Rơ Lan H' Siu	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C2	2026-03-27 14:11:41.992+00
8ddaeccd-555a-4221-97dc-f62b70f08dd5	2025-2026	HK2	27	Thứ 5	2026-03-26	11C2	10A8	658c8665-9a38-409a-a8b7-19946738f131	Trần Văn Bảo Nam	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C2	2026-03-27 14:12:50.699+00
cd0072e7-4abe-4c21-b937-f68aca2c3733	2025-2026	HK2	27	Thứ 5	2026-03-26	11C2	10A8	330637d3-a201-4e5d-aaa2-18103c027e09	Rơ Mah H' Jin	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C2	2026-03-27 14:13:48.761+00
99f7e556-df91-448d-a407-d39c86a9d5f8	2025-2026	HK2	27	Thứ 6	2026-03-27	11C2	10A8	330637d3-a201-4e5d-aaa2-18103c027e09	Rơ Mah H' Jin	TC41	Vắng học có lí do (1 tiết)	Vi phạm	0.25	0		11C2	2026-03-27 14:16:03.469+00
b688ab06-74a5-4354-8712-b2f45b1f7c54	2025-2026	HK2	27	Thứ 5	2026-03-26	12B1	11C6	517f6af7-404c-47b3-967b-25c192f4ebc9	Rơ Lan H' Sa Bét	TC08	Sai đồng phục	Vi phạm	5	0		12B1	2026-03-27 15:34:56.867+00
73964ea9-d08f-45fb-9171-9888b0e880b4	2025-2026	HK2	27	Thứ 5	2026-03-26	12B1	11C6	517f6af7-404c-47b3-967b-25c192f4ebc9	Rơ Lan H' Sa Bét	TC07	Không bảng tên	Vi phạm	5	0		12B1	2026-03-27 15:35:31.268+00
841f409f-ddf6-4adc-b04b-03c8152d133a	2025-2026	HK2	27	Thứ 5	2026-03-26	12B1	11C6	b5db3da7-da08-4057-b8cf-dc36fd186086	Hồ Thị Nguyệt	TC08	Sai đồng phục	Vi phạm	5	0		12B1	2026-03-27 15:36:04.15+00
4f01c7fb-2e6c-4a1f-b796-01add85b27eb	2025-2026	HK2	27	Thứ 6	2026-03-27	12B1	11C6	42287fbd-089e-418c-be55-4b93e4952c57	Đỗ Thị Hải My	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B1	2026-03-27 15:36:42.851+00
54e3044e-32ad-46bc-9be8-f3af9e63f906	2025-2026	HK2	27	Thứ 6	2026-03-27	12B1	11C6	24a48163-cf7a-446f-8234-6121d3f686db	Nguyễn Tài Phát	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B1	2026-03-27 15:37:14.468+00
c5b83941-8f92-4548-af40-a79664ed2ae6	2025-2026	HK2	27	Thứ 6	2026-03-27	12B1	11C6	ab87653b-5dcd-4a06-87f2-1d0d7acabd2a	Ngô Thảo Vy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B1	2026-03-27 15:37:38.642+00
d5955fe8-64a7-4368-939b-4b4475273c21	2025-2026	HK2	27	Thứ 5	2026-03-24	11C9	12B7	4ebe940f-0294-42fa-a80c-d3ff973e93d2	Nguyễn Thị Thùy Dung	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C9	2026-03-28 00:04:07.432+00
0d22a101-1645-4441-82b7-25553188ce43	2025-2026	HK2	27	Thứ 7	2026-03-28	11C12	12B10	ec737772-c13d-4b58-b705-1b4a5e6e80a1	Lê Khanh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C12	2026-03-28 00:05:40.328+00
246e21d5-f755-4d40-9877-fcb45e521321	2025-2026	HK2	27	Thứ 6	2026-03-25	12B8	12B1	9f2c6377-386b-4248-814f-518974076d1b	Nguyễn Trịnh Gia Bảo	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B8	2026-03-28 00:32:50.95+00
b5d13691-be06-48d9-9679-1c8fcfe97bd7	2025-2026	HK2	27	Thứ 7	2026-03-26	12B8	12B1	9f2c6377-386b-4248-814f-518974076d1b	Nguyễn Trịnh Gia Bảo	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-28 00:34:02.641+00
715f8ab0-d7c8-4e90-a08e-68f8824b3e0b	2025-2026	HK2	27	Thứ 7	2026-03-26	12B8	12B1	98e83d70-42cb-4cbc-baab-e1410533b772	Bùi Thị Tú Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-28 00:34:25.071+00
4eb704f9-5eb8-45a5-80a7-8df6d29c0a03	2025-2026	HK2	27	Thứ 7	2026-03-26	12B8	12B1	c77e4670-587c-4675-844a-a691ab08b0ed	Đỗ Hà Phi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-28 00:34:53.327+00
61174323-583c-4499-8964-ddda4eae5095	2025-2026	HK2	27	Thứ 7	2026-03-26	12B4	11C9	ecc7e4b7-edf3-4895-a9e1-08c50d2a861d	Lê Quỳnh Như	TC01	Đi học muộn	Vi phạm	2	0		12B4	2026-03-28 03:56:32.118+00
f303eeb8-ed2c-4047-9c55-b024cb01c92f	2025-2026	HK2	27	Thứ 7	2026-03-21	12B4	11C9	ecc7e4b7-edf3-4895-a9e1-08c50d2a861d	Lê Quỳnh Như	TC16	Mặc áo khoác ngoài	Vi phạm	5	0		12B4	2026-03-28 03:56:59.121+00
e08be0e2-3e35-4492-905b-19d0333ca0c9	2025-2026	HK2	27	Thứ 6	2026-03-27	10A4	11C4	6f0028c7-3f97-4bb2-88ad-fcf84f64056a	Cù Hoàng Gia An	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		10A4	2026-03-28 11:04:01.676+00
506a60f5-cf9f-44d5-b6b8-4b36facab53a	2025-2026	HK2	27	Thứ 6	2026-03-27	10A4	11C4	298eec5c-3e66-4c72-8b28-854bbdb75cb5	Nguyễn Hồ Khải Hoàng	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		10A4	2026-03-28 11:03:33.47+00
df32a5de-34a0-45e2-a0fe-cb480b21e823	2025-2026	HK2	27	Thứ 6	2026-03-25	12B3	11C8	6e803843-4f5e-46ae-bbd0-96f40dc0943f	Trần Thị Mỹ Hạ	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B3	2026-03-28 11:13:02.561+00
19ad58ce-d648-44bb-ad72-418de828cb0c	2025-2026	HK2	27	Thứ 7	2026-03-28	11C8	12B6	7589e41e-000a-4c46-ad9e-231f5e6015cf	PHẠM THỊ VÂN ANH	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C8	2026-03-28 11:14:02.239+00
7f2d5c76-3883-4c3f-9faa-eadedaa226c4	2025-2026	HK2	27	Thứ 7	2026-03-28	11C8	12B6	c044cdb7-4422-4911-b004-86e9b4560331	TRẦN MINH HIẾU	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C8	2026-03-28 11:14:32.462+00
49482883-23eb-4f6b-a043-5a96b783962b	2025-2026	HK2	27	Thứ 7	2026-03-28	11C8	12B6	eb8f7447-2398-45d5-acd0-a8df3923a089	RMAH H' LY SA	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C8	2026-03-28 11:15:16.857+00
f5f6d5a1-4c20-46be-ae23-f1a7de82de43	2025-2026	HK2	27	Thứ 7	2026-03-28	10A6	10A1	159008c5-8420-44ac-a23f-ec704a3be66a	Tập thể 10A1	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A6	2026-03-28 11:24:30.98+00
f846cbc8-c9fb-4a6c-84b0-1ced2da9a04d	2025-2026	HK2	27	Chủ nhật	2026-03-27	10A7	10A2	36c971e3-f482-4703-a4fb-f3bff27485a1	Tập thể 10A2	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		10A7	2026-03-28 11:25:44.97+00
86ea16a2-4921-42a6-9997-d2135d9b76ca	2025-2026	HK2	27	Thứ 7	2026-03-28	11C3	10A9	8e925e67-2d7d-4f06-a279-021264e559d6	Phan Lê Quốc Huy	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-28 12:41:32.599+00
7ba31614-3bde-4b45-b15e-35d330998592	2025-2026	HK2	27	Thứ 7	2026-03-28	11C3	10A9	58186ebc-f6db-4a3b-9086-a13e781e8d5a	Đặng Hồ Phương Linh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-28 12:42:34.139+00
7084e891-a3f5-4f44-9c4a-0adf2ec8cd1a	2025-2026	HK2	27	Thứ 7	2026-03-28	11C3	10A9	c1cea216-5cbd-435d-9e7a-21ffe1cb040b	Lương Hữu Phương	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-28 12:43:15.614+00
d9f71fa0-7ad4-4364-a804-e518eb2d8499	2025-2026	HK2	27	Thứ 7	2026-03-28	11C3	10A9	4e5c248d-3ad9-4562-9af2-fdb65705b2a1	Nguyễn Đình Phong	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-28 12:43:44.695+00
70bd73de-6062-4b4b-a0d6-a70e0bcfd030	2025-2026	HK2	27	Thứ 5	2026-03-26	12B6	11C11	abc80259-d940-46bf-b946-8ba67506e87b	Bùi Thị Tường Vy	TC16	Mặc áo khoác ngoài	Vi phạm	5	0		12B6	2026-03-28 12:48:53.929+00
92c905bc-efae-4edb-941a-fb53f307f950	2025-2026	HK2	27	Thứ 7	2026-03-28	12B6	11C11	afc32642-87a3-47f9-aeb9-7326c9f3102c	Trần Minh Hiếu	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B6	2026-03-28 12:51:08.208+00
d64c2011-e588-474f-86b5-300c18e3c9a9	2025-2026	HK2	27	Thứ 7	2026-03-28	12B6	11C11	30a8b007-0db3-4a1d-a56c-713af0dd6f6d	Phạm Nguyễn Hoàng Linh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B6	2026-03-28 12:52:01.639+00
2128dbeb-3d21-42cc-875e-428007ef83ba	2025-2026	HK2	27	Thứ 7	2026-03-28	12B6	11C11	835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B6	2026-03-28 12:52:28.468+00
41270bc4-bdc4-4986-ba15-07864040bf17	2025-2026	HK2	27	Thứ 5	2026-03-26	10A10	10A5	ef37eda6-8f8d-471b-9f0e-0b5eca5abc04	Nguyễn Thị Minh Hằng	TC01	Đi học muộn	Vi phạm	2	0		10A10	2026-03-28 14:25:05.614+00
bf49a872-5f01-43e7-a545-f0e7dda14e91	2025-2026	HK2	27	Thứ 2	2026-03-23	10A5	11C5	25d78477-f93d-401d-85b3-3a39ba2e83e7	Tập thể 11C5	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		10A5	2026-03-29 01:49:18.439+00
c9ec8942-979b-480d-898b-8941d534560e	2025-2026	HK2	27	Thứ 3	2026-03-24	10A5	11C5	25d78477-f93d-401d-85b3-3a39ba2e83e7	Tập thể 11C5	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		10A5	2026-03-29 01:49:48.424+00
e0edc054-49c6-4c93-a6fc-a7840eac22a5	2025-2026	HK2	27	Thứ 4	2026-03-25	10A5	11C5	25d78477-f93d-401d-85b3-3a39ba2e83e7	Tập thể 11C5	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		10A5	2026-03-29 01:50:05.487+00
90f9244b-dd22-4f73-a8b0-b25ef14e362f	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	73703faa-1726-454d-bf40-9c0df35722c3	Rơ Lan H' Bích	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:04:18.087+00
18988168-e05c-4416-91d5-b16f5f53f48b	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	c19553fc-9cbd-44b3-82df-9dde159122eb	Hoàng Việt Anh	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:05:27.976+00
e0557a2f-5a7d-4d5c-a253-37c35beb5e19	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	df3d058a-ae56-4685-aa21-e1eb8e89a388	Trần Thị Thanh Nhàn	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:06:02.405+00
4130a76d-64ad-433b-8794-31cd08ece6b6	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	e9bfb6e7-d97b-4a59-9385-b8f9b666bf7b	Trần Ngọc Quốc	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:06:47.975+00
7a0c4965-5ff5-4d22-b41a-79709f2dfdb1	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	863d2837-882a-4fb6-825f-63983b871f31	Dương Quỳnh Trâm	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:07:38.562+00
7cc5626a-fc81-4bdb-a4a3-0fc5539d00a0	2025-2026	HK2	27	Thứ 6	2026-03-27	11C7	12B5	24b6f0ac-86b3-4e66-af39-523d2f21e5b5	Rơ Mah Phiên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C7	2026-03-29 03:08:05.594+00
a0165d6f-2f04-4d84-97fe-ea0569266d47	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 09:25:47.741+00
93215425-bc18-4e96-8297-262648691a49	2025-2026	HK2	27	Thứ 7	2026-03-28	11C2	10A8	61561ed7-3041-4a72-ab63-691bb6bdc351	Trương Văn Hiếu	TC41	Vắng học có lí do (1 tiết)	Vi phạm	0.25	0		11C2	2026-03-29 11:19:55.698+00
dbd3db5e-abe8-488f-adb9-8fd2c81990cd	2025-2026	HK2	27	Thứ 7	2026-03-28	11C2	10A8	71090bf5-4da7-40e3-9615-2903bce8496f	Nguyễn Thị Ly Ly	TC16	Mặc áo khoác ngoài	Vi phạm	5	0		11C2	2026-03-29 11:20:27.031+00
9b909616-77e8-4009-9581-13c0ceb205e8	2025-2026	HK2	27	Thứ 7	2026-03-28	11C2	10A8	658c8665-9a38-409a-a8b7-19946738f131	Trần Văn Bảo Nam	TC16	Mặc áo khoác ngoài	Vi phạm	5	0		11C2	2026-03-29 11:21:43.426+00
d0787ef7-c7af-4c31-a13b-e19ccbfc1d14	2025-2026	HK2	27	Thứ 7	2026-03-28	12B1	11C6	29131a6e-2554-4250-aebc-b91005c6fa7c	Rơ Lan H' Rêny	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B1	2026-03-29 11:31:20.087+00
e3ce974f-8326-4634-885d-29aaa6136ddd	2025-2026	HK2	27	Thứ 6	2026-03-27	12B7	11C12	d78a83dd-fcb3-4376-8aa0-bf1550182273	Trần Đăng Phong	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B7	2026-03-29 11:35:26.53+00
afa88c00-589a-474b-b2cc-fd54fbb40f23	2025-2026	HK2	27	Thứ 6	2026-03-27	12B7	11C12	09a3934d-30bf-43e1-876f-04dbdf2badb5	Đặng Duy Quốc Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B7	2026-03-29 11:36:14.295+00
a6a1e6af-1c67-41ab-b7dc-24ef99af70be	2025-2026	HK2	27	Thứ 5	2026-03-26	12B7	11C12	647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	TC01	Đi học muộn	Vi phạm	2	0		12B7	2026-03-29 11:36:41.064+00
36511f7a-63ab-4366-8ad4-3f4d845c3588	2025-2026	HK2	27	Thứ 5	2026-03-26	12B7	11C12	647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	TC08	Sai đồng phục	Vi phạm	5	0		12B7	2026-03-29 11:37:00.38+00
5f0f7fe0-5655-4872-8fb4-f4b8566272d4	2025-2026	HK2	27	Thứ 5	2026-03-26	12B7	11C12	647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	TC07	Không bảng tên	Vi phạm	5	0		12B7	2026-03-29 11:37:28.381+00
f4c76b57-59dd-4c24-af93-2cc7d78f8b57	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:13:56.363+00
1440758a-d06b-4c2e-89ad-d93873e9cfa3	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:14:43.328+00
f8c70d6a-dd05-4453-8dc0-c1721b73d60e	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	c34ec979-147f-4a00-bbdd-8efb79f1efb2	Rơ Mah H' Hyưng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:15:17.811+00
686710e7-ee0a-453d-88b1-b1646376298a	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	25808d2f-e5f8-4e3e-afd1-6b8c4555390e	Nguyễn Ngọc Tiên Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:15:48.109+00
7373294c-f5f5-4612-9992-2c75484e5963	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:16:25.331+00
20126952-44b3-4cb6-9f3d-7aebd911963f	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	982edc30-d71e-45de-b860-2dbd2a26e4d7	Trịnh Quốc Quân	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:16:58.374+00
e8751a4c-a171-43db-992b-5f1e44286f14	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:17:33.07+00
3f85e1f0-4a8f-47bc-8d35-f9189ca50867	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	faffb8ff-2084-4fc2-a189-0a15a0e0c058	Đoàn Trần Anh Thư	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:18:27.962+00
773b0be7-6b1f-4474-9177-64705a148967	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:18:57.14+00
879f85b0-cd3c-4ae3-b2e6-31d8f4b6ef28	2025-2026	HK2	28	Thứ 2	2026-03-30	11C11	12B10	44722561-7fa7-44ef-9a26-cdfeb098934f	Tập thể 12B10	TC26	Vệ sinh muộn 	Vi phạm	5	0		Hồ Hữu Thế - QT	2026-03-30 00:11:19.251+00
0610703b-b31b-431b-a5d7-54c6caed64df	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	4187fc2a-ecb1-4b47-8d0d-818f132cf4a9	Kpuih H' Tinh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:19:41.783+00
85569145-b707-4f8e-aa42-d242aa9f5c7a	2025-2026	HK2	28	Thứ 2	2026-03-30	11C12	11C6	24a48163-cf7a-446f-8234-6121d3f686db	Nguyễn Tài Phát	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C12	2026-03-30 02:32:01.585+00
2d3892dd-8067-4bfa-aabc-cf7dbfa5ae10	2025-2026	HK2	27	Thứ 7	2026-03-28	12B5	11C10	146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B5	2026-03-29 12:20:17.839+00
09d260d5-c48f-4e08-b1e6-d10f2d91eca2	2025-2026	HK2	27	Thứ 7	2026-03-28	12B1	11C6	fab400ab-d92e-4467-bd6c-c7b868440277	Nguyễn Thị Thanh Hoài	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B1	2026-03-29 12:50:21.994+00
fd5e4766-8088-49b9-96f8-a154e27165cb	2025-2026	HK2	27	Thứ 5	2026-03-26	12B2	11C7	2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B2	2026-03-29 13:45:53.415+00
0dcb47dc-dc27-4810-bf34-7013ed9383ea	2025-2026	HK2	27	Thứ 2	2026-03-23	11C5	10A11	1d80f7c0-2ea2-4c0b-9d1f-69040602433c	Hồ Thị Nguyệt Ánh	TC06	Không sơ vin	Vi phạm	5	0		Hồ Hữu Thế - QT	2026-03-29 13:45:30.538+00
5400ee0c-9341-4c64-9b97-5171d28e1e38	2025-2026	HK2	27	Thứ 5	2026-03-26	12B2	11C7	16748258-0e33-4a8d-8f0f-8f65a2d14f32	Hoàng Ngọc Bảo Long	TC42	Vắng học có lí do (2 tiết)	Vi phạm	0.5	0		12B2	2026-03-29 13:46:29.048+00
fac96de9-96e7-4936-9611-26cc778f314d	2025-2026	HK2	27	Thứ 5	2026-03-26	12B2	11C7	28b22e7b-7e12-42e2-b936-3d5092413259	Rơ Mah Hân	TC43	Vắng học có lí do (3 tiết)	Vi phạm	0.75	0		12B2	2026-03-29 13:46:57.52+00
e1e8beef-ac41-4903-b577-5f8c7d79837b	2025-2026	HK2	27	Thứ 5	2026-03-26	12B2	11C7	db87c044-75f2-4446-91e7-84148a3f40f6	Nguyễn Như Tình	TC43	Vắng học có lí do (3 tiết)	Vi phạm	0.75	0		12B2	2026-03-29 13:47:18.307+00
6ee07ff2-1afd-4f32-998d-fb35b8d83d02	2025-2026	HK2	27	Thứ 6	2026-03-27	12B2	11C7	16748258-0e33-4a8d-8f0f-8f65a2d14f32	Hoàng Ngọc Bảo Long	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B2	2026-03-29 13:47:46.878+00
0c2aa901-1fbc-4790-922f-4476c2f58b1b	2025-2026	HK2	27	Thứ 6	2026-03-27	12B2	11C7	2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B2	2026-03-29 13:48:05.103+00
3ed63e82-abfd-47bd-ac9e-b8531c78c348	2025-2026	HK2	27	Thứ 6	2026-03-27	12B2	11C7	28b22e7b-7e12-42e2-b936-3d5092413259	Rơ Mah Hân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B2	2026-03-29 13:48:25.684+00
20044d67-a7de-419e-b931-b420a3f6f58c	2025-2026	HK2	27	Thứ 6	2026-03-27	12B2	11C7	984ceeeb-c970-4243-9fc0-2143e88e7b62	Ngô Thị Thảo Nguyên	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B2	2026-03-29 13:49:03.367+00
5d8fa0b5-e82b-4e77-99b9-a746e6ddcc02	2025-2026	HK2	27	Thứ 6	2026-03-27	12B2	11C7	77ce3140-5697-4d8c-960a-d48e08aa1c6f	Rơ Mah H' Dulen	TC01	Đi học muộn	Vi phạm	2	0		12B2	2026-03-29 13:49:23.951+00
a2f600aa-4d07-4ad5-9cc0-d72e074b8462	2025-2026	HK2	27	Thứ 7	2026-03-28	12B2	11C7	884638a5-4bc2-4aa2-a53e-568e101bea20	Phan Khanh Hoà Bình	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B2	2026-03-29 13:50:02.867+00
f5376b9b-42d7-42f5-a298-dbb0ddda7b3a	2025-2026	HK2	27	Thứ 7	2026-03-28	12B2	11C7	2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B2	2026-03-29 13:51:10.896+00
fd70ee69-8daa-49a0-9f1f-898c5db24abe	2025-2026	HK2	27	Thứ 7	2026-03-28	12B2	11C7	84ac0880-6825-48e5-8aeb-decb2b61402f	Nguyễn Hữu Duy	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B2	2026-03-29 13:51:28.268+00
79d4c934-825d-43bc-8f6b-e2cc92f5e57d	2025-2026	HK2	28	Thứ 2	2026-03-30	11C9	12B8	7c9f12d7-d8a9-4890-9da6-0bf91b9bfe56	Nguyễn Xuân Tiến	TC07	Không bảng tên	Vi phạm	5	0		Hồ Hữu Thế - QT	2026-03-29 23:42:40.836+00
45138380-f1ae-45fa-aa7b-068a2f21bc2e	2025-2026	HK2	28	Thứ 2	2026-03-30	12B4	11C10	5ef21e40-6b45-40d8-a24d-6bee8c1f432c	Tập thể 11C10	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định	Vi phạm	10	0		Hồ Hữu Thế - QT	2026-03-30 00:10:52.188+00
ffe642d8-bfd8-4a1b-9a51-d96c25bd6e40	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	53d800b8-60af-4182-803f-7c1df4727525	Bùi Sinh Thái	TC10	Không quai dép	Vi phạm	5	0		Trần Thị Thủy Tâm - Phó BT ĐT	2026-03-30 08:05:39.254+00
77811b5d-d7d0-4e91-98a9-eb4c1be3db6a	2025-2026	HK2	27	Chủ nhật	2026-03-29	10A9	10A4	09d8ade5-bb92-46ab-98e7-3ab869d59f75	Tập thể 10A4	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		Hồ Hữu Thế - QT	2026-03-30 09:22:57.697+00
2a39fad4-1d59-46ad-a89e-163775f275d3	2025-2026	HK2	28	Thứ 2	2026-03-30	10A9	10A5	65560ab5-035b-496a-9133-a50d9bf0a0d0	Tập thể 10A5	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.	Khác	0	0		10A9	2026-03-30 11:10:17.74+00
bc4469b3-550d-431f-a576-5b1b3c7b7e98	2025-2026	HK2	28	Thứ 2	2026-03-30	11C1	10A8	658c8665-9a38-409a-a8b7-19946738f131	Trần Văn Bảo Nam	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C1	2026-03-30 12:17:45.212+00
116c7321-d5e4-4ae6-9138-db78ed2c4d73	2025-2026	HK2	28	Thứ 2	2026-03-30	11C3	10A10	5988f370-49b7-4e81-877a-da653534429e	Trần Đức Quân	TC16	Mặc áo khoác ngoài	Vi phạm	5	0		11C3	2026-03-30 12:34:47.892+00
1c48e600-f577-4221-a45d-0c3ba884eed9	2025-2026	HK2	28	Thứ 2	2026-03-30	11C3	10A10	5d823d24-0a48-4e55-9782-67bff369ad8e	Nguyễn Thị Thu Hiền	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-30 12:41:30.207+00
79080a89-7313-413f-af5f-75b63cb23dfc	2025-2026	HK2	28	Thứ 2	2026-03-30	11C3	10A10	3b816258-ea65-42e9-a577-a3a9b89005f8	Vi Thị Phương Linh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C3	2026-03-30 12:41:45.292+00
a411c830-ce2b-4bed-a50e-9437d144adb7	2025-2026	HK2	28	Thứ 7	2026-03-28	10A7	10A3	46e1df24-e9ca-4a12-afdb-0c14e3a73a49	Lê Thu Huyền	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A7	2026-03-30 12:49:35.327+00
c2c00fac-f12a-4d8a-bf39-d8fa5f422553	2025-2026	HK2	28	Thứ 7	2026-03-28	10A7	10A3	4e843068-6823-458f-bdfe-bdd02bf4f551	Phạm Thị Anh Thư	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A7	2026-03-30 12:50:00.99+00
9b879226-78d6-4508-aeb4-8939cf981b7e	2025-2026	HK2	28	Thứ 7	2026-03-28	10A7	10A3	be946fd6-fd18-4346-b8e4-8cbde0fbdf5b	Nguyễn Ngọc Anh Quân	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A7	2026-03-30 12:50:21.799+00
b081b4db-cf59-492c-b9a4-35213c316428	2025-2026	HK2	28	Thứ 7	2026-03-28	10A7	10A3	d049b2b3-79d5-493a-bc16-501641b99788	Hồ Đại Nghĩa	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A7	2026-03-30 12:50:35.709+00
f317d6e0-b520-4880-ab92-302f5e07da5b	2025-2026	HK2	28	Thứ 2	2026-03-30	12B6	11C12	647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B6	2026-03-30 13:02:02.538+00
c8e11143-e6c7-4fec-8e8f-8625b22b0674	2025-2026	HK2	28	Thứ 2	2026-03-30	10A8	10A4	aa2880ce-9399-44f8-baec-4f268d9b5f8e	Hoàng Mai Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		10A8	2026-03-30 15:56:14.413+00
6f38ddf3-bd30-4d80-87c2-70cfbb1fb214	2025-2026	HK2	28	Thứ 2	2026-03-30	10A8	10A4	722083d2-e4c8-4b94-8f2d-ffd599eda079	Lê Thị Khánh Băng	TC01	Đi học muộn	Vi phạm	2	0		10A8	2026-03-30 15:57:39.007+00
168dd2c2-0ad7-4483-8a12-81b0434a80ba	2025-2026	HK2	28	Thứ 2	2026-03-30	12B8	12B2	4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-31 00:03:09.836+00
c85dd93e-889c-44be-99b5-23315fd85284	2025-2026	HK2	28	Thứ 2	2026-03-30	12B8	12B2	4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-31 00:03:10.657+00
913a3636-727e-448c-b351-c93a894c1d87	2025-2026	HK2	28	Thứ 3	2026-03-31	12B8	12B2	4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-31 00:04:09.183+00
6e52b92e-7a31-4207-b86c-cb864c714f5d	2025-2026	HK2	28	Thứ 3	2026-03-31	12B8	12B2	4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		12B8	2026-03-31 00:04:09.86+00
ecca898f-ab3c-4374-b0f7-39811a2da6a8	2025-2026	HK2	28	Thứ 2	2026-03-30	11C9	12B8	15becc7c-fdbb-4368-a2de-2a455f2b4a66	Phan Đình Hoàng Anh	TC21	Hút thuốc lá	Vi phạm	30	0		Hồ Hữu Thế - QT	2026-03-31 01:40:51.492+00
55d9ab19-42ed-413b-bb51-2a80c4c8edf4	2025-2026	HK2	28	Thứ 2	2026-03-30	11C9	12B8	8e239664-a6fa-4cd9-8f03-ba74607678d4	Nguyễn Văn Sỹ	TC21	Hút thuốc lá	Vi phạm	30	0		Hồ Hữu Thế - QT	2026-03-31 01:41:05.006+00
c9e70922-22e5-4407-9404-fba88eee8b47	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	46d7d6b2-ae19-4f9f-956a-8c35c52d6b84	Nguyễn Hữu Huy	TC41	Vắng học có lí do (1 tiết)	Vi phạm	0.25	0		11C4	2026-03-31 03:36:06.274+00
26d3084c-2b1a-4cde-a654-28de34a95b94	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	3c1120e0-4081-4a2f-a9ed-ce296b052ad4	Nguyễn Hoàng Minh	TC41	Vắng học có lí do (1 tiết)	Vi phạm	0.25	0		11C4	2026-03-31 03:36:25.92+00
284f3903-2f29-40e7-b1cb-cf186ec0191b	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	281424bc-c299-4c4e-8179-6e190ef1712a	Hồ Huy Hoàng	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-31 03:39:47.93+00
1a437020-9ee0-4fb2-a08f-4161baf2330f	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	355f918b-fc5b-4d55-aee8-7e3239dd1561	Phạm Nguyễn Nhật Linh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-31 03:40:05.839+00
2add5078-8b3f-4f0b-80b1-0971f1c515ec	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	a80f88a9-a190-4ab9-aa62-24ebb9a38e52	Siu Phương Linh	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-31 03:40:42.858+00
8493d5c9-ac9b-4efb-b970-5973d10036bf	2025-2026	HK2	28	Thứ 2	2026-03-30	11C4	10A11	42be00ab-855f-486f-9366-672190e46405	Võ Phước Nguyên	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C4	2026-03-31 03:41:07.209+00
50497e51-a89b-4a53-bcca-2ad5906038a7	2025-2026	HK2	28	Thứ 2	2026-03-30	11C7	12B6	daedc3c8-03de-4774-b82a-1a706032e2e0	PUIH H' NHE	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C7	2026-03-31 05:12:52.104+00
59311db3-d8d5-4aaa-ab02-7b16535e8f1a	2025-2026	HK2	28	Thứ 3	2026-03-31	11C1	10A8	1c25e82c-dbb5-45a7-b735-64effe1346fc	Đặng Thị Huyền Trang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C1	2026-03-31 06:32:54.167+00
b522b626-b5e8-46f6-8416-77de61a40d7d	2025-2026	HK2	28	Thứ 3	2026-03-31	11C1	10A8	1c25e82c-dbb5-45a7-b735-64effe1346fc	Đặng Thị Huyền Trang	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		11C1	2026-03-31 06:32:55.127+00
abcec142-8e2c-4dce-850e-571e73008745	2025-2026	HK2	28	Thứ 2	2026-03-30	11C8	12B7	f7c69ce2-07ac-4435-828a-477e445c053b	Nguyễn Thị Hồng Phương	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C8	2026-03-31 07:14:42.326+00
f35e0caa-9f80-4861-81f3-063e4f977fda	2025-2026	HK2	28	Thứ 2	2026-03-30	11C8	12B7	660e4094-17b4-4e26-adac-b064767c0ac4	Nguyễn Ngọc Vũ	TC44	Vắng học có lí do (4 tiết)	Vi phạm	1	0		11C8	2026-03-31 07:15:07.68+00
513692e8-8e84-40cd-b28b-e675291f8d46	2025-2026	HK2	28	Thứ 3	2026-03-31	12B6	11C12	d78a83dd-fcb3-4376-8aa0-bf1550182273	Trần Đăng Phong	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-31 09:36:48.315+00
4549aad1-f6f0-4c0b-927d-ea6776045e04	2025-2026	HK2	28	Thứ 3	2026-03-31	12B6	11C12	09a3934d-30bf-43e1-876f-04dbdf2badb5	Đặng Duy Quốc Quân	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-31 09:37:06.682+00
31ca2b6e-65b8-4ef3-9f12-2c2ba93b6459	2025-2026	HK2	28	Thứ 3	2026-03-31	12B6	11C12	9ab2b93a-25c6-4659-a188-a3fed4d2f066	Phạm Trần Anh Thư	TC45	Vắng học có lí do (5 tiết)	Vi phạm	1.25	0		12B6	2026-03-31 09:37:32.122+00
\.


--
-- Data for Name: doanvien; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."doanvien" ("id", "hoTen", "ngaySinh", "gioiTinh", "danToc", "doiTuong", "doanVien", "chiDoan", "ngayVaoDoan", "sdt", "thongTinThem", "updatedAt", "namHoc", "hocKy", "diaChi") FROM stdin;
2738080d-5571-4364-a757-d69e0363d5d1	Phạm Dương Anh	01/02/2010	Nữ	Kinh		f	10A1				2026-03-23 13:54:58.836+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai.
246793e9-faa6-43d4-b335-84cae58115d0	Phạm Văn Bé	10/04/2010	Nam	Kinh		f	10A1				2026-03-23 13:54:59.779+00	2025-2026	\N	Tổ dân phố 4,xã Đức Cơ,Tỉnh Gia Lai
5b191095-03b7-445b-a963-7f5c3f5501ca	Lương Thanh Bình	12/05/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:00.203+00	2025-2026	\N	Làng Đo,xã Ia Dơk,tỉnh Gia Lai
a988533a-3f49-4d1e-acbb-844ebde94a9c	TRẦN KHÁNH HÀ	02/01/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:00.699+00	2025-2026	\N	thôn Đoàn kết, xã iakla, tỉnh Gia Lai
89ba2ff9-f83a-4b79-9b86-50937270d5a7	Nguyễn Công Hậu	25/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:00.996+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
e00f63cd-2d29-4754-ab19-0dfc0ab1bbc0	Nguyễn Đức Hiếu	21/09/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:01.207+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
84b8a216-f2e2-4f0c-9a39-b862aaff69c6	Nguyễn Văn Hiếu	13/02/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:01.404+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
1c59013d-6cdc-455c-a302-8c22696290b5	Lê Thị Thúy Hoài	09/08/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:01.606+00	2025-2026	\N	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai
be0d20da-7373-4df8-ac9b-f8254fd9a510	Đinh Ngọc Khánh Huyền	11/02/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:01.828+00	2025-2026	\N	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai
29af0a1f-08f7-4fb8-8a2b-52d8c4d272cc	Phạm Quốc Hưng	25/09/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:02.073+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
11e3acab-c414-4201-941c-0e033a92e1c1	Đào Viết Khánh	29/06/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:02.293+00	2025-2026	\N	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai
fa234ec7-7623-4bc4-a39a-fc0b2cbfa007	Nguyễn Quang Kiên	08/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:02.45+00	2025-2026	\N	thôn Thanh giáo, xã ia Krêl, tỉnh Gia Lai
e584406d-7c4e-4293-bd76-b8f2dd881ad2	Nguyễn Khánh Linh	14/08/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:02.623+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
4ac2d9a8-965e-4be9-92ad-8d955f6c6aff	Nguyễn Phi Long	03/02/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:02.818+00	2025-2026	\N	thôn chư bồ,xã Ia Dơk, tỉnh Gia Lai
8856d7ab-23f7-443f-a534-5621d9f01da4	Trần Đức Lương	20/06/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:03.006+00	2025-2026	\N	Làng Ngo Rông , xã Iakrêl , tỉnh Gia Lai
68b2aa8f-74ee-4449-aa47-14cd38f166c4	Hồ Thị Khánh Ly	08/01/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:03.202+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
78e23220-89f7-4fa8-bc44-c97497df5638	Nguyễn Hoàng Bảo Minh	25/04/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:03.399+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
946c1b33-6b97-4141-81cb-0b2cca81f407	Hồ Thu Nga	13/01/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:03.586+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
584219b4-5a48-410f-b402-22394bc91417	Trịnh Thị Hằng Nga	28/06/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:03.769+00	2025-2026	\N	Thôn Thanh Giáo, Ia Krêl, Gia Lai
15a19231-0f54-4a0b-9dee-aa8e804f307e	Nguyễn Lục Ngạn	26/05/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:03.978+00	2025-2026	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai
07cd0fa4-8871-472e-86cb-d68931cd5b36	Lê Hoàng Mỹ Ngọc	01/10/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:04.163+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
a84eaed0-1ec4-4d44-a29f-39c9068eeeef	Lê Thị Bảo Ngọc	29/04/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:04.34+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
ae8f8a48-33e8-4c0c-aaf4-fc77bb19f856	Cao Anh Nhân	24/05/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:04.499+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, Gia Lai
d83a8584-e8a9-4277-bdfa-cd199e0484b1	Lê Võ Thanh Nhật	01/12/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:04.677+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
7cf81748-67c2-496a-bf4d-b1fa071231f9	Đặng Thị Thu Phương	04/01/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:04.848+00	2025-2026	\N	Làng Bua - IaPnôn -Gia Lai
44ce93f0-2a2d-454f-bf83-237ec0d77812	Đỗ Bảo Quang	05/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:05.024+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
3821debf-c40d-4c8f-8100-75fa775f5496	Hồ Hữu Quang	03/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:05.185+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
4b840e86-5a41-448b-bd32-6d8b046a6ee3	Hô Khắc Anh Quân	21/07/2009	Nam	Kinh		f	10A1				2026-03-23 13:55:05.337+00	2025-2026	\N	thôn Thanh giáo, Xã Ia Krêl, Tỉnh Gia Lai
dd43c4f3-52e3-4192-a82b-d0234833435a	Hồ Sỹ Quân	22/12/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:05.479+00	2025-2026	\N	Tổ dân phố 7, Đức Cơ, Gia Lai
10093c72-4764-4382-80c9-7737af9d3d52	Phạm Vũ Như Quỳnh	03/08/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:05.604+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
c34b9a51-278e-42b5-bc6e-208d4d2e19d4	Nguyễn Ngọc Lan Thanh	07/07/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:05.761+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai
6221facb-1157-4cac-8174-fc0c5bfc8408	Võ Hạnh Thảo	26/07/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:05.922+00	2025-2026	\N	thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai
40b1b2c1-40c9-4d16-b234-5c9720d029ca	Trần Hồng Thế	24/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:06.081+00	2025-2026	\N	Thôn Thanh Tân ,xã Ia Krêl, tỉnh Gia Lai
fc843970-1826-446e-a689-37df73d45ea3	Dương Đức Thịnh	05/07/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:06.259+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
1fb96135-f83d-4128-9caf-293eaa637322	Phan Ngọc Thịnh	02/02/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:06.413+00	2025-2026	\N	Tổ dân phố 9, Đức Cơ, Gia Lai
a84a2733-3aa4-4cd8-9cb1-782f0889943a	Bùi Thị Lý Thu	05/07/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:06.568+00	2025-2026	\N	Làng Bua - Xã Ia Pnôn - Tỉnh Gia Lai
e1406ae8-6c1b-4aa9-9ce9-266fa05076a9	Hồ Nguyễn Khánh Trang	02/09/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:06.719+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
401eb701-ba07-4abd-88d0-0560abb5b1b5	Hồ Thị Thùy Trang	22/05/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:06.888+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
28a6d925-adbe-41d6-972d-265e5d311f71	Lê Thị Thùy Trang	25/05/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:07.038+00	2025-2026	\N	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai
5c09ed4e-a1c1-4cb2-8344-d7776ca98b08	Nguyễn Thị Huyền Trang	11/09/2008	Nữ	Kinh		f	10A1				2026-03-23 13:55:07.17+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
e49e1985-ee03-4abd-9653-c6a56b694ac5	Nguyễn Trần Huyền Trang	10/08/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:07.311+00	2025-2026	\N	Thôn Lâm Tôk , xã Ia Krêl, tỉnh Gia Lai
9f6d8f34-861f-4c04-91b3-612fc568535c	Nguyễn Quốc Trọng	11/05/2010	Nam	Kinh		f	10A1				2026-03-23 13:55:07.475+00	2025-2026	\N	Tổ dân phố 1,xã Đức Cơ, tỉnh Gia Lai
8b8941ac-a221-4e94-8467-ab42ab71b371	Đoàn Tường Vy	11/04/2010	Nữ	Kinh		f	10A1				2026-03-23 13:55:07.606+00	2025-2026	\N	Làng Ngo le 1 - xã Iakrêl - tỉnh Gia Lai
8cb7283c-6910-4083-8ac9-37d95b0531c3	Lê Hồ Hoài An	28/10/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:07.744+00	2025-2026	\N	Tổ  3, xã Đức Cơ, tỉnh Gia Lai
9f841822-3ae7-465a-8d2a-956e0c5811a2	Lê Thị Hoài Anh	29/01/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:07.894+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
06ce04f2-60f8-4cbd-820b-b8c76ebe9e1b	Nguyễn Tuấn Anh	17/07/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:08.043+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
c2b90606-a3bd-4dd2-808c-9924e87f6e9e	Nguyễn Hoàng Đức Duy	26/01/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:09.56+00	2025-2026	\N	Thôn IaTang, xã ia Dơk, tỉnh Gia lai
9c9ecb1b-12eb-4751-a133-0e8982afc316	Đinh Thị Nhã Hương	09/08/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:11.336+00	2025-2026	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai
7a373ebb-80d6-41ba-b544-47d2c1fa6e26	Lê Dương Nhất Tâm	01/01/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:12.836+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
07a77fcf-a88e-4f7b-be11-99e15715aea6	Nguyễn Đình Tuân	21/12/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:14.436+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
1d2a3f7e-7575-47b4-b7fb-2bd5404d9390	Phan Anh Đức	12/10/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:15.912+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
113f7d38-43e3-40e8-9d3f-cb43e49f4c19	Trần Thị Thùy Linh	08/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:17.471+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
4d2f9aca-d97e-4ded-b623-7c8a99a56180	Trương Đình Cảm Thái	12/07/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:18.834+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
2fea2d65-3055-426e-b4d3-79574b757bda	Thiều Quang Vinh	20/11/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:20.206+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
59345d98-8db8-49db-8715-ffad9ad15fc6	Hà Tiến Đạt	07/04/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.574+00	2025-2026	\N	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai
bd4e72c9-25b0-433c-8c03-2c065a60430c	Lê Đình Lâm	03/02/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.884+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
e571d368-76ac-43ec-9c65-ea2bce2d34ce	Nguyễn Thị Như Quỳnh	2010-02-14	Nữ	Kinh		t	10A4	2025-04-20			2026-03-27 14:13:39.054+00	2025-2026	HK2	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai
7d08a62d-8d62-4b40-89f2-6dd270f5e8cd	Trần Quỳnh Anh	26/04/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:08.19+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
36c39979-f168-49c9-b7e2-a2a0645a86a5	Nguyễn Ngọc Quỳnh Dương	14/08/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:09.71+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
e242a7aa-fe62-4c10-be77-9266e32b1f4e	Phạm Lê Gia Linh	10/09/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:11.486+00	2025-2026	\N	Làng Bua, xã Ia pnôn, tỉnh Gia lai
f308b8a6-ff90-4132-8a9d-11b77594252f	Lê Đức Thành	11/05/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:12.983+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, Gia Lai
af16b771-2663-4be2-9026-e1cc9516d5af	Nguyễn Hoàng Vi	10/11/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:14.584+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
770ee9f8-5c9a-4b72-a069-793973423712	Lê Hương Giang	04/07/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:16.092+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
20595c3e-2ff0-4df7-b61a-fb772c8488cd	Võ Đại Mạnh	09/02/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:17.615+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
f3352c76-5f5c-4829-a220-fe4d16cd2229	Huỳnh Nguyễn Phương Thảo	01/10/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:18.968+00	2025-2026	\N	Xã Ia Dom, tỉnh Gia Lai
796b5f44-e506-42a5-be28-fd807e29d1cd	Nguyễn Quách Uy Vũ	23/02/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:20.345+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
fc8c0354-cd5f-4355-a755-2d0e86420c62	Đào Gia Đức	01/10/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.706+00	2025-2026	\N	Làng Khóp, xã Ia Krel tỉnh Gia Lai
5cc028da-9684-4853-9448-8a823fb94823	Bùi Ngọc Đạt	11/08/2010	Nam	Kinh		t	10A1				2026-03-24 14:06:17.546+00	2025-2026	HK1	Thôn Thanh Tân, IaKrêl, Gia Lai
9d2172ca-0a0f-449f-a804-4e25c1ac53d2	Quách Thùy Linh	2010-02-21	Nữ	Kinh		t	10A4	2025-04-25			2026-03-27 14:11:25.1+00	2025-2026	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
19c8028f-5cb3-4e99-a19d-00d5bdbdc55f	Lê Thị Thanh Ánh	05/04/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:08.347+00	2025-2026	\N	Làng Bua, xã Ia Pnôn, tỉnh Gia Lai
a34ccfed-b85d-4151-a0ab-b76982ae07af	Lê Đức Đạt	11/05/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:09.856+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
36b8dced-28ed-4030-8774-0f621f610dc3	Bùi Thanh Luân	14/02/2010	Nam	Mường		f	10A2				2026-03-23 13:55:11.636+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
2f4b812f-f627-4fb6-94e5-aa80c956815f	Võ Văn Thành	19/07/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:13.139+00	2025-2026	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai
b815bac1-88df-4457-a7d1-2778b12f5298	Hồ Xuân An	26/04/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:14.734+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
4cb8ed34-d57a-48d8-a0be-cffb08b5ce54	Hồ Ngọc Hậu	21/06/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:16.253+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
02c15e2b-18fe-49a0-8344-cf567335207c	Nguyễn Thảo Minh	04/02/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:17.794+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
b159d678-8ef4-437f-8eae-4d5cf5cc2310	Võ Thị Anh Thơ	06/09/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:19.096+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
7d9c6197-fe84-4a3c-8241-66682071789d	Bùi Thị Tường Vy	15/05/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:20.5+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
281a1c3f-9c02-42ed-9cac-67597edecdac	Bạch Thị Ngọc Hà	05/08/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:21.83+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
9d3933ae-a49e-4e06-8826-b22993b27254	Nguyễn Bảo Ngọc	11/03/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:23.141+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
d31c986b-f027-429b-894c-f9cd50a58549	Bùi Nữ Vy Oanh	16/10/2009	Nữ	Kinh		t	11C1				2026-03-25 14:49:24.681+00	2025-2026	HK2	Tổ DP4-  Đức Cơ- Gia Lai
87d1d9a2-0ee6-4170-81de-2623e88bfbfd	Nguyễn Quang Ánh	02/11/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:08.491+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
d24a4e71-72bb-416a-8a4f-0f3e085c74fb	Hồ Việt Đức	13/10/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:10.006+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
d8bec594-035e-49c8-b125-a82435fdcef6	Lê Ngọc Hoàng Minh	23/03/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:11.791+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
eb096b30-1fde-40bf-98f7-b568a81335b3	Hồ Diên Thuận	24/08/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:13.292+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
cc27c152-ea52-476e-8161-720823c00d8d	Nguyễn Trường An	03/05/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:14.872+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
50f7cc2a-ca1b-4f8b-af28-867aa433733f	Bùi Việt Hoàng	18/10/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:16.4+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
b20882b3-85db-4597-b470-f51b22e47384	Nguyễn Thị Kim Ngân	30/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:17.946+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
bf18b4a8-271f-4af6-adf5-a9ddb7d4758d	Trần Thị Thu Trang	09/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:19.256+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
1d3a2ecc-1252-4061-a547-3c70a1e3152c	Hồ Ngọc Trâm Anh	22/09/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:20.64+00	2025-2026	\N	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai
1465c63c-1e0a-4e99-9ffb-a85bceb97b9e	Hồ Ngọc Hải	29/09/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.962+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
95826f84-a0e6-40ac-85b4-170cad68fdfa	Nguyễn Thị Mai Ly	25/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:29.025+00	2025-2026	HK2	Thôn Ia Tang, Xã Ia Dơk, Tỉnh gia lai
b580585d-7a6e-4fd9-9778-60431fda6f4f	Võ Trần Bảo Ngọc	2010-10-03	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:12:35.995+00	2025-2026	HK2	thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
115bafb5-e235-42ff-b891-7524eeda0bf0	Phạm Lê Gia Bảo	27/05/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:08.627+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
df48ff9e-289f-4808-aca2-ce53e98e7636	Vũ Ngọc Trường Giang	18/01/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:10.408+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
bf0c774f-003e-4209-b74a-1136ac539a64	Đoàn Thị Trà My	10/09/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:11.933+00	2025-2026	\N	Thôn đoàn kết, xã Ia Dơk, tỉnh Gia Lai
a0756f44-7666-4630-8091-817caade21ec	Nguyễn Hoàng Anh Thư	26/03/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:13.437+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
8f6d3a9d-95cb-4afc-bf0d-fc59484e6446	Huỳnh Thị Ngọc Anh	13/01/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:15.019+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
26558ee4-886c-4ae7-97d6-7671a912c845	Mai Văn Nguyên Hoàng	23/09/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:16.535+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
249c1d91-6ea8-48c2-993c-d3dbad26be7a	Trương Nữ Kiều Ngân	12/08/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:18.077+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
e62b9ede-80c6-49f9-8e2d-9b7fdcc21bdb	Võ Ngọc Minh Trâm	14/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:19.413+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
ccc4ec59-ccdd-490e-9f6a-2d34cd9ebf2e	Nguyễn Đăng Hoàng	12/10/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.088+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
ea7fe20f-f7aa-4509-a14f-49e1d2e551a4	Nguyễn Thị Quỳnh Nhi	10/04/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:49.665+00	2025-2026	HK2	Làng Hrang- Xã Đức Cơ - Gia Lai
9eef5557-b6b6-41b4-8677-0a2839dfed77	Phạm Hà Anh	2010-01-23	Nữ	Kinh		t	10A4	2025-04-25	0901910680		2026-03-27 14:11:36.496+00	2025-2026	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
0de094dd-08c5-41ca-a4e8-397792be2146	Trần Đức Nguyên	2010-02-25	Nam	Kinh		t	10A4	2025-09-07			2026-03-27 14:15:24.839+00	2025-2026	HK2	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai
e77707e7-82aa-4b79-a8f6-063e23940912	Lường Thị Ngọc Bích	19/08/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:08.774+00	2025-2026	\N	Thôn Thống Nhất, xã Ia Krêl, tỉnh Gia Lai
e764c673-4004-414a-8436-1a9819a9b0ad	Nguyễn Hồ Thanh Hà	09/10/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:10.57+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
9397e2e9-1817-4a89-a00c-cebf2d8b2596	Đỗ Như Nguyệt	04/01/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:12.081+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
0b23ad7b-e7ab-4b4a-8b22-8f26d4faff8b	Võ Anh Thư	18/09/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:13.589+00	2025-2026	\N	Thôn Thanh Bình, xã Bàu Cạn , tỉnh Gia Lai
c50a8b3c-3a53-4912-b659-58e70eb88a2c	Nguyễn Thị Trâm Anh	14/04/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:15.169+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
ed708fb6-4fd9-410d-8e2a-22e9e36985df	Võ Đại Hùng	09/02/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:16.68+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
d049b2b3-79d5-493a-bc16-501641b99788	Hồ Đại Nghĩa	30/06/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:18.207+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
92a150b8-bf3f-4445-9c6a-749a7a83867f	Nguyễn Minh Trí	05/04/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:19.549+00	2025-2026	\N	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai
4df0a3a6-0766-4078-8b43-9ddc6b2c17c5	Vũ Thị Hà Anh	17/10/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:20.924+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
06f90b36-5d96-4bda-b6f1-f1af4165b58c	Nguyễn Tuấn Anh	2008-08-13	Nam	Kinh		t	12B1	2024-01-14	0984802579		2026-03-26 02:25:42.195+00	2025-2026		Thôn Đoàn Kết - Xã Ia Dơk- Tỉnh Gia Lai
98e8b3ec-e44c-41c5-95d2-7ff55b733aab	Nguyễn Đăng Huy	2010-10-12	Nam	Kinh		t	10A4	2025-09-07			2026-03-27 14:14:19.953+00	2025-2026	HK2	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
aa2880ce-9399-44f8-baec-4f268d9b5f8e	Hoàng Mai Nhi	2010-09-19	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:16:11.858+00	2025-2026	HK2	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
e460ae79-4e3f-485d-8de9-1ee3948d63e1	Đặng Bảo Châu	19/07/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:08.939+00	2025-2026	\N	Làng Dơk Ngol, Xã Ia Dơk, Tỉnh Gia Lai
1afd5843-c747-4ac5-91e8-9a55447d9e74	Đào Ngọc Hân	24/01/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:10.712+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
b5cda1d4-8ffd-4f1b-a819-1f90c7a94d4e	Hồ Thị Như	02/04/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:12.233+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
3ea20177-64c8-4a1d-ba98-8ef8f34e05cc	Đặng Việt Tiến	31/03/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:13.808+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
748672ab-1711-448a-b6f8-84d9c8b7617e	Hồ Nguyễn Khánh Băng	17/11/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:15.307+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
46e1df24-e9ca-4a12-afdb-0c14e3a73a49	Lê Thu Huyền	26/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:16.851+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai
47c43c11-227d-4043-85f1-b7c70f66ca8a	Lê Nguyễn Hồng Ngọc	29/06/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:18.335+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
93e6541e-8624-4fab-96df-4794ae743df4	Võ Huỳnh Trung	02/09/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:19.675+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
722083d2-e4c8-4b94-8f2d-ffd599eda079	Lê Thị Khánh Băng	16/01/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:21.06+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
2d173741-0f7e-45d5-9b45-a5cffe149bf4	Nguyễn Văn Huy	29/06/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.38+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
380cc84a-98c3-4e1c-a6c3-a23bc527ffc3	Hồ Thị Yến Nhi	20/02/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:23.677+00	2025-2026	\N	Làng ấp, xã Đức Cơ, tỉnh Gia Lai
1e83d23f-392d-4fd7-8e82-a78e68e5a837	Bùi Thùy Dương	2023-01-04	Nữ	Kinh		t	12B1	2023-03-26	 0346923157		2026-03-26 04:58:25.875+00	2025-2026	HK2	Tổ 1 - xã Đức Cơ - Tỉnh Gia Lai
f2df631c-9f4e-43b2-84a9-a6da661d2d43	Nguyễn Thị Kim Cúc	12/10/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:09.109+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
37cacdb2-2849-43d1-98b8-88e41d927a13	Lê Minh Hiếu	08/02/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:10.867+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
94712c43-fa81-4864-a3d7-42761c0adc97	Lê Quang Phú	02/07/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:12.377+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk , Gia lai
9c3e0bbf-9527-47f1-99fe-a6e513336bf1	Nguyễn Minh Trí	01/11/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:13.954+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
85a963dc-6a3c-4811-b815-de08c239759e	Kpuih Bân	06/09/2010	Nữ	Gia-rai		f	10A3				2026-03-23 13:55:15.454+00	2025-2026	\N	Làng Dơk Klăh, xã Ia Dơk, tỉnh Gia Lai
aa7dc6f9-3abb-41bf-b655-211a7422cbfd	Nguyễn Ngọc Lan	10/02/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:16.987+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
49053bc8-25a9-4ed1-b8b1-602e9712986f	Hồ Trần Gia Như	15/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:18.459+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
343806f3-38d5-4eee-a0c8-e03bab116d6b	Nguyễn Khắc Anh Tuấn	19/02/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:19.798+00	2025-2026	\N	Xã Ia Krêl, tỉnh Gia Lai
1c024700-02ac-4848-9dc6-4f4f6a9619ea	Hồ Anh Dũng	17/07/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.194+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
3f286083-cab9-437d-bf2e-a03f8037a771	Võ Đình Huy	17/05/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.506+00	2025-2026	\N	tổ dân phố 7, xác Đức Cơ, tỉnh Gia Lai
6591fe0f-abf3-45c5-a517-67d4ce0e8ca9	Hoàng Lâm Phú	05/10/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:23.798+00	2025-2026	\N	Làng Bi, xã Ia Dom, huyện Đức Cơ, tỉnh Gia Lai
9a559309-ee32-4ce3-a520-37eae6cf4ffb	Nguyễn Quang Thành Công	2008-09-04	Nam	Kinh		t	12B1	2025-11-30	0349995067		2026-03-26 13:09:12.324+00	2025-2026	HK2	Thôn Thanh Tân- Xã Ia Krêl- Tỉnh Gia Lai
9e08f249-67f9-4d25-b87f-b2cd2b62251c	Bùi Thị Thùy Dung	23/11/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:09.255+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
31727578-dc57-4d00-a22c-cc922f7d1a44	Hà Thị Kim Huệ	09/01/2010	Nữ	Thái		f	10A2				2026-03-23 13:55:11.028+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
15e62d70-9dbb-4016-8477-78a9043f38b9	Võ Hồ Thanh Phúc	08/06/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:12.526+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
71e6011e-b4f5-4911-a030-1e9576b0ec98	Đỗ An Triều	06/01/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:14.113+00	2025-2026	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai
aa00af45-c9d9-4706-9945-b5bbe9d95d5e	Vũ Thị Ánh Dương	15/03/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:15.605+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
5401ba01-e1d9-4fa0-af67-00e65f3f7ac3	Lữ Thị Mỹ Linh	20/12/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:17.143+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
d93394a4-180c-46b6-a1a9-9553553d5cef	Lê Thị Uyên Phương	29/08/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:18.584+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
4e843068-6823-458f-bdfe-bdd02bf4f551	Phạm Thị Anh Thư	02/11/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:19.933+00	2025-2026	\N	Thôn 3, xã Ia Krăi, Ia Grai, Gia Lai
bbb65f3f-7e4c-46b8-9689-ae63b0c642d2	Lê Quang Dũng	24/08/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.323+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
c34e4f5c-bd0d-45e0-b593-8a8ccb24fd70	Nguyễn Phùng Tuấn Hưng	08/09/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.629+00	2025-2026	\N	Đội 12, xã Ia Chía, tỉnh Gia Lai
a266e837-1b3a-459c-aea5-579a1bca14d0	Lại Minh Quang	12/12/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:23.931+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
8e9998ba-172e-4fa4-b27c-34997c86eabc	Nguyễn Ngọc Quỳnh Trân	2010-08-25	Nữ	Kinh		t	10A4	2025-09-07			2026-03-27 14:04:18.173+00	2025-2026	HK2	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
be7dae59-597d-4238-900f-7db6a96041f0	Hoàng Lê Trung Dũng	30/10/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:09.412+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
36b4252a-12b8-47ad-a6f7-667183471f44	Nguyễn Văn Quốc Hùng	03/02/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:11.174+00	2025-2026	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai
98afe58d-a8f2-48c6-a2d4-c1dc0226692c	Đinh Hồng Quy	22/10/2010	Nữ	Kinh		f	10A2				2026-03-23 13:55:12.692+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
065af969-9c0e-4797-b526-d5b68e6b03dc	Phạm Đức Trung	13/01/2010	Nam	Kinh		f	10A2				2026-03-23 13:55:14.282+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
78b2d801-dac6-46a8-8737-03cb694df53f	Lê Anh Đức	27/05/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:15.753+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
8af58bc3-1272-4b7e-9d96-6e19fa05a30b	Lương Võ Hà Linh	14/05/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:17.319+00	2025-2026	\N	Thôn IaTang, xã Ia Dơk, tỉnh Gia Lai
be946fd6-fd18-4346-b8e4-8cbde0fbdf5b	Nguyễn Ngọc Anh Quân	07/10/2010	Nam	Kinh		f	10A3				2026-03-23 13:55:18.712+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
27e5d9d6-db0c-4916-820a-1ab01c9ec1a3	Hồ Nguyễn Thục Uyên	16/06/2010	Nữ	Kinh		f	10A3				2026-03-23 13:55:20.066+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
8ccb7764-027b-4dd9-a6c5-afb4fe633e4c	Đỗ Viết Đạt	16/11/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:21.447+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
fca46968-183d-4bd3-901d-f6808854d653	Trần Đăng Khoa	28/12/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:22.76+00	2025-2026	\N	thôn Chư bồ 1, xã Ia Dơk, tỉnh Gia Lai
533a3d0d-8928-4e5f-bc47-2ac613cf80c9	Dương Thị Hồng Quyên	29/09/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:24.072+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
6dfbbb0d-3ccf-454a-9143-ea8168bffc0f	Hồ Văn Tài	22/02/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:24.347+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
e37d84d3-2c81-4ac6-88c4-6bc96a1408c6	Võ Lê Thanh Thảo	05/02/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:24.668+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai
abf18cb0-4618-4ddd-8481-68a23aa25d87	Võ Hoàng Ngọc Thiên	03/07/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:24.806+00	2025-2026	\N	Ấp chợ, Xã Thống Nhất, Tỉnh Đồng Nai
633de0c5-a190-4999-bf71-2d31a735f04d	Hồ Diên Thiện	30/08/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:24.952+00	2025-2026	\N	Thôn Ia Lâm, xã Iakrel, tỉnh Gia Lai
3db167b5-b445-4b1c-bc6f-d822b469efa9	Võ Huỳnh Thiên Thư	02/04/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:25.101+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
b09cd342-6338-4093-b09f-38d738914c21	Trần Trọng Tiến	09/11/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:25.279+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
d0a4a7c3-fd26-4238-b682-8250b456ec44	Võ Văn Tiến	01/01/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:25.45+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
911cf14c-aa32-46af-819e-66bef517ec66	Nguyễn Thị Thảo Trang	22/01/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:25.6+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
35221125-27d2-4995-9505-f106f0796480	Nguyễn Thị Thùy Trang	17/01/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:25.746+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
c0011a25-8d65-4fcd-8a40-ab05437d8cbd	Trần Văn Trọng	08/09/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:26.159+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
1cb8daea-2018-42a2-b902-a10df5c5fdd3	Nguyễn Huỳnh Như Trúc	27/02/2010	Nữ	Kinh		f	10A4				2026-03-23 13:55:26.293+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
bc56e160-4833-426f-a473-8d6eb2a531d6	Trần Đỗ Uy Vũ	23/03/2010	Nam	Kinh		f	10A4				2026-03-23 13:55:26.426+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
c1bbd11a-8ec6-4c27-9e85-b3410306e99e	Mã Quỳnh Anh	29/05/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:26.555+00	2025-2026	\N	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai
7af30e53-b4e2-4078-b78e-a96c991800ed	Nguyễn Thị Mai Anh	24/05/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:26.673+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
034f3566-f2c2-48a2-ab7a-b3f62cc48ec0	Nguyễn Ngọc Bảo Châu	03/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:26.814+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
2dfa3208-1704-4826-b43d-0c8db1de46cf	Rơ Lan Chun	31/10/2010	Nam	Gia-rai		f	10A5				2026-03-23 13:55:26.941+00	2025-2026	\N	Làng Sung le Kắt, xã Ia Dơk, tỉnh Gia La
7af1fbde-8e57-4fa2-bbdf-0bcbe99a3c94	Kpuih H' Han	11/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:27.066+00	2025-2026	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai
ef37eda6-8f8d-471b-9f0e-0b5eca5abc04	Nguyễn Thị Minh Hằng	01/01/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:27.209+00	2025-2026	\N	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai
8e4174b8-5675-4363-9157-65b538490ca1	Phạm Công Hậu	01/02/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:27.37+00	2025-2026	\N	Thôn Thanh Giáo. xã Ia Krêl, tỉnh Gia Lai
8e122d44-9380-4d31-a84e-9b7c903137ac	Võ Xuân Hiền	12/09/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:27.499+00	2025-2026	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai
fe271c35-24f8-4766-8c07-46d49790226b	Hoàng Thị Thu Hoài	02/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:27.642+00	2025-2026	\N	Làng Lung, xã Đức Cơ, tỉnh Gia Lai
517da195-7676-4682-8d99-58045e893918	Lê Đình Huy	24/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:27.774+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
79861eb9-1241-4584-a656-13de4216083b	Trần Thị Khánh Huyền	12/07/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:27.904+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
93e5d59a-78e0-47e1-8e86-d259c45c4109	Lưu Thị Phương Khanh	22/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.029+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
c5eea9f0-a1cc-42c4-a0c6-241f42f0fe9e	Phạm Ngọc Cao Kiệt	20/07/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:28.154+00	2025-2026	\N	Thôn Lâm Tôk, xã IaDơk, tỉnh Gia Lai
ce963ebe-989f-4412-b4cb-05e3d4eefb19	Kpuih H' Lăk	01/10/2009	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:28.303+00	2025-2026	\N	Làng Ghè, xã IaDơk, tỉnh GIa Lai
8ff162e9-e162-43dd-87d7-17e5b691d173	Rơ Mah H' Liên	05/07/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:28.426+00	2025-2026	\N	Làng Pong, xã IaDơk, tỉnh GIa Lai
73d5fb36-6389-4f4e-a6ce-fa44d7acfbf8	Bùi Thị Khánh Linh	05/09/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.545+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
ba9bbf15-6cb1-4feb-bbb5-a6546135e489	Đào Thị Thùy Linh	20/06/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.698+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
520b03c9-3846-4a10-be0c-405f6ce627c8	Hồ Thị Mỹ Linh	03/07/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.831+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
dd59b2e4-fbfb-43ba-ac01-5782da31b7a4	Lê Hoàng Kiều My	02/07/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:28.959+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
aeacc36d-49d3-49c4-b2ea-fd0dbf8751a3	Nguyễn Thị Tố Nga	04/01/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.347+00	2025-2026	\N	Làng Grôn,  xã Đức Cơ, tỉnh Gia Lai
587c35c2-af99-4659-a932-3afaf148e79d	Phan Văn Trọng	2010-04-28	Nam	Kinh		t	10A4	2025-04-25			2026-03-27 14:11:13.423+00	2025-2026	HK2	thôn Chư bồ 2, xã Ia Dơk, tỉnh Gia Lai
01f805eb-3449-4126-bcae-bfdf9f47e615	Nguyễn Hà Thảo My	03/02/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.083+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
3725c6a7-045e-448b-aa38-3e662a06c170	Trần Văn Thái	25/08/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:30.458+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
0135e0b3-c41c-4c70-b644-6ba204fcd6c0	Rơ Mah H' Trinh	19/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.871+00	2025-2026	\N	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai
0a5bb4bd-c7f5-466e-a6dd-1514c591ab6e	Lương Thị Hà Anh	25/12/2010	Nữ	Thái		f	10A6				2026-03-23 13:55:33.437+00	2025-2026	\N	Tỉnh Gia Lai
05c832b5-d3af-4f7f-9ec9-7c5f9c5bbc06	Lê Đình Khánh	30/07/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.893+00	2025-2026	\N	Làng Ấp, Đức Cơ, Gia Lai
fa45f554-b9fe-4224-b289-8c6e847ab4a0	Hà Như Ngọc	01/12/2010	Nữ	Mường		f	10A6				2026-03-23 13:55:36.35+00	2025-2026	\N	Đội 8, xã Ia Púch,tỉnh Gia Lai
652cccb3-c7fa-4fd8-8291-6fff01d86fb0	Lục Phương Thảo	18/01/2010	Nữ	Sán Dìu		f	10A6				2026-03-23 13:55:37.821+00	2025-2026	\N	Thôn Ia Mang, Iadơk, Đức Cơ, Gia Lai
6c786001-0a08-482b-8edb-2620f7fc358e	Vũ Hoàng Minh Tuấn	16/12/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:39.264+00	2025-2026	\N	Thôn Lệ Kim, Ia Dơk, Gia Lai
24ce332c-5cfe-4fe1-ae54-8b44bbfea345	Bùi Thị Thảo	05/12/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:43.821+00	2025-2026	\N	Tổ dân phố 9 , Đức Cơ, Gia lai
5ae36145-cbaf-410d-a420-e8374322777f	Rơ Mah H' Ury	10/01/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:45.279+00	2025-2026	\N	Làng sung Kắt - Ia Dơk -Gia Lai
78e8b072-41a3-42a5-bc32-e16b9249d0c3	Rơ Mah H' Hạ	18/10/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.773+00	2025-2026	\N	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai
fa5b96f6-1ba3-4529-9e39-d7ed1ace3fb9	Trần Doãn Kiên	20/06/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:48.256+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai
20cf3766-167c-44af-ac0d-1f6e6d15bbc7	Đỗ Bảo Nhi	13/10/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:49.765+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
5b7de434-c274-4b3b-a93b-d2a584da8fc2	Phan Thị Phương Thảo	21/09/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.247+00	2025-2026	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai
f94b2d91-a32f-4111-8bdb-58acf4b46ee7	Dương Bình An	08/02/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:52.722+00	2025-2026	\N	TỔ dân phố 7, xã Đức Cơ, Tỉnh Gia Lai
11e416e8-414f-47b0-bf87-b56a91e0c952	Võ Hữu Hoàng	28/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.247+00	2025-2026	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
acfddfbd-1b1b-4993-9abe-7eac7c4bebba	Trần Văn Mạnh	06/10/2009	Nam	Kinh		f	10A9				2026-03-23 13:55:55.829+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
47754fdb-ced0-4541-aa77-4795419a9e61	Rơ Mah H' Sarina	25/05/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:57.308+00	2025-2026	\N	Làng sung le -Iakla- Đức cơ - Tỉnh Gia Lai
97b33d21-a1d4-408d-903e-7ccd9355240c	Nguyễn Thị Cẩm Tú	10/03/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.848+00	2025-2026	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai
e21bf7b6-2fb6-4af6-bcc7-eaacf5877502	Cầm Trung Hiệp	14/11/2010	Nam	Thái		f	10A10				2026-03-23 13:56:00.358+00	2025-2026	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
3b816258-ea65-42e9-a577-a3a9b89005f8	Vi Thị Phương Linh	17/11/2010	Nữ	Thái		f	10A10				2026-03-23 13:56:01.983+00	2025-2026	\N	Thôn IaTang - IaKla - Đức Cơ - Gia Lai
225ff706-1178-49eb-b8f8-b3e2f537066e	Nguyễn Thị Diễm Phương	07/09/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:03.496+00	2025-2026	\N	Tổ dân phố 5,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
8b29ea93-06af-4f1f-b80b-7e9b6013aa96	Lương Quốc Trọng	16/11/2010	Nam	Tày		f	10A10				2026-03-23 13:56:05.068+00	2025-2026	\N	Làng Ấp, IaKriêng, Đức Cơ, Gia Lai
2a4eaedb-db81-4e0f-8647-bca8afd73444	Cao Trần Gia Bảo	21/09/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:06.476+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai
281424bc-c299-4c4e-8179-6e190ef1712a	Hồ Huy Hoàng	30/09/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:08.03+00	2025-2026	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai
a80f88a9-a190-4ab9-aa62-24ebb9a38e52	Siu Phương Linh	31/12/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:09.542+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai
5599cb8d-fb94-4661-b1df-586ac2a16e5b	Hồ Viết Sỹ	02/01/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.059+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
49f081a1-ab76-4e7a-81ae-b231b07258ab	Nguyễn Đình Gia Bảo	10/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.534+00	2025-2026	\N	Thôn Ialâm - Iakrêl - Gia Lai
496c7624-b8b2-4b61-a09c-2f8073354ca9	Lê Khánh Hằng	03/09/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.106+00	2025-2026	\N	Gia Lai
2837e1b3-0b3d-4fec-95ab-f2b4c51e3da2	Hàn Quốc Hải	13/02/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:48.349+00	2025-2026	HK2	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
ac731f7e-fcc0-4dc2-bf6c-55250be6e668	Lê Thị Thùy Linh	03/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:34.609+00	2025-2026	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
00b874e6-94b9-46d9-a3e0-6c37acba92f1	Trần Thị Tuệ Tâm	2010-05-03	Nữ	Kinh		t	10A4	2024-03-26			2026-03-27 14:07:20.702+00	2025-2026	HK2	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai.
2b7cb785-206f-4139-837b-b85e48d5c05e	Rơ Mah H’ An ne	09/12/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:29.221+00	2025-2026	\N	Làng Sung le Tung, Xã Ia Dơk, tỉnh Gia Lai
607c43b9-b919-4745-b012-34d35f90a31d	Hồ Thu Thảo	04/12/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:30.591+00	2025-2026	\N	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai
9fdcdc43-e228-4cf5-9f5b-fd0feab06445	Nguyễn Ngọc Trung	21/10/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:32.01+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
f7ec447c-444b-4d34-a18f-45ccda9dbab5	Nguyễn Hoàng Hân Di	22/12/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.574+00	2025-2026	\N	Tổ dân phố 7,Đức Cơ, Gia Lai
f1e5773a-d263-4bea-a200-c5066720380c	Nguyễn Duy Khánh	09/06/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:35.03+00	2025-2026	\N	Làng Krêl, IaKrêl, Gia Lai
2b9cbf01-35f2-48a4-b7a2-06afed784206	Nguyễn Thị Thanh Ngọc	28/04/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.494+00	2025-2026	\N	Thôn Thanh Tân, IaKrêl, Gia Lai
89f2e86a-684f-4a9c-80d7-0a4b85dc5655	Đậu Thị Anh Thư	01/02/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:37.971+00	2025-2026	\N	Ia Kăm, Ia Krêl, Gia Lai
3dc0af5f-c895-4875-a0a7-832f607356c8	Lê Thị Hạ Vy	04/11/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:39.446+00	2025-2026	\N	Hợp Nhất - Ia Hrung - Gia Lai
63aa427d-0d01-4be0-b195-6df7993dfc5d	Nguyễn Dương Thanh Hằng	24/08/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:46.917+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
330637d3-a201-4e5d-aaa2-18103c027e09	Rơ Mah H' Jin	26/02/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:48.416+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai
bc500fd0-3b26-4ed5-87e8-8e2f75bf92f7	Ksor Hà Nhi	01/01/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:49.923+00	2025-2026	\N	Làng Khóp, xã Ia Krêl, tỉnh Gia Lai
806645fe-43a6-4b84-8444-811c5a441f97	Hồ Hữu Thắng	16/01/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:51.394+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
e9b4b1a7-3183-414b-8ed7-8136589b472a	Lê Hoàng Anh	21/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:52.873+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
8e925e67-2d7d-4f06-a279-021264e559d6	Phan Lê Quốc Huy	06/03/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.398+00	2025-2026	\N	Thôn Đoàn Kết, Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai
38713c13-ce9a-4839-ae44-a86d7c5f58dc	PHẠM TRỌNG BẢO NAM	06/11/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.999+00	2025-2026	\N	Đội 15, Xã IA Púch, huyện Chư Prông
04e8f5ec-60dc-4a3e-bf56-fff17a704d14	Hà Ngọc Thành	13/08/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.454+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
ce7b2908-1bb8-47d1-84ae-8d094b7f950c	Phan Đình Tùng	21/10/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.994+00	2025-2026	\N	Tổ dân phố 7, Chư Ty, Đức Cơ, Gia Lai
340c7f3c-b4ab-4a86-abc6-6de0aa99025f	Nguyễn Khánh Hoà	10/08/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:00.499+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, huyện Đức cơ, tỉnh Gia Lai
bb25bc9d-8436-454d-8258-c55afeb98b01	Phạm Sỹ Hoàng Long	12/08/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.148+00	2025-2026	\N	Tổ dân phố 4,Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
702a03a5-1641-41ba-821f-7c0c4eb6e46b	Ngô Trí Quân	13/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.644+00	2025-2026	\N	Làng Kom Ngó, Ia Chía, Ia Grai, Gia Lai
c714c574-cb27-4cc8-ac81-f2da791c3816	Kpuih Trực	15/11/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:05.203+00	2025-2026	\N	Làng sung Tung - Ia kla - Đức Cơ -Gia La
eabf8f7d-1ae6-4fb1-b265-4388962e6855	Hà Phạm Gia Bảo	28/10/2010	Nam	Thái		f	10A11				2026-03-23 13:56:06.641+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
484c4026-0ae9-4cd1-a431-3e2bd3b52574	Lương Hoàng Huy	18/11/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:08.171+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
3c1120e0-4081-4a2f-a9ed-ce296b052ad4	Nguyễn Hoàng Minh	10/11/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:09.687+00	2025-2026	\N	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai
53d800b8-60af-4182-803f-7c1df4727525	Bùi Sinh Thái	08/01/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.205+00	2025-2026	\N	Thôn 9, Xã Chư Prông, Tỉnh Gia Lai
6ad01ada-5069-49d6-a871-bcb3dad3bb23	Phạm Ngọc Chính	14/01/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.708+00	2025-2026	\N	Sung kép - Ia Dơk- Gia Lai
3a05ebde-5b29-430d-b6f9-d3445b9418d9	Diêu Gia Hân	05/01/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.272+00	2025-2026	\N	Tổ DP9-  Đức Cơ- Gia Lai
5e0bb03a-1728-4bcd-b72f-4cca3ebf71be	Dương Bảo Hân	09/12/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:13.341+00	2025-2026	HK2	Tổ dân phố 4, Đức Cơ, Gia Lai
620bbc2a-94c9-419d-a8d7-2382be78ee42	Hoàng Bá Thiên	21/06/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:54.565+00	2025-2026	HK2	Làng Krêl- xã Krêl, tỉnh Gia Lai
a6b6c24c-77c9-438a-8d7e-04db8ef9129e	Lê Thị Phương Uyên	05/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:12.741+00	2025-2026	HK2	Tổ dân phố 7, Đức Cơ, Gia Lai
751f1c0c-404e-4f68-a602-416a9eb9332d	Nguyễn Thị Thùy Linh	28/11/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:38.675+00	2025-2026	HK2	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
f6ece7c2-5d91-4617-b820-a31ad8f60fb8	Hàn Thị Hồng Nguyên	15/10/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.472+00	2025-2026	\N	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai
5460c122-86f9-4911-bf06-7a6d115f3ada	Rơ Mah H' Thủy	26/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.871+00	2025-2026	\N	Làng Sung Kắt, Xã Ia Dơk, tỉnh Gia Lai
42209264-0932-4c06-b343-465180e61494	Kpuih H' Yên	08/06/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:32.316+00	2025-2026	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai
d5b7810b-6a0e-44ef-96d3-db6d170ae520	Lê Minh Hoàng	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:33.883+00	2025-2026	\N	Tổ dân phố 6, Đức Cơ, Gia Lai
ad304002-5d95-44c0-97ca-b6cc43b04c11	Nguyễn Văn Quốc Kiệt	10/10/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:35.325+00	2025-2026	\N	Tổ dân phố 6, Đức Cơ, Gia Lai
7eeec437-5229-4e15-b124-1039f3bc28c8	Kpuih H' Nhanh	24/07/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:36.785+00	2025-2026	\N	Làng Pnuk - Đức Cơ - Gia Lai
3786ad9f-9d14-4599-ab64-3d74e0b26799	Rơ Lan H' Thư	17/05/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.248+00	2025-2026	\N	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai
a7d48afa-ce1e-477b-af29-483b78df746c	Trần Thị Ngọc Huyền	11/04/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:41.263+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
0bb83554-85ff-49cc-a4af-ba7018051b5b	Rơ Châm Zaka	11/04/2009	Nam	Gia-rai		f	10A7				2026-03-23 13:55:45.722+00	2025-2026	\N	Làng Ấp, Đức Cơ, Gia Lai
a07d5e49-9d17-4b87-9873-e38e601f7184	Nguyễn Nữ Bảo Hân	15/06/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:47.21+00	2025-2026	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai
0e2c7021-8766-4858-a3fa-09eb82929180	Rơ Lan H' Khuyên	30/09/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:48.722+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai
e82bd0e6-4828-441c-9285-150405ae12e0	Lường Thị Kiều Oanh	03/03/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:50.204+00	2025-2026	\N	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai
7d0f9a2f-a165-40d4-97ea-c49abf025882	Rơ Mah Phạm Thị Thương	21/05/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:51.691+00	2025-2026	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai
7d1efe29-8015-410a-adae-dd9745b4a204	Nguyễn Xuân Anh	21/01/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:53.143+00	2025-2026	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
7b879a48-c03d-4b4d-b1ca-9bc25488a544	Khuất Anh Khoa	07/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.701+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
22eb3de1-f12b-4cc2-b037-cdf54f66da58	Rơ Mah H' Ngiêt	17/03/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:56.281+00	2025-2026	\N	Làng Khóp, xã Ia krêl, Đức Cơ, tỉnh Gia Lai
e48eacfc-c1dd-46a9-8ff7-968d8b061b69	Vũ Thu Thảo	28/10/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:57.747+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai
c0071337-e27c-405a-a40d-7c8a2ede3f52	Nguyễn Hồng An	20/02/2010	Nam	Kinh		f	10A10				2026-03-23 13:55:59.32+00	2025-2026	\N	Thôn Chư Bồ I, IaKLa, Đức Cơ, Gia lai
3a2e075b-3a93-42ca-a0ea-261f0abac7dd	Lê Bảo Nam	01/10/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.458+00	2025-2026	\N	Làng Dơk Ngol, Iadơk, Đức Cơ, Gia Lai
5988f370-49b7-4e81-877a-da653534429e	Trần Đức Quân	19/04/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.973+00	2025-2026	\N	
cdaf652c-09f1-4085-8a32-c336b3c357c1	Lê Văn Tuấn Tú	19/03/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.471+00	2025-2026	\N	Thôn Iakăm, xã Ia Krêl, huyện Đức Cơ, tỉnh Gia Lai
0a09fa25-7832-4a1d-840a-c72e33c006d9	Nhữ Thị Kim Dung	27/03/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.982+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
ce6b3764-acc6-4ce5-be3c-0d07348043d3	Lê Thị Lưu Huyền	28/06/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:08.49+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
d19db5f1-d49c-4dfb-bc37-0204f352cf69	Nguyễn Văn Bảo Nam	24/11/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:10.005+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
6de24c68-5bfc-4de1-a3c6-faacb7d8b734	Kpă Tiếu	05/08/2009	Nam	Gia-rai		f	10A11				2026-03-23 13:56:11.493+00	2025-2026	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai
d5796adb-c619-45a5-a17b-2421cec8f5b2	Đào Tuấn Duy	29/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.016+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
325281bf-30ea-42c9-a403-10b78c097fd3	Lê Phạm Công Hiếu	10/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:14.612+00	2025-2026	\N	Tổ DP2-  Đức Cơ- Gia Lai
09715ed6-1cc0-4b81-acbb-2a662311e84a	Đoàn Thị Ngọc An	02/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:40.036+00	2025-2026	HK2	Ia Tang, Ia Kla, Đức Cơ, Gia Lai
a34d6ef6-c720-46c2-8fe1-55b71db8eb5a	Lê Thị Trà My	21/09/2010	Nữ	Kinh		t	10A7				2026-03-26 02:30:42.286+00	2025-2026	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
6297eb0b-b110-4015-a2dc-504b9469fa58	Nguyễn Lê Bảo Thư	26/10/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:09.199+00	2025-2026	HK2	Làng Sung Kép, xã Ia Dơk, Gia Lai
25e5014b-fbcd-4048-a014-dca960c95cda	Dương Thị Như Nguyệt	14/11/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:29.601+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
75ee1dc8-6fe0-4a85-bac5-94e61d7523ad	Trần Vũ Anh Thư	16/06/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.037+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
c1425aff-8437-42a1-8e40-96f4e974ed3e	Trần Thị Bảo Yến	27/12/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:32.541+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
6d58bd2e-43b3-405c-b79d-78c548e24243	Nguyễn Việt Hoàng	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.05+00	2025-2026	\N	Tổ dân phố 7, Đức Cơ, Gia Lai
eaf87147-67a0-479e-94fe-6303294ea8fe	Bùi Thị Mỹ Linh	11/05/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:35.459+00	2025-2026	\N	Tổ dân phố 7, Đức Cơ, Gia Lai
a5cb860e-7aa8-4aac-bbd6-64f63e2407ef	Nguyễn Ngọc Bảo Như	04/11/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.93+00	2025-2026	\N	Làng Krêl, Đức Cơ, Gia Lai
21ffd761-624b-42d8-bacb-af6c8d43495d	Trần Anh Thư	24/10/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:38.391+00	2025-2026	\N	Tổ dân phố 7, Đức Cơ, tỉnh Gia Lai
88504133-610c-4051-8b97-1d0cf3b3ab59	Lê Thị Thu Hương	24/01/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:41.408+00	2025-2026	\N	Làng Krêl - xã Iakrêl - Gia Lai
facf8dd1-963a-417b-b0de-e5b54f3c3798	Nguyễn Ngọc Anh Thư	29/01/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.406+00	2025-2026	\N	Tổ dân phố 3, Đức Cơ, Gia Lai
bc027983-4c3d-4fae-99aa-4a47e44d4f53	Vũ Ngọc Bảo Anh	11/09/2009	Nữ	Kinh		f	10A8				2026-03-23 13:55:45.869+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
a7477a2a-d6b0-48e9-b823-19debca63f3d	Nguyễn Đình Hiếu	08/09/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:47.358+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
981e130a-3ab5-4493-a4ec-ef9d54a0b0ad	Ngô Thị Kim Luân	10/08/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:48.881+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
e63bd1f8-fdbc-4e22-a40f-2ecd024d37f9	Rơ Lan H’ Rubin	07/08/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.365+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
0271c9a4-ab62-4151-8b75-2ed7e6e7a7d6	Nguyễn Duy Tiến	25/07/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:51.831+00	2025-2026	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai
88172d2b-aad4-4851-8143-7e5292096469	Rơ Lan Anh	04/04/2009	Nam	Gia-rai		f	10A9				2026-03-23 13:55:53.306+00	2025-2026	\N	Làng Krai, Ia Kiêng, Đức Cơ, Gia Lai
393b79bc-53a7-47bd-b9c4-849109a54fc1	Nguyễn Trọng Khoa	01/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:54.926+00	2025-2026	\N	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
35e49996-cbdf-48eb-bec7-2c198cc3e92f	Kpuih Nguyên	19/01/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:56.421+00	2025-2026	\N	Làng Trolđeng, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
963dddec-f485-4c50-9bd5-5727ef315649	Bùi Sỹ Thắng	04/05/2008	Nam	Kinh		f	10A9				2026-03-23 13:55:57.924+00	2025-2026	\N	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai
00134d7c-aabf-44c6-bc27-353ce5bcc464	Rơ Lan H' Hường	27/04/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:00.974+00	2025-2026	\N	Làng Sung Tung, xã IaKla, huyện Đức Cơ, Tỉnh Gia Lai
b945aae9-3222-4b9e-9263-8ff0e0d07eae	Phạm Quang Nam	02/01/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:02.6+00	2025-2026	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
b4d26962-fb8a-4d54-b718-f51b6909c227	Kpuih H' Quế	28/11/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:04.106+00	2025-2026	\N	Làng Trol Đeng, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
6d8b28de-318f-4c20-b323-1bb23a261524	Rơ Mah H' Viên	06/02/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:05.603+00	2025-2026	\N	Làng Pong, Ia Dơk, Đức Cơ, Gia Lai
8d8f6a71-1666-4a3d-befa-af9af1d1912d	Kpuih H' Dương	18/08/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:07.138+00	2025-2026	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai
d7c94e81-ebeb-478a-b7a6-9707e4468be5	Rơ Lan Khàng	11/02/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.646+00	2025-2026	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai
d52fbbbe-e6c4-449e-97e2-7f30a28bc43a	Rơ Mah Nguyên	17/12/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:10.154+00	2025-2026	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia lai
eb5a9e9c-8963-43cb-84c7-2320b5d5d2e1	Nguyễn Vĩnh Triều	04/12/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.654+00	2025-2026	\N	Thôn Ia Kăm, xã Ia Krêl, tỉnh Gia Lai
fc500ba6-ee21-4836-8b5c-4bef5884d606	Nguyễn Nhật Duy	02/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.169+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
e11a1aa2-b221-4dcc-bb4e-baa788094843	Lê Thị Ánh Hồng	03/08/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.758+00	2025-2026	\N	Tổ DP2-  Đức Cơ- Gia Lai
0ecb07cf-4366-4c57-a15d-de80da19eb1c	Bùi Gia Bảo	17/09/2010	Nam	Kinh		t	10A7				2026-03-26 02:29:01.263+00	2025-2026		Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
38bfddd0-f935-46f8-af19-1d4516871268	Nguyễn Minh Nguyệt	14/11/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:18.598+00	2025-2026	HK2	Tổ dân phố 4, Đức Cơ, Gia Lai
7de07f3b-d7ec-4664-a987-0110f00955a8	Nguyễn Thị Quỳnh Như	11/06/2010	Nữ	Mường		f	10A5				2026-03-23 13:55:29.769+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
4d471811-0f1b-48d6-85ba-5f1661e1a20d	Rơ Măh Thương	02/11/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.186+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, tỉnh Gia Lai
9b522a06-2aa3-4f33-b6ca-dfa21cd25c79	Trương Thị Hồng Yến	27/08/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:32.691+00	2025-2026	\N	Thôn Thanh Giáo, xã IaKrêl, tỉnh Gia Lai
03af4e5f-43fe-4ef4-a4cf-0e4fcf1b7209	Nguyễn Thị Hồng	21/09/2009	Nữ	Kinh		f	10A6				2026-03-23 13:55:34.197+00	2025-2026	\N	Làng Krai, Đức Cơ, Gia Lai
ceeb18db-609b-417b-befc-135d9c318197	Rơ Mah Thị Thanh Mai	14/08/2009	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.599+00	2025-2026	\N	Làng Ghè, Xã Ia Dơk , Tỉnh Gia Lai
2577d390-a4d5-4cb0-8b24-dbad6f96f707	Đinh Nhương	26/11/2010	Nữ	Ba na		f	10A6				2026-03-23 13:55:37.079+00	2025-2026	\N	Làng Pnuk, xã Đức Cơ, Gia Lai
482853b8-16e1-4058-85ad-0fa6c01c634d	Rơ Lan H' Thương	27/10/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.539+00	2025-2026	\N	Làng sung Le - Ia Dơk, GIa Lai
611ecdac-8c20-446a-bd82-709803d23ce7	Siu H' Xim Bi	13/03/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.037+00	2025-2026	\N	Làng Sung kép , Xã Ia Dơk, Gia lai
b08c1dba-7943-4041-a3de-dee86a86687d	Lê Hữu Khang	13/07/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:41.554+00	2025-2026	\N	Làng Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai
c00eacf3-4684-457c-82ac-50555ebcb978	Kpuih H' Nhuy	04/11/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:43.07+00	2025-2026	\N	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai
bf0acbcb-0831-4ded-b1ad-9a2f34b60a6f	Trần Thị Thu Thủy	27/10/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.554+00	2025-2026	\N	Thôn Lệ Kim , xã Ia Dơk, tỉnh Gia Lai
609124df-b7e1-4c07-a60a-94b814993c40	Nguyễn Sỹ Thế Bảo	17/10/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:46.03+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
61561ed7-3041-4a72-ab63-691bb6bdc351	Trương Văn Hiếu	06/05/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:47.512+00	2025-2026	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai
71090bf5-4da7-40e3-9615-2903bce8496f	Nguyễn Thị Ly Ly	02/12/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:49.019+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
ce6e5faf-0dd4-4212-b4a8-de0d4e7038d1	Kpuih Sái	09/11/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.505+00	2025-2026	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai
1c25e82c-dbb5-45a7-b735-64effe1346fc	Đặng Thị Huyền Trang	17/04/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.985+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
272370da-8369-404a-b8d8-c60da9269abc	Lương Thị Ngọc Ánh	07/09/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.458+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
502a342f-9384-4302-9978-f230df716068	Bùi Hữu Kiên	19/01/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.07+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, Gia Lai
9c2040f6-0dd0-4d32-b694-fba05587f50f	Hồ Trọng Nhật	18/05/2009	Nam	Kinh		f	10A9				2026-03-23 13:55:56.564+00	2025-2026	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
d48bcd7f-4adc-409c-a0d4-054cdf29788f	Rơ Lan H' Thư	12/10/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:58.073+00	2025-2026	\N	Làng Sung Le Tung, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
b3e79ebf-d3d9-42f9-a0d4-ae6e3ba1eddd	Siu H' Beo	19/02/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:55:59.618+00	2025-2026	\N	Làng Krai, Iakriêng, Đức Cơ
6231ecca-15a1-440b-bf1e-43763213fde8	Võ Trần Gia Khánh	31/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.127+00	2025-2026	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
d0364fbd-f5f0-4ee1-b259-db4b795707ad	Nguyễn Hoàng Bảo Ngọc	17/07/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:02.761+00	2025-2026	\N	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
53b06f76-6f6d-4bcf-b19f-3ff7bd8890dc	Lê Đình Tài	23/11/2009	Nam	Kinh		f	10A10				2026-03-23 13:56:04.252+00	2025-2026	\N	Tổ Dân Phố 1 Chư Ty , Đức Cơ , Gia Lai
d9ba578d-620d-440e-a811-ae60582078e9	Phan Quốc Vương	08/03/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.728+00	2025-2026	\N	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai
ba70cbec-b12f-446e-b874-59f019865db9	Rơ Lan Điệp	14/06/2009	Nam	Gia-rai		f	10A11				2026-03-23 13:56:07.278+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
8b711101-381f-4ab5-82a1-f136830840c4	Rơ Lan A Khiển	11/07/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.796+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
42be00ab-855f-486f-9366-672190e46405	Võ Phước Nguyên	20/07/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.293+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
1177883b-bf16-41fc-97f8-3c05a483c3a9	Hồ Sỹ Tuấn	07/06/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.8+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
47e0d6fb-4a01-48e2-99c4-5429de21489b	Bùi Thị Thùy Duyên	01/01/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:13.317+00	2025-2026	\N	Tổ DP6-  Đức Cơ- Gia Lai
6b4f82da-2380-4c71-bcb8-390bf4ced282	Lê Quang Khải	25/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:14.906+00	2025-2026	\N	Tổ Dân Phố 6, Đức Cơ, Gia Lai
2410031d-4e67-4e33-9616-e0b05711c51a	Ksor H' Za Ni	21/10/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:29.9+00	2025-2026	\N	Làng Sung Kép, xã Ia Dơk tỉnh Gia Lai
ca10d869-943a-4d54-a0a4-3df254ea6db6	Đinh Thị Thùy Trang	24/10/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.335+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
70a98b39-a6bd-435e-ab45-c866831726ac	Lê Hồ Lan Anh	22/02/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:32.846+00	2025-2026	\N	Thôn Thanh Giáo - xã Iakrêl - Gia Lai
e497a6c5-6938-4807-9d2e-d9dc0690da97	Hồ Viết Tường Huy	18/10/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:34.334+00	2025-2026	\N	Thôn IaMang, xã IaDơk, tỉnh Gia Lai
363aa6a3-5fc3-4342-af41-46bdf215e459	Rơ Châm H' Mẫn	20/09/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.744+00	2025-2026	\N	Làng Pong, IaDơk, GIa Lai
e84e5bf8-1c66-48b5-9965-42f5062c9a13	Nguyễn Thị Như Quỳnh	22/05/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:37.22+00	2025-2026	\N	Thôn Iamang, IaDơk, Gia Lai
600a84d8-4f96-44e1-80a5-29f9d808ba03	Rơ Châm Vũ Bảo Trang	17/11/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.675+00	2025-2026	\N	Làng Ngo Le 1 - Ia Krêl - Gia Lai
c5300675-c6cc-473a-b29d-444bb840c78b	Trần Văn Khánh	29/06/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:41.704+00	2025-2026	\N	Thôn Lệ Kim, Xã Ia Dơk, Tỉnh Gia Lai
b964e3a3-692b-47a9-bc19-80c4ad5f2a34	Nguyễn Thị Diệu	22/02/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:46.177+00	2025-2026	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai
c5208b0f-3302-4323-9f99-e4b566bda949	Trần Đức Hoàng	06/08/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:47.668+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
91853786-4884-4a5e-af28-46253012dc9d	Phạm Gia Minh	23/07/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:49.168+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
0e19d0ff-492c-46f5-8431-80583c879093	Kpuih H' Sen	28/04/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.646+00	2025-2026	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai
f9b78ac9-aa13-41ac-b895-39fd64eef05f	Mai Giang Tuyết	02/11/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:52.118+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
2833fa4c-c043-4259-9ff2-ed20f4853874	Mai Thị Anh Đào	14/03/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.636+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
87a4a611-8036-416e-82e5-df585f7337a1	Nguyễn Tuấn Kiệt	06/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.21+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
26a78d3d-69d3-47e3-8812-ab57d45cf66e	Mai Võ Yến Nhi	23/08/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:56.695+00	2025-2026	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
805a2617-0b7d-4756-b5ff-509ba9914bdb	Đào Nguyễn Lâm Tiên	29/12/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.223+00	2025-2026	\N	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai
378b06c1-76c4-4249-a2fc-7a7a54dac4e8	Nguyễn Vũ Tuấn Kiểm	06/01/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.278+00	2025-2026	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
e9ec14d0-c297-4bc9-8c0f-cfc7ca120a70	Rơ Mah Xâm	28/09/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:05.871+00	2025-2026	\N	Làng sung kép 1 - Iakla -Đức cơ -Gia Lai
dae1df7d-722f-4ab8-b094-0b166d3e6d01	Ksor Đinh Đức	24/08/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:07.428+00	2025-2026	\N	Tổ dân phố 8, xã Đức Cơ, tỉnh Gia Lai
1e5628b0-5f33-4f9f-8f39-1267747e100a	Kpuih Khruin	20/11/2010	Nam	Gia-rai		f	10A11				2026-03-23 13:56:08.945+00	2025-2026	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai
811f25f1-4531-41af-8d56-90e3998e1445	Ngô Quang Nhật	01/09/2009	Nam	Kinh		f	10A11				2026-03-23 13:56:10.444+00	2025-2026	\N	Thôn Ia Mút, xã Ia Dom, tỉnh Gia Lai
c26e5e5d-18df-4300-8883-40e40a0b0bbf	Tống Minh Tùng	20/05/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:11.934+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
99ba8b45-b1cb-4254-92a8-319e8bdabe80	Nguyễn Tấn Đạt	26/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.466+00	2025-2026	\N	Tổ DP4-  Đức Cơ- Gia Lai
9c614028-1d47-43fd-8c4b-6adcc0f9ed84	Nguyễn Đức Nhật Khánh	01/09/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:15.061+00	2025-2026	\N	Tổ DP6- Đức Cơ- Gia Lai
9208ea3b-7eca-421c-80d3-20a8adf4fbd3	Nguyễn Thị Bích Ngọc	08/09/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:32.856+00	2025-2026	HK2	Xã Ia Kla, Huyện Đức Cơ, Tỉnh Gia Lai
4f0e3907-85bb-47ef-828e-a64c36d16ac2	Nguyễn Thị Hồng Thắm	07/08/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:41.743+00	2025-2026	HK2	Xã ia chía, Huyện Ia grai,Tỉnh gia lai.
14190fb8-bfa9-4aee-b881-d1e7f8b24017	Kpuih Y Lan Tina	05/02/2010	Nữ	Gia-rai		t	10A7				2026-03-26 02:30:05.379+00	2025-2026	HK2	Làng Ghè, Ia Dơk, Gia Lai
d684d7d6-a3e5-493d-bc9a-2ff67a1b152f	Phạm Khánh Chi	19/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:32:25.744+00	2025-2026	HK2	Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai
3055501c-c63a-44ba-82c7-06a94c85531d	Siu En Ny	28/02/2010	Nam	Gia-rai		t	10A7				2026-03-26 02:32:53.47+00	2025-2026	HK2	Làng Lung Prông, xã Đức Cơ, Gia Lai
2167f676-0c33-487c-bfa2-5b83891393b4	Phạm Thị Oanh	18/10/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:30.044+00	2025-2026	\N	Thôn Chư Bồ, xã Ia Dơk, tỉnh Gia Lai
c644dc1a-321f-4b1e-be34-06b59e3e41eb	Hồ Thị Huyền Trang	26/03/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.472+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
2eb12ec5-33c1-46f5-91a0-d27f32f3c5dd	Lê Thị Mai Anh	03/08/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.022+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl,tỉnh Gia Lai
cc6c26cb-603c-4360-9ff5-9489e8f7e092	Hoàng Thị Thanh Thanh Huyền	24/03/2010	Nữ	Mường		f	10A6				2026-03-23 13:55:34.461+00	2025-2026	\N	Tổ dân phố 2, Đức Cơ, tỉnh Gia Lai
b2d8bc5d-1bd5-4ffa-8461-dad6b9397750	Nguyễn Hoài Diễm My	24/09/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:35.895+00	2025-2026	\N	Tổ dân phố 7, Đức Cơ , Gia Lai
18147bfc-4b50-4603-bd51-82f472b8b89e	Rơ Mah Y H’ RiLa	28/04/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:37.362+00	2025-2026	\N	Làng sung le - Ia Dơk- Gia Lai
edbb473d-8a68-4d71-841a-bed34215f321	Ksor Nguyễn Tráng	29/04/2010	Nam	Gia-rai		f	10A6				2026-03-23 13:55:38.828+00	2025-2026	\N	Làng Mới, Xã Ia Dơk , Tỉnh Gia Lai
65f8c316-e7d9-40b3-a21d-ae7f9e984cae	Ksor H' Giang	23/11/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.315+00	2025-2026	\N	Làng Pnuk, Xã Đức Cơ, GIa lai
606bf350-60cb-4191-a732-3d01732c4b79	Mã Văn Kiệt	11/12/2010	Nam	Tày		f	10A7				2026-03-23 13:55:41.859+00	2025-2026	\N	Làng Grôn, xã Đức Cơ, Gia Lai
7769404a-0af8-40f3-a5ba-ee9c819e3e3d	Rơ Mah H' Đa	15/09/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.323+00	2025-2026	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai
9dfab549-5dab-499a-8f02-eeec88e0dfbc	Nguyễn Lê Thu Huyền	13/11/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:47.816+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
516b8cfa-f3b3-4783-899d-04640f486b9c	Đoàn Văn Nam	22/03/2009	Nam	Kinh		f	10A8				2026-03-23 13:55:49.332+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
a23ccfd6-a018-4fdb-b28e-f22020c8b4d0	Rơ Lan H' Siu	13/09/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.791+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
6889527e-19fa-4bfd-a062-4bf22e4dd559	Kpuih H' Uyên	29/06/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:52.263+00	2025-2026	\N	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai
dbc07e68-5e68-41e9-a16c-eed1bf066a53	Kpuih Hải	02/04/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:53.778+00	2025-2026	\N	Làng Lung Prông, Iakriêng, Đức Cơ, Gia Lai
58186ebc-f6db-4a3b-9086-a13e781e8d5a	Đặng Hồ Phương Linh	30/07/2009	Nữ	Kinh		f	10A9				2026-03-23 13:55:55.363+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
4e5c248d-3ad9-4562-9af2-fdb65705b2a1	Nguyễn Đình Phong	15/10/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:56.857+00	2025-2026	\N	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
cec84b70-24ae-43a7-b5de-a091b4f2bd5c	Nguyễn Song Toàn	07/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.382+00	2025-2026	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
84240a86-2f2a-42a9-af81-19b48208a478	Nguyễn Đinh Ngọc Duy	26/10/2010	Nam	Kinh		f	10A10				2026-03-23 13:55:59.905+00	2025-2026	\N	Thôn Păng tul - Ia Dơk - Đức Cơ Gia Lai
6538c9ab-9f9c-42f5-afd3-c52c75ade10f	Kpuih Kiệt	26/02/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:01.438+00	2025-2026	\N	Làng Grôn, IaKriêng, Đức Cơ, Gia Lai
6f06a0f9-d009-4090-8049-dc32c3f3a07c	Phạm Thị Như Ngọc	07/09/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:03.074+00	2025-2026	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
20003609-c70d-43c3-9ed7-9c61d26c0f75	Nguyễn Xuân Thắng	03/06/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:04.593+00	2025-2026	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
5f14efd2-4b32-43ed-90a7-edbe2f2a8382	Lê Thị Mai Anh	19/12/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.031+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
e7cf006a-25fc-44f5-abcf-3ea659785d13	Nguyễn Thị Khánh Hà	02/09/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.58+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
9ed00fda-679e-440e-b5bf-9fc7886528d2	Cao Thục Khuê	14/07/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:09.099+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
47303f97-6e00-41da-bc9f-e31767d56a99	Hồ Hữu Minh Phong	04/05/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.6+00	2025-2026	\N	Làng Ấp, xã Đức Cơ, tỉnh Gia Lai
642ec80c-f1dd-4bc3-bb7d-d5a3c171b6ee	Hồ Thị Lan Anh	29/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:12.085+00	2025-2026	\N	Tổ DP6- Đức Cơ- Gia Lai.
d16094e7-0513-4943-94c1-46dbdd154297	Nguyễn Hải Đăng	29/07/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.624+00	2025-2026	\N	Tổ DP2- Đức Cơ- Gia Lai
d0813061-cd90-44a6-8d18-72e1f8cfbbfd	Nguyễn Phạm Phương Linh	06/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:15.21+00	2025-2026	\N	Tổ DP1- Đức Cơ- Gia Lai
129dcd98-2afa-4224-afc3-153982a9e9a9	Lê Viết Tình	24/01/2010	Nam	Kinh		t	10A7				2026-03-26 02:30:53.953+00	2025-2026	HK2	Làng Krêl, xã Ia Krêl, Gia Lai
818e187b-dbc1-4a49-b4a2-8057d1677415	Rơ Mah H' Quỳnh	22/04/2010	Nữ	Gia-rai		t	10A7				2026-03-26 02:32:47.175+00	2025-2026	HK2	Làng Hrang, Đức Cơ, Gia Lai
46fd5316-a304-4dfa-bac6-f28977556841	Mai Tiến Quân	19/04/2010	Nam	Kinh		f	10A5				2026-03-23 13:55:30.188+00	2025-2026	\N	Làng Krai,xã Đức Cơ, tỉnh Gia Lai
5b2dc503-d8ce-4fda-8da8-01ae238322dc	Hồ Thị Ngọc Trang	20/03/2010	Nữ	Kinh		f	10A5				2026-03-23 13:55:31.606+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
aee77de4-b1e8-48dd-98d2-93d72ebb17ff	Rơ Lan Anh	02/12/2009	Nam	Gia-rai		f	10A6				2026-03-23 13:55:33.17+00	2025-2026	\N	Làng Ghè- IaDơk,Gia Lai
d9b6734e-e516-4789-a818-a45b9d0d15ca	Rơ Châm H' Huyền	19/03/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:34.613+00	2025-2026	\N	Làng Lang, Ia Dơk, Gia Lai
988fa30a-9865-479a-a7a7-322cebf490f1	Nguyễn Phan Trà My	11/06/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.028+00	2025-2026	\N	Tổ dân phố , Đức Cơ, Gia Lai
2844d861-9243-4feb-abf9-868cfbc33237	Rơ Lan H’ Sương	20/12/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:37.508+00	2025-2026	\N	Sung Le 2, Ia Dơk, Gia Lai
3456e14e-cc90-418b-b3cc-71a302e09af0	Kpuih H' Trâm	22/06/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:38.968+00	2025-2026	\N	Làng Krai, Đức Cơ, Gia Lai
af86bd09-34ed-414a-b3e8-c4ed1f8ea066	Kpuih H' Lin	01/02/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:42.007+00	2025-2026	\N	Làng Dơk Ngol, Ia Dơk, Gia Lai
dbf0d81a-6454-44cd-b1ff-6720b90b3ad2	Kpuih Sữa	05/06/2010	Nam	Gia-rai		f	10A7				2026-03-23 13:55:43.514+00	2025-2026	\N	Làng Lung Prông, IaKriêng, Đức Cơ, Gia Lai
775576e2-b3ae-40cf-b2d1-aa5a4bebeac5	Ksor H' Đuin	23/01/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:46.468+00	2025-2026	\N	Làng Sung Kép, xã Ia Dơk, tỉnh Gia Lai
17d5b0e2-be37-4618-a3f9-3088f4dc608a	Trần Ngọc Huyền	06/02/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:47.955+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
658c8665-9a38-409a-a8b7-19946738f131	Trần Văn Bảo Nam	22/02/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:49.471+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
64a057ed-56ce-405f-8d55-2e44b340ae11	Rơ Mah H’ Sôri	06/12/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:50.96+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
282e7a0e-4921-49c9-b581-97bf653a0697	Nguyễn Thị Hải Yến	24/01/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:52.416+00	2025-2026	\N	Làng Lung Prông, xã Đức Cơ, tỉnh Gia Lai
48d37194-6cd5-44b6-97da-5cd226260755	Đinh Thị Hằng	26/09/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:53.928+00	2025-2026	\N	Tổ dân phố 2, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
20e53e7c-1e8e-4202-9df9-41adbb9e8e10	Nguyễn Thành Long	12/07/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:55.515+00	2025-2026	\N	Tổ dân phố 3, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
c1cea216-5cbd-435d-9e7a-21ffe1cb040b	Lương Hữu Phương	13/04/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.013+00	2025-2026	\N	Thôn Iatang, Ia Dơk tỉnh Gia Lai
d8ff06c9-dc90-4b99-a26b-d101c3cff02d	Võ Thị Kiều Trinh	25/11/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:58.528+00	2025-2026	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
b48f48fb-748f-49c7-89bd-746ac26097ec	Đoàn Hà Giang	16/11/2010	Nữ	Kinh		f	10A10				2026-03-23 13:56:00.044+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, huyện Đức Cơ, tỉnh Gia Lai
e5b57e59-0507-465e-84b6-01313157d8eb	Rơ Mah Kiệt	12/09/2010	Nam	Gia-rai		f	10A10				2026-03-23 13:56:01.645+00	2025-2026	\N	Làng Dơk Ngol, Ia Dơk, Đức Cơ, Gia Lai
302e5178-058e-4df0-a570-0bd051efbdbe	Hồ Thanh Nguyên	15/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:03.208+00	2025-2026	\N	Tổ dân phố 4, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
1d80f7c0-2ea2-4c0b-9d1f-69040602433c	Hồ Thị Nguyệt Ánh	30/10/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:06.172+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
0a6763b9-a1f3-434a-b7cb-36811d73ac6f	Nguyễn Diệp Hân	13/03/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.731+00	2025-2026	\N	Làng Pnuk, xã Đức Cơ, tỉnh Gia Lai
732d693b-6496-4b45-a2ef-3a2829bf1961	Hoàng Tùng Lâm	11/12/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:09.235+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
f6a96036-128c-4010-9fcd-2ceb406e77c7	Hoàng Minh Quân	18/10/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.748+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai
853dbe68-63b8-4ff9-8ff5-58bd659f4126	Nguyễn Mai Công Anh	22/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.235+00	2025-2026	\N	Thôn Chư Bồ 2- Ia Dơk- Gia Lai
b614c228-e053-4871-ad05-fae722a1bcbb	Vũ Minh Đức	09/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:13.792+00	2025-2026	\N	Sung kép - Ia Dơk- Gia Lai
ffff29a4-941c-47f4-a14a-4307f8f4ba97	Bùi Văn Lộc	27/07/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:15.358+00	2025-2026	\N	Thôn Ia Kăm - Ia Krêl  - Gia Lai
3a068f6d-f9a7-49ce-8568-53e195e91f16	Nguyễn Hiền Thu	05/10/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:22.301+00	2025-2026	HK2	Xã Đức Cơ, tỉnh Gia Lai
a6315b45-1031-46e8-a944-24973ed9798b	Nguyễn Bảo Trân	07/04/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:00.017+00	2025-2026	HK2	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
360acaf7-a85e-47b9-ac8d-a4e88b2117ed	Nguyễn Thị Trà Giang	13/03/2010	Nữ	Kinh		t	10A7				2026-03-26 02:31:45.748+00	2025-2026	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
93fed5e4-85fd-4fb1-a163-b266c79d38ed	Rơ Lan A Sở	02/05/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.328+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, tỉnh Gia Lai
4f9f4998-4db6-4f5d-8167-15dced091674	Kpuih H' Trinh	26/08/2009	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:31.745+00	2025-2026	\N	Làng Đo, xã Ia Dơk, tỉnh Gia Laỉ
d4c38d8b-8c8c-41e5-9511-549fafe44210	Rơ Lan H' Bích	20/07/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:33.31+00	2025-2026	\N	Làng Sung Le, Xã Ia Dơk, Gia Lai
9a6de8b6-b095-449e-816c-285ca3a678ec	Hoàng Thị Cúc Hương	06/08/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:34.753+00	2025-2026	\N	Làng Ấp, Đức Cơ, Gia Lai
0ad7d3ae-d26b-4190-a891-00c70a22cf75	Nguyễn Thị Thanh Ngân	31/01/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:36.196+00	2025-2026	\N	Làng Ngole, xã Ia Krêl, Tỉnh Gia Lai
cfbd79a3-17e8-44f6-938b-58c572cd485a	Nguyễn Phùng Thành	18/08/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:37.655+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk , Tỉnh Gia Lai
c06b663c-129e-40f1-9c79-40d28a09236c	Hà Bùi Cẩm Tú	17/03/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:39.111+00	2025-2026	\N	Tổ dân phố 9, Xã Đức Cơ, Gia Lai
4cab838a-d4d3-40ba-9b2c-3606e2967345	Rơ Mah H’ Grinh	11/05/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:40.626+00	2025-2026	\N	Làng sung le - Ia kla - Đức Cơ-Gia Lai
7d45f1fd-0035-49c1-b1a3-749a4d4924e2	Chu Thị Thanh Linh	12/07/2010	Nữ	Tày		f	10A7				2026-03-23 13:55:42.157+00	2025-2026	\N	Làng Krêl, xã Ia Krêl, Tỉnh Gia Lai
451c59ea-bad9-4481-8bb9-aa6169aa1b82	Rơ Lan Lê Thành	16/08/2010	Nam	Gia-rai		f	10A7				2026-03-23 13:55:43.661+00	2025-2026	\N	Làng Pnuk, xã Đức Cơ, Gia Lai
ff827b54-e647-4664-8e3d-e8c1e31d46b3	Lê Đình Anh Tuấn	22/09/2010	Nam	Kinh		f	10A7				2026-03-23 13:55:45.139+00	2025-2026	\N	Làng Ấp, xã Đức Cơ, Gia Lai
2375a2a4-52d9-47f2-a97f-43a6eff54db5	Nguyễn Thị Thanh Hà	10/11/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:46.616+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
cc0f58bb-8992-418c-a807-b58f61771378	Nguyễn Thị Hương	24/12/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:48.098+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
6c3a83f2-8687-45b1-b3ef-3842e7f29e24	Kpuih H' Ngon	17/12/2009	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:49.611+00	2025-2026	\N	Làng Ghè, xã Ia Dơk, tỉnh Gia Lai
e0d186ce-0005-4163-bb8e-9292c89d19bd	Đặng Phương Thảo	30/01/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:51.094+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
753fe8e5-5cbc-4e9c-9264-5b6f65ab1f3e	Rơ Lan Kim A	04/04/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:52.576+00	2025-2026	\N	Làng Sung Kép -Xã Iadơk- Tỉnh Gia Lai
c426e0a2-3764-48af-8a62-80c2fdbc1181	Ksor Hân	19/01/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:54.081+00	2025-2026	\N	Làng Krol, Xã IaKrêl, Đức Cơ, GIa lai
20b4bcbf-7b45-4176-8d86-6360d624f909	Trần Thị Ngọc Mai	08/10/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:55.671+00	2025-2026	\N	Tổ dân phố 9, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
e8a0938e-adad-4d7c-bd03-84f56748c585	Trần Anh Quân	21/06/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:57.168+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Kla, huyện Đức Cơ, tỉnh Gia Lai
bc79b6ed-26fc-4988-98a6-835d31d4cd0f	Lê Trần Anh Trung	20/06/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:58.692+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk , Tỉnh Gia Lai
85247163-36df-412e-9bb2-4fc9e7e549f2	Hà Thanh Lâm	25/08/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:01.803+00	2025-2026	\N	Xã Đức Cơ, tỉnh Gia Lai
6a8deaa2-586c-4c99-b914-02abacb33589	Rơ Mah H' Niê	27/07/2010	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:03.359+00	2025-2026	\N	Làng Ghè, Xã Ia Dơk , Huyện Đức Cơ , Tỉnh Gia Lai
ce4d2760-9643-4d56-96a9-de07a4ebad9d	Rơ Lan H' Bạch	14/07/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:06.325+00	2025-2026	\N	Làng Sung Le Tung, xã Ia Dơk, tỉnh Gia Lai
84696ed3-f819-467a-9391-59dfbaacb6b4	Hồ Thị Như Hoa	21/06/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:07.884+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
355f918b-fc5b-4d55-aee8-7e3239dd1561	Phạm Nguyễn Nhật Linh	30/01/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:09.391+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
17a1717c-3d99-4605-aa90-835c2045326b	Lê Thế Quý	12/02/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:10.899+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
561aebed-c038-4fad-92a5-6f41f830d9de	Nguyễn Thị Hoài Ân	20/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:12.38+00	2025-2026	\N	Làng Krai- Đức Cơ- Gia Lai
d9d8f7d6-f68f-4c1d-99ee-e70e3f02a3f3	Nguyễn Thu Hà	23/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:13.95+00	2025-2026	\N	Tổ DP2- Đức Cơ- Gia Lai
5279daa6-ad57-4da3-970d-7136269d3a93	Hồ Thị Ngọc Trâm	2010-12-11	Nữ	Kinh		t	10A10	2025-09-07	0343400608		2026-03-26 02:05:31.445+00	2025-2026		Tổ dân phố 6, Chư Ty, Đức Cơ, Gia Lai
5d823d24-0a48-4e55-9782-67bff369ad8e	Nguyễn Thị Thu Hiền	01/06/2010	Nữ	Kinh		t	10A10				2026-03-26 02:06:49.195+00	2025-2026	HK2	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
93140630-880e-4c64-8577-437319c7a2c1	Rơ Lan H' Thiết	27/01/2010	Nữ	Gia-rai		f	10A5				2026-03-23 13:55:30.743+00	2025-2026	\N	Làng Đo, xã Ia Dơk , tỉnh Gia Lai
ee8dec8c-1e45-446e-88a6-4c53feff60ae	Hàn Quốc Tuấn	09/11/2009	Nam	Kinh		f	10A5				2026-03-23 13:55:32.16+00	2025-2026	\N	Thôn Chư Bồ , xã Ia Dơk, tỉnh Gia Lai
f75a97d6-60ef-4a00-9a7c-d10bb23df620	Đàm Thị Thanh Hà	03/04/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:33.73+00	2025-2026	\N	Tổ dân phố 6, Đức Cơ, Gia Lai
1765a7d6-f5e2-4244-b537-2eec009698a5	Ksor H' Khuê	10/10/2010	Nữ	Gia-rai		f	10A6				2026-03-23 13:55:35.176+00	2025-2026	\N	Làng Krol, xã Ia Krêl, tỉnh Gia Lai
b9dae8b9-a64c-4fbb-9e3e-2d16981ab5fb	Nguyễn Sỹ Nguyên	16/05/2010	Nam	Kinh		f	10A6				2026-03-23 13:55:36.635+00	2025-2026	\N	
3005239b-53f2-441c-9aad-49414e6166b4	Lê Thị Anh Thư	28/09/2010	Nữ	Kinh		f	10A6				2026-03-23 13:55:38.104+00	2025-2026	\N	Tổ dân phố 9, Đức Cơ, tỉnh Gia Lai
720f92d6-550d-4085-95e0-210bfbce23f2	Ksor H’ Lê A	23/08/2010	Nữ	Gia-rai		f	10A7				2026-03-23 13:55:39.601+00	2025-2026	\N	Làng Sung le kắt, xã Ia Dớt , Gia Lai
fafcbf94-121b-4df0-b417-fd2085f40dfb	Dương Thị Thanh Thúy	29/03/2010	Nữ	Kinh		f	10A7				2026-03-23 13:55:44.106+00	2025-2026	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai
599b49cc-1992-4526-ae52-5bf7d940e264	Phan Thị Thu Hằng	17/05/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:47.069+00	2025-2026	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai
e9ace483-8b33-4256-ab68-e6df2b6a0be9	Nguyễn Nhật Kha	01/01/2010	Nam	Kinh		f	10A8				2026-03-23 13:55:48.564+00	2025-2026	\N	Thôn Lệ Kim, xã Ia Dơk, tỉnh Gia Lai
629c4eaa-bbc5-4381-bb9f-d9bbfa4dc147	Vũ Thị Tuyết Như	11/07/2010	Nữ	Kinh		f	10A8				2026-03-23 13:55:50.06+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
4ac64c46-dd0e-4be9-8e5f-891e494d2e55	Kpuih Thuy	09/02/2010	Nữ	Gia-rai		f	10A8				2026-03-23 13:55:51.539+00	2025-2026	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai
9bf3e426-823b-4df8-a37a-f0d0804807d8	Lê Khả Tuấn Anh	26/05/2010	Nam	Kinh		f	10A9				2026-03-23 13:55:53.006+00	2025-2026	\N	Tổ dân phố 4, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
99f632c6-652b-4da8-8572-6f4e2bbe5807	Rơ Lan Khiếp	04/02/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:54.548+00	2025-2026	\N	Làng Lung Prông xã Đức Cơ, tỉnh Gia Lai
8c9ecfb1-967c-453b-908e-6209993dcc3e	Rơ Lan H’ Nasi	10/10/2010	Nữ	Gia-rai		f	10A9				2026-03-23 13:55:56.144+00	2025-2026	\N	Làng Sung le - Xã Ia Kla - Đức Cơ - Gia Lai
4ce065b3-09d8-4366-8fc8-c8eaf6377908	Nguyễn Thị Thảo	01/04/2010	Nữ	Kinh		f	10A9				2026-03-23 13:55:57.607+00	2025-2026	\N	Tổ dân phố 7, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
cdafe818-3f41-48b3-b8fc-38924c6c70e7	Kpuih Lan Văn	24/12/2010	Nam	Gia-rai		f	10A9				2026-03-23 13:55:59.141+00	2025-2026	\N	Làng Pnuk, IaKriêng, Đức Cơ, Gia Lai
7a8debc4-53db-482e-bc06-6eb6e38bf10f	Trần Bá Hoàng	03/09/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:00.657+00	2025-2026	\N	Tổ dân phố 2, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
905ccb7f-b98f-459d-b287-6e1cebd633f0	Rơ Châm Thảo My	10/10/2009	Nữ	Gia-rai		f	10A10				2026-03-23 13:56:02.306+00	2025-2026	\N	Tổ dân phố 1, Thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
0b3d45ef-dd2d-4a2b-b3aa-3d1729ab4ff7	Hoàng Anh Tú	11/07/2010	Nam	Kinh		f	10A10				2026-03-23 13:56:05.338+00	2025-2026	\N	Thôn IaMang -Iakla - Đức Cơ Gia Lai
b06cef60-b9df-4f2d-aa17-bfe2f275fce1	Rơ Mah H' Chúc	28/01/2010	Nữ	Gia-rai		f	10A11				2026-03-23 13:56:06.812+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
46d7d6b2-ae19-4f9f-956a-8c35c52d6b84	Nguyễn Hữu Huy	02/06/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:08.339+00	2025-2026	\N	Làng Kòm Ngó, xã Ia Chia, tỉnh Gia Lai
9ac0856c-e82a-43cd-88e2-3b1824c18201	Trần Nhật Minh	29/07/2010	Nam	Kinh		f	10A11				2026-03-23 13:56:09.844+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
891d1a70-3418-48b4-a27e-4a1c02c51bbb	Mai Thị Thắm	09/11/2010	Nữ	Kinh		f	10A11				2026-03-23 13:56:11.345+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
62d75473-75c5-43ae-991a-c1b0e1f2d69b	Phan Minh Cường	24/02/2009	Nam	Kinh		f	11C1				2026-03-23 13:56:12.864+00	2025-2026	\N	Tổ DP2-  Đức Cơ- Gia Lai
9cc1fd4f-ab5d-4f42-9ca4-37e623d28559	Nguyễn Thanh Hiền	12/05/2009	Nữ	Kinh		f	11C1				2026-03-23 13:56:14.427+00	2025-2026	\N	Tổ DP2- Đức Cơ- Gia Lai
9dadc88f-5410-4beb-9925-34e4a79afbc2	Văn Tiến Mạnh	11/12/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:49.821+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
efdc6863-c8e6-4448-a6ac-8daa29963681	Đào Quang Minh	19/10/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:50.768+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
47ba941a-a089-46af-8cec-8ac580e12644	Phạm Thanh Bảo Ngọc	09/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.196+00	2025-2026	\N	Tổ DP6-  Đức Cơ- Gia Lai
8b3c6882-a993-473c-b6f5-e19a51fa02e1	Phan Bảo Ngọc	21/04/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:51.477+00	2025-2026	\N	Ia Mang- Ia Dơk- Gia Lai
4705c16f-7bd3-4db7-ad23-3221f865d73e	Trần Bảo Ngọc	10/11/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.744+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
8741d17a-55f5-4b4e-8dfd-d1d67290784f	Phan Trần Gia Nhi	04/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:51.98+00	2025-2026	\N	Thanh Giáo- Ia Krêl- Gia Lai
1c00b9e3-210a-4cfd-a499-c01c64ff46fb	Nguyễn Tấn Phát	29/10/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:52.454+00	2025-2026	\N	Tổ DP6- Đức Cơ- Gia Lai
215ef349-fb6f-433b-8308-942ada78510e	Lê Minh Phương	06/05/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:52.726+00	2025-2026	\N	Tổ DP7- Đức Cơ- Gia Lai
9ee80d9b-3b38-4a29-88e3-0c078674244e	Nguyễn Ngọc Nhã Phương	28/03/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:52.998+00	2025-2026	\N	Chư Bồ 1- Ia Dơk- Gia Lai
139249a6-aed8-45fd-aaa9-90ca4dbdb25d	Cao Nhữ Hoàng Quân	13/09/2009	Nam	Mường		f	11C1				2026-03-23 13:57:53.305+00	2025-2026	\N	Làng Ấp -  Đức Cơ- Gia Lai
f7330a95-e5af-46dd-b557-b3e391e99285	Hoàng Thủy Tần	16/06/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:53.493+00	2025-2026	\N	Tổ DP7-  Đức Cơ- Gia Lai
a459bf02-a11e-4fba-bbf8-4562708197c9	Cù Lê Gia Thanh	06/04/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:53.688+00	2025-2026	\N	Ia Lâm- Ia Krêl- Gia Lai
ea23a775-b453-498c-841a-0ae17d4246a4	Lê Thị Ngọc Thư	11/06/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:53.887+00	2025-2026	\N	Làng Dơk Ngol- Ia Dơk - Gia Lai
0be561a7-b9d1-4539-a565-33762c6da77c	Nguyễn Thị Minh Thư	17/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.055+00	2025-2026	\N	Tổ DP6-  Đức Cơ- Gia Lai
12f520ea-a11f-4065-97e3-4197564fb24b	Đặng Đình Tiến	17/08/2009	Nam	Kinh		f	11C1				2026-03-23 13:57:54.239+00	2025-2026	\N	Làng Bua- Ia Pnôn- Gia Lai
873b9dfa-551d-4bb7-a7df-25c07775495e	Nguyễn Huỳnh Yến Trang	06/06/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.436+00	2025-2026	\N	Tổ DP3-  Đức Cơ- Gia Lai
a1218f08-ffc9-468c-8f38-ffe68df01a5b	Đặng Thị Thảo Vy	14/05/2010	Nữ	Kinh		t	10A7				2026-03-26 02:29:33.297+00	2025-2026	HK2	Làng Triêl- Xã Ia Pnôn - Tỉnh Gia Lai
31362a01-8e42-4d12-9b29-5cabbe9a7d44	Nguyễn Phi Hậu	20/08/2009	Nam	Kinh		t	10A7				2026-03-26 02:31:29.66+00	2025-2026	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
956b039e-da8e-4e33-ad6c-68f9ad79f22f	Trần Thị Khánh Ly	02/09/2010	Nữ	Kinh		t	10A7				2026-03-26 02:33:00.762+00	2025-2026	HK2	Thôn Chư Bồ I, Ia Dơk, Gia lai
07b7aab4-2f5a-498d-9a3c-c1f5e54ca211	Nguyễn Hoàng Bảo Trâm	05/03/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.621+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
80e3b0bf-5a11-4d9f-8fec-35de7afacfef	Hồ Ngọc Diễn	17/11/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.318+00	2025-2026	\N	Tdp 7 - Đức Cơ - Gia Lai
29e29e25-4086-4d0f-b33a-6c4b30f21f16	Trần Thiên Khánh	16/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.893+00	2025-2026	\N	Tdp 9 - Đức Cơ - Gia Lai
169526a1-b152-46c4-9ac1-ed340b7a7ee4	Nguyễn Yến Nhi	06/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.523+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
90e42e2a-4a4f-4538-a5e4-27640cfc455d	Vũ Thị Thùy Trang	11/09/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.961+00	2025-2026	\N	Làng Ấp - xã Đức Cơ - Gia Lai
a35680ca-d653-4ac2-9c58-e09d7a3be4eb	Nguyễn Văn Huy	04/09/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:03.909+00	2025-2026	\N	Thôn Thanh giáo -  Xã Ia Krêl  -  Tỉnh Gia Lai
9b4dbe3d-af5a-4df8-bda1-fde86d13ec23	Hoàng Hoài Băng	26/09/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.895+00	2025-2026	\N	Thôn Ia Lâm Tốk - Xã Ia Krêl - Tỉnh Gia Lai
298eec5c-3e66-4c72-8b28-854bbdb75cb5	Nguyễn Hồ Khải Hoàng	29/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:11.385+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
9515aa68-817b-4449-a5ad-d5cebc02c306	Hồ Bảo Yến Nhi	28/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.845+00	2025-2026	\N	TDP 6 - Đức Cơ - Gia Lai
7b647e29-8e11-420d-9400-4c551b27e442	Nguyễn Thị Thương	17/05/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.339+00	2025-2026	\N	Ia Tang - Ia Dơk- Gia Lai
1a9d963f-ffa0-4892-95c8-45043eaf7b64	Đào Duy Anh	18/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:15.803+00	2025-2026	\N	Tổ Dân Phố 1, xã Đức Cơ, Gia Lai
ff953529-746b-40b8-bc40-1b33cb6b57b5	Nguyễn Thanh Hà	11/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.288+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
a6d30d03-30e6-4907-abb8-5540b284466e	Nguyễn Lê Quỳnh Mai	14/08/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.736+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
5c7ec2d9-286d-4e38-a5d2-60b345b1cfc1	Khiếu Thị Như Quỳnh	30/10/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.204+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
ec09764f-aa9e-4954-a62f-69bb2a5cd9ca	Trịnh Đình Tuấn	01/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.628+00	2025-2026	\N	Thôn Thanh Giáo, Ia Krêl, Gia Lai
41114c2f-e5c0-4a65-92ba-7b27adc49544	Cao Chấn Đông	13/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:23.055+00	2025-2026	\N	Làng Grôn, Xã Đức Cơ, Tỉnh Gia Lai
56f2d642-1cb8-4645-b045-0583d0252fe3	Bùi Ngọc Tĩnh	19/09/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:13.465+00	2025-2026	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai
b7c5f9b2-172f-4d65-aca3-8c9f3866b6d0	Cầm Thị Quỳnh Mai	30/08/2009	Nữ	Thái		t	11C3				2026-03-26 02:03:31.524+00	2025-2026	HK2	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai
8d22bd54-fd9c-4192-80ef-5c4889c246d0	Đàm Quỳnh Anh	10/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:36.918+00	2025-2026	HK2	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai
3f6d9bbe-2382-4698-a090-5c71836ffc6f	Trần Gia Như	06/05/2009	Nữ	Kinh		t	11C3				2026-03-26 02:29:40.641+00	2025-2026	HK2	TDP2 , Xã Đức Cơ, Tỉnh gia lai
bd97ecf7-d4f7-4e32-97df-b360216508ea	Võ Hồ Yến Vi	25/02/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.812+00	2025-2026	\N	Tổ DP1-  Đức Cơ- Gia Lai
881ede24-9751-444a-aa92-8ad9dde7f409	Hồ Nghĩa Dũng	09/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.48+00	2025-2026	\N	Tdp 9 - Đức Cơ - Gia Lai
2aaa6039-08b8-46ba-9713-5e06920e3026	Nguyễn Anh Kỳ	28/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.046+00	2025-2026	\N	Thôn Ia Tang - xã Ia Dơk - Gia Lai
e12104b2-5404-4f27-94af-3e8abbd90696	Ngô Thị Tuyết Nhung	06/06/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.672+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
0192ba81-a254-4fac-85f4-930c6a1bdd1b	Võ Hoài Bảo Trâm	03/01/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.1+00	2025-2026	\N	Tdp 1 - Đức Cơ - Gia Lai
b313feb5-d496-496f-b6ff-fc319033872d	Hoàng Gia Bình	15/09/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.041+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
797fdb83-47b6-48b1-8af5-f20ffd5e7247	Võ Văn Huân	18/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.534+00	2025-2026	\N	Ia Kăm - Ia Krêl - Gia Lai
27de95a7-b314-4a37-906e-44bb03e532fb	Nông Lê Yến Nhi	26/08/2009	Nữ	Tày		f	11C4				2026-03-23 13:58:12.996+00	2025-2026	\N	Ia Kăm - Ia Krêl - Gia Lai
d2905eef-7569-4a4d-85b2-2173d8954678	Hồ Vĩnh Tiến	11/09/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.475+00	2025-2026	\N	Thôn Đoàn Kết - Ia Dơk - Gia Lai
7a12b0b2-110f-4dce-bbbb-4d1e086bb3e3	Hà Vĩnh Hoàng Anh	07/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:15.955+00	2025-2026	\N	Tổ Dân Phố 4, xã Đức Cơ, tỉnh Gia Lai
6be6a9dc-e8d5-4382-8697-71fdc3764084	Nguyễn Văn Hào	22/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.433+00	2025-2026	\N	Thôn Ia Mang, xã Ia Dơk, tỉnh Gia Lai
85cf9679-309b-40ae-9ebc-0ec626b0e755	Phạm Sao Mai	22/06/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.888+00	2025-2026	\N	Tổ 8, phường Hội Phú, tỉnh Gia Lai
6feeafcb-822f-44e4-b5cc-97333a10c6de	Hồ Vĩnh Duy Tài	17/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.36+00	2025-2026	\N	Tổ Dân Phố 1, xã Đức Cơ, tỉnh Gia Lai
ee502bc9-8cf4-448a-9470-04253d7094d1	Lã Thị Tố Uyên	05/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:21.766+00	2025-2026	\N	thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia lai
d80156c3-5009-4bdb-9f96-0737eab7340b	Hồ Thị Ngọc Hà	23/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.211+00	2025-2026	\N	TDP2, Xã Đức Cơ, Tỉnh Gia Lai
df178bdb-aa0e-422f-9ce0-c2a8279b966e	Đỗ Thị Ngọc Mai	02/05/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:42.962+00	2025-2026	HK2	Tổ dấn phố 1 - Xã Đức Cơ -  Gia Lai
40a5ed2a-3e0f-46f5-bbf6-6cce00bf6b5f	Hoàng Thị Kim Oanh	21/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:00.95+00	2025-2026	HK2	Tdp7, Xã Đức Cơ, Gia Lai
6f8767ac-14b8-4d38-be86-43b29d348045	Nguyễn Thanh Huyền	30/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:57.332+00	2025-2026	HK2	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai
f3ae58fa-e2ab-4bb8-bb13-66b347f4cfc2	Phạm Minh Anh	17/04/2009	Nữ	Kinh		t	11C3				2026-03-26 02:10:21.102+00	2025-2026	HK2	Tổ dân phố 2 - Xã Đức Cơ-Gia Lai
8a6035fd-a4d8-43ba-9296-2fbfcd300d6e	Vũ Thùy Trang	15/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:30:04.773+00	2025-2026	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai
c3b4cc69-b422-4f54-99b5-dfc70fa0d875	Châu Ngọc Như Ý	18/06/2008	Nữ	Kinh		f	11C1				2026-03-23 13:57:54.985+00	2025-2026	\N	Tổ DP2- Đức Cơ- Gia Lai
825fbf1f-dd8d-4da5-9f00-cccd03693f77	Nguyễn Thị Hồng Duyên	21/06/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:56.627+00	2025-2026	\N	Thôn Ia Lâm - xã Ia Krêl - Gia Lai
2803dd6b-beae-4f97-85d4-3f70d3fcaf0d	Phan Ngọc Lâm	11/03/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.202+00	2025-2026	\N	Tdp 1 - Đức Cơ - Gia Lai
e643ae7e-94fe-4154-80e7-f37a2cc14840	Trần Gia Như	01/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.797+00	2025-2026	\N	Tdp 4 - Đức Cơ - Gia Lai
25a8b8c0-0949-4533-a342-12feac3c29ca	Nguyễn Phan Bảo Trân	25/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.243+00	2025-2026	\N	Thôn Thanh Tân  - xã Ia Krêl - Gia Lai
a1755292-551e-4c73-b67e-3552fcd9173f	Phan Trần Yến Minh	14/06/2009	Nữ	Kinh		f	11C3				2026-03-23 13:58:05.741+00	2025-2026	\N	Kpă Klong, Xã Đức Cơ, Gia Lai
e812a2f7-4836-4edb-877c-b3194221f942	Nguyễn Trọng Bình	19/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.18+00	2025-2026	\N	Làng Krai - xã Đức Cơ - Gia Lai
53e63949-39b3-4bee-a891-47776ab15ba6	Lương Phi Long	05/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.665+00	2025-2026	\N	Thôn Ia Lâm Tôk - Ia Krêl - Gia Lai
a24e2c56-d104-43f5-a023-31c854cebe21	Trương Nguyễn Quỳnh Như	18/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.137+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
233e3135-7263-41c8-8fe3-29005e6d4950	Nguyễn Thị Thùy Trang	02/10/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.621+00	2025-2026	\N	Thôn Chư Bồ 1- Ia Dơk - Gia Lai
61a08e7a-3e63-4308-8701-615d42207b5f	Hồ Quỳnh Anh	27/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.097+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
ad33184d-6f2a-4ab3-9a32-6fe67f475a60	Nguyễn Thị Minh Hoàng	10/08/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.574+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
daafd810-2363-49e2-9aad-2f2e62c3dabf	Nguyễn Lê Mạnh	14/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:19.015+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk , tỉnh Gia Lai
83c2bde5-6030-4fc3-946e-029de5300b98	Nguyễn Xuân Thành	05/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.501+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
836d5331-f382-468b-8483-7082bde20cd1	Đinh Đức Anh	10/09/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:21.917+00	2025-2026	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai
0ec6631f-5028-41fe-b3d0-dd81abac3c80	Đinh Thị Thuý Hiền	13/07/2009	Nữ	Tày		f	11C6				2026-03-23 13:58:23.365+00	2025-2026	\N	TDP9, Xã Đức Cơ, Tỉnh Gia Lai
cabc5369-ca9c-4cd4-9013-c1cd4cc15b81	Huỳnh Văn Phúc	14/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:04:50.537+00	2025-2026	HK2	Thôn Thanh giáo-Xã Ia Krêl-Huyện Đức Cơ Tỉnh Gia Lai
623b00fa-8175-42a6-8bc6-42c22abcffc5	Nguyễn Thị Lan Hương	19/03/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:24.016+00	2025-2026	HK2	Làng gron -  Xã Đức Cơ - Tỉnh gia lai
7261a333-17b9-45bb-b280-ea6b276fc00c	Thiều Thanh Trúc	16/09/2009	Nữ	Kinh		t	11C3				2026-03-26 02:26:51.538+00	2025-2026	HK2	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai
07ad3692-61ff-4392-9541-bd82a7b77782	Trần Gia Bảo	13/07/2009	Nam	Kinh		t	11C3				2026-03-26 02:28:42.864+00	2025-2026	HK2	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai
cfff97af-ca0f-430d-91ae-c2a044f50d6d	Nguyễn Ngọc Như Ý	28/10/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:55.141+00	2025-2026	\N	Làng Ấp - Đức Cơ- Gia Lai
d112a9b1-b9a9-44d9-962a-4e2725df2fdc	Nguyễn Quang Dương	24/12/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.778+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk- Gia Lai
94a1781e-5855-4959-98d0-19f249fd540b	Thủy Ngọc Lĩnh	14/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.377+00	2025-2026	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai
5aa3ab25-0f70-4c89-9341-675517f58439	Nguyễn Thị Kim Oanh	15/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.945+00	2025-2026	\N	Làng Ấp - xã Đức Cơ - Gia Lai
c3825d27-cd8a-4248-a9b3-71002f487360	Nguyễn Phạm Đức Trí	01/04/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.392+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk - Gia Lai
606f0d11-11ad-4dab-b8a7-de0b5e24ea9a	Phạm Hồng Diễm	25/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:10.339+00	2025-2026	\N	TDP 7 - Đức Cơ - Gia Lai
1bfb3547-34d9-40b0-ab85-eaea57ba1ffd	Mai Xuân Long	20/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.804+00	2025-2026	\N	Thôn Thanh Giáo - Ia Krêl - Gia Lai
ad8e9960-4383-470b-82ee-4c4f7a8e8f44	Nguyễn Văn Phúc	08/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:13.281+00	2025-2026	\N	Ia Lâm - Ia Krêl - Gia Lai
4d64f75b-b7d5-4884-9a25-31f582601d49	Trần Thị Thùy Trâm	13/05/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.777+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
0cc547d5-3920-4b71-b1e8-d4040d7e8f73	Phạm Nguyễn Việt Anh	27/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.243+00	2025-2026	\N	Tổ Dân Phố 6, xã Đức Cơ, tỉnh Gia Lai
48afbb4b-fef8-4575-b889-67ca218fb8a2	Lường Quốc Huy	23/04/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.721+00	2025-2026	\N	Thôn Ia Lâm Tốk, xã Ia Krêl, tỉnh Gia Lai
824eb43a-b1f2-4ddf-a6de-9f2b68159f88	Bùi Phan Bảo Ngọc	18/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.157+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
c6775b1c-7f69-498c-b50e-c1faf1197953	Đặng Anh Thư	16/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.654+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
af68e96b-51bc-461c-8fb6-fe4e89f74bb5	Đỗ Hạ Nguyên Anh	17/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:22.06+00	2025-2026	\N	TDP6, Xã Đức Cơ, tỉnh Gia Lai
fab400ab-d92e-4467-bd6c-c7b868440277	Nguyễn Thị Thanh Hoài	02/06/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.522+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
8b5bfed8-0f21-4c63-9c4f-1f34c69f90fd	Hồ Ngọc Bích	02/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:11.028+00	2025-2026	HK2	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai
1b9f7174-583e-4f07-87cb-afd522f1b37f	Hồ Thanh Tâm	06/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:23.463+00	2025-2026	HK2	TDP 1- Xã Đức Cơ- Tỉnh Gia Lai
fa259129-a95c-41c0-b8eb-89ced6e293d4	Huỳnh Nguyễn Trà My	20/01/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:42.83+00	2025-2026	HK2	Ia Mút - Ia Dom - Gia Lai
3749caa1-7b29-4cb5-ad07-9d95732bd29b	Lê Hoàng Tuấn	20/10/2009	Nam	Kinh		t	11C3				2026-03-26 02:05:48.049+00	2025-2026	HK2	Thôn Chư Bồ I, Xã Ia Dơk, Tỉnh Gia Lai
ba0631d6-f91d-4118-92cd-7cc6ab2abe93	Nguyễn Thế Khang	09/03/2009	Nam	Kinh		t	11C3				2026-03-26 02:07:09.177+00	2025-2026	HK2	Tổ dân phố 7, Xã Đức Cơ, Gia Lai
fae31961-3ea6-4f8c-9889-99836f82663c	Phan Thị Yến	20/07/2009	Nữ	Kinh		f	11C1				2026-03-23 13:57:55.33+00	2025-2026	\N	Tổ DP2-  Đức Cơ- Gia Lai
bbe75490-d8b9-466b-9dd4-3c02ed8c3fd5	Nguyễn Việt Đức	27/10/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.951+00	2025-2026	\N	Làng Krêl - xã Ia Krêl - Gia Lai
4d4977e6-06f0-4143-9938-a563a8615eb1	Phan Minh Bảo Long	08/07/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.537+00	2025-2026	\N	681 Quang Trung - Đức Cơ - Gia Lai
a6c87c09-4491-4694-8fc1-5d40824e661b	Trần Gia Phát	26/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.08+00	2025-2026	\N	Tdp 1 - Đức Cơ - Gia Lai
251643c9-c20a-46c7-b461-4e117d4f8e3d	Lê Hồng Trúc	12/11/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:01.539+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk - Gia Lai
0b90f39a-7f6f-4c8d-acf8-9b8ead01fc6a	Nguyễn Nhật Tân	24/12/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:07.596+00	2025-2026	\N	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai
424aedd1-4870-4d21-93e1-f2d8238f19ff	Lê Anh Dũng	24/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.485+00	2025-2026	\N	TDP 6 - Đức Cơ - Gia Lai
e568c161-e745-4ac1-b5c7-c476c399cac2	Vũ Tiến Long	25/07/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.97+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
1a23b66a-cca3-446b-adb4-425c18ba8563	Phạm Văn Quân	03/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:13.42+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
e70ddf31-aefa-4aed-b906-c38c8417cc89	Trà Minh Trí	27/11/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.921+00	2025-2026	\N	Thanh Giáo - Ia Krêl - Gia Lai
d4339819-dad5-4164-a570-a69055af3526	Lê Thị Thanh Bình	03/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.38+00	2025-2026	\N	Tổ dân phố 1, thị trấn Chư Ty, huyện Đức Cơ, tỉnh Gia Lai
7359aa5a-bac0-4859-bc28-c812d8d544ff	Phan Tấn Huy	18/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:17.875+00	2025-2026	\N	Làng Nuk, xã Đức Cơ, tỉnh Gia Lai
de2b26e5-e86b-4e23-af02-dc7c6facce1a	Đinh Thị Bảo Ngọc	19/07/2009	Nữ	Mường		f	11C5				2026-03-23 13:58:19.297+00	2025-2026	\N	Thôn Ia Mang ,Ia Dok ,Đức Cơ,Gia Lai
9a1966af-0200-4130-ade0-2afe185c330f	Phạm Anh Thư	20/09/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.794+00	2025-2026	\N	Thôn Ia Lâm, xã Ia Krêl, tỉnh Gia Lai
f7f58791-54ce-4d0e-9e61-4a2334ef539a	Đỗ Đình Bảo	26/09/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.193+00	2025-2026	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai
0b9aba8f-043a-4e72-919b-4668d1fc8d85	Nguyễn Thị Thu Hoài	14/08/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:23.668+00	2025-2026	\N	TDP 7, Xã Đức Cơ ,Tỉnh Gia Lai
67c16ed5-0cab-44c0-9ae6-9294833f2a48	Hoàng Lê Ngọc Nam	26/05/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:56.322+00	2025-2026	HK2	TDP 3, Xã Đức Cơ, Gia Lai
71e83e3c-485f-4f6d-abd5-7ad47086d7ce	Lê Nguyễn Giáng Châu	08/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:09.431+00	2025-2026	HK2	Làng Ngolrong, Xã Ia Krêl, Tỉnh Gia Lai
dfddf2ea-eeac-4752-8757-a4408d5e0b11	Nguyễn Trí Vĩ	23/10/2009	Nam	Kinh		t	11C3				2026-03-26 02:25:38.34+00	2025-2026	HK2	Đường Quang Trung, TDP 2, Xã Đức Cơ, Gia Lai
fa37f754-ce4f-4edd-aaf9-600d03853354	Trần Anh Khoa	01/05/2009	Nam	Kinh		t	11C3				2026-03-26 02:27:19.813+00	2025-2026	HK2	Tổ dấn phố 7, Chư Ty, Đức Cơ,Gia Lai
c0d96e9d-0b1e-4b4a-9faf-1cf50b39e0a1	Lương Kim Anh	18/02/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.523+00	2025-2026	\N	Thôn Ia Lâm - xã Ia Krêl - Gia Lai
e5366ddc-62ec-41d1-b6f2-8ef027107025	Lê Thị Việt Hà	22/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:57.138+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
d0d515ad-3673-46cc-98ce-02e1b3ecb8f5	Trần Lê Xuân Mai	25/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:58.688+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
1ec2c0bc-84a6-4447-b7cc-b32cb2b0bbcb	Nguyễn Thị Diễm Quỳnh	21/09/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.216+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk - Gia Lai
038116f8-eaa7-45de-8db2-8c67a61e8a33	Lữ Thành Tú	30/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.695+00	2025-2026	\N	Thôn Thanh Tân - xã Ia Krêl - Gia Lai
6f0028c7-3f97-4bb2-88ad-fcf84f64056a	Cù Hoàng Gia An	02/03/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.195+00	2025-2026	\N	TDP 7 - Đức Cơ - Gia Lai
2cd83bc6-581a-461a-b03b-fec7a7d2fa89	Nguyễn Anh Dũng	02/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.636+00	2025-2026	\N	TDP 7 - Đức Cơ - Gia Lai
df00e483-5d57-4ef6-98de-9b73e2c2d9ed	Nguyễn Tấn Lợi	08/10/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:12.115+00	2025-2026	\N	TDP 6 - Đức Cơ - Gia Lai
7d5f0524-7e14-49f6-8256-797c15db7594	Rơ Lan Ai Quyết	13/01/2009	Nam	Gia-rai		f	11C4				2026-03-23 13:58:13.585+00	2025-2026	\N	Làng Pnuk - Đức Cơ - Gia Lai
0051947c-1f9f-4d34-9667-236bcc58ae60	Nguyễn Thị Diệu Trinh	13/12/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.066+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
b907a383-6201-4589-8bbc-ef1d62de7a1d	Phạm Thị Kim Chi	27/02/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:16.524+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, tỉnh Gia Lai
9a74b5d3-0741-4145-8477-abbfd6179e89	Hồ Hoàng Hưởng	01/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.015+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
9e741bd7-79a3-444c-b54e-9b4dbf91581a	Bùi Văn Hoàng Nguyên	23/08/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:19.439+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
bb6d376d-8056-4acf-a8de-f05bc4de297f	Dương Thị Thùy Trang	14/07/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:20.934+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
517f6af7-404c-47b3-967b-25c192f4ebc9	Rơ Lan H' Sa Bét	27/11/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:22.33+00	2025-2026	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai
fb4be1a9-98e0-4b7f-9419-70165b1e91a0	Rơ Lan H' Hoài	31/07/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:23.805+00	2025-2026	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai
3fe46f87-61f8-46bb-91b0-8974bc5b6a8e	Đồng Gia Khôi	04/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:03:51.431+00	2025-2026	HK2	Tổ dấn phố 2, Xã Đức Cơ, Gia Lai
186fe7fc-162b-4f23-914f-44e61cd8543b	Hoàng Thị Kim Thoa	16/12/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:05.941+00	2025-2026	HK2	TDP 4- Xã Đức Cơ- Tỉnh Gia Lai
d73cf1b4-4762-498d-a121-82387a818110	Lê Thị Hồng Ngọc	17/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:24.05+00	2025-2026	HK2	TDP7, Xã Đức Cơ, Gia Lai
21ce3fe0-0dd2-4bd9-b0e2-cfdf4c6292e6	Nguyễn Đình Dũng	15/12/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:38.363+00	2025-2026	HK2	Thôn Thanh Giáo, Xã Iakrêl, Gia Lai
93bd3405-6133-4087-a140-6cf0ebf86419	Nguyễn Hồ Quỳnh Anh	14/10/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.706+00	2025-2026	\N	Tdp 7 - Đức Cơ - Gia Lai
5e2c6463-923b-4dbe-afe3-5b74b27123cc	Nguyễn Hoàng Thu Hiền	22/04/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:57.277+00	2025-2026	\N	Tdp 1 - Đức Cơ - Gia Lai
965aa45f-d05a-4fd8-805e-7be4387dad0d	Hoàng Văn Nam	17/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:58.866+00	2025-2026	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai
97f732d7-96c0-4293-902b-a70ac4f7098a	Nguyễn Xuân Sang	30/01/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.357+00	2025-2026	\N	Thôn Ia Mang - Ia Dơk - Đức Cơ - Gia Lai
e4282849-e3e5-4d9f-90a1-bdb1c1af6569	Lê Anh Tuấn	27/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.837+00	2025-2026	\N	Tdp 4 - Đức Cơ - Gia Lai
02add307-04a3-4535-abf0-1d69331766ef	Đào Lê Minh Anh	20/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:09.342+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
aa3e2ec9-bc2e-47b9-b44e-961c591a9725	Vũ Hải Hà	20/05/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:10.79+00	2025-2026	\N	TDP 6 - Đức Cơ - Gia Lai
cb6d72fe-e323-4ec5-80b5-1f0960d33d11	Lê Phương Thảo My	08/02/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.25+00	2025-2026	\N	TDP 2 - Đức Cơ - Gia Lai
d934a219-66ed-415b-b0eb-9c3fdad6c2fa	Hoàng Thị Thanh Sáng	20/04/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.738+00	2025-2026	\N	TDP 4 -  Đức Cơ - Gia Lai
266837ce-8c03-4a75-acc5-12433c664048	Trương Phương Trinh	16/03/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.218+00	2025-2026	\N	Thôn Ia Tang - xã Ia Dơk - Gia Lai\r\n
9e204875-9e12-4f96-9150-423a82aee36e	Nguyễn Thành Công	16/05/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.681+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
9c868e89-7b3c-4e13-9b07-3197f434276c	Nguyễn Hoàng Gia Khánh	03/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.15+00	2025-2026	\N	Tổ Dân Phố 7, xã Đức Cơ, tỉnh Gia Lai
0c3a6b82-c874-4a0c-9a16-08ac32d5cbd1	Nguyễn Lê Yến Nhi	23/01/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.57+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
85675ff6-eb57-4ba7-bbb9-dec6ad0be0ce	Trần Minh Trí	17/10/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.075+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
060f1731-c412-49f7-b32a-c8ff26c53e62	Khuất Duy Công	16/06/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.478+00	2025-2026	\N	TDP 4 , Xã Đức Cơ, Tỉnh Gia Lai
ccf56243-3adc-4b3f-93aa-7b406cea605f	Nguyễn Minh Hoàng	17/11/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:23.959+00	2025-2026	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai
88d1f008-a3dd-4d33-a880-46f1cd84fc4d	Hồ Thị Anh Thơ	04/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:04:32.426+00	2025-2026	HK2	TDP2- Xã  Đức Cơ-Tỉnh Gia Lai
ce544b20-5dc5-4cbc-98d9-29028144fb52	Lê Đình Đại	30/09/2009	Nam	Kinh		t	11C3				2026-03-26 02:05:01.575+00	2025-2026	HK2	Làng Ấp, Xã Đức Cơ, GiaLai
c6945a7e-bfb9-4edc-81c5-a42d4a7b1de5	Nguyễn Công Ngọc	21/06/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:30.646+00	2025-2026	HK2	Thôn ia Mang, Xã Ia Dơk ,Tỉnh Gia Lai
78aec30f-e89b-4919-a844-4a28abb35c43	Nguyễn Trần Thùy Linh	21/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:58.37+00	2025-2026	HK2	Tổ dân phố 4- Xã Đức Cơ- Gia Lai
d2aa0eb0-0246-4a90-a70a-5f9339a13367	Nguyễn Thị Ngọc Anh	09/05/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:55.882+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
d78f4f0a-c96c-44f4-bd3c-919f02040616	Hoàng Văn Hiếu	13/07/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.456+00	2025-2026	\N	Thôn Thanh Giáo - xã Ia Krêl - Gia Lai
d2199296-6a58-4d20-b17b-112a3d5a956b	Hồ Minh Nguyệt	29/01/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.02+00	2025-2026	\N	Thôn Thanh Tân - xã Ia Krêl - Gia Lai
2272eeb2-fd81-4497-aee9-c7672928c5cf	Lê Ngọc Thái	01/05/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:00.518+00	2025-2026	\N	Tdp 7 - Đức Cơ - Gia Lai
2ad8ba7d-2776-48e7-9f12-473d1b0932d4	Trần Nguyên Tuấn	14/03/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:01.978+00	2025-2026	\N	Làng Ấp - xã Đức Cơ - Gia Lai
aedc3d80-8df2-4f9d-a311-7acaaba6aecf	Trần Trịnh Nhất Gia	15/08/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:03.46+00	2025-2026	\N	Tổ dân phố 7 -  Xã Đức Cơ - Gia Lai
ea90cc0a-7a61-4728-a0b3-ccf6ae43aef0	Nguyễn Khắc Việt Anh	09/02/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.48+00	2025-2026	\N	Làng Khóp - Ia Krêl - Gia Lai
c98f1745-b0c3-43df-8b58-73f99b3cb2c3	Phạm Nguyễn Bảo Hân	24/11/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:10.939+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
83113869-0bef-4f3c-95bd-8f43d0e8073e	Hà Nhật Nam	11/06/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:12.39+00	2025-2026	\N	TDP 2 - Đức Cơ - Gia Lai
423a4553-f919-4490-834f-81283499ac24	Nguyễn Khánh Sương	19/10/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:13.913+00	2025-2026	\N	Ia Lâm - Ia Krêl - Gia Lai
c86b3feb-8dc1-4a46-85e1-1e2b58fcb3e2	Trương Vũ Cẩm Tú	25/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.354+00	2025-2026	\N	TDP 6 - Đức Cơ - Gia Lai
8d8e1371-92d8-443a-b14c-e3752d47c0a1	Giang Hải Đăng	30/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.851+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
1fe5d840-e64f-4d7b-9ce0-4ce035cf4623	Phạm Thùy Linh	20/03/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.29+00	2025-2026	\N	Thôn Ia Tang , xã Ia Dơk, tỉnh Gia Lai
016c27c5-685a-42d3-8ff5-6d5a7889ad71	Lê Thị Thu Phương	29/04/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.721+00	2025-2026	\N	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
c3a47f7a-64dd-45f8-9264-f73c1ef792ff	Nguyễn Hữu Trung	20/11/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.195+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, Gia Lai
c5c7336a-d21e-4ffb-9c3d-32e360429c2a	Nguyễn Công Dân	02/03/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:22.623+00	2025-2026	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai
0e49699d-fab1-40db-b974-b957dbdaf591	Phan Công Hoàng	05/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:24.104+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
0fde7158-e64e-43cd-9920-a574a793169c	Nguyễn Quang Long	07/02/2009	Nam	Kinh		t	11C3				2026-03-26 02:06:49.681+00	2025-2026	HK2	Tổ dân phố 7 - Xã Đức Cơ- Gia Lai
37100e9d-91b4-42f2-8d99-f1b2747ce4c6	Nguyễn Thị Ái Thuận	24/09/2009	Nữ	Kinh		t	11C3				2026-03-26 02:07:16.157+00	2025-2026	HK2	TDP1- Xã Đức Cơ-Tỉnh Gia Lai
e00c0d37-3125-42d9-b8c6-8f3808361e2d	Trịnh Thị Bích Ngọc	19/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:29:48.384+00	2025-2026	HK2	Làng Ia Mút, Xã IaDom,  Tỉnh Gia Lai
89fec2ef-32f5-4c1c-b3c0-90b5b97086ba	Phan Nguyên Khang	02/08/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.604+00	2025-2026	\N	Tdp 3 - Đức Cơ - Gia Lai
4de7f2d8-b38c-43e6-a535-2ed51a7998a2	Phan Thanh Nhân	15/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:59.183+00	2025-2026	\N	Tdp 1 - Đức Cơ - Gia Lai
502ad2e8-ef81-4a90-a401-f7d181a02ea5	Bùi Thị Anh Thơ	23/03/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.661+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
88b633e6-6a8b-4879-a530-036e235f8126	Cao Đăng Quang Tùng	05/06/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:02.143+00	2025-2026	\N	Thôn Đoàn Kết  -Xã Ia Dơk- Gia Lai
d381d186-4ea7-46e7-8352-cb0d5cc05fe5	Trương Gia Long	24/05/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:05.112+00	2025-2026	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Gia Lai
7198612f-7b60-4fd6-ae1c-f44a985f412c	Phạm Đình Ánh	15/10/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.61+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
c8f4fa0a-27c8-4aee-9d1c-03ee016efd84	Nguyễn Trung Hiếu	15/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.086+00	2025-2026	\N	TDP 4 -Đức Cơ - Gia Lai
7181e1ae-ea3d-4484-91dd-36da3d070218	Lê Thị Bảo Ngọc	29/01/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.549+00	2025-2026	\N	Thôn Sung Le Tung - Ia Dơk -  Gia Lai
23cd1229-73bb-47b7-b4d7-11a7bf1224a9	Lê Phú Thành	06/04/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:14.065+00	2025-2026	\N	Ia Lâm - Ia Krêl - Gia Lai
e57753f0-e6b5-47a3-9252-fdb74c66f921	Lê Thị Hồng Tuyết	14/02/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.504+00	2025-2026	\N	TDP 9 - Đức Cơ - Gia Lai
a2bda564-75fd-4508-a791-d34ee0912d7a	Nguyễn Hữu Đức	05/12/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:16.991+00	2025-2026	\N	Thôn Chư Bồ 1, xã Ia Dơk, tỉnh Gia Lai
9a27c07a-2e91-4e35-952b-81871ea2aaf3	Tăng Văn Hải Long	12/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:18.445+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
91f3d2b2-2f07-4f43-9370-32466584356b	Nguyễn Thị Linh Phương	31/05/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:19.883+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
189a18cc-7e13-449c-8b92-56776514bf94	Trần Xuân Tú	26/01/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.331+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
e5c88258-512c-4037-aa7a-d6e48b2ffaa4	Vũ Thị Duyên	30/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:22.768+00	2025-2026	\N	Tdp 4, Xã Đức Cơ, Tỉnh Gia Lai
b5825ec6-40a5-427c-9da6-1fe07e4745e6	Phan Ngọc Khánh Huyền	01/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.235+00	2025-2026	\N	Thôn Thanh Tân, Xã Ia Krêl, Tỉnh Gia Lai
367a4cd3-520e-4afc-8fea-c7806a7f9091	Bùi Thị Yến Nhi	01/02/2009	Nữ	Kinh		t	11C3				2026-03-26 02:03:24.151+00	2025-2026	HK2	Tdp2, Xã Đức Cơ, Tỉnh Gia Lai.
a40a021d-41e6-4ffc-bba4-2efa06c4f92a	Bùi Công Gia Bảo	21/09/2009	Nam	Kinh		f	11C2	2025-09-19			2026-03-26 02:05:32.115+00	2025-2026	HK2	Tdp 6 - Đức Cơ - Gia Lai
0b44dce8-9eac-49df-b6b0-4c2d0a154f56	Nguyễn Hoàng Bảo Hân	25/11/2009	Nữ	Kinh		t	11C3				2026-03-26 02:06:42.882+00	2025-2026	HK2	Tổ dân phố 2, Xã Đức Cơ, Gia Lai
e984e8c1-2250-4b56-87a7-893640fe24c4	Phạm Hoàng Anh Thư	22/10/2009	Nữ	Kinh		t	11C3				2026-03-26 02:10:27.066+00	2025-2026	HK2	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
e5e7a250-7eb6-422b-bb69-315ce69e8406	Mai Nguyễn Quốc Cường	01/08/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:56.17+00	2025-2026	\N	Thôn Lâm Tốc, Iakrêl, Gia Lai
b602543d-440b-46af-a537-fbebd1e42361	Phạm Đình Khánh	06/02/2009	Nam	Kinh		f	11C2				2026-03-23 13:57:57.745+00	2025-2026	\N	Tdp 2 - Đức Cơ - Gia Lai
fa1a4e8b-951a-4099-a284-11377d747281	Nguyễn Thị Yến Nhi	27/02/2009	Nữ	Kinh		f	11C2				2026-03-23 13:57:59.376+00	2025-2026	\N	Tdp 7 - Đức Cơ - Gia Lai
c6adab7a-bc5e-49e1-b5c4-95f699a61ec0	Trịnh Tâm Thư	01/11/2009	Nữ	Kinh		f	11C2				2026-03-23 13:58:00.814+00	2025-2026	\N	Tdp 6 - Đức Cơ - Gia Lai
e4705265-1745-4a99-9fb1-fc3f6f2f7c70	Vũ Sơn Tùng	07/10/2009	Nam	Kinh		f	11C2				2026-03-23 13:58:02.286+00	2025-2026	\N	Làng Dơk Klăh - xã Ia Dơk - Gia Lai
a7cab8f1-58ba-4f65-9fb4-10dd4a318e66	Vũ Đức Tiến	22/08/2009	Nam	Kinh		f	11C3				2026-03-23 13:58:08.333+00	2025-2026	\N	Thôn IaMang, Xã IaDơk, Đức Cơ,Gia Lai
1c96441e-2d7a-4b5b-9953-7114afe9cf37	Huỳnh Ngọc Bảo	09/02/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:09.745+00	2025-2026	\N	TDP 2 - Đức Cơ - Gia Lai
21f113bd-468c-4808-a0e5-ee3f62f8ef60	Nguyễn Hoàng	05/01/2009	Nam	Kinh		f	11C4				2026-03-23 13:58:11.223+00	2025-2026	\N	Làng Grôn - Ia Kriêng - Đức Cơ - Gia Lai
06d4851e-7cae-4994-870d-9d57885c88bd	Nguyễn Thị Bảo Ngọc	22/09/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:12.694+00	2025-2026	\N	Chư Bồ 1- Ia Dơk - Gia Lai
c17bc08c-c887-4984-9c88-2f0b2d9d3967	Hồ Thị Anh Thư	24/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:14.213+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
15ba57c2-2fff-4d89-85d4-515f876a90e4	Nguyễn Ngọc Như Ý	13/07/2009	Nữ	Kinh		f	11C4				2026-03-23 13:58:15.653+00	2025-2026	\N	TDP 9 - Đức Cơ - Gia Lai
ba6ba7c7-a0e8-437f-9de5-211f040b8e38	Võ Hương Giang	05/11/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:17.141+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
8d2a3d07-d382-463a-8fdf-9d08b6ebc0f5	Lê Bùi Xuân Mai	11/04/2009	Nữ	Kinh		f	11C5				2026-03-23 13:58:18.578+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
2b67e6f6-fa90-4015-ba31-6e32e6cb60b5	Bùi Minh Quân	27/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:20.047+00	2025-2026	\N	Tổ dân phố 4, Chư Ty, Đức Cơ, Gia Lai
93e4c1df-a235-47cb-9ebb-c98186a9bfa0	Phan Trọng Tuấn	25/02/2009	Nam	Kinh		f	11C5				2026-03-23 13:58:21.483+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
1e8cc3e8-a50e-4d85-8db3-a51d1b2d7e7a	Ksor Dứ	01/10/2009	Nam	Gia-rai		f	11C6				2026-03-23 13:58:22.913+00	2025-2026	\N	Làng Sung Le Tung, Xã Ia Dơk, Tỉnh Gia Lai
4fdf5821-8c5e-4f74-a466-ebdaf6512eae	Trần Khánh Huyền	12/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.391+00	2025-2026	\N	TDP 1 , Xã Đức Cơ , Tĩnh Gia Lai
76a7ae09-83c7-442a-b64d-795bcb42f968	RMah H' Jin	31/10/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:24.528+00	2025-2026	\N	Làng Sung Le Kắt, Xã Ia Dơk, Tỉnh Gia Lai
e7d179a6-70b2-4a20-91de-f7c63a4e9544	Nguyễn Đăng Khoa	03/10/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:24.669+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
1616271d-9962-4feb-b356-91b7e879855e	Kpuih Khuyên	10/07/2009	Nam	Gia-rai		f	11C6				2026-03-23 13:58:24.836+00	2025-2026	\N	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai
3e4e390e-4501-45a8-b170-460abed64f84	Đào Quách Hạ Lan	06/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:24.983+00	2025-2026	\N	Thôn Ia Mang , Xã Ia Dơk, Tỉnh Gia Lai
79550dd9-80e0-4b8e-8682-6c09b1383969	Vũ Đỗ Thùy Lâm	01/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.119+00	2025-2026	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai
4e29f357-4997-44c7-a64b-275378cbf2aa	Rơ Mah Liêm	06/09/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:25.28+00	2025-2026	\N	Làng Sung, Xã Ia Dơk, Tỉnh Gia Lai
5c8297bd-cdd8-430f-b4f1-f29e7180ecad	Đặng Thị Hà Linh	17/08/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.419+00	2025-2026	\N	Làng Triêl, Xã Ia Pnôn, Tỉnh Gia Lai
ea24cd60-67bc-4a46-a5f6-70bd772abeac	Nguyễn Thị Ngọc Linh	25/06/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:25.55+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
de0e07cb-cfdc-4447-b3ee-9de56b636d76	Đinh Mai Loan	13/03/2009	Nữ	Mường		f	11C6				2026-03-23 13:58:25.705+00	2025-2026	\N	Làng Krêl, Xã Iakrêl, Tỉnh Gia Lai
5a31628e-edd8-4c53-9b49-42e475b770bf	Trần Văn Long	14/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:25.848+00	2025-2026	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai
077c6095-64b4-4599-8148-eb646209a6f8	Phạm Gia Bảo Lộc	28/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:25.989+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
d1222f2b-7862-4d3b-b31f-6d4676ffc4fa	Nguyễn Thị Lượng	10/01/2007	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.128+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
c5ba6c36-88f6-475a-be9c-5557ba4d9562	Phan Thị Thúy Ly	17/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.272+00	2025-2026	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai
63c78be7-713e-45bb-be13-ca45d7f4d3ef	Phan Đình Minh	06/06/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:26.431+00	2025-2026	\N	TDP6, Xã Đức Cơ, Tỉnh Gia Lai
59381e5a-27aa-4aa0-8236-1c51bb8e291a	Ksor H' Mlan	09/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:26.58+00	2025-2026	\N	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai
42287fbd-089e-418c-be55-4b93e4952c57	Đỗ Thị Hải My	22/05/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.735+00	2025-2026	\N	TDP 9, Xã Đức Cơ, Tỉnh Gia Lai
20ee3cd9-d292-4fee-8421-8660fc971614	Lưu Thị Thảo Nguyên	24/07/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:26.882+00	2025-2026	\N	TDP7 , Xã Đức Cơ, Tỉnh Gia Lai
b5db3da7-da08-4057-b8cf-dc36fd186086	Hồ Thị Nguyệt	29/12/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.016+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ , Tỉnh Gia Lai
c2293c28-3a92-4917-a3b0-13fa024cb963	Nguyễn Thị Gia Nhi	06/05/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.161+00	2025-2026	\N	Thôn Thanh Tân , Xã Iakrêl , Tỉnh Gia Lai
81214e59-b082-44ab-b5ff-cb5ee6a43417	Nguyễn Thị Quỳnh Nhi	20/01/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.296+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
d653118c-d8c2-40cc-af0f-d4562ac708cb	Trần Linh Nhi	22/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.438+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
24a48163-cf7a-446f-8234-6121d3f686db	Nguyễn Tài Phát	23/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:27.583+00	2025-2026	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai
3f4b1823-485a-4b62-a021-50f48c81164f	Trần Trung Quân	10/10/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:27.737+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
29131a6e-2554-4250-aebc-b91005c6fa7c	Rơ Lan H' Rêny	10/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:27.896+00	2025-2026	\N	Làng Bua, Xã Ia Pnôn, Tỉnh Gia Lai
c0f7e869-fd25-41c9-8772-24d1b5cfc86c	Siu Run	04/12/2007	Nam	Gia-rai		f	11C6				2026-03-23 13:58:28.076+00	2025-2026	\N	Làng Lung Prông, Xã Đức Cơ, Tỉnh Gia Lai
22b4effb-c2c7-42c2-857b-3c1233857dee	Rơ Lan H' Tâm	21/07/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:28.239+00	2025-2026	\N	Làng Dơk Ngol, Xã Ia Dơk , Tỉnh Gia Lai
40310a1a-6235-4c1b-8687-55c47c56b751	Trịnh Thủy Tiên	14/02/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.421+00	2025-2026	\N	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai
b3f0f83a-d339-4714-a742-b7a628f0cb77	Hồ Thị Mai Trinh	17/07/2008	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.734+00	2025-2026	\N	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai
c6ec4e8e-6a1b-45d6-a900-e70c691be9f5	Siu Đỗ Tuấn Hùng	09/03/2009	Nam	Gia-rai		t	11C3				2026-03-26 02:26:11.734+00	2025-2026	HK2	Làng Trol Đen, Xã Đức Cơ, Gia Lai
7296b526-bd56-4a6a-9300-fa6b4b625c85	Lê Ngọc Bảo Trâm	28/07/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:28.589+00	2025-2026	\N	Làng Sung Le Kắt, xã Ia Dơk, Tỉnh Gia Lai
77ce3140-5697-4d8c-960a-d48e08aa1c6f	Rơ Mah H' Dulen	02/12/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:30.176+00	2025-2026	\N	Làng Sung Le Kắt, Ia Dơk , Gia Lai
a3d210a6-cf7c-4481-86b7-e7e25dd35672	Hoàng Thị Hợp	28/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:31.657+00	2025-2026	\N	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai
b82cc3d8-2da6-4566-bb9a-974ca6887dfc	Rơ Lan H' Lyna	12/03/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:33.146+00	2025-2026	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai
55492d8c-6809-49b2-b9b3-1aea0da70712	Đinh Đức Thắng	29/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.583+00	2025-2026	\N	Lang Krol, Xã Ia krêl, Tỉnh Gia Lai
ace23fbc-2b31-41fa-8979-6e8354fa83a7	Rơ Mah H' Chi	01/11/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:37.576+00	2025-2026	\N	Làng Hrang - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai
eca3f4e4-0d44-4210-8828-ed9b8045cffa	Rơ Mah H' Hiệp	14/06/2007	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:39.014+00	2025-2026	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
52e98590-c955-42b2-96dd-d74e2864389a	Ksor Net	01/08/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:40.475+00	2025-2026	\N	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
ded08e2b-8668-4663-b6e1-028c89ed6510	Phạm Thị Bích Thuận	02/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.863+00	2025-2026	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
82a75688-7acd-4015-a2ae-ad5806e282b1	Lường Viết Việt	08/09/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:43.368+00	2025-2026	\N	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
04eccc7d-8439-421e-aee8-ab07b4dec31b	Vũ Quốc Huy	12/06/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:53.282+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
f6f8386d-2eee-45c0-935d-b15f705fb3f1	Rơ Lan H' Thoại	11/08/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:56.346+00	2025-2026	\N	Làng Dơk Ngol, xã Ia Dơk, tỉnh Gia Lai
debc3d6c-b3c9-43e5-bec4-04d6bbc79fdc	Trần Văn Đạt	29/01/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.33+00	2025-2026	\N	Tổ dân phố 3- Chư Ty- Đức Cơ- Gia Lai
e91eccf5-a2a0-48ef-b54a-42476b8b32bc	Trần Thị Diễm Quỳnh	25/10/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:01.48+00	2025-2026	\N	Tổ dân phố 1 - Đức Cơ- Gia Lai
e639dd8e-2b58-41a7-a4d1-1fd9fd546167	Tống Thành Đạt	25/06/2008	Nam	Kinh		f	11C12				2026-03-23 13:59:04.493+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
7b82b3f8-73c7-43c8-896d-3efdaecdaa26	Mai Xuân Khánh	29/09/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:06.003+00	2025-2026	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
eef38dec-b9d1-4a11-9247-828a47a491f9	Chu Đặng Nhật Phương	06/07/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:07.57+00	2025-2026	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai
835afa3d-b955-424f-bb3e-088c79875680	Lê Thị Xuân Mai	21/10/2009	Nữ	Kinh		t	11C11	2024-09-19	0344040341		2026-03-26 04:50:16.232+00	2025-2026	HK2	Tổ dân phố 1- Đức Cơ- Gia Lai
20af80d9-8c54-471f-a317-2a066dbe720c	Nguyễn Ngọc Bảo Trâm	17/11/2009	Nữ	Kinh		t	11C11	2024-09-14	0706131033		2026-03-26 04:51:51.334+00	2025-2026	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai
d9077bf3-6a69-4f26-bedd-958dbf04cb41	Lê Thị Nga	05/10/2009	Nữ	Kinh		t	11C10				2026-03-27 01:06:11.534+00	2025-2026	HK2	Tổ dân phố 3, xã Đức cơ, tỉnh Gia Lai
6bdd3e87-dfcd-4627-8ad5-7edc06dabab5	Rơ Lan Điệp	26/07/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:48:13.581+00	2025-2026	HK2	Làng Dơk Klăh - xã Ia Dơk - Gia Lai
177bf43c-e295-49ac-bbec-144e021d6cf2	Phan Thanh Trà My	16/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:04.215+00	2025-2026	HK2	TDP 7 - xã Đức Cơ - Gia Lai
7cef6cdb-1638-46b9-82cd-528170dcd480	Hồ Thị Thúy Kiều	14/10/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:46.123+00	2025-2026	HK2	TDP2 - Xã Đức Cơ - Gia Lai
fdd21df6-a7a9-4780-a5fe-82c8a32f372a	Đặng Hải Yến	17/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:50:23.236+00	2025-2026	HK2	TDP 1 - xã Đức Cơ - Tỉnh Gia Lai
097d15fe-c46e-472d-ae67-3b1f3ee9ef9c	Lưu Thị Thu Trang	01/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:06.474+00	2025-2026	HK2	Thôn Đoàn Kết - Xã Ia Dơk - tỉnh Gia Lai
97a5867d-cbe4-4cfa-b2d6-978f586483ad	Nguyễn Khắc Tường	2009-05-22	Nam	Kinh		t	11C7	2024-10-21	0344580369		2026-03-29 10:05:56.134+00	2025-2026	HK2	Thôn 2, Xã Phú Riềng, Tỉnh Đồng Nai
1bf1a97a-5581-4ace-b80f-099e1c669ec9	Hoàng Nguyễn Thành Trung	11/01/2009	Nam	Kinh		f	11C6				2026-03-23 13:58:28.907+00	2025-2026	\N	Thôn Thanh Giáo, Xã Iakrêl, Tỉnh Gia Lai
e052696e-c811-4581-9d4d-310ffe710102	Nguyễn Quang Dũng	25/07/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:30.492+00	2025-2026	\N	Thôn Ia Lâm, Iakrêl, Gia Lai
da04c58e-b041-46af-a7cc-e741cd23bc22	Mai Nguyễn Tuấn Hưng	29/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.97+00	2025-2026	\N	Tổ dân phố 9, Xã  Đức Cơ, Tỉnh Gia Lai
6501ebe8-3a77-4c1b-b2af-8bad0b68f5bf	Ksor Kỳ Vọng	22/07/2008	Nam	Gia-rai		f	11C7				2026-03-23 13:58:36.382+00	2025-2026	\N	Làng Sung Le tung, Xã Ia Dơk,  Tỉnh Gia Lai
45ffe0e0-7031-4734-b848-4a1e36fcff45	Nguyễn Công Danh	28/09/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:37.855+00	2025-2026	\N	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
b39af8fc-cd54-42d9-9dea-957a5793ba78	Hồ Thị Thu Hoài	16/12/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.289+00	2025-2026	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
ca605f17-703e-429e-a363-28fb82004dee	Lê Diễm Quỳnh Ngân	31/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.763+00	2025-2026	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
d9c0a6fc-8aaa-4477-8cee-f5b80f5e20cc	Lê Đoàn Thị Thủy Tiên	30/01/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.155+00	2025-2026	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
39300d24-b2ac-4374-a34b-7b876cddbc11	Bùi Thanh Xuân	14/06/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.642+00	2025-2026	\N	Tổ dân phố 6 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
c8310e18-83ea-4a5e-840e-8cc4d2c3aff8	Rơ Mah H' Lệ	16/12/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:46.61+00	2025-2026	\N	Làng Ia Dơk Ngol - Xã Ia Dơk - Gia Lai
bf9a62f7-f370-43cd-bbd0-4dbcab81ef91	Đỗ Quang Hữu	07/05/2008	Nam	Kinh		f	11C10				2026-03-23 13:58:53.6+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
2b17aacb-578d-49d5-9e05-34bc64b315fb	Hồ Anh Thư	13/11/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:56.953+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia lai
5d9d3085-14c0-4279-828e-724554c134c3	Hoàng Trung Hiếu	01/06/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.65+00	2025-2026	\N	Thôn Iatang- Iakla- Đức cơ- Gia lai
5181ceb1-7b78-4dbe-8c89-1358a0fa2e1a	Lê Anh Minh	14/12/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:00.262+00	2025-2026	\N	Tổ dân phố 7- Đức Cơ- Gia Lai
4e128bd3-0d5b-4e47-a6d1-95db4b8ae83f	Cao Thái Sơn	26/05/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:01.799+00	2025-2026	\N	Tổ dân phố 6 - Đức Cơ- Gia Lai
3e631f27-48da-4a5f-8f0b-adacdccd5f99	Nguyễn Văn Tuấn	16/09/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:03.325+00	2025-2026	\N	Tổ dân phố 2- Đức Cơ- Gia Lai
ca5c8ee4-7988-438d-8cee-b7068064f86f	Lại Hoàng Bảo Hân	29/05/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:04.79+00	2025-2026	\N	Tổ dân phố 1, Phường Pleiku, Tỉnh Gia Lai
8f412ae2-f76f-4f2f-9aec-dffbf1043a48	Nguyễn Thị Thùy Linh	19/05/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:06.322+00	2025-2026	\N	Tổ dân phố 9, Xã Đức Cơ, Tỉnh Gia Lai
09a3934d-30bf-43e1-876f-04dbdf2badb5	Đặng Duy Quốc Quân	04/09/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:07.949+00	2025-2026	\N	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai
25808d2f-e5f8-4e3e-afd1-6b8c4555390e	Nguyễn Ngọc Tiên Nhi	26/02/2009	Nữ	Kinh		t	11C10				2026-03-27 01:07:00.688+00	2025-2026	HK2	Thôn Ia Lâm Tốc, xã Ia Krêl, tỉnh Gia Lai
731211bd-f11b-47d2-b43a-b8220940edcf	Nguyễn Vũ Hải Anh	11/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:08:00.023+00	2025-2026	HK2	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
ecc7e4b7-edf3-4895-a9e1-08c50d2a861d	Lê Quỳnh Như	25/03/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:14.852+00	2025-2026	HK2	TDP 6 - xã Đức cơ - Gia Lai
49ffd0c1-3d18-4bbc-b3cf-554c194dfba0	Rơ Mah H' Hần	13/09/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:51:01.326+00	2025-2026	HK2	Làng Sung Kép - Ia Dơk - Gia Lai
43d92203-94f2-4534-b5d1-9c2388e6169a	Lê Tây Hùng Trường	21/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:52:42.36+00	2025-2026	HK2	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai
288f3df5-11f6-45d3-971f-8dd2e163172f	Hồ Thị Nguyên	2009-07-03	Nữ	Kinh		t	11C7	2024-05-06	0369569267		2026-03-28 22:53:56.109+00	2025-2026	HK2	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai
80393b63-96a7-4fc6-8678-d72f4a6b7bf4	Văn Võ Anh Thơ	2009-07-02	Nữ	Kinh		t	11C7	2026-01-19	03354213		2026-03-28 22:55:37.377+00	2025-2026	HK2	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
ab87653b-5dcd-4a06-87f2-1d0d7acabd2a	Ngô Thảo Vy	15/11/2009	Nữ	Kinh		f	11C6				2026-03-23 13:58:29.066+00	2025-2026	\N	Làng Ngo Le 2, Xã Ia Krêl, Tỉnh Gia Lai
84ac0880-6825-48e5-8aeb-decb2b61402f	Nguyễn Hữu Duy	21/01/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:30.648+00	2025-2026	\N	Thôn Ia Tang,Ia Dơk, Gia Lai
c6f6665c-15bd-423e-a177-55c5ad77a556	Nguyễn Hồng Lai	17/04/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:32.117+00	2025-2026	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
de6619e0-2001-426c-bab5-b7fcf5e108ab	Rơ Lan H' Thư	29/03/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:35.061+00	2025-2026	\N	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai
9894332a-f038-4d38-b32f-103b13dc254f	Ksor Long Vũ	22/07/2008	Nam	Gia-rai		f	11C7				2026-03-23 13:58:36.538+00	2025-2026	\N	Làng Sung Le Tung, Xã Ia Dơk,  Tỉnh Gia Lai
610044a0-55d0-4590-8fc4-c0821bf8f328	Lương Thị Mỹ Duyên	17/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:38.022+00	2025-2026	\N	Thôn Iatang, Ia Kla, Đức Cơ, Gia Lai
05a6f664-7c39-4008-8872-3470bb07b204	Nguyễn Ngọc Hưng	04/10/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:39.434+00	2025-2026	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
b905d8dc-5ca3-4db1-84e8-553ea8cb855b	Phạm Thảo Nguyên	08/11/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.908+00	2025-2026	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
a5983fb6-06da-4e98-99af-4568e92ecdc1	Lê Thị Thủy Tiên	30/03/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.291+00	2025-2026	\N	Tổ dân phố 2, Chư Ty, Đức Cơ, Gia Lai
6e909183-d169-4fa4-adc6-0b0a1e8f0bfe	Rơ Mah H' Xuân	17/11/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:43.799+00	2025-2026	\N	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
fb3d6b03-d3ea-4641-b44f-5f866668e30b	Trần Đình Tú	09/03/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:50.33+00	2025-2026	\N	Thôn Ia Tang - xã Ia Dơk - Gia Lai
d7253c52-2efb-4b00-acb4-51edd46b02d4	Phạm Ngọc Khánh Băng	04/11/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:52.136+00	2025-2026	\N	Làng Khóp, xã Iakrêl, tỉnh Gia Lai
b6385120-f9f0-4c28-964e-6594b2aaabd5	Mai Hoàng Phi	10/07/2008	Nam	Kinh		f	11C10				2026-03-23 13:58:55.206+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
fa8124cb-5c38-4526-962d-42189be91762	Ngô Đức Hiếu	24/09/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.805+00	2025-2026	\N	Tổ dân phố 4- Chư Ty- Đức Cơ- Gia Lai
8afcb311-be53-432d-b167-5ec73c58615f	Nguyễn Khắc Tân	23/10/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:01.947+00	2025-2026	\N	Tổ dân phố 7 - Đức Cơ- Gia Lai
8b99282b-51cf-411f-b377-20e10f3ae0f1	Kim Ngọc Long	16/09/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:06.47+00	2025-2026	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai
69a061d8-edbd-4261-99d2-1960bea8ebcf	Vũ Diệu Thảo	26/09/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:08.108+00	2025-2026	\N	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai
c3c9e8e3-bb7d-40c6-bafe-16c3640bf2b8	Huỳnh Thị Diễm My	18/01/2009	Nữ	Kinh		t	11C11	2024-12-28	033 6850730		2026-03-26 04:49:01.351+00	2025-2026	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai
47fb78ed-d332-4e96-9a48-a3aa8213b383	Mã Thị Kim Tuyến	16/01/2009	Nữ	Kinh		t	11C11	2024-09-14	0392466042		2026-03-26 04:49:43.584+00	2025-2026	HK2	Thôn chư bồ 1-iadok- Gia Lai
ea629791-0320-4363-acb1-22828ee96f1f	Nguyễn Thị Ngọc Hân	2009-09-06	Nữ	Kinh		f	11C12				2026-03-27 00:39:08.329+00	2025-2026	HK2	Thôn Ia Lâm Tôk, Xã Ia Krêl, Tỉnh Gia Lai
fbc232dd-112e-4d25-8f7a-0c93b4363ca7	Lê Văn Tiến	30/09/2009	Nam	Kinh		t	11C10				2026-03-27 01:06:23.242+00	2025-2026	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai
c34ec979-147f-4a00-bbdd-8efb79f1efb2	Rơ Mah H' Hyưng	05/01/2009	Nữ	Gia-rai		t	11C10				2026-03-27 01:08:18.21+00	2025-2026	HK2	Làng Khóp, xã Iakrêl, tỉnh Gia Lai
b07f85a6-eb20-4339-a3a5-04e33d119260	Siu Quyết	2009-07-30	Nam	Gia-rai		t	11C9				2026-03-28 10:43:56.812+00	2025-2026		Làng Hrang - xã Đức Cơ - Gia Lai
17d6aa72-10d1-4cc6-b413-bce3de96cc01	Mai Đức Hiếu	27/02/2009	Nam	Kinh		t	11C9				2026-03-28 10:47:22.605+00	2025-2026	HK2	TDP 4 - Đức Cơ - Gia Lai
49b0089a-191d-4124-9549-e0b7b7dfebef	Ngô Phạm Thùy Linh	24/07/2009	Nữ	Kinh		t	11C9				2026-03-28 10:51:17.808+00	2025-2026	HK2	Làng TrolĐeng - xã Đức Cơ - tỉnh Gia Lai
984ceeeb-c970-4243-9fc0-2143e88e7b62	Ngô Thị Thảo Nguyên	2009-08-19	Nữ	Kinh		f	11C7		0358280046		2026-03-28 22:56:40.488+00	2025-2026	HK2	Làng Krel, Xã Ia krêl, Tỉnh Gia Lai
31f518ac-da83-4dae-890c-0dfbc1ea9a47	Rơ Mah H' Xari	10/03/2009	Nữ	Gia-rai		f	11C6				2026-03-23 13:58:29.234+00	2025-2026	\N	Làng Sung Le Kắt, Xã Ia Dơk , Tỉnh Gia Lai
f999cb05-84a5-49b6-9e99-061b00bd01b3	Đỗ Hà Lan	28/10/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:32.255+00	2025-2026	\N	Làng Krel, Xã Đức Cơ, Gia Lai
e957a8d2-550c-420a-bc2e-ce3edf295a47	Hồ Tuyết Nhi	21/11/2008	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.706+00	2025-2026	\N	Tổ 3, Xã Đức Cơ, Tinh Gia Lai
c72122c4-6774-4328-822b-8e8cf894492f	Nguyễn Vũ Trúc Thy	02/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.197+00	2025-2026	\N	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai
aa86d92e-5c18-42ef-aff0-734abc20dd22	Hoàng Thị Hải Yến	27/09/2006	Nữ	Kinh		f	11C7				2026-03-23 13:58:36.683+00	2025-2026	\N	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai
f7f744b7-183b-4404-9ad7-961bdbc3208b	Phan Trần Thành Đạt	27/01/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:38.175+00	2025-2026	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
85b7e1db-bd32-4f4e-8cf7-ad1390616a21	Nguyễn Thị Mai Lan	16/04/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.602+00	2025-2026	\N	Làng Trol Đeng - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
0636d010-1927-4102-ae8a-4612a8ec10f7	Hồ Diên Nhật	24/07/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:41.044+00	2025-2026	\N	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
90013f38-f277-4bf7-9b06-9e74ee1f3a10	Đỗ Thị Huyền Trang	31/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.427+00	2025-2026	\N	Thôn Chư Bồ I - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
0fba99ba-6789-43a8-98a2-474dbd8df77d	Trần Lê Ngọc Anh	23/06/2009	Nữ	Kinh		f	11C9				2026-03-23 13:58:43.938+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
a11b688f-7467-4cbc-8bf7-141d0bc9966c	Nguyễn Ngọc Hiếu	05/10/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:45.428+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk - Gia Lai
ebc991e9-0bfa-4008-ab41-89ac79626754	Phan Nguyễn Anh Tuấn	09/08/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:50.497+00	2025-2026	\N	Làng Lang - xã Ia Dơk - Gia Lai
c8e5bcc6-dd6a-44ff-b008-249cb82a2dac	Siu Châm Khang	09/11/2008	Nam	Gia-rai		f	11C10				2026-03-23 13:58:53.896+00	2025-2026	\N	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai
e052839c-4c78-47de-b7b1-d12f4bfc1abc	Hoàng Quang Hải Quân	06/01/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.354+00	2025-2026	\N	Tổ dân phố 7, xã Đức cơ, tỉnh Gia Lai
4187fc2a-ecb1-4b47-8d0d-818f132cf4a9	Kpuih H' Tinh	07/02/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:57.262+00	2025-2026	\N	Làng Trol Đeng, xã Đức Cơ, Gia Lai
fa15a5c0-2db3-4869-83bb-83eb8af8de4b	Rơ Mah A Thanh	12/10/2009	Nam	Gia-rai		f	11C11				2026-03-23 13:59:02.099+00	2025-2026	\N	Làng sung Le Tung- ladok - Gia Lai
4cc1238f-4257-4064-b012-90999b3d401c	Lê Quang Hiếu	09/04/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.074+00	2025-2026	\N	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai
0b91027f-3501-478b-8821-e889defd8904	Hồ Hữu Mạnh	29/10/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:06.624+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
9ab2b93a-25c6-4659-a188-a3fed4d2f066	Phạm Trần Anh Thư	29/10/2008	Nữ	Kinh		f	11C12				2026-03-23 13:59:08.276+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
abc80259-d940-46bf-b946-8ba67506e87b	Bùi Thị Tường Vy	2009-10-03	Nữ	Kinh		t	11C11	2025-09-14	0345685398		2026-03-26 02:23:59.102+00	2025-2026	HK2	Thôn chư bồ 1- Iadok-Gia Lai
afc32642-87a3-47f9-aeb9-7326c9f3102c	Trần Minh Hiếu	21/01/2009	Nam	Kinh		t	11C11	2025-01-09	0327889830		2026-03-26 04:51:04.888+00	2025-2026	HK2	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai
05e00bfa-db20-47fe-8dda-3ea2194c8609	Đặng Bảo Nam	04/08/2009	Nam	Kinh		t	11C11	2025-01-09	0398869302		2026-03-26 04:52:35.461+00	2025-2026	HK2	Tổ dân phố 4- Đức Cơ- Gia Lai
5a90323c-b9bb-48a8-b3b8-2ca43c7fac7d	Lê Đình Dụng	17/03/2009	Nam	Kinh		t	11C10				2026-03-27 01:05:30.165+00	2025-2026	HK2	Làng ấp, xã Ia Kriêng, tỉnh Gia Lai
81ae88f1-3c99-463a-bc92-fa5b3e23d5b9	Đỗ Thị Thanh Thảo	03/03/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:58.273+00	2025-2026	HK2	TDP 7 - xã Đức Cơ - Gia Lai
adaa5d5a-b1f1-4ed3-aba0-9676706dfa05	Ngô Thị Khánh Ly	14/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:34.268+00	2025-2026	HK2	Thôn Chư Bồ 1 - Xã Ia Dơk - Gia Lai
9264b026-bf60-4f34-ac71-4e3173b9dc71	Nguyễn Thị Mỹ Duyên	2009-11-10	Nữ	Kinh		f	11C7		0868220435		2026-03-29 10:01:51.364+00	2025-2026	HK2	Tổ 9, Chư Ty, Đức Cơ, Gia Lai
9de0ffed-2437-4f57-8086-d633bdf42c9c	Đỗ Nguyễn Thiên Ái	08/12/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:29.366+00	2025-2026	\N	Chư bồ 1- Ia Dơk- Gia Lai
bcd71496-703b-4147-afd9-4da246e1c4ec	Hồ Hữu Đại	15/09/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:30.936+00	2025-2026	\N	Tổ dân phố 3 - Xã Đức Cơ - Tỉnh Gia Lai
3107d2be-c342-40a7-9664-dfd7cc38d186	Rơ Mah H' Lang	08/06/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:32.406+00	2025-2026	\N	Làng Lang Hrang, Xã Đức Cơ, Tỉnh Gia Lai
6cd458b6-8f6b-42be-a53e-70c2f98ddf5e	Thiều Hoàng Yến Nhi	03/07/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.864+00	2025-2026	\N	Tổ 3, Xã Đức Cơ, Tỉnh Gia Lai
db87c044-75f2-4446-91e7-84148a3f40f6	Nguyễn Như Tình	10/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.366+00	2025-2026	\N	Tổ 2, Xã Đức Cơ, Tỉnh Gia Lai
0f7c0fa5-7ba2-4f4a-ac47-38dc43384f4d	Rơ Mah Điềm	20/06/2008	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:38.33+00	2025-2026	\N	Làng Sung Lớn - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
fa3c23b5-70f6-426c-98e9-6e4c49b51325	Rơ Lan Lâm	26/08/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:39.758+00	2025-2026	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
0a99db8e-575b-4350-8221-c723fa97e1ac	Vũ Quang Nhật	27/03/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:41.213+00	2025-2026	\N	Thôn Chư Bồ II - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
f9c48044-beb9-4ca0-ae76-13586115e60a	Kpuih Trí	17/09/2009	Nam	Gia-rai		f	11C8				2026-03-23 13:58:42.578+00	2025-2026	\N	Làng Lung - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai
46dee9e9-0e6e-4b90-ad43-9ff5c2237596	Rơ Lan H' Lysa	12/01/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:47.06+00	2025-2026	\N	Làng Sung Le Kắt - Xã Ia Dơk - Gia lai
6b64130b-7240-4b2f-8c60-381babc8eb71	Kpuih H' Tuyết	07/04/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:50.684+00	2025-2026	\N	Làng Lang - xã Ia Dơk - Gia Lai
deea0c5e-6693-438b-95fd-bed7773331bf	Nguyễn Thị Mai Linh	15/12/2009	Nữ	Kinh		f	11C10				2026-03-23 13:58:54.051+00	2025-2026	\N	Làng Khóp, xã Iakrêl, tỉnh Gia Lai
982edc30-d71e-45de-b860-2dbd2a26e4d7	Trịnh Quốc Quân	30/08/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.523+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
4df92eaf-43f5-466d-88de-474c7c111c39	Nguyễn Văn Nguyên Hoàng	20/04/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:59.145+00	2025-2026	\N	Làng Hrang- Đức Cơ - Gia Lai
a3b4c2d8-b70b-464a-8282-c77ad9e70605	Kpuih H' Ngát	10/08/2009	Nữ	Gia-rai		f	11C11				2026-03-23 13:59:00.714+00	2025-2026	\N	Xã Iakrieng- Đức Cơ- Gia Lai
f0869dd8-0c61-4e2b-bad0-4dc402f477aa	Trần Thành An	09/12/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:03.772+00	2025-2026	\N	Thôn Ia Chia, Xã Ia Nan, Tỉnh Gia Lai
647de030-3be1-4f59-91f0-a9f19b993352	Phạm Khánh Hoà	01/08/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.226+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
df50fd43-81cd-47da-848b-28d2f7df861d	Kpă Mathê	17/04/2009	Nam	Gia-rai		f	11C12				2026-03-23 13:59:06.778+00	2025-2026	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai
0c6b04b7-2a4c-4b08-978f-605588ed49f6	Trần Thị Anh Thư	29/10/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:08.439+00	2025-2026	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai
87c87f73-e750-4c2d-b91c-e5f109ff2e33	Nguyễn Anh Thịnh	30/04/2009	Nam	Kinh		t	11C11	2024-01-09	0372442289		2026-03-26 04:53:55.204+00	2025-2026	HK2	Tổ dân phố 4 - Đức cơ- Gia Lai
542ca34b-93db-4a05-9cfd-688fd8266197	Mai Thị Huyền Trang	26/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:06:48.276+00	2025-2026	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia lai
51b84e02-5b81-4cf8-92c1-7cdd446a9f09	Nguyễn Trương Đắc Đạt	08/04/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:43.141+00	2025-2026	HK2	Thôn Iamang, xã IaDơk, tỉnh Gia Lai
40724bd9-1c8a-4f9d-baa2-84e4803c01a6	Bùi Mai Hoa	18/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:47.019+00	2025-2026	HK2	Làng Krêl - Ia Krêl - Gia Lai
785bec33-d4d0-45d7-80a3-49b2a3859173	Trần Nguyễn Mai Anh	28/07/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:20.031+00	2025-2026	HK2	TDP 1 - Đức Cơ - Gia Lai
7fdc5e38-5773-4fed-b710-a7a855b0f31c	Lường Viết Thuận	23/08/2009	Nam	Kinh		t	11C9				2026-03-28 10:52:26.542+00	2025-2026	HK2	Lệ Kim - xã Ia Dơk - Gia Lai
c4757cd2-4478-4e0d-aa1a-f895dfd9f2ed	Phạm Ngô Hoàng Yến	2009-07-06	Nữ	Kinh		t	11C7	2024-04-21	0344307611		2026-03-29 10:03:56.863+00	2025-2026	HK2	Tổ 6, Xã Đức Cơ, Tỉnh Gia Lai
16f0e3d0-1bfe-47f6-a737-35e4a7452a0d	Nguyễn Thị Vân Anh	27/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:29.516+00	2025-2026	\N	Làng Krel- Iakrêl- Gia Lai
3f2c8c4b-aa9a-4758-9a60-ac47ff8d5765	Nguyễn Phùng Đạt	30/06/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.078+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
d46db213-a03a-4d36-96a4-38013bc6b8aa	Hồ Thị Nhung	11/01/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:34.014+00	2025-2026	\N	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai
d9831a87-b463-4d27-8ea3-dc80092d495d	Lương Thị Linh An	24/09/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.009+00	2025-2026	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
60751503-b03e-4720-9d0a-ee4a2a84246e	Rơ Mah H'phương	23/01/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:38.464+00	2025-2026	\N	Làng Poong - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
0a4e59dc-cf48-41c9-9554-c7ed639e2539	Đặng Thùy Linh	25/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:39.91+00	2025-2026	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
81fdfcc7-aff9-4443-a168-eb45fa3d3734	Nguyễn Hoài Bảo Như	31/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.339+00	2025-2026	\N	Tổ dân phố 3 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
ea717622-a82a-44b4-b2dc-c96197af3e89	Mai Trung Tuyển	12/10/2008	Nam	Kinh		f	11C8				2026-03-23 13:58:42.748+00	2025-2026	\N	Tổ dân phố 2- Chư Ty- Đức Cơ- Gia Lai
ca785681-53e3-42ab-8071-dc665a45ef31	Nguyễn Gia Ân	05/08/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:44.234+00	2025-2026	\N	Thôn Đoàn Kết - Xã Ia Krêl - Tỉnh Gia Lai
7567d038-4a7e-40c2-9c0f-1bba44b12137	Ksor Hòa	01/04/2009	Nam	Gia-rai		f	11C9				2026-03-23 13:58:45.71+00	2025-2026	\N	Làng Hrang - Đức Cơ - Gia Lai
146fdb02-0c4c-49b2-b32f-efb174b3f886	Bùi Lương Hải Đăng	12/08/2009	Nam	Mường		f	11C10				2026-03-23 13:58:52.669+00	2025-2026	\N	TỔ dân phố 3, Chư Ty, Đức CƠ, Gia Lai
1394f89b-1f75-4624-820e-a773b5d62a3c	Kiều Tuấn Sang	07/10/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.666+00	2025-2026	\N	xã Ia Kriêng, tỉnh Gia Lai
8cdd1e55-2614-4e9a-ab36-09099d1b97e2	Nguyễn Tiến Vinh	11/11/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:57.584+00	2025-2026	\N	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai
b87c4788-bb06-46d6-a302-91d3ce976de9	Nguyễn Văn Lâm	18/11/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:59.303+00	2025-2026	\N	Thôn chư bồ 1- Iakla- Đức cơ - Gia lai
739a4ffa-2149-4054-9d38-8a564fc6728d	Siu H' Dịu	22/01/2009	Nữ	Gia-rai		f	11C12				2026-03-23 13:59:03.913+00	2025-2026	\N	Làng Lang, Xã Ia Dơk, Tỉnh Gia Lai
9a1c1fc5-be1f-47fb-86b8-6a48bdadf3df	Phan Công Hùng	10/03/2008	Nam	Kinh		f	11C12				2026-03-23 13:59:05.369+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
d0ad0ef5-3523-4ee8-98df-00c41cd69f16	Hồ Thúy Nga	21/11/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:06.945+00	2025-2026	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai
d7466a45-637c-4355-ab6a-37037696e1c0	Hoàng Thị Thanh Thúy	18/09/2009	Nữ	Kinh		t	11C11				2026-03-26 02:18:27.992+00	2025-2026	HK2	Tổ dân phố 4 - Đức cơ- Gia Lai
11754698-c919-45eb-bc73-913ec4700980	Bạch Thị Bảo Ngọc	16/07/2008	Nữ	Kinh		t	11C11	2025-09-14			2026-03-26 02:23:37.625+00	2025-2026	HK2	Tổ dân phố 9- Đức Cơ- Gia Lai
c15ea371-e3c3-4007-9206-2f88c7d56b2f	Hoàng Nguyễn Bảo Long	09/10/2009	Nam	Kinh		t	11C10				2026-03-27 01:05:16.636+00	2025-2026	HK2	TỔ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
d8ba8902-effe-49f7-a926-085946260049	Tăng Văn Mạnh	08/01/2009	Nam	Kinh		f	11C9				2026-03-28 10:25:05.719+00	2025-2026		Ia Lâm - xã Ia Krêl - Gia Lai
edaafec7-1f49-4741-a4cb-cb17ea29e040	Lê Bảo Uyên	21/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:50:01.663+00	2025-2026	HK2	TDP 6 - xã Đức Cơ - Gia Lai
ec03b35f-dfed-47af-8caa-c62bdf5f0dbd	Nguyễn Anh Thư	18/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:56.302+00	2025-2026	HK2	TDP 9 - xã Đức Cơ - Gia Lai
9dccd05c-526f-4e43-98e1-c3d16bb8fd4e	Đoàn Thị Mỹ Lệ	2009-09-13	Nữ	Kinh		t	11C7	2023-11-20	0387058713		2026-03-28 22:51:11.562+00	2025-2026		Thôn Chư bồ 1, Xã Ia Dơk, Tỉnh Gia Lai
8f8a1a5d-692a-4243-9196-5f901d21b4d2	Trịnh Ngọc Khánh Trang	31/05/2009	Nữ	Kinh		t	11C7	2024-09-18	0345181657		2026-03-28 22:54:21.513+00	2025-2026	HK2	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai
2ed5d5f2-7e4c-4278-a557-79afd0fb8bcb	Lê Trần Gia Bảo	03/01/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:29.685+00	2025-2026	\N	Phường Pleiku, Tỉnh Gia Lai
4e9086d7-48ad-40e2-a99a-1fda9c824789	Nguyễn Thị Thanh Hằng	29/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:31.223+00	2025-2026	\N	Tổ dân phố 1, Đức Cơ, Gia Lai
9ab2c379-baf8-4f74-8a45-2574bf546c07	Siu H' Li-ya	08/04/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:32.675+00	2025-2026	\N	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai
4f47a42a-98d1-4ded-b9ad-c2d0ee96b8be	Đinh Thị Quỳnh Như	16/09/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:34.148+00	2025-2026	\N	Tổ 9, Xã Đức Cơ, Tỉnh Gia Lai
52eff953-ea0f-454d-8143-2f10e35847d7	Hoàng Anh Tuấn	18/06/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:35.652+00	2025-2026	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai
db5e3772-492a-49f6-be61-07736f135a06	Rơ Mah H' Bạch	20/01/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:37.16+00	2025-2026	\N	Làng Sung Le Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
6e803843-4f5e-46ae-bbd0-96f40dc0943f	Trần Thị Mỹ Hạ	29/10/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:38.602+00	2025-2026	\N	Thôn Thanh Tân - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
a2d29e5e-7d7a-4516-9bb6-0f4f351c2f68	Đinh Thị Thùy Linh	21/07/2008	Nữ	Kinh		f	11C8				2026-03-23 13:58:40.06+00	2025-2026	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
b2fdf05a-ed13-407c-ac24-107e4a0331d1	Rơ Châm H' Plil	19/07/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:41.475+00	2025-2026	\N	Làng Khóp - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
80d0b73a-bb20-456b-81f8-a9e9ce236ae0	Trần Tố Uyên	28/06/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.931+00	2025-2026	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
b821ee27-a45a-4a67-a02c-acae88f78837	Rơ Mah H' Bdít	12/10/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:44.401+00	2025-2026	\N	Làng Pong - Ia Dơk - Gia Lai
cf35b19c-6a66-4cf1-a3ae-ff2ec40481f6	Phùng Chí Long	28/06/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:54.314+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
71767878-bb5f-43d2-a409-17a95f26ff39	Nguyễn Văn Sang	13/11/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:55.82+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
3b86ae24-61e0-46ed-a553-e48ba54b6e8d	Lê Đức Bảo	31/05/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:57.824+00	2025-2026	\N	Làng Iatang- Iadok- Đức Cơ- Gia Lai
f6d8265b-6a9e-4b84-b7da-8859f8db0866	KSOR H' LIA	06/04/2008	Nữ	Gia-rai		f	11C11				2026-03-23 13:58:59.466+00	2025-2026	\N	Làng Sung Le Tung - Iatuk - Gia Lai
8bc698e4-3e3e-4263-b581-4a35a5fa5f87	Nguyễn Đức Dương	24/10/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:04.05+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
71d89426-a1a2-49f4-881f-5c9898718bf9	Nguyễn Hoàng Gia Huy	18/07/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.517+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
5b4cd120-6b29-4ec6-b695-c2ba6a4effac	Hoàng Bảo Ngân	11/07/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:07.119+00	2025-2026	\N	Làng Kom Ngó, Xã Ia Chia, Tỉnh Gia Lai
ca26d313-1cc3-4afc-8b47-bcd94628bbd6	Lương Thị Yến Nhi	19/03/2009	Nữ	Kinh		t	11C11		038 4626009		2026-03-26 02:25:05.342+00	2025-2026	HK2	Tổ dân phố 2- Đức Cơ- Gia Lai
f1f7e40a-a5d6-47df-adc2-40fda1c32d13	Trần Hồ Anh Thư	09/10/2009	Nữ	Kinh		t	11C11	2024-01-09	0967874123		2026-03-26 04:53:13.609+00	2025-2026	HK2	Tổ dân phố 1- Đức Cơ- Gia Lai
4c229b52-6a6b-485c-ad5b-5a6ce5cfbbd2	Nguyễn Xuân Hà	22/01/2009	Nam	Kinh		t	11C10				2026-03-27 01:08:07.191+00	2025-2026	HK2	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
9fc0cea3-2187-460c-a070-2af5c87bac8a	Nguyễn Sỹ Hoàng	12/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:46:20.833+00	2025-2026	HK2	Thôn Thanh Tân - Ia Krêl - Gia Lai
78c88923-615a-43aa-85ae-db9ce325b993	Hoàng Yến My	09/04/2009	Nữ	Kinh		t	11C9				2026-03-28 10:47:57.943+00	2025-2026	HK2	Thôn Chư Bồ 1 - Đức Cơ - Gia Lai
77337c4c-6f0c-47ef-8ddd-caf97c2a556a	Hoàng Ngọc Huyền Trang	28/06/2009	Nữ	Kinh		t	11C9				2026-03-28 10:48:29.209+00	2025-2026	HK2	Ia Tang - xã Iadok - Gia Lai
062e518f-b6ba-4bf5-b3ea-05cb92eb5b7e	Rơ Mah H' Uyên	28/11/2009	Nữ	Gia-rai		t	11C9				2026-03-28 10:51:33.271+00	2025-2026	HK2	Làng Sung Tung - xã Ia Dơk - Gia Lai
28b22e7b-7e12-42e2-b936-3d5092413259	Rơ Mah Hân	26/11/2008	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:31.363+00	2025-2026	\N	Làng Lang Pong, Xã Iadơk, Tỉnh Gia Lai
16748258-0e33-4a8d-8f0f-8f65a2d14f32	Hoàng Ngọc Bảo Long	09/06/2008	Nam	Kinh		f	11C7				2026-03-23 13:58:32.823+00	2025-2026	\N	Thôn Iatang, Xã Ia Dơk, Tỉnh Gia Lai
de58d862-f04b-4552-a136-416efbac62b0	Cù Ngọc Sáng	29/07/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.292+00	2025-2026	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
5d8b0e52-a867-4472-9593-603d651b99c5	Mai Thị Ánh Tuyết	01/06/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:35.799+00	2025-2026	\N	Tổ 4, Xã Đức Cơ, Tỉnh Gia Lai
332b53cd-3f1b-499a-9921-5abd3d1dd4b2	Trịnh Thị Hồng Bích	26/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.305+00	2025-2026	\N	Thôn Ia Lâm - xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
2fc7eb58-93d6-4f03-884b-e79ce398f759	Hà Gia Hân	16/01/2009	Nam	Thái		f	11C8				2026-03-23 13:58:38.744+00	2025-2026	\N	Làng Grôn - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai
2083d0ed-7b13-42b2-9920-e5cc79aeb529	Ksor Mai Linh	28/12/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:40.2+00	2025-2026	\N	Tổ dân phố 1 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
af48a2ca-937f-4649-9811-323774b1faa6	R Mah H' Yu Ri	10/10/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:41.605+00	2025-2026	\N	Làng Sung Le Kắt - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
91817b2c-508b-4124-ae7e-1939a8301e87	Hồ Thị Thanh Vân	05/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.084+00	2025-2026	\N	Thôn Thanh Giáo - Xã Ia Krêl - Huyện Đức Cơ - Tỉnh Gia Lai
804d98d5-4bca-4973-bd31-a50df2d1244e	Mai Văn Tuấn Đạt	14/03/2009	Nam	Kinh		f	11C9				2026-03-23 13:58:44.539+00	2025-2026	\N	TDP 2 - Đức Cơ - Gia Lai
0ec78550-c28d-410c-a4f0-2d32bf704195	Rơ Mah Vũ	13/09/2008	Nam	Gia-rai		f	11C9				2026-03-23 13:58:51.232+00	2025-2026	\N	Làng Sung - xã Ia Dơk - Gia Lai
a403da2f-c3e0-4ea9-9583-c051154fe4d2	Rơ Châm H' Hà	09/12/2009	Nữ	Gia-rai		f	11C10				2026-03-23 13:58:52.993+00	2025-2026	\N	Làng Hrang, xã Ia Kiêng, tỉnh Gia Lai
7b3b945b-4956-4eba-af49-d6af3cfce237	Dương Hữu Lộc	16/03/2009	Nam	Kinh		f	11C10				2026-03-23 13:58:54.464+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai
86563e05-62a2-4979-8fe7-e4989e11d977	Bùi Quang Dương	01/02/2008	Nam	Kinh		f	11C11				2026-03-23 13:58:57.991+00	2025-2026	\N	Tổ dân phố 9- Chư Ty- Đức Cơ- Gia Lai
57df4632-5181-4070-a25e-60e6211d5271	Phạm Lê Hoài Thương	08/11/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:02.728+00	2025-2026	\N	Tổ dân phố 3- Đức Cơ- Gia Lai
e9596774-8bea-4462-855c-60d1e7edf0ae	Trương Đắc Dương	10/07/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:04.206+00	2025-2026	\N	Tổ Dân Phố 4, Xã Đức Cơ, Tỉnh Gia Lai
3ee749f7-ac66-44d0-b8ff-8d06d989b4d1	Nguyễn Hồ Nhật Hưng	27/11/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.675+00	2025-2026	\N	Thôn Ia Kăm, Xã Ia Krêl, Tỉnh Gia Lai
8b29cbc7-baf4-4f12-aa52-adce4774dcf3	Mai Thanh Nguyên	28/10/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:07.263+00	2025-2026	\N	Thôn Chư Bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
30a8b007-0db3-4a1d-a56c-713af0dd6f6d	Phạm Nguyễn Hoàng Linh	12/05/2009	Nữ	Kinh		t	11C11				2026-03-26 02:19:33.108+00	2025-2026	HK2	Tổ dân phố 4-Đức Cơ- Gia Lai
5ab534b7-3bfe-4120-9e29-21fd96e046f7	Vũ Minh Phương	21/09/2009	Nữ	Kinh		t	11C11	2025-09-14	0375374792		2026-03-26 02:25:38.763+00	2025-2026	HK2	Thôn Chư Bồ 2 - Iadok - Gia Lai
440b60d2-0be6-401a-9ca6-03787396db35	Nguyễn Văn Tài	06/10/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:53.02+00	2025-2026	HK2	Tổ dân phố 2, xã Đức cơ, tỉnh Gia Lai
a17a332e-eac6-4700-9172-8e34e6fe7e54	Hoàng Thị Cao Trang	24/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:44:32.887+00	2025-2026	HK2	TDP 9 - xã Đức Cơ - Gia Lai
45d3d5cb-d945-4183-89b4-475bf7cb698d	Lê Thị Trà My	15/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:48:56.18+00	2025-2026	HK2	TDP 4 - xã Đức Cơ - Gia Lai
78a4a0f0-0bc5-4e5b-8654-0c364f55f136	Cầm Thị Hường	19/03/2009	Nữ	Thái		t	11C9				2026-03-28 10:50:35.734+00	2025-2026	HK2	Làng Krai - Xã Đức Cơ - Gia Lai
884638a5-4bc2-4aa2-a53e-568e101bea20	Phan Khanh Hoà Bình	2009-11-25	Nam	Kinh		t	11C7	2024-09-18	0328348334		2026-03-28 22:52:42.321+00	2025-2026	HK2	Chư bồ 1, Ia Dơk, Gia Lai
d48e3588-3ba5-4692-b9c2-a4e71e7bd98a	Võ Đặng Ngọc Châm	15/09/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:30.016+00	2025-2026	\N	Tổ 9, Đức Cơ, Gia Lai
daa9ff1c-563b-4635-8e46-380fb650657a	Nguyễn Xuân Hiệp	20/11/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.513+00	2025-2026	\N	Làng Kom Ngó, Xã Iachia, Tỉnh Gia Lai
029ee39a-3c58-4536-9df6-cb3762208b47	Hứa Thị Lưu Luyến	18/10/2009	Nữ	Nùng		f	11C7				2026-03-23 13:58:32.978+00	2025-2026	\N	Thôn IaTang, Xã Ia Dơk, Tỉnh Gia Lai
e1a1cc4a-daba-4f04-b37a-6928f17653b6	Rơ Mah H' Sơrka	02/02/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:34.435+00	2025-2026	\N	Làng Ấp, Xã Đức Cơ, Tỉnh Gia Lai
494ece49-4327-40c5-885c-e0b1c3e636d2	Phạm Đức Bin	11/04/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:37.432+00	2025-2026	\N	Làng Dơk Lăh - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
f913e407-a879-4bd6-b492-ff93a0675db1	Lê Minh Hiệp	20/02/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:38.872+00	2025-2026	\N	Thôn Ia Tang - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
ddbe469a-6c2f-44bb-85cd-1a653aaf62c1	Nguyễn Đức Mạnh	12/10/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:40.334+00	2025-2026	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
77788384-5040-4a69-84a8-f1c272ae9264	Nguyễn Thị Mỹ Tâm	09/07/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:41.741+00	2025-2026	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
e75b87f9-ee4b-41e3-a76f-b5c4227f3cf7	Nguyễn Thị Bích Vân	20/04/2009	Nữ	Thổ		f	11C8				2026-03-23 13:58:43.231+00	2025-2026	\N	Thôn Lệ Kim - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
6441c4c8-e88a-4381-a3f0-e87afed358f8	R' Mah Hy-lia	14/02/2009	Nữ	Gia-rai		f	11C9				2026-03-23 13:58:46.175+00	2025-2026	\N	Làng Sung Kép - Xã Ia Dơk - Gia Lai
096954c7-591e-49f4-afc1-6da9d7f1111b	Nguyễn Thế Thành Đại	17/06/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.171+00	2025-2026	\N	Tổ dân phố 1- Chư Ty- Đức Cơ- Gia Lai
2f26724f-0e53-4b43-82f9-ca2d6f87f06d	Đoàn Ngô Vũ Luân	04/10/2008	Nam	Kinh		f	11C11				2026-03-23 13:58:59.795+00	2025-2026	\N	Làng DơkKiah- Ia Dơk- Gia Lai
76691235-4889-43c5-912f-22ec7dbfb5f3	Chu Thị Quỳnh	12/10/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:01.328+00	2025-2026	\N	Tổ dân phố 9- Đức Cơ- Gia Lai
024fbd36-51e3-4530-8f16-f098b0134cac	Lê Thị Quỳnh Trang	29/08/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:02.885+00	2025-2026	\N	Thôn Chư BồI, Iadok, Gia Lai
dad8ab2d-e120-4784-9660-d77b801119d5	Đặng Quang Thành Đạt	29/07/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:04.345+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
2d4aa584-fd50-472b-828e-986a7abf9992	Vũ Nguyễn An Khang	07/01/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:05.852+00	2025-2026	\N	Tổ Dân Phố 2, Xã Đức Cơ, Tỉnh Gia Lai
d78a83dd-fcb3-4376-8aa0-bf1550182273	Trần Đăng Phong	23/09/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:07.414+00	2025-2026	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai
b4581b56-01f7-4b0f-bb3a-f8a9cb75aa82	Nguyễn Quang Huy	25/07/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:08.753+00	2025-2026	HK2	Thôn Iatang, xã Ia Dơk, tỉnh Gia Lai
50517434-db92-4415-86fe-330f5067431d	Nguyễn Trọng Tâm	05/04/2009	Nam	Kinh		t	11C10				2026-03-27 01:07:34.741+00	2025-2026	HK2	Tổ dân phố 1, xã Đức cơ, tỉnh Gia Lai
fbc40e20-d8df-41ba-818e-6ce834dc3513	Rơ Mah Si Mô	30/11/2009	Nam	Gia-rai		t	11C10				2026-03-27 01:08:24.639+00	2025-2026	HK2	Làng Sung le , Ia Dơk, tỉnh Gia Lai
bdc39df0-476c-454d-b0df-36e5d9de613f	Nguyễn Lệ Trà My	13/11/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:32.481+00	2025-2026	HK2	TDP 7 - xã Đức Cơ - Gia Lai
ca916969-ebc4-4fab-bed2-ed8eaf8fd643	Trần Tiến Đạt	10/04/2009	Nam	Kinh		t	11C9				2026-03-28 10:48:43.016+00	2025-2026	HK2	TDP 7 - Xã Đức Cơ - Gia Lai
572e1040-aa60-4ed3-a758-7fa16940426a	Trần Thị Kiều Vy	22/02/2009	Nữ	Kinh		t	11C9				2026-03-28 10:49:29.769+00	2025-2026	HK2	TDP 2 - xã Đức Cơ - Gia Lai
ef02ad98-049b-4fb9-990c-688ee9079dba	Lương Thị Đoan Trang	13/01/2009	Nữ	Mường		t	11C9				2026-03-28 10:50:47.505+00	2025-2026	HK2	Làng Krai - xã Đức Cơ - Gia Lai
8d1f498c-6f11-44e1-a2bb-536451ff7314	Nguyễn Thị Kim Tuyết	2009-06-17	Nữ	Kinh		f	11C7		0349738669		2026-03-29 10:04:44.06+00	2025-2026	HK2	Làng Đo, Xã Iadơk, Tỉnh Gia Lai
6b45e3c2-c794-4d7f-9106-ca009f621515	Ksor Dũng	23/02/2009	Nam	Gia-rai		f	11C7				2026-03-23 13:58:30.321+00	2025-2026	\N	Làng sung le kép,Ia Dơk , Gia Lai
dc34afe3-54e8-469f-b3ea-2c3790902765	Nguyễn Quang Huy	06/08/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:31.821+00	2025-2026	\N	Thôn IaTang - Xã Ia Dơk - Tỉnh Gia Lai
ccaa6f72-343e-44b5-bd9d-d30c468203e0	Lê Nguyễn Trà My	16/08/2009	Nữ	Kinh		f	11C7				2026-03-23 13:58:33.285+00	2025-2026	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai
7f2e57dc-7262-4a88-97a2-91fdbbe9802e	Nguyễn Ngọc Thông	06/01/2009	Nam	Kinh		f	11C7				2026-03-23 13:58:34.742+00	2025-2026	\N	Thôn chư bồ 2, xã Ia Dơk, Tỉnh Gia Lai
7adf467d-f80a-417b-ae47-4da667a4b6ce	Ksor H' Vệ	08/07/2009	Nữ	Gia-rai		f	11C7				2026-03-23 13:58:36.232+00	2025-2026	\N	Làng Khóp, Xã Iakrêl, Tỉnh Gia Lai
73362900-3a34-43be-ae47-1d7413bb629d	Trần Thị Khánh Chi	05/08/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:37.713+00	2025-2026	\N	Thôn Đoàn Kết - Xã Ia Dơk - Huyện Đức Cơ - Tỉnh Gia Lai
9fe0bc0c-5be7-4eeb-8f79-76eca2c9500c	Nguyễn Trung Hiếu	06/01/2009	Nam	Kinh		f	11C8				2026-03-23 13:58:39.159+00	2025-2026	\N	Tổ dân phố 9 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
8b42bf9e-4c68-4abd-a688-fe765316507d	Rơ Mah H' Ngâm	18/09/2009	Nữ	Gia-rai		f	11C8				2026-03-23 13:58:40.61+00	2025-2026	\N	Làng Sung Kép - Xã Ia Kla - Huyện Đức Cơ - Tỉnh Gia Lai
eb0cc01b-e7f7-488f-99a6-2c640cafc2b7	Trương Thị Hoài Thương	10/05/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:42.006+00	2025-2026	\N	Tổ dân phố 2 - Thị trấn Chư Ty - Huyện Đức Cơ - Tỉnh Gia Lai
7f6eef3a-6a8d-4244-9fe3-e833a19a2717	Lê Thảo Vy	11/10/2009	Nữ	Kinh		f	11C8				2026-03-23 13:58:43.498+00	2025-2026	\N	Làng Krai - Xã Ia Kriêng - Huyện Đức Cơ - Tỉnh Gia Lai
bf28accd-a226-49f7-8715-c05bf8857353	Đậu Quang Thỏa Hiệp	13/03/2009	Nam	Kinh		f	11C11				2026-03-23 13:58:58.495+00	2025-2026	\N	Thôn Ia Lâm tốc- Iakrel- - Gia lai
82a6c205-d925-48d9-9f98-f0559b639f9a	Nguyễn Văn Mạnh	17/12/2009	Nam	Kinh		f	11C11				2026-03-23 13:59:00.105+00	2025-2026	\N	Tổ dân phố 2- Đức Cơ- Gia Lai
6f1665b3-349a-4e60-85d1-8e41e32cbde6	Kpuih Sen	26/10/2009	Nam	Gia-rai		f	11C11				2026-03-23 13:59:01.64+00	2025-2026	\N	Làng Lung- Đức Cơ- Gia Lai
e43db322-3873-41ee-84ba-07ec32e28940	Lê Thị Huyền Trân	03/04/2009	Nữ	Kinh		f	11C11				2026-03-23 13:59:03.178+00	2025-2026	\N	Tổ dân phố 9 - Đức Cơ- Gia Lai
bb030ea0-1fa1-4c3c-8a27-1e3830ae550e	Doãn Thị Hồng Hạnh	20/05/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:04.65+00	2025-2026	\N	Tổ Dân Phố 3, Xã Đức Cơ, Tỉnh Gia Lai
8b922185-4fc3-4026-ac3e-1bcfb8cff236	Nguyễn Phùng Khánh	09/02/2009	Nam	Kinh		f	11C12				2026-03-23 13:59:06.157+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
13f76236-96ab-41d0-ac24-8bf2d814bbba	Đoàn Ngọc Nam Phương	27/12/2009	Nữ	Kinh		f	11C12				2026-03-23 13:59:07.769+00	2025-2026	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai
cefade75-ab69-48c4-8e90-b8512369c4ef	Kpuih H' Thứ	26/09/2009	Nữ	Gia-rai		f	11C12				2026-03-23 14:00:06.224+00	2025-2026	\N	Làng Trol Đeng, Xã Đức Cơ, Tỉnh Gia Lai
77afc10e-f33f-4e28-8dad-3566bc4b63f6	Kpuih Trần	18/12/2009	Nữ	Gia-rai		f	11C12				2026-03-23 14:00:07.193+00	2025-2026	\N	Làng Ghè, Xã Ia Dơk, Tỉnh Gia Lai
215b997d-a041-4264-b99a-67fa8f07e662	Mai Văn Hoàng	2008-01-23	Nam	Kinh		t	12B1	2023-03-26	0375346667		2026-03-26 13:06:52.756+00	2025-2026	HK2	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai
9f2c6377-386b-4248-814f-518974076d1b	Nguyễn Trịnh Gia Bảo	2008-08-26	Nam	Kinh		t	12B1	2024-04-22	0869899621		2026-03-26 04:59:51.107+00	2025-2026	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai
0c67a6e3-c8bd-4934-99e4-5231462c9c90	Hà Minh Đức	2008-11-13	Nam	Tày		t	12B1	2026-01-18	0373462577		2026-03-26 04:58:46.706+00	2025-2026	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai
b4f44e9e-af2d-44a3-a90e-825fca1e5e34	Nguyễn Đức Hoàng	2008-05-04	Nam	Kinh		t	12B1	2025-04-24	0349315963		2026-03-26 04:59:04.059+00	2025-2026	HK2	Tổ 3 -Xã Đức Cơ -Tỉnh Gia Lai
12b5bcba-e952-494f-8743-f52dec7d161d	Nguyễn Ngọc Giáng Hương	2008-01-04	Nữ	Kinh		t	12B1	2023-09-20	0377295803		2026-03-26 04:59:22.275+00	2025-2026	HK2	Thôn Chư Bồ 1- Xã Ia Dơk - Tỉnh Gia Lai
d49220f5-b7d2-4a99-97fd-091184a01be8	Dương Minh Đức	2008-07-08	Nam	Kinh		t	12B1	2025-01-09	0865646339		2026-03-26 13:02:28.643+00	2025-2026		Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai
ebeaa4c4-bead-4ea0-b118-30ea7426095d	Nguyễn Thị Diệu Linh	2008-05-17	Nữ	Kinh		t	12B1	2023-09-20	0328875445		2026-03-26 04:59:37.979+00	2025-2026	HK2	Làng Krêl - Xã Ia Krêl - Tỉnh Gia Lai
dd3c804e-75b9-4814-8477-17fc4910e3f9	Lê Đức Giang	2008-09-02	Nam	Kinh		t	12B1	2025-01-09	0398171374		2026-03-26 04:58:56.357+00	2025-2026	HK2	Tổ 7 -Xã Đức Cơ - Tỉnh Gia Lai
b2bf647e-c742-4a0f-8ac7-1c5e501b59ff	Nguyễn Hoàng Anh	2008-03-06	Nam	Kinh		t	12B1	2023-03-26	0366927743		2026-03-26 04:59:12.674+00	2025-2026	HK2	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai
220853d7-7555-4da8-8e86-5481c2a416bf	Cao Thị Thanh Mai	2008-03-13	Nữ	Kinh		t	12B1	2023-03-26	0328444459		2026-03-26 04:58:30.546+00	2025-2026	HK2	Tổ 4 -Xã Đức Cơ - Tỉnh Gia Lai
aa10a0dc-63f2-4c16-ad54-15bf93e68121	Nguyễn Quang Huy	2008-06-20	Nam	Kinh		t	12B1	2025-04-24	0396036852		2026-03-26 04:59:31.362+00	2025-2026	HK2	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai
2e4bdf78-f62b-4914-b197-d343c6df748e	Phạm Ngọc Gia Hân	2008-10-12	Nữ	Kinh		t	12B1	2023-09-20	0983029959		2026-03-26 13:04:28.354+00	2025-2026	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai
faffb8ff-2084-4fc2-a189-0a15a0e0c058	Đoàn Trần Anh Thư	15/04/2009	Nữ	Kinh		t	11C10				2026-03-27 01:05:04.842+00	2025-2026	HK2	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
c7853e57-adac-4fec-a22e-8a00a083cbb3	Đỗ Đình Mạnh	2008-01-26	Nam	Kinh		t	12B1	2023-03-26	0348607726		2026-03-26 13:09:56.461+00	2025-2026	HK2	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai
e37126c7-6438-4097-8af1-734fce2c0ca1	Nguyễn Vũ Đức Minh	2008-03-15	Nam	Kinh		t	12B1	2023-03-26	0373807315		2026-03-26 13:11:15.691+00	2025-2026	HK2	Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai
82165843-b5cc-426b-b143-236a811566b9	Nguyễn Ngọc An	2008-04-01	Nữ	Kinh		t	12B1	2025-01-09	0333855032		2026-03-26 14:33:10.51+00	2025-2026	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai
755ab2a2-f1f8-4761-b4a3-59b7d69c4079	Lê Thị Bích Ngọc	12/09/2009	Nữ	Kinh		t	11C10				2026-03-27 01:05:38.158+00	2025-2026	HK2	Thôn Chư Bồ 2, xã Ia Dơk, tỉnh Gia Lai
e3c26229-9eaa-4eae-8ac4-39574857d2ac	Lê Thị Lan Hương	03/12/2008	Nữ	Kinh		t	11C10				2026-03-27 01:06:02.221+00	2025-2026	HK2	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
6f549b5d-6d68-482d-94b5-e89086362d0d	Nguyễn Thị Thanh Ngân	17/04/2009	Nữ	Kinh		t	11C9				2026-03-28 10:44:58.877+00	2025-2026	HK2	TDP 4 - xã Đức Cơ - Gia Lai
d1878cd5-5c6d-4064-86e0-be443e1dc5d6	Nguyễn Thị Yến	22/09/2009	Nữ	Kinh		t	11C9				2026-03-28 10:45:48.099+00	2025-2026	HK2	TDP 7- xã Đức Cơ - Tỉnh Gia Lai
1e66add3-6f72-40f0-a236-822cda2dbc5d	Trần Thị Ngọc Lan	30/08/2009	Nữ	Kinh		t	11C9				2026-03-28 10:46:59.48+00	2025-2026	HK2	TDP 7 - Đức Cơ - Gia Lai
7fd6e40a-54b1-4ec7-bb33-a767d8265667	Lê Duy Đức	13/12/2009	Nam	Kinh		t	11C9				2026-03-28 10:47:11.859+00	2025-2026	HK2	TDP 7 - Xã Đức Cơ - Gia Lai
83a8d7e0-c42b-4dae-8ee9-c31b12a27ab8	Nguyễn Thị Quỳnh Trang	19/05/2009	Nữ	Kinh		t	11C9				2026-03-28 10:52:12.406+00	2025-2026	HK2	TDP 9 - xã Đức Cơ - Gia Lai
1130623a-825a-4f51-8b26-0a627a6740cc	Nguyễn Trần Gia Huy	2008-06-22	Nam	Kinh		t	12B1	2026-01-18	0973227717		2026-03-30 14:09:24.211+00	2025-2026	HK2	Tổ 3 - Xã Đức Cơ - Tỉnh Gia Lai
db5368db-f848-4390-966d-09d1e07c620e	Phan Tấn Đức	16/05/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:16.545+00	2025-2026	\N	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai
1162ee66-aafb-4640-a4b9-38cda1c4f05b	Phan Văn Long	11/11/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:18.056+00	2025-2026	\N	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai
2cf32bf0-41e5-4fc1-a714-a4a303999133	Lê Thị Xuân Thu	01/01/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:19.58+00	2025-2026	\N	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai
98812f85-c454-4c4b-90c6-856350ceb915	Lê Đình Nam Anh	23/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.217+00	2025-2026	\N	Tổ dân phố 3, Xã Đức Cơ, Tỉnh Gia Lai
48611046-f7e9-48ae-bc0a-cba8d32102b5	Hồ Văn Đức	08/06/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.769+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
cb57f506-3593-4196-8f3b-b138b29839d1	Nguyễn Thị Bảo Ly	27/06/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.309+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
bfb5b809-bb5f-422d-8852-3945e84e1948	Nguyễn Thị Anh Thư	25/02/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.802+00	2025-2026	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
6e8d79bd-912b-4be6-b6a6-4541e98eb616	Đỗ Võ Tuấn Anh	17/08/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:27.46+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai\r\n
1513bbe3-61b1-424a-84a7-2f7485dbf0c3	Hồ Thái Dương	20/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.929+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
db06f205-cf40-4c9b-b80b-72cac448dc58	Trần An Lợi	14/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.443+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
9cccfa10-98e8-4e96-8aaf-040692de5b5e	Lê Thị Mai Phương	25/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.949+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
c16d2489-e91d-4f21-b656-5fe7b2889ddc	Phan Hoàn Vũ	26/07/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:33.489+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
7b34c619-c863-4656-8446-b2482cd18b06	Lương Quốc Chiến Dương	25/02/2008	Nam	Tày		f	12B5				2026-03-23 14:00:34.971+00	2025-2026	\N	Làng Ấp - Đức Cơ - Gia Lai
4d000028-a3f2-40d7-99f3-dee2ea576edb	Đỗ Thị Tuyết Ngân	23/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.438+00	2025-2026	\N	Ia Kăm - xã Ia Krêl - Gia Lai
e9bfb6e7-d97b-4a59-9385-b8f9b666bf7b	Trần Ngọc Quốc	19/06/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.973+00	2025-2026	\N	Thanh Giáo - Iakrêl - Gia Lai
43da93a4-e591-46e9-95a6-da05ac356c8b	Lê Thị Ngọc Trang	09/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.43+00	2025-2026	\N	Tổ dân phố 6 - Đức Cơ - Gia Lai
cd03fd6f-ef16-4fc9-b9f7-09bd0aab3712	Ksor H' Uyên	21/10/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.908+00	2025-2026	\N	Sung Le Tung - Ia Dơk - Gia Lai
0790f0fa-9841-4576-a8e2-296ed742c09c	LÊ THỊ ÁNH ĐỨC	18/08/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:42.394+00	2025-2026	\N	Ia Tang - Ia Kla - Đức Cơ - Gia Lai
1c2454f6-60e7-4170-b9aa-17681999ea9e	NGUYỄN THỊ KHÁNH HUYỀN	09/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.982+00	2025-2026	\N	Ia Lâm Tốk - Ia Krêl - Đức Cơ - Gia Lai
daedc3c8-03de-4774-b82a-1a706032e2e0	PUIH H' NHE	12/02/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:45.499+00	2025-2026	\N	Làng Khóp - Ia Krêl - Đức Cơ - Gia Lai
ca743bb2-01cc-4408-9efd-218c5de5075e	NGUYỄN THỊ DIỆU THẢO	01/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.067+00	2025-2026	\N	TDP 3 - Chư Ty - Đức Cơ - Gia Lai
0b5bbf91-ab2f-46ab-8421-0d9387503c27	PHAN ANH TÚ	10/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:48.731+00	2025-2026	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai
48936d5b-c1f2-4e21-8a06-c95435d1d2e4	Phạm Thị Thùy Dung	26/02/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:50.237+00	2025-2026	\N	TDP 6-xã Đức Cơ-Gia Lai
c0c99a07-9b7d-431f-89cb-dbb7b2f59422	Lê Thị Hoài	03/06/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:51.809+00	2025-2026	\N	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai
77033a63-6963-49f8-8036-a3cba878d51e	Vũ Thu Ly	25/05/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:53.272+00	2025-2026	\N	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia lai
f7c69ce2-07ac-4435-828a-477e445c053b	Nguyễn Thị Hồng Phương	14/02/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:54.779+00	2025-2026	\N	Thôn Lâm Tôk- Xã Ia Dơk -Gia Lai
73afdc9f-a846-41ce-be40-3dce2aadfec3	Rơ Mah H' Vân	19/12/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:56.334+00	2025-2026	\N	Làng Sung Le - xã Ia Dơk - Gia Lai
7e6d804b-4bb7-4790-becd-6146d8d46a07	Lê Đại Đồng	15/03/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.861+00	2025-2026	\N	Thôn Thanh Tân - Xã Ia Krêl  - Gia Lai
4279c481-4639-4c4c-83d0-73e077471151	Nguyễn Hà Thảo My	10/05/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.431+00	2025-2026	\N	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai
4fabd4c6-0367-4e37-9683-55ec3900641f	Trần Thị Thảo	05/12/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.001+00	2025-2026	\N	Tổ dân phố 6 - Xã  Đức Cơ - Gia Lai
c286c4bc-ce2b-4176-9a80-7ca0a3c9223b	Thái Hoàng Mỹ Uyên	20/04/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.51+00	2025-2026	\N	Thôn Ia Lâm - Ia Krêl  - Gia Lai
522e7e6c-82c8-4dd3-9c0f-bbd2bbb7c1ae	Nguyễn Văn Cường	26/10/2007	Nam	Kinh		f	12B9				2026-03-23 14:01:04.102+00	2025-2026	\N	Dơk Klăh, Ia Dơk, Gia Lai
4408c016-3444-47a3-86bd-2b36da2d3bb4	Lê Thái Châu	22/01/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:10.218+00	2025-2026	\N	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai
7def4cfc-11ef-4778-a941-99d5a5000b60	Nguyễn Công Hiếu	31/01/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:11.724+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk - Tỉnh Gia Lai
6689140b-b1e4-46d9-ab08-d7000ebd45e3	Rơ Châm Trung Nguyên	07/03/2008	Nam	Gia-rai		f	12B10				2026-03-23 14:01:13.304+00	2025-2026	\N	Làng Bi - Xã Ia Dom - Tỉnh Gia Lai
3402f21d-9054-4f8e-a0f0-c984c05a272c	Nguyễn Thị Cẩm Tú	12/05/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:14.901+00	2025-2026	\N	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai
a5c3f1ee-2de2-4365-a10e-629586ceddab	Mai Văn Sơn	07/08/2008	Nam	Kinh		t	12B9				2026-03-26 02:06:56.413+00	2025-2026	HK2	Tổ dân phố 3, xã Đức Cơ, Gia Lai
da4048d5-7dad-483f-b278-a94dc4f2aac0	Nguyễn Lê Diệu Linh	06/03/2008	Nữ	Kinh		t	12B9				2026-03-26 02:07:17.931+00	2025-2026	HK2	TDP1, xã Đức Cơ, Gia Lai
f92c3902-dc44-44f0-8182-c75102267f4c	Thái Tú Trinh	30/08/2008	Nữ	Kinh		t	12B9				2026-03-26 02:13:47.396+00	2025-2026	HK2	Thôn Tiên Sơn 1, xã Biển Hồ, Gia Lai
fc1adb1e-9636-4103-beaf-ffab98331be7	Nguyễn Thị Bích Ngọc	2008-02-27	Nữ	Kinh		t	12B1	2023-03-26	0362367022		2026-03-26 02:28:11.872+00	2025-2026	HK2	Làng Hrang - Xã Đức Cơ -Tỉnh Gia Lai
a8bd55a6-6031-4549-b670-3e93fc6ba7df	Nguyễn Thị Minh Uyên	2008-08-22	Nữ	Kinh		t	12B1	2023-01-09	0355425605		2026-03-26 04:59:42.835+00	2025-2026	HK2	Tổ 1 -Xã Đức Cơ -Tỉnh Gia Lai
df653b68-26f9-44fe-a521-9df394182282	Hồ Thị Bảo Phúc	2008-01-29	Nữ	Kinh		t	12B1	2023-03-26	0386701578		2026-03-26 04:58:50.167+00	2025-2026	HK2	Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai
fac1df30-2515-4311-85d4-f962126e8ba8	Trần Thị Bích Hằng	13/07/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:16.702+00	2025-2026	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
1c80abd0-67a7-4386-bf28-791613746a58	Lê Thị Mai	02/05/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:18.213+00	2025-2026	\N	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai
e6251d75-2242-44ea-bd1a-4771504c50be	Đoàn Anh Thư	02/10/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:19.728+00	2025-2026	\N	THÔN ĐOÀN KẾT, Xã Ia Dơk, Tỉnh Gia Lai
8cdbe5ad-9a05-4f45-ab11-fa6f756d0674	Lý Trâm Anh	31/10/2008	Nữ	Nùng		f	12B3				2026-03-23 14:00:21.371+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
d5a18a60-4b57-4281-adc6-8ba9b19f93df	Vũ Thị Thanh Giang	08/01/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:22.921+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
8479210f-ce52-42bc-8103-6e46bf731af8	Nguyễn Nhật Minh	16/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.476+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
bf8ff2b8-31d1-4e45-88e4-2c5a5b64956e	Trần Minh Thư	16/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.952+00	2025-2026	\N	Làng Krai, Xã Đức Cơ, Tỉnh Gia Lai
192d9aca-7cc0-452b-bc42-d0869d581e2d	Phan Thị Ngọc Anh	29/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:27.614+00	2025-2026	\N	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai
3ecd7eb2-5d77-4827-91b5-6f39e70bd506	Hà Ngọc Hạnh	30/04/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.067+00	2025-2026	\N	Thôn Chư Bồ 2 , xã IaDơk, tỉnh Gia Lai 
18863ceb-a1e9-4b21-a213-31ce35339b2e	Phan Vũ Thành Luân	25/08/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.584+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
44d2bae7-5b4a-4fe6-b491-79e549cf05d2	Nguyễn Thị Phương	05/09/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:32.101+00	2025-2026	\N	Thôn Ia Lâm Tôk, xã Ia Krêl, tỉnh Gia Lai\r\n
6a2299e5-9ef8-4ee6-8713-1200cfb1d8f0	Đinh Hoàng Anh	14/10/2008	Nam	Mường		f	12B5				2026-03-23 14:00:33.625+00	2025-2026	\N	Ia Mang - Ia Dơk - Gia Lai (cũ)
fd88f4bf-194e-4c8b-8906-27fda8e6a296	Lê Viết Đạt	04/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.125+00	2025-2026	\N	Làng Krêl - Ia Krêl  - Gia Lai
5806caa7-2c91-4a3c-b74c-b1c4a2bffd30	Nguyễn Thị Hồng Ngọc	01/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.581+00	2025-2026	\N	Thôn Chư Bồ II - Ia Dơk - Gia Lai
4cab72c9-4483-4684-bc1f-2c82b76c7c21	Kpuih H' Si	20/01/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:38.12+00	2025-2026	\N	Làng Hrang  - Đức Cơ - Gia Lai
f0ec2d32-f776-4c86-b344-30ee8fe4cda3	Phạm Thị Huyền Trang	25/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.577+00	2025-2026	\N	TDP 1  - Đức Cơ - Gia Lai
d37ac663-6905-40e6-8186-b266cb357352	Nguyễn Thị Hải Yến	13/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:41.064+00	2025-2026	\N	Thanh Tân - Ia Krêl - Gia Lai
3024cd81-df29-42f1-915b-cc03f2fef35c	TRẦN LÊ THU HÀ	19/12/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:42.535+00	2025-2026	\N	Đoàn Kết - Ia Kla - Đức Cơ - Gia Lai
1de55e42-2ff6-4087-b2bb-45a3e4ce3038	LÊ NGỌC KIÊN	27/09/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.135+00	2025-2026	\N	TDP 2 - Chư Ty - Đức Cơ - Gia Lai
30fb2c2d-22d3-418f-b3de-3ebe95879912	KSOR THEO	01/01/2008	Nam	Gia-rai		f	12B6				2026-03-23 14:00:47.21+00	2025-2026	\N	Làng Sung Kép - Ia Kla - Đức Cơ - Gia Lai
a15ee922-af29-4364-92d0-eb3084501371	RƠ LAN H' TUỆ	27/11/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:48.88+00	2025-2026	\N	Làng Sung Le Tung - Ia Kla - Đức Cơ - Gia Lai
14d2fda5-8218-4fa5-9efd-7d3e22b2a2e8	Nguyễn Sỹ Dũng	07/01/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:50.393+00	2025-2026	\N	Tổ dân phố 6 - Đức Cơ- Tỉnh Gia lai
2cf34699-c8d1-4f84-b7bc-46bf86555ddc	Phạm Đình Hùng	02/02/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:51.966+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, Tỉnh Gia Lai
03337fd9-bcc7-45bc-9b67-840253859c76	Nguyễn Thị Ngọc Phượng	04/05/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:54.948+00	2025-2026	\N	Tổ dân phố 2, xã Đức cơ, Tỉnh Gia Lai
a6931248-5e04-487f-8d2e-6bdcf0ec7270	Rơ Mah H' Vị	17/06/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:56.487+00	2025-2026	\N	Làng Sung Kép - xã Ia Dơk- Tỉnh Gia Lai
dde005b5-13a8-4642-a2a6-2194f5641fb2	Nguyễn Hoàng Gia	18/12/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.002+00	2025-2026	\N	Tổ dân phố 7 - Xã Đức Cơ - Gia Lai
d7d3766f-b453-44ff-af8d-0da223e683e2	Trương Thị Thu Na	09/04/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.611+00	2025-2026	\N	Tổ dân phố 9 - Xã  Đức Cơ - Gia Lai
2f1e630f-cc24-419e-8ee4-c492dc1875d6	Đặng Nguyễn Thu Thủy	11/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.143+00	2025-2026	\N	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai
87acdd03-fa06-4223-bb18-ce9fdd75666c	Nguyễn Trương Anh Vũ	12/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.668+00	2025-2026	\N	Thôn Ia Mang - Ia Dơk  - Gia Lai
7994dab9-614a-4f9d-ae27-c76996ac0a34	Rơ Mah Dấu	14/11/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:04.265+00	2025-2026	\N	Làng Ấp - xã Đức Cơ - Gia Lai
a109f481-e19a-4375-a321-897acf8974c7	Rơ Mah Luy	29/04/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:05.836+00	2025-2026	\N	Làng Hrang, xã Đức Cơ, Gia Lai
ce788c35-70e4-4230-8da8-8fc188eb3a7c	Trương Minh Vũ	11/11/2007	Nam	Kinh		f	12B9				2026-03-23 14:01:08.916+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, Gia Lai
ed25adb1-556f-4a7c-a8b6-a19e543664c5	Nguyễn Công Chiến	15/09/2006	Nam	Kinh		f	12B10				2026-03-23 14:01:10.357+00	2025-2026	\N	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai
0593006d-35bf-4ac3-9049-c3fb0a595a7e	Nguyễn Huy Hoàng	21/11/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:11.886+00	2025-2026	\N	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai
64228e3d-77ee-47b3-b225-d475560864ee	Kpuih H' Nhàn	31/01/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:13.45+00	2025-2026	\N	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai
53d5a892-dace-4c6f-baee-9499138a16e4	Hồ Đức Việt	23/01/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:15.063+00	2025-2026	\N	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai
f9902433-6495-41d8-b4e6-6be2f07062a8	Hoàng Thị Diệu My	02/09/2008	Nữ	Kinh		t	12B7				2026-03-26 02:04:48.808+00	2025-2026	HK2	Đường Tăng Bạt Hổ, Tổ dân phố 9,  Đức Cơ, Gia Lai
dcf6f56c-49ce-4852-a8ff-94e848e5cc0d	Bùi Đức Tài	13/01/2007	Nam	Kinh		t	12B9				2026-03-26 02:04:50.462+00	2025-2026		TDP 7 - xã Đức Cơ - Gia Lai
987dac80-3d3a-493c-9316-f7cf064d5363	ĐẶNG THỊ YẾN NHI	18/06/2008	Nữ	Kinh		t	12B6				2026-03-26 02:05:15.813+00	2025-2026	HK2	TDP 9 - Chư Ty - Đức Cơ - Gia Lai
5b559020-fc99-4e84-8e60-d0e432084ef2	Nguyễn Thành Nhân	2008-01-22	Nam	Kinh		t	12B1	2025-01-09	0383800177		2026-03-26 02:16:22.572+00	2025-2026	HK2	Làng Sung Le Tung - Xã Ia Dơk - Tỉnh Gia Lai
d14d7465-8213-4acb-97e8-f174ee4d6cd0	Nguyễn Lê Vy	2008-02-14	Nữ	Kinh		t	12B1	2026-01-18	0356918059		2026-03-26 04:59:17.365+00	2025-2026	HK2	Thôn Mook Trang - Xã Ia Dom - Tỉnh Gia Lai
6b0c00d6-e5f1-4a77-a1c3-a169f6043204	Đoàn Anh Quân	2008-10-26	Nam	Kinh		t	12B1	2026-01-18	0867942248		2026-03-26 04:58:41.443+00	2025-2026	HK2	Thôn Đoàn Kết - Xã Ia Dơk - Tỉnh Gia Lai
d334fa93-aa99-46c1-a4e7-db9e9ec4c31c	Lê Quang An	11/12/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:15.137+00	2025-2026	\N	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai
b03bffec-b32e-4490-bbc3-2d1e6eb75d68	Phạm Tuấn Hoàng	20/01/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:16.873+00	2025-2026	\N	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai
f94f4b6e-b430-4e56-aa7c-c3f53c51f81a	Cao Thị Trà My	14/08/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:18.385+00	2025-2026	\N	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai
8650a090-c27c-4be3-9929-7d9edfe84616	Nguyễn Bùi Anh Thư	28/11/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:19.905+00	2025-2026	\N	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai
7ff4fd75-482d-4ecd-a3c2-21f399e2c004	Nguyễn Hà Anh	22/12/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:21.523+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
eb1f7847-bc4f-4b44-bead-4951b9cf81a8	Lê Nguyễn Hồng Hà	09/06/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.073+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
8dfbb737-86fa-49c4-8333-05c79204cafc	Lê Diệu My	21/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.645+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
5fd16c23-5628-44ca-b810-32642cc1c344	Đoàn Huỳnh Mạnh Tiến	05/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:26.113+00	2025-2026	\N	Làng Pnuk, Xã Đức Cơ, Tỉnh Gia Lai
bf20e7ab-141c-40a3-ac0d-fd72052e7a6e	Phan Tùng Anh	12/03/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:27.739+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
975edefc-c756-497d-bad7-f70ccaf2aa8b	Lê Thị Thu Hiền	29/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.216+00	2025-2026	\N	Thôn Đoàn Kết, xã Ia Dơk, tỉnh Gia Lai
3b716902-7062-4b3c-82cb-69c0f4e6cf0b	Trần Hải Ly	03/11/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.723+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai\r\n
5f92d89d-48cd-4088-8d05-b9d393a1ed5e	Trần Minh Quang	01/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.266+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
c19553fc-9cbd-44b3-82df-9dde159122eb	Hoàng Việt Anh	10/07/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:33.757+00	2025-2026	\N	TDP 7 - Đức Cơ- Gia Lai
2c8a6736-8d59-439e-8f20-0ea17a854734	Mạc Phạm Hải Đăng	11/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.268+00	2025-2026	\N	Thôn Ia Tang - Ia Dơk - Gia Lai
6e16ff30-e7b1-4ea8-9198-d9f4d44fb341	Tào Trần Bảo Ngọc	26/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.729+00	2025-2026	\N	TDP 4 - Đức cơ - Gia Lai
e81697e9-1ced-4536-a43b-b069f9fa8e26	Kpuih H' Soa	08/06/2007	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:38.248+00	2025-2026	\N	Làng Bua - Ia Pnôn  -Gia Lai
fd8d05db-40d4-4d6d-ab3b-bd794eadc10b	Rơ Lan H' Thuỳ Trang	01/11/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:39.736+00	2025-2026	\N	Làng Sung Le Tung - Ia Dơk - Gia Lai
9d5662d0-023f-425c-b675-d6f5b7976c85	KSOR H' HOÀNG ANH	10/07/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:41.213+00	2025-2026	\N	Làng Sung Kép - Xã Ia Kla - Đức Cơ - Gia Lai
ddfafa59-9703-44e4-ac1d-117c9aa726c5	KPUIH H' HAO	21/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:42.692+00	2025-2026	\N	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai
3aee2c4d-fd4f-4502-8f46-c7893b247764	LÊ THỊ THÙY LINH	18/03/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:44.28+00	2025-2026	\N	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai
c532cc21-8885-43e9-b82c-73868b1a0f70	TRẦN BẢO NHI	28/12/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.787+00	2025-2026	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai
b92386ce-aa6d-4aa2-867f-b2a4671c8481	QUÁCH ĐỨC THỊNH	08/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:47.365+00	2025-2026	\N	Làng Krol - Ia Krêl - Đức Cơ - Gia Lai
8f44da22-e44c-4fbe-9eac-f3f7b1591398	SIU VIÊN	06/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:49.028+00	2025-2026	\N	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai
778bf6eb-03c9-45b8-8365-26256af0d735	Nguyễn Thị Duyên	31/07/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:50.531+00	2025-2026	\N	Tổ dân phố 7 - Đức Cơ- Gia Lai
f47a78a5-8b86-4dff-95e3-63ef9f74c0a3	Hà Thị Lan Hương	25/08/2008	Nữ	Thái		f	12B7				2026-03-23 14:00:52.111+00	2025-2026	\N	Làng Krái, Xã Đức Cơ, Tỉnh Gia Lai
1302ed8d-8cb3-4202-8962-336ce5a35d88	Hồ Hoài Ngân	02/04/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:53.574+00	2025-2026	\N	Thôn Chư Bồ II - Ia Dơk - Gia Lai
96840637-b85e-4eba-a0b2-ee53083d34f9	Nguyễn Mạnh Quân	28/10/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:55.099+00	2025-2026	\N	Tổ dân phố 9 – Đức Cơ – Gia Lai
660e4094-17b4-4e26-adac-b064767c0ac4	Nguyễn Ngọc Vũ	25/04/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:56.65+00	2025-2026	\N	Tổ dân phố 9- Đức Cơ- Gia Lai
49c12e12-98aa-4395-b653-78244d03bae9	Rơ Mah H' Hà	04/10/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:00:58.143+00	2025-2026	\N	Sung Kắt - Xã Iadơk- Gia Lai
ef558d67-138f-4993-a951-88629b9b44a3	Hồ Thị Thúy Nga	04/09/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.81+00	2025-2026	\N	Tổ dân phố 4 - Xã  Đức Cơ - Gia Lai
6790af23-60bd-4ac9-910e-15309dac06cf	Hồ Ngọc Anh Thư	04/11/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.309+00	2025-2026	\N	Tổ dân phố 2 - Xã  Đức Cơ - Gia Lai
17c0731b-2f8b-4f2b-95e6-873e94a4dca0	Lê Nguyễn Thảo Vy	21/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.842+00	2025-2026	\N	Thôn Ia Tang - Xã IaDơk- Gia Lai
93c82600-6d32-4e2c-a86f-772e943d1507	Hoàng Thị Mai	04/05/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:05.991+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, Gia Lai
53b01c4f-b7a6-41f5-b6c2-123c90766d78	Nguyễn Thị Hải Yến	06/04/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:09.062+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, Gia Lai
c471def1-7bf4-4b0b-b068-d11bac427a8a	Trần Thị Chính	26/01/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:10.523+00	2025-2026	\N	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai
db9db073-6740-49e4-9061-2446cc87cf2d	Nguyễn Ngọc Hùng	17/12/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:12.035+00	2025-2026	\N	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai
631b6641-095f-45fc-b682-5ce9a577f739	Văn Đức Hoàng Phúc	30/09/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:13.59+00	2025-2026	\N	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai
f53b1209-34b8-4de1-b5f6-c6d905f64385	Nguyễn Quốc Việt	20/12/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:15.213+00	2025-2026	\N	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai
5711d9f1-d232-44ac-aff2-50383fba2ff2	Ksor H' Diệp	24/06/2008	Nữ	Gia-rai		t	12B9				2026-03-26 02:06:13.812+00	2025-2026	HK2	Làng Sung Kép, Ia Dơk, Gia Lai
8ed1bcf2-3916-4f3f-89cf-cf7316df8988	Ngô Đức Sỹ	2008-12-03	Nam	Kinh		t	12B1	2024-01-14	0862246494		2026-03-26 02:35:15.227+00	2025-2026		Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai
a12f298d-0116-4768-adbf-796de7a08268	Trần Đức Tài	13/09/2008	Nam	Kinh		f	12B9				2026-03-26 02:13:40.19+00	2025-2026	HK2	Tổ dân phố 6 - xã Đức Cơ - Gia Lai
98e83d70-42cb-4cbc-baab-e1410533b772	Bùi Thị Tú Nhi	2008-05-09	Nữ	Kinh		t	12B1	2023-01-09	0385397067		2026-03-26 04:58:21.14+00	2025-2026	HK2	Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai
c6cb6d4a-ba83-4eb8-b701-503c780f3543	Nguyễn Ngân Anh	20/10/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:15.283+00	2025-2026	\N	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai
fe6fc0e2-e4ef-404f-a971-001dd2657bb3	Trần Lê Huy Hoàng	10/03/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.022+00	2025-2026	\N	Làng Sung Kép, Xã Ia Dơk, Tỉnh Gia Lai
4db0cde0-30dc-4256-a7c0-c8136c742d3a	Phạm Lê Hoài Nhi	02/01/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:18.542+00	2025-2026	\N	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai
c29c6ce0-3b52-4e93-bc6f-37b63d13fe6d	Võ Hoài Thương	12/06/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:20.06+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
f6b604a1-b109-4a9f-8610-113d45fdab83	Trần Gia Bảo	28/02/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.672+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
a186e1c4-d046-4ec8-81b1-bc22cda32a23	Nguyễn Gia Hân	01/02/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.211+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
95373280-be3e-4d27-8e64-61eab1cdaa54	Lê Võ Thanh Nguyên	20/08/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.779+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
b60b7002-9d44-4145-9a43-4bb1981f5002	Phạm Thị Huyền Trang	16/09/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.263+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
a0dd3f66-abc9-4caf-be52-97a40ed286da	Hoàng Thị Kim Ánh	01/02/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:27.875+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
71812587-ca41-4e53-81b0-cc6c1af73e2b	Vương Thị Hiền	28/06/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.37+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai
465bddef-b56e-46fb-a631-9a1357a735f6	Đàm Cảnh Minh	07/04/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.876+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n
b10235d9-5e80-4398-b9c9-a45805b0425e	Trần Khánh Quân	05/10/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.42+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai\r\n
c7d01113-e171-43ad-9c83-bf8e46d3e120	Lê Công Ngọc Anh	25/06/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:33.904+00	2025-2026	\N	Làng Ấp - Đức Cơ  - Gia Lai
5febe599-3eb1-472c-9758-679337c56d14	Trần Thị Vân Giang	23/08/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.408+00	2025-2026	\N	TDP 7 - Đức Cơ - Gia Lai
df3d058a-ae56-4685-aa21-e1eb8e89a388	Trần Thị Thanh Nhàn	15/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.876+00	2025-2026	\N	Ia Tang - Ia Dơk - Gia Lai
1904fab1-ef63-4218-81b6-481d02a11853	Hồ Thanh Thanh	18/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:38.396+00	2025-2026	\N	Tổ dân phố 1 -  Đức Cơ - Gia Lai
7589e41e-000a-4c46-ad9e-231f5e6015cf	PHẠM THỊ VÂN ANH	14/04/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:41.35+00	2025-2026	\N	Lâm Tôk - Ia Krêl - Đức Cơ - Gia Lai
fe908b0e-06b5-4bb9-8545-4712bc17cc94	NGUYỄN HÀO	04/07/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:42.841+00	2025-2026	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai
b7243717-ec9c-45d0-bab3-9e53be60449a	NGUYỄN THỊ PHƯƠNG LINH	17/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:44.437+00	2025-2026	\N	Đoàn Kết - Ia Dơk - Đức Cơ - Gia Lai
68e5e9b0-7386-4e4c-8693-e4b15fd31c4c	TRƯƠNG THỊ HỒNG NHUNG	01/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.947+00	2025-2026	\N	Ia Tang - Ia Kla - Đức Cơ - Gia Lai
863a4692-6fcb-4181-bd84-40115904e3b5	NGUYỄN THỊ BÍCH THỦY	02/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.525+00	2025-2026	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai
1299580c-c9d3-4aab-b3a9-62ff91ef79e8	Rơ Mah H' Y-Su-In	16/05/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:49.159+00	2025-2026	\N	Sung Kép - IaDơk - Gia Lai
c80bcc49-262e-4322-9dab-dff7f5442016	Rơ Mah H' Điệp	08/01/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:50.675+00	2025-2026	\N	Sung, Ia Dơk, Gia Lai
626fbadc-25a8-4e88-8fab-ac8ac7cab153	Lê Văn Khánh	05/10/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:52.243+00	2025-2026	\N	TDP 7- xã Đức Cơ-Tỉnh Gia Lai
a7c4e27f-1e2a-4429-8e3a-ab0f488f32d9	Lê Nam Thiên	24/06/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:55.274+00	2025-2026	\N	Tổ 2, xã  Đức Cơ, Tỉnh Gia Lai
71c8598a-556e-46fd-b823-22989f74109e	Hồ Thị Ngọc Yến	27/11/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:56.792+00	2025-2026	\N	Tdp9 , Đức cơ , tỉnh Gia Lai
0d12676f-06e1-41a6-8496-55d4f5a1d418	Nguyễn Thu Hiền	22/07/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:58.298+00	2025-2026	\N	Tổ dân phố 2 -Xã Đức Cơ - Gia Lai
cf5e3e39-f305-4365-b972-811829ec9fff	Kpuih Ngân	17/03/2008	Nam	Gia-rai		f	12B8				2026-03-23 14:00:59.971+00	2025-2026	\N	Làng Dơk Ngol - Ia Dơk  - Gia Lai
7c9f12d7-d8a9-4890-9da6-0bf91b9bfe56	Nguyễn Xuân Tiến	04/05/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:01.469+00	2025-2026	\N	Tổ dân phố 6 - Xã Đức Cơ - Gia Lai
bc7bfc36-6049-4e79-929e-300430e2ce06	Rơ Mah H' Yumi	20/11/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:03.013+00	2025-2026	\N	Sung Le Kăt - Xã IaDơk- Gia Lai
9f6d8ea1-ea7a-4470-88fe-012bd8189b07	Phạm Khánh Duy	30/12/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:04.589+00	2025-2026	\N	TDP2 - xã Đức Cơ - Gia Lai
ea95d4a1-6792-44c8-9a45-07f974dd2bfd	Trương Anh Ngọc	09/04/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:06.144+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, Gia Lai
953fbdbe-e072-4ed0-8527-2ab3b881ea57	Trần Thị Hải Yến	09/03/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:09.212+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, Gia Lai
ec737772-c13d-4b58-b705-1b4a5e6e80a1	Lê Khanh	26/06/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:12.212+00	2025-2026	\N	TDP 6 - Xã Đức Cơ - Tỉnh Gia Lai
4e154d85-e207-495d-a0d7-81ea460fbf90	Vũ Văn Quân	29/04/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:13.744+00	2025-2026	\N	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai
a746ab31-0add-4e6f-909f-2224882ebff2	Đinh Thái Nghĩa	28/12/2008	Nam	Kinh		t	12B7				2026-03-26 02:04:39.906+00	2025-2026		Tổ dân phố 1 -  Đức Cơ - Gia Lai
0fdc65a7-703d-465c-a13f-ec517f30940a	Lê Tiến Công	2008-05-12	Nam	Kinh		t	12B10				2026-03-26 02:05:10.696+00	2025-2026	HK2	TDP 7 - Xã Đức Cơ - Tỉnh Gia Lai
2599fe3a-9d72-4c77-a6bb-a98f38fd0d41	Đinh Thị Yến Nhi	2008-04-22	Nữ	Kinh		t	12B1	2024-12-05	0354844896		2026-03-26 04:58:35.771+00	2025-2026	HK2	Tổ 3 -Xã Đức Cơ - Tỉnh Gia Lai
863d2837-882a-4fb6-825f-63983b871f31	Dương Quỳnh Trâm	17/06/2008	Nữ	Kinh		t	12B5				2026-03-26 02:05:17.738+00	2025-2026		TDP 6 - Đức Cơ - Gia Lai
c1a121e9-d6aa-4dff-9736-56bf57296aeb	Ngô Sỹ Thêm	17/08/2006	Nam	Kinh		t	12B9				2026-03-26 02:07:12.031+00	2025-2026	HK2	Lâm Tốk, xã Ia Krêl, Gia Lai
0968a4b1-ad38-4f2d-b524-082a6f7db231	Đinh Hoàng Thu Thảo	26/03/2008	Nữ	Kinh		t	12B1	2023-03-26	0794643167		2026-03-26 02:22:46.897+00	2025-2026	HK2	Làng Lung Prông - Xã Đức Cơ - Tỉnh Gia Lai
6c0e569c-1a13-4df8-af86-dd08dbf5033c	Phan Ngọc Gia Bảo	19/07/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:15.44+00	2025-2026	\N	TỔ DÂN PHỐ 9, Xã Đức Cơ, Tỉnh Gia Lai
16536226-1435-49fe-bb97-d006c613c18a	Hồ Sỹ Huy	02/01/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.174+00	2025-2026	\N	TỔ DÂN PHỐ 6, Xã Đức Cơ, Tỉnh Gia Lai
f45ab8da-c689-492e-aab6-3221086d65a0	Dương Lê Thảo Phương	17/09/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:18.67+00	2025-2026	\N	TỔ DÂN PHỐ 4, Xã Đức Cơ, Tỉnh Gia Lai
5dfe42a9-e356-47c9-9fbb-0ddf84dad8eb	Nguyễn Thị Ngọc Trâm	20/01/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:20.214+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
95d0db16-b907-4332-8406-44c95d0d53c4	Trịnh Phan Kim Chi	23/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:21.811+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
4513cbe1-3f68-47c2-accc-350504325682	Nguyễn Khắc Hùng	22/01/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.391+00	2025-2026	\N	Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
25af07a3-214e-4966-9a34-82741cfb0cf8	Nguyễn Thị Ánh Nguyệt	12/04/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.921+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
eecc6503-dd6a-4cb1-ba78-2ad04aa6a719	Trần Cao Thùy Trang	25/11/2007	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.435+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
7e359d7b-edff-426e-bad6-dc1831b5d8c0	Nguyễn Thanh Bắc	17/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.02+00	2025-2026	\N	Thôn IaLâm, xã Ia Krêl, tỉnh Gia Lai
d56b292e-01b8-4347-b481-f716f87b98ba	Đỗ Ngọc Hoàng	24/04/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:29.527+00	2025-2026	\N	Tổ dân phố 6, xã Đức Cơ, tỉnh Gia Lai
600579a6-9b6c-483c-89aa-168b597a8b32	Võ Hoàng Minh	23/06/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:31.012+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
975db041-e368-42e6-b013-c4fd31668915	Trần Minh Quân	21/09/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.565+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
55d9b0ce-d2d3-4918-8c20-8f48ee7ea50c	Nguyễn Hoàng Anh	29/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.048+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
e261c136-2e2a-4909-b692-909c5df0fbd8	Lê Thị Thanh Hằng	29/01/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.55+00	2025-2026	\N	Thôn Lâm Tốk - Ia Krêl - Gia Lai
9745b2f1-855a-43cd-bfaa-9d3b7ffb231d	Đinh Trọng Nhân	08/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.049+00	2025-2026	\N	Làng Lung Prông - Ia Kriêng - Gia Lai
176638cd-84e5-4afb-873c-a49c33938ee2	Phan Chí Thành	02/02/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:38.532+00	2025-2026	\N	TDP 3 - Đức Cơ - Gia Lai
bc1042e2-f070-4adc-a555-f225484863ad	Nguyễn Thị Trâm	14/12/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:40.042+00	2025-2026	\N	Ia Mang - Ia Dơk  - Gia Lai
7a3fd32a-6563-4049-bd0b-028cf80699ae	LỤC VÕ THÁI BÌNH	11/09/2008	Nam	Mường		f	12B6				2026-03-23 14:00:41.509+00	2025-2026	\N	Làng Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai
f8e5b7b6-70b7-4ddb-8c59-3eea0fbb40a5	HOÀNG THỊ THÚY HẰNG	14/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.033+00	2025-2026	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai
821fef90-4bc7-4f69-b846-882c8cd6f482	Hồ Hữu Lộc	11/05/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.583+00	2025-2026	\N	Tổ dân phố 1,TT Chư Ty, Đức Cơ - Gia Lai
3788aab0-6af0-4675-b2dc-a85a8908595d	NGUYỄN THANH PHƯƠNG	24/06/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:46.111+00	2025-2026	\N	TDP 3 - Chư Ty - Đức Cơ - Gia Lai
d43c006f-a52e-4caf-ada9-85f601457e5b	TRƯƠNG THỊ THANH THỦY	20/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.677+00	2025-2026	\N	TDP 2 - Chư Ty - Đức Cơ - Gia Lai
ce0c7e8e-131b-47c2-a649-268d1095ee94	Lương Hà Anh	07/09/2008	Nữ	Thái		f	12B7				2026-03-23 14:00:49.3+00	2025-2026	\N	Làng Krai - Đức Cơ - Gia Lai
de19ec21-3be3-41a2-a97f-a055c61a3d63	Lê Đình Đức	13/03/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:50.835+00	2025-2026	\N	Tổ dân phố 6- Đức Cơ – Gia Lai
9254323a-d17b-48b1-b357-ddb124c7c766	Trần Lê Ngọc Khánh	09/01/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:52.384+00	2025-2026	\N	Thôn Đoàn kết, Xã Ia Dơk, Tỉnh Gia Lai
40b5bfc9-5b2b-4f1b-a0c5-1ec23b42b374	Đỗ Khánh Ngọc	11/04/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:53.875+00	2025-2026	\N	Làng Pnuk-  Đức Cơ- Gia Lai
aac97621-0d84-43ff-b0ad-8bd7656c5754	Lê Trường Thịnh	17/07/2007	Nam	Kinh		f	12B7				2026-03-23 14:00:55.411+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ , Tỉnh Gia Lai
04a6b33a-196b-4b5b-9c8d-c468fe341d1b	Nguyễn Thị Ngọc Yến	05/06/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:56.943+00	2025-2026	\N	Thôn krel ,xã ia krel , tỉnh Gia Lai
1afb362c-ea42-412c-8cfb-775a6d74da92	Phạm Văn Hiếu	06/09/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.436+00	2025-2026	\N	Tổ dân phố 2 - Xã Đức Cơ - Gia Lai
282fef23-b806-4b83-b7fe-69d6d5ba7272	Đào Trần Gia Như	05/08/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:00.114+00	2025-2026	\N	Tổ dân phố 3 - Xã Đức Cơ - GiaLai
7c5182ea-58d5-4764-875a-bd9fff4d36ee	Luyện Tiến Tình	23/05/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:01.607+00	2025-2026	\N	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai
4e1d3528-0282-41f6-a17c-b04f7a5bb22d	Bùi Lê Trung Nguyên	01/01/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:06.283+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, Gia Lai
4237ef4b-1eaf-4a70-8e3f-ad014563b483	Nguyễn Thị Kim Thu	09/11/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:07.837+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ - Gia Lai
2b3669db-9f34-43a0-b366-5a97426de76b	Dương Như Hoàng Anh	01/03/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:09.346+00	2025-2026	\N	TDP 9 - Xã Đức cơ- Tỉnh Gia Lai
4e74b97f-7e2a-4e78-bdf6-3760ef88ac4e	Kpuih H' Diệu	23/03/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:10.833+00	2025-2026	\N	Làng Ấp - Xã Đức Cơ - Tỉnh Gia Lai
cdad5bb4-20a1-4e7a-9d3f-71565b1d5f46	Ksor Khởi	24/05/2008	Nam	Gia-rai		f	12B10				2026-03-23 14:01:12.375+00	2025-2026	\N	Làng Sung Le - Xã Ia Dơk - Tỉnh Gia Lai
002d140f-f3d7-4a8e-8d08-9373485e8abd	Nguyễn Từ Tài	16/09/2007	Nam	Kinh		f	12B10				2026-03-23 14:01:13.929+00	2025-2026	\N	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai
2ed6f272-9525-4da5-b8bc-401736d0acfe	Hồ Hữu An	19/04/2008	Nam	Kinh		t	12B9				2026-03-27 13:00:49.243+00	2025-2026	HK2	Tổ dân phố1 - xã- Đức Cơ - Gia Lai
37073a9a-f49a-40f9-a4f5-c2d06fc49b59	Hồ Vĩnh Hạnh	03/02/2008	Nam	Kinh		t	12B9				2026-03-26 02:05:43.262+00	2025-2026	HK2	Tổ dân phố 9, xã Đức Cơ, Gia Lai
5a7150d8-5904-41bd-a81a-2795235f7906	Hoàng Thị Phương Thảo	2008-10-29	Nữ	Kinh		t	12B1	2026-01-18	0389905667		2026-03-26 14:32:06.744+00	2025-2026	HK2	Tổ 1 -Xã Đức Cơ - Tỉnh Gia Lai
9f584a6c-9db1-4dab-a915-d223f7a695fb	Nguyễn Thị Nguyệt Nhi	2008-01-27	Nữ	Kinh		t	12B1	2023-03-26	0854427247		2026-03-26 04:59:46.131+00	2025-2026	HK2	Làng Pnuk - Xã Đức Cơ - Tỉnh Gia Lai
eacfe4a6-e5f4-4300-8b52-883450632f81	Nguyễn Thị Bình	01/02/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:15.61+00	2025-2026	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
2492fc08-0d6c-4b14-a015-729fdd1c803f	Hồ Sỹ Huy	27/07/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.325+00	2025-2026	\N	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai
c8b4e087-cb01-4fef-9a70-2d7eebf6013a	Nguyễn Anh Phương	08/09/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:18.809+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
d270dd5f-da28-4f5d-90a9-20f62338e466	Trịnh Lâm Trí	28/03/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:20.384+00	2025-2026	\N	Làng Bi, Xã Ia Dom,Tỉnh Gia Lai
367101d5-a069-46a2-99c1-ec40bfd45437	Nguyễn Trọng Cảnh Duy	28/12/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:21.966+00	2025-2026	\N	Thôn Ia Lâm Tốk, Xã Ia Krêl, Tỉnh Gia Lai
6dbb142e-17ee-475c-8346-fbe6c5cac59b	Dương Công Huy	24/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.564+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
d672953c-6649-4413-a88b-acdd5f2dc52f	Cao Thị Yến Nhi	12/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.084+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
2c2859c8-a399-4b37-80a5-ef58fe4101c9	Lương Thanh Trúc	06/10/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.594+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
296656d9-c8d1-4981-858d-2500be27f4f1	Hoàng Hải Bình	27/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:28.172+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
4f5f0e20-b05a-4cd8-8f5f-9ea9d131de4d	Nguyễn Thị Thu Huyền	06/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.677+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
8a78bee0-72f2-4763-b656-2863ffba7abe	Hà Thị Trà My	19/09/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.166+00	2025-2026	\N	Thôn Chư Bồ 2, xã IaDơk, tỉnh Gia Lai
eef33700-72ef-40c7-9a83-df4b6c3a308a	Nguyễn Cảnh Tân	05/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.709+00	2025-2026	\N	Tổ dân phố 7, xã Đức Cơ, tỉnh Gia Lai\r\n
0857f74c-82c8-4d8c-8ac2-208139216c0a	Trần Đinh Hoàng Anh	18/04/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:34.187+00	2025-2026	\N	TDP1 - Đức Cơ - Gia Lai
b40bbeb9-bc12-4c77-9625-edfcabcc37af	Lý Gia Hân	30/05/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:35.699+00	2025-2026	\N	Thôn Thanh Giáo - Ia Krêl  - Gia Lai
f390fd1e-ceee-41d1-b01e-5af0773efe42	Nguyễn Thị Linh Nhi	10/10/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:37.184+00	2025-2026	\N	Thôn Thanh Tân - Ia Krêl· - Gia Lai
4a76cfb0-70fe-4760-8959-a34f60ba6926	Phan Thị Phương Thảo	27/04/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:38.692+00	2025-2026	\N	Thôn Thanh Giáo, Iakrel, Gia Lai
dddfa51d-ad9e-4e7b-85ac-14cc2a71de4f	Rơ Mah Trân	28/08/2008	Nam	Gia-rai		f	12B5				2026-03-23 14:00:40.196+00	2025-2026	\N	Làng Ấp - Đức Cơ - Gia Lai
d2eae698-3b31-458d-b3f0-cfd109c29b8b	NGUYỄN HỮU CHỨC	22/06/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:41.673+00	2025-2026	\N	TDP6 - Chư Ty - Đức Cơ - Gia Lai
9149b326-91ef-4edd-93b6-eb66041f14d2	LƯƠNG THỊ THU HẰNG	18/09/2008	Nữ	Thái		f	12B6				2026-03-23 14:00:43.204+00	2025-2026	\N	Làng Krai - Ia Kriêng - Đức Cơ - Gia Lai
44e65627-dca7-40a7-858f-9b3021c5a08a	NGUYỄN HOÀNG HỮU LƯỢNG	11/09/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:44.729+00	2025-2026	\N	TDP 4 - Chư Ty - Đức Cơ - Gia Lai
f0ed3c7e-1f3f-4500-a995-af0d69014a73	PUIH PLÝ	02/06/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.275+00	2025-2026	\N	Làng Dơk Klăh - Ia Dơk - Đức Cơ - Gia Lai
9a2d7088-0b0e-4541-be1e-cd46093523c0	NGUYỄN BÙI ANH THƯ	09/09/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:47.858+00	2025-2026	\N	Ia Kăm - Ia Krêl - Đức Cơ - Gia Lai
47ed7345-c3e5-45f0-830e-cd4bf7844b98	Nguyễn Thị Ngọc Anh	29/10/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:49.446+00	2025-2026	\N	Tổ dân phố 3- xã Đức Cơ- Gia Lai
f8506008-599b-453f-96fa-f4ee85158249	Nguyễn Hồng Hạnh	10/05/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:50.998+00	2025-2026	\N	Làng Bua, xã Ia Pnôn, Tỉnh Gia Lai
eef5ff90-cdd8-4360-93aa-c85d74139988	Kpuih Khoa	12/11/2008	Nam	Gia-rai		f	12B7				2026-03-23 14:00:52.533+00	2025-2026	\N	Làng Sung le tung, Xã Ia Dơk, Tỉnh Gia Lai
0dbe9589-0cbd-41bd-a9dc-bb7ba7e4361c	Nguyễn Thị Khánh Ngọc	31/12/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:54.023+00	2025-2026	\N	Tổ dân phố 7 - xã Đức Cơ – Tỉnh Gia Lai
a99cbc2b-41bf-4b55-9844-4f2026c0b768	Nguyễn Đình Tiến	01/06/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:55.555+00	2025-2026	\N	Tổ DP 6 -  Đức Cơ - Gia Lai
15becc7c-fdbb-4368-a2de-2a455f2b4a66	Phan Đình Hoàng Anh	01/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.088+00	2025-2026	\N	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai
80ea8573-9dfe-4540-bb09-5aefd89dc5a3	Rơ Lan H Khâm	11/06/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:00:58.615+00	2025-2026	\N	Làng Sung Le Tung - Xã Iadơk- Gia Lai
4309e016-21c7-4f68-85c2-26e635208bc5	Lê Hoàng Hạ Phương	06/10/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:00.258+00	2025-2026	\N	Thôn Ia Lâm - Ia Krêl - Gia Lai
5c75cd61-6999-44fa-81a4-14a12adb9fd8	Rơ Mah H’ Trang	21/01/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:01.751+00	2025-2026	\N	Làng Krai - Xã Đức Cơ - Gia Lai
f1ca01f0-619d-4789-a271-b77408e4679b	Kpuih Nhan	09/06/2007	Nữ	Gia-rai		f	12B9				2026-03-23 14:01:06.43+00	2025-2026	\N	Dơk Ngol, xã Ia Dơk, Gia Lai
c9b57d09-3368-4697-a499-778d72440840	Lê Thị Minh Thư	29/04/2008	Nữ	Kinh		f	12B9				2026-03-23 14:01:07.991+00	2025-2026	\N	Làng H'rang,, xã Đức Cơ, Gia Lai
5d442b14-0bc4-4e4f-878b-bce8bd8a9e64	Rơ Mah H' Diệu	23/01/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:10.973+00	2025-2026	\N	Làng Dơk Ngol- Xã Ia Dơk - Tỉnh Gia Lai
4b463588-7bd1-45ae-b554-3c5b195ea877	Lê Thị Thúy Kiều	24/02/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:12.524+00	2025-2026	\N	Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai
1b92e9c8-1ef8-412f-ab0b-39c081dd2080	Đoàn Thị Mỹ Tâm	12/06/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:14.077+00	2025-2026	\N	TDP 8 - Xã Đức Cơ - Tỉnh Gia Lai
7c2d600c-2ccf-481a-bb87-0d319d77f0a9	Đậu Tuấn Anh	31/12/2008	Nam	Kinh	Học sinh	t	12B10				2026-03-26 02:04:22.952+00	2025-2026	HK2	TDP 1 - Xã Đức cơ- Tỉnh Gia Lai
911a0b92-86be-4c39-834c-5aa4a0b8dbd6	Lê Thị Hiền	22/05/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:29.157+00	2025-2026	HK2	Tổ dân phố I, xã Đức Cơ, Gia Lai
b2fea11b-52ad-49b5-ad74-91721c6254a3	Nguyễn Hương Thảo	2008-09-30	Nữ	Kinh		t	12B1	2025-01-09	0347745938		2026-03-26 02:13:03.187+00	2025-2026	HK2	Thôn Chư Bồ 2 - Xã Ia Dơk - Tỉnh Gia Lai
5d4a576a-431f-41fe-8673-0be04fd2cac5	Phạm Lê Gia Nhi	2008-10-28	Nữ	Kinh		t	12B1	2025-01-09	0977823975		2026-03-26 02:29:31.175+00	2025-2026	HK2	Tổ 4 - Xã Đức Cơ - Tỉnh Gia Lai
5b727795-d975-41cc-8854-ee5a186cac6e	Hồ Văn An	18/11/2008	Nam	Kinh		f	12B9				2026-03-27 13:18:36.859+00	2025-2026	HK2	Làng Lung Prông- xã Đức Cơ- Gia Lai
ac26f03f-6aa3-4169-886a-ecf60ff9cd07	Lê Thành Danh	19/07/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:15.772+00	2025-2026	\N	TỔ DÂN PHỐ 7, Xã Đức Cơ, Tỉnh Gia Lai
c13a7d3d-486f-4473-a3d8-5a84ebac1db0	Trần Quang Huy	13/05/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.47+00	2025-2026	\N	Thôn Mook Trang, Xã Ia Dom, Tỉnh Gia Lai
81db37b4-ea37-4c90-b483-cd26206a2f7c	Nguyễn Chí Quốc	27/11/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:18.963+00	2025-2026	\N	TỔ DÂN PHỐ 1, Xã Đức Cơ, Tỉnh Gia Lai
dacdc150-bec0-4dac-94b0-a45dfd1b7519	Nguyễn Đình Văn	24/02/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:20.552+00	2025-2026	\N	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai
c931216e-dfef-4df9-bebf-235bebf30693	Lê Văn Đạt	22/07/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.119+00	2025-2026	\N	Thôn Đoàn Kết, Xã Ia Dơk, Tỉnh Gia Lai
add056e6-633f-4513-a9ea-3b6c3268fc6c	Trần Thị Lan Hương	03/10/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:23.703+00	2025-2026	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
066cd95e-59cc-452f-8750-7882b68eab82	Nguyễn Ngọc Phương Như	17/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.226+00	2025-2026	\N	Làng Nú, Xã Ia Nan, Tỉnh Gia Lai
e803bd36-ea79-4bd7-b894-29ac803e6d98	Hoàng Khương Kiên Trung	19/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:26.784+00	2025-2026	\N	Tổ 6, Phường Thống Nhất, Tỉnh Gia Lai
3f8fbcc1-4a52-4f08-9661-63eb62c6c361	Nguyễn Ngọc Chương	22/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.32+00	2025-2026	\N	Thôn Chư Bồ 1, xã IaDơk, tỉnh Gia Lai
870a2781-ca46-4a5b-8281-15d1e08ce611	Đinh Thị Hương	16/10/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.837+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai
ac4da855-3d61-4bf6-bf98-b6b0fd02eaa7	Tăng Ngọc Nam	06/11/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:31.319+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai\r\n
175af990-74d0-4e58-b396-40775116269c	Nguyễn Hữu Thắng	09/12/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:32.875+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n
73703faa-1726-454d-bf40-9c0df35722c3	Rơ Lan H' Bích	01/10/2007	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:34.346+00	2025-2026	\N	Làng Sung le Kắt - Ia Dơk - Gia Lai
66e59e76-018e-4548-bf28-4efa446bf994	Vương Tiến Hùng	29/08/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:35.868+00	2025-2026	\N	Làng Krêl - Ia Krêl - Gia Lai
d61c81f0-1a38-41c9-9a99-95b2156e7182	Nguyễn Thị Hồng Nhung	21/02/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:37.339+00	2025-2026	\N	Thanh Giáo - Đức Cơ -Gia Lai
b81aaeaa-2886-430b-a981-d76be304d491	Hồ Phúc Thịnh	07/02/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:38.857+00	2025-2026	\N	TDP4 , Đức Cơ ,Gia Lai
aad7adf5-ca55-418f-8c6f-a9b85f347e87	Lê Văn Anh Tuấn	02/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:40.335+00	2025-2026	\N	Ia Kăm - Ia Krêl -Gia Lai
3f70de70-385c-41f1-8a1b-d717f0572d3b	RLAN H' DIỆU	28/10/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:41.819+00	2025-2026	\N	Sung Le Kắt - Ia Kla - Đức Cơ - Gia Lai
3465251d-593b-4694-af6d-652ab1ac0eb2	NGUYỄN NGỌC BẢO HÂN	28/07/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:43.387+00	2025-2026	\N	TDP 6 - Chư Ty - Đức Cơ - Gia Lai
03c425d7-b523-48d9-a5f9-f4d283ea8bf6	RƠ LAN H' MƯNH	04/06/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:44.885+00	2025-2026	\N	Sung Kép - Ia Kla - Đức Cơ - Gia Lai
135ef86b-608e-4265-9980-665425a6b8b2	Hoàng Long Quyền	18/11/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:46.426+00	2025-2026	\N	Ia Mang, Ia Dơk, Đức Cơ, Gia Lai
1f30e8f5-f518-4958-93b8-ea96c0baf6c4	NGUYỄN LÊ HOÀI THƯƠNG	29/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.008+00	2025-2026	\N	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai
b887f276-28f4-437f-9389-213219a5b231	Dương Văn Bảo	18/03/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:49.608+00	2025-2026	\N	Tổ dân phố 7 - Đức Cơ – Gia Lai
d481540e-cbbe-4014-94c3-61840e097124	Rơ Mah H' Hát	19/10/2007	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:51.156+00	2025-2026	\N	Làng Lung -Đức Cơ- Gia Lai
151e88e9-fdac-4e3d-9dd9-2e68e666b7f2	Rơ Mah H' Lan	16/06/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:52.677+00	2025-2026	\N	Làng Hrang -xã Đức Cơ - Tỉnh  Gia Lai
47a4fb58-9dcf-48d8-83d8-d04482c2306f	Vũ Phương Yến Ngọc	14/02/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:54.168+00	2025-2026	\N	Làng Sung tung - Xã Iadơk- Tỉnh Gia Lai
67d2ade5-ffe5-4b70-ac95-f79f2f9d175e	Rơ Lan Tiếp	07/08/2008	Nam	Gia-rai		f	12B7				2026-03-23 14:00:55.705+00	2025-2026	\N	Làng Đo, xã Ia Dơk, Tỉnh Gia Lai
37cee3da-3e60-49ca-9012-a5f622db3279	Đặng Gia Bảo	20/09/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.247+00	2025-2026	\N	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai
815c61e0-22eb-4e24-9874-a04174ff10b5	Đỗ Đình Lâm	29/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.779+00	2025-2026	\N	Làng Lang - Ia Dơk - Gia Lai
5f1b6845-92e9-4b5d-a37e-2b6536c805cb	Hoàng Thị Quế Trân	10/02/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:01.902+00	2025-2026	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai
60509c94-6d43-4f23-ae58-067e6f4f787a	Châu Thanh Hoàng	01/06/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.056+00	2025-2026	\N	Làng Kom Ngó, Ia Chia, Gia Lai
45ee9d02-8ddb-4e2f-b145-a4f93b887308	Y Linh Nhi	20/06/2008	Nữ	Xơ-Đăng		f	12B9				2026-03-23 14:01:06.604+00	2025-2026	\N	Làng Ghè,xã Ia Dơk, Gia Lai
00b35e54-24f6-4602-9b8b-d03b4c6ba5e8	Đinh Hải Anh	19/01/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:09.627+00	2025-2026	\N	Làng Dơk Ngol - Xã Đức Cơ - Tỉnh Gia Lai
821bb8ec-2c51-4ceb-961f-d93410638567	Lê Thị Anh Đào	30/01/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:11.128+00	2025-2026	\N	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai
a09136ff-d80c-4bef-8424-eedc928b9301	Hoàng Thị Khánh Linh	25/11/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:12.689+00	2025-2026	\N	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai
7ad7f163-53e9-4aa7-8209-54fc4eb2a052	Lưu Thị Phương Thảo	18/03/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:14.257+00	2025-2026	\N	Thôn Lâm Tôk - Xã Ia Krêl - Tỉnh Gia Lai
751c748c-9aa5-41d6-aac8-495e85ee8f42	Cao Thục Quyên	2008-06-28	Nữ	Kinh		f	12B8		0333481577		2026-03-26 00:53:03.322+00	2025-2026		Tổ dân phố 4 - Xã Đức Cơ - Gia Lai
7eb62d3c-f9cb-4386-9df9-6cd71c4b6391	Đinh Thị Ngọc Anh	13/01/2008	Nữ	Kinh		t	12B9				2026-03-26 01:47:25.642+00	2025-2026		Làng Dơk Klăh, Ia Dơk, Gia Lai
d6ae2d2d-c066-4623-862e-85e65eb8a809	Lương Thị Thủy Tiên	12/10/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:47.495+00	2025-2026	HK2	Lệ Kim, Ia Dơk, Gia Lai
31e7b682-8f52-4ef8-aa53-d81dce9e46df	Lê Tâm Như	2008-10-09	Nữ	Kinh		t	12B1	2025-04-01	0975046279		2026-03-26 14:31:13.031+00	2025-2026		Thôn Ia Lâm - Xã Ia Krêl - Tỉnh Gia Lai
8ed1f656-50db-404f-9530-8b034378a8d4	Nguyễn Đức Thắng	2008-09-09	Nam	Kinh		t	12B1	2025-04-01	0839687889		2026-03-26 04:59:09.02+00	2025-2026	HK2	Tổ 7 - Xã Đức Cơ - Tỉnh Gia Lai
9d975242-8822-4d59-9ea3-88c05be2513c	Đoàn Thị Ngọc Diệp	26/01/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:15.932+00	2025-2026	\N	Thôn Ia Tang, Xã Ia Dơk, Tỉnh Gia Lai
b1d95700-efa0-4f80-a77d-89ca94043c31	Hoàng Thị Thu Huyền	14/03/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:17.616+00	2025-2026	\N	Làng Hrang, Xã Đức Cơ, Tỉnh Gia Lai
cac87fb2-3566-41b6-b947-8f2de83c086a	Nguyễn Thị Diễm Quỳnh	07/02/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:19.115+00	2025-2026	\N	ThônThanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
9e83712a-d214-4c05-836a-7d3b14bd7142	Phạm Nguyên Việt	04/12/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:20.723+00	2025-2026	\N	Tổ Dân Phố 1, Xã Đức Cơ, Tỉnh Gia Lai
5592e235-1a16-437e-bc5e-fe467c6bb116	Nguyễn Thành Đạt	29/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.282+00	2025-2026	\N	 Thôn Thanh Giáo, Xã Ia Krêl, Tỉnh Gia Lai
0ddfb5eb-7c58-4244-9ed2-b511fa92b79a	Lương Nguyễn Anh Kiệt	29/11/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:23.85+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
dc299478-2c81-48e4-993e-46f7a5696e84	Nguyễn Văn Quyền	29/02/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:25.364+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
1c223398-697d-4178-833f-9619aace9423	Từ Thị Ngọc Tuyên	28/08/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:26.936+00	2025-2026	\N	Tổ dân phố 4, Xã Đức Cơ, Tỉnh Gia Lai
bdf566ab-f80f-47ec-b378-ffb134c8eab8	Lê Tuấn Dũng	06/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.486+00	2025-2026	\N	Tổ dân phố 3, xã Đức Cơ, tỉnh Gia Lai
509d5d5e-4d18-4a7d-8941-363a782a2443	Đặng Thu Hường	12/06/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:29.987+00	2025-2026	\N	Tổ dân phố 9, xã Đức Cơ, tỉnh Gia Lai
c22dd1ed-5c26-42be-bba9-168bc2b8992c	Nguyễn Thị Quỳnh Nga	21/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.465+00	2025-2026	\N	Thôn Thanh Giáo, xã Ia Krêl, tỉnh Gia Lai
ba3f2636-6731-4d7b-9e42-a770dd4f1834	Phạm Anh Thư	14/12/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:33.03+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
fc990922-7be4-4a37-a99b-728db753b2cd	Hoàng Thị Quỳnh Chi	09/11/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.501+00	2025-2026	\N	TDP 3  - Đức Cơ - Gia Lai
f3b46399-66eb-4656-8362-9d0c1777ab76	Lương Trung Huy	18/07/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:36.016+00	2025-2026	\N	Ia Tang - Ia Dơk - Gia Lai
24b6f0ac-86b3-4e66-af39-523d2f21e5b5	Rơ Mah Phiên	13/10/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:37.496+00	2025-2026	\N	Làng Ghè - Ia Dơk  - Gia Lai
fd3e72f9-0292-4ec6-ab47-5670e6ed9f4c	Vũ Hồ Anh Thư	12/11/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.008+00	2025-2026	\N	TDP 6, Đức Cơ , Gia Lai
2d5c39de-aa33-4039-850e-487fd6421a95	Rơ Mah Tuấn	02/07/2008	Nam	Gia-rai		f	12B5				2026-03-23 14:00:40.479+00	2025-2026	\N	Làng Pong - Ia Dơk - Gia Lai
a077bb60-c826-47ab-92e1-4a8866c58670	Hồ Thị Thùy Dung	12/05/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:41.959+00	2025-2026	\N	Tổ dân phố 2,TT Chư Ty, Đức Cơ - Gia Lai
c044cdb7-4422-4911-b004-86e9b4560331	TRẦN MINH HIẾU	03/08/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:43.533+00	2025-2026	\N	TDP 4 - Chư Ty - Đức Cơ - Gia Lai
2c1151ec-2d2b-4fb4-988b-669c1b344ad8	LÊ THỊ MỸ	26/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.049+00	2025-2026	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai
eb8f7447-2398-45d5-acd0-a8df3923a089	RMAH H' LY SA	05/01/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.595+00	2025-2026	\N	Làng Le Kắt - Ia Kla - Đức Cơ - Gia Lai
8f0539ce-d58e-4666-9a06-e3c024654752	TRƯƠNG ÁI MỸ TIÊN	29/01/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.24+00	2025-2026	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai
f9d9726a-819f-4b1c-acaa-eef518022b9d	Rah Lan H' Ru Bi	28/11/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:49.755+00	2025-2026	\N	Làng Sung le kăt, Xã Ia Dơk, Tỉnh Gia Lai
97e161ea-32a2-48e5-8007-878eea143513	Nguyễn Thị Hiền	10/12/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:51.324+00	2025-2026	\N	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai
a7cd57d6-1b09-49a2-9e34-c7a0b89a073b	Nguyễn Hải Lâm	12/01/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:52.83+00	2025-2026	\N	Thôn ia lam- xã Iakrêl - Gia Lai
20ebc8e9-5126-4e3e-8cf9-9cfe674d2db2	Rơ Lan Nhung	28/09/2007	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:54.313+00	2025-2026	\N	Làng Sung- xã Ia Dơk, Tỉnh Gia Lai
71af3a99-14f6-4076-9eae-8b04da85a96e	Quyền Đình Trọng	11/12/2008	Nam	Kinh		f	12B7				2026-03-23 14:00:55.852+00	2025-2026	\N	Thôn IaKênh, xã Ia Dơk, Tỉnh Gia Lai
5a5765ad-1305-40f7-82f3-24e65a995c2d	Hoàng Gia Bảo	18/10/2008	Nam	Sán Dìu		f	12B8				2026-03-23 14:00:57.398+00	2025-2026	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai
b9cd09c5-26e5-4bc1-833c-ec8145073a36	Đinh Quang Lộc	09/01/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:58.958+00	2025-2026	\N	Tổ dân phố 3 - Xã Đức Cơ - Gia Lai
edb2c247-8cf0-4a3d-a803-c9e1fbcc2da1	Rơ Mah H' Quỳnh	06/04/2008	Nữ	Gia-rai		f	12B8				2026-03-23 14:01:00.565+00	2025-2026	\N	Làng Khóp - Ia Krêl  - Gia Lai
10c4503b-ee11-4239-97ce-8e2eb878d10e	Lê Khả Tuấn Tú	10/06/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.058+00	2025-2026	\N	Tổ dân phố 1 - Xã Đức Cơ - Gia Lai
5609c740-ff28-4573-9637-39ea8d9a1733	Trần Gia Hưng	23/09/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.2+00	2025-2026	\N	Thôn Lệ Kim, Xã Ia Dơk ,Tỉnh Gia Lai
39b75e25-4553-419b-a470-7781402ec0b3	Trần Ngọc Ánh	09/12/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:09.754+00	2025-2026	\N	TDP 9 - Xã Đức Cơ - Tỉnh Gia Lai
ef7883d1-b42b-4816-805e-c2f0461bed45	Ksor Ngọc Hân	26/07/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:11.285+00	2025-2026	\N	Làng Đo - Xã Ia Dơk - Tỉnh Gia Lai
2915eda8-3f13-4d03-8b84-08198b41e52f	Trịnh Hoàng Long	12/09/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:12.85+00	2025-2026	\N	TDP 3 - Xã Đức Cơ - Tỉnh Gia Lai
bef97884-4450-46d3-b542-e2e7daa13e2b	Mai Thị Thảo	04/07/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:14.417+00	2025-2026	\N	TDP 2 - Xã Đức Cơ - Tỉnh Gia Lai
df73b4e5-693a-497f-aceb-90b67fc6836f	Lê Thị Hồng Nhung	15/02/2008	Nữ	Kinh		t	12B9				2026-03-26 02:06:38.016+00	2025-2026	HK2	Làng Khóp, xã Ia Krêl, Gia Lai.
a191c6e0-2c9f-4602-89a0-a5998768ebba	Nguyễn Thành Tín	04/08/2008	Nam	Kinh		t	12B9				2026-03-26 02:07:25.497+00	2025-2026	HK2	Tổ dân phố 3, xã Đức Cơ, Gia Lai
da5590cc-d266-47b8-b0c8-9f82ea87a79a	Nông Hoàng Diệp Bình	07/07/2008	Nữ	Tày		t	12B9				2026-03-26 02:07:55.947+00	2025-2026	HK2	Thôn Chư Bồ 1, Xã Ia Dơk,Gia Lai
f51a0119-252e-49f4-b948-8f5beede90d5	Đinh Thị Thanh Thùy	2008-11-25	Nữ	Kinh		t	12B1	2025-01-09	0833827587		2026-03-26 02:14:10.54+00	2025-2026	HK2	Làng Pong - Xã Ia Dơk - Tỉnh Gia Lai
d5f577c0-c80d-4347-994e-8590d5df231a	Trịnh Tâm Như	2008-08-14	Nữ	Kinh		t	12B1	2023-03-26	0789725567		2026-03-26 04:59:57.594+00	2025-2026	HK2	Tổ 6 - Xã Đức Cơ- Tỉnh Gia Lai
cd630baa-3309-4581-b346-41ffdeb30125	Phan Văn Dũng	14/10/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:16.133+00	2025-2026	\N	Thôn Ia Mang, Xã Ia Dơk, Tỉnh Gia Lai
2d054e22-5389-4d58-b275-d5228b404630	Đào Duy Hưởng	16/06/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.768+00	2025-2026	\N	Thôn Ia Lâm, Ia Krêl, Tỉnh Gia Lai
c5a9f3ec-eafe-467f-ad27-43041f30d9dd	Võ Duy Tài	06/10/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:19.265+00	2025-2026	\N	Thôn IaLâm, Xã Ia Krêl, Tỉnh Gia Lai
5cb9a5d3-18fa-4dad-8a7b-9358218b2bd5	Lê Thị Yến Vy	18/07/2008	Nữ	Kinh		f	12B2				2026-03-23 14:00:20.884+00	2025-2026	\N	Thôn Chư Bồ 1, Xã Ia Dơk, Tỉnh Gia Lai
2c003304-4d9d-4511-bb2f-6181686e3dac	Nguyễn Tiến Đạt	27/05/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.439+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
122e6e7e-60e7-482f-b8ec-9108cfa8ecd7	Nguyễn Việt Linh	16/10/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:24.006+00	2025-2026	\N	Thôn Chư bồ 2, Xã Ia Dơk, Tỉnh Gia Lai
73fd5eb9-d6a9-47be-b1aa-5392d2466618	Trần Thị Mỹ Tâm	28/09/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.509+00	2025-2026	\N	Tổ dân phố 1, Xã Đức Cơ, Tỉnh Gia Lai
8de405c4-8ff1-4071-97c1-fc7429879305	Phạm Minh Vũ	24/10/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:27.104+00	2025-2026	\N	Tổ dân phố 6, Xã Đức Cơ, Tỉnh Gia Lai
73867a61-1489-4d04-8d5a-370db6cd586b	Mai Tấn Dũng	20/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.643+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
06b6c8af-bbe8-47ee-9e74-126a36ebbb09	Ngô Đức Linh	31/07/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:30.154+00	2025-2026	\N	Làng Krê, xã Ia Krêl, tỉnh Gia Lai
33a34d8d-28de-4609-83b9-6e22fd6bc398	Chu Nguyễn Bảo Ngọc	18/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.613+00	2025-2026	\N	Thôn Ia Tang, xã Ia Dơk, tỉnh Gia Lai
0f26470e-a037-409a-9021-2c91f9e2c0dd	Nguyễn Thị Thùy Trang	13/01/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:33.186+00	2025-2026	\N	Làng Krai, xã Đức Cơ, tỉnh Gia Lai
f7e545c2-0e26-4aea-8c85-813db14521bf	Hồ Ngọc Quế Chi	26/10/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:34.666+00	2025-2026	\N	TDP 4 - Đức Cơ - Gia Lai
90b1cfcc-f351-42c4-9fd0-2c214ee74618	Nguyễn Trần Minh Khôi	01/09/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:36.159+00	2025-2026	\N	TDP 1 - Đức Cơ - Gia Lai
fa8b40e7-511f-4cea-b4e8-904e3014cd01	Phí Mạnh Phúc	25/01/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.647+00	2025-2026	\N	Thôn Chư Bồ 2 - Ia Dơk - Gia Lai
d88b763e-9215-407a-83ff-a242b7a8df93	Lê Xuân Tiến	25/10/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:39.149+00	2025-2026	\N	Tổ dân phố 1 - Đức Cơ - Gia Lai
3e2bbebf-7a9d-4acb-a30d-a2dbfbec49ad	Rơ Mah H' Tuệ	12/12/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.623+00	2025-2026	\N	Làng Pong - Ia Dơk - Gia Lai
e17d31d0-a8ad-49b2-9972-47a9eb4ae3a3	NGUYỄN THỊ DUYÊN	02/10/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:42.109+00	2025-2026	\N	TDP7 - Chư Ty - Đức Cơ - Gia Lai
a029fd18-2dea-491f-bfa8-f82007a35f7f	KPUIH H' HÚI	23/04/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:43.677+00	2025-2026	\N	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai
7d0c240e-82fd-48ae-a669-80653c39c7a9	NGUYỄN THỊ HỒNG NGỌC	29/02/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.209+00	2025-2026	\N	Đội 12 - Ia Chía - Ia Grai - Gia Lai
2181db6e-9b3d-441a-bc69-a4db1b146a88	SIU LI SA	26/03/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:46.769+00	2025-2026	\N	Làng Ghè - Ia Dơk - Đức Cơ - Gia Lai
d5b9feaa-c94d-4a36-b2e4-67af8cf7c939	LÊ THỊ HUYỀN TRANG	11/04/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:48.417+00	2025-2026	\N	TDP 7 - Chư Ty - Đức Cơ - Gia Lai
a04ac8ce-c777-4167-8f5c-2fe3b2443207	Kpuih H' Chúc	15/09/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:49.931+00	2025-2026	\N	Làng Lung Prông -  xã Đức Cơ - Tỉnh Gia Lai
a986da86-eab1-4a7d-a8f1-ba9e01ae9d0d	Nguyễn Thị Thu Hiền	14/11/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:51.514+00	2025-2026	\N	Tổ dân phố 2,  Đức Cơ, Gia Lai
8f5dcc7d-552a-4412-9a4c-45ae1ec162ad	Rơ Châm H' Lệ	23/10/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:52.983+00	2025-2026	\N	làng dơk ngol ,xã ia dơk , tỉnh Gia Lai
68549c64-0e11-4ef7-9556-3457d6bd399d	Kpuih H' Như	20/04/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:54.449+00	2025-2026	\N	Làng Lung Prông-  Đức Cơ- Gia Lai
1390fd9b-a37e-4456-89f2-c779d07d916e	Rơ Mah H' Trúc	28/11/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:55.984+00	2025-2026	\N	Sung Le - Ia Dơk-  Gia Lai
781e1550-6997-4030-8c5d-78f2b3359bcc	Nguyễn Trần Nhật Đang	16/09/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.549+00	2025-2026	\N	Tổ dân phố 4 - Xã Đức Cơ - Gia Lai
0b51473e-4c9e-4db2-93a6-f852b71e180b	Nguyễn Ngọc Mai	10/10/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.112+00	2025-2026	\N	Tổ dân phố 7 - Xã  Đức Cơ - Gia Lai
8e239664-a6fa-4cd9-8f03-ba74607678d4	Nguyễn Văn Sỹ	04/06/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:00.72+00	2025-2026	\N	Thanh Giáo - Ia Krêl - Gia Lai
d06913f3-7e8d-4706-a1a6-4233258945a0	Nguyễn Quốc Tuấn	19/08/2008	Nam	Kinh		f	12B8				2026-03-23 14:01:02.21+00	2025-2026	\N	Tổ dân phố 1 - Xã  Đức Cơ - Gia Lai
ea020c65-cdad-4926-8071-673f30c2789e	Rơ Mah Bom	19/01/2008	Nam	Gia-rai		f	12B9				2026-03-23 14:01:03.814+00	2025-2026	\N	Làng Sung, Ia Dơk, Gia Lai
3629e93f-e662-4798-9a0e-fd10327fd3ad	Võ Duy Hưng	28/09/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:05.356+00	2025-2026	\N	Tổ dân phố 9 - xã Đức Cơ, Gia Lai
81fcc328-a5ea-439e-8521-062dd08c2760	Rơ Mah H' AYưng	24/01/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:09.899+00	2025-2026	\N	Làng Khóp - Xã Ia Krêl - Tỉnh Gia Lai
6763fd9a-dd17-435d-b71a-02bbfdfd7560	Lương Gia Hân	29/12/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:11.418+00	2025-2026	\N	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai
4a3d995f-ca7d-4809-a983-ca766d83e986	Rơ Lan Hoa Mai	22/11/2008	Nữ	Gia-rai		f	12B10				2026-03-23 14:01:12.994+00	2025-2026	\N	Làng Poong - Xã Ia Dơk - Tỉnh Gia Lai
1b91d0ea-9fd6-44b4-805b-de6173527264	Vũ Thị Thu Thảo	24/10/2008	Nữ	Kinh		f	12B10				2026-03-23 14:01:14.57+00	2025-2026	\N	Thôn Ia Mang - Xã Ia Dơk - Tỉnh Gia Lai
93fe0665-7970-46b9-9e71-4dbaeee859cc	Đỗ Quỳnh Tố Như	23/09/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:14.675+00	2025-2026	HK2	Thanh Bình, xã Bàu Cạn, Gia Lai
0083cea7-e3e1-496b-b8fc-2071d71db7ab	Hoàng Thị Bảo Trâm	10/11/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:26.308+00	2025-2026	HK2	Thôn Lệ Kim, Ia Dơk, Gia Lai
5c64d923-7527-4400-b617-ad638b8035dd	Nguyễn Thị Trầm Thương	2008-01-11	Nữ	Kinh		t	12B1	2023-03-26	0395372178		2026-03-26 02:26:58.528+00	2025-2026		Tổ 2 -Xã Đức Cơ - Tỉnh Gia Lai
c77e4670-587c-4675-844a-a691ab08b0ed	Đỗ Hà Phi	2008-01-06	Nam	Kinh		t	12B1	2022-10-16	0382316601		2026-03-26 13:07:48.141+00	2025-2026		Làng Krai - Xã Đức Cơ - Tỉnh Gia Lai
b2c73d89-3c9e-48c8-845d-20bc521a9aec	Mai Thanh Lâm	23/12/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:17.918+00	2025-2026	\N	Thôn Ia Chía, Xã Ia Nan, Tỉnh Gia Lai
f0363907-9f7b-4a1a-a1bd-601f624f0b36	Lê Hữu Thành	08/09/2008	Nam	Kinh		f	12B2				2026-03-23 14:00:19.428+00	2025-2026	\N	TỔ DÂN PHỐ 3, Xã Đức Cơ, Tỉnh Gia Lai
a25123eb-dd94-4039-96c4-16a8c245a51f	Vũ Đình Đạt	26/08/2008	Nam	Kinh		f	12B3				2026-03-23 14:00:22.615+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
bd5740bc-dd57-49be-9620-8c02826ff329	Nguyễn Trần Khánh Lợi	30/01/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:24.15+00	2025-2026	\N	Thôn Ia Lâm, Xã Ia Krêl, Tỉnh Gia Lai
d78eb5c4-c164-4c35-88f2-d281803b1fc6	Trần Thị Lệ Thanh	29/11/2008	Nữ	Kinh		f	12B3				2026-03-23 14:00:25.66+00	2025-2026	\N	Tổ dân phố 2, Xã Đức Cơ, Tỉnh Gia Lai
3024cc64-b6a2-45b4-83d7-df1f9c2a1043	Hoàng Uyên Vy	12/05/2008	Nữ	Mường		f	12B3				2026-03-23 14:00:27.295+00	2025-2026	\N	Tổ dân phố 7, Xã Đức Cơ, Tỉnh Gia Lai
97b01cd9-1c32-40ca-b7ce-208ea15dd64a	Mai Tiến Dũng	20/02/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:28.791+00	2025-2026	\N	Tổ dân phố 4, xã Đức Cơ, tỉnh Gia Lai
b2fddc4e-27d2-40c7-9f4d-f9428e6157dd	Nguyễn Ngọc Hồng Linh	06/08/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:30.299+00	2025-2026	\N	Thôn Thanh Tân, xã Ia Krêl, tỉnh Gia Lai
ebbd3731-9f01-47ca-bb5f-4993539aa4ca	Mai Thị Yến Nhi	27/05/2008	Nữ	Kinh		f	12B4				2026-03-23 14:00:31.787+00	2025-2026	\N	Tổ dân phố 2, xã Đức Cơ, tỉnh Gia Lai\r\n
99261e54-0c12-46dd-9e30-2d357167b0f0	Nguyễn Xuân Việt	15/01/2008	Nam	Kinh		f	12B4				2026-03-23 14:00:33.332+00	2025-2026	\N	Tổ dân phố 1, xã Đức Cơ, tỉnh Gia Lai\r\n
d1e1de5d-683e-45c9-a76d-1b68c38e6b71	R Lan H' Diệp	19/04/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:34.819+00	2025-2026	\N	Sung Lê Kắt - Ia Dơk- Gia Lai
55fdbc60-d17a-43df-8942-8e45163d0dec	Hồ Lê Phương Linh	27/09/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:36.304+00	2025-2026	\N	TDP1 - Đức Cơ - Gia Lai
280a8629-c319-4584-aafd-9dfa85cdc9dd	Đậu Tiến Quân	05/03/2008	Nam	Kinh		f	12B5				2026-03-23 14:00:37.815+00	2025-2026	\N	Thôn Đoàn Kết- Ia Dơk - Gia Lai
074fd61a-7962-468b-8fba-c9a953675059	Hồ Thị Tình	24/08/2008	Nữ	Kinh		f	12B5				2026-03-23 14:00:39.277+00	2025-2026	\N	Thôn Đoàn Kết - Ia Dơk  - Gia Lai
80848897-b43e-47e7-8eaa-40c9de625db7	Rơ Mah H' Út	30/09/2008	Nữ	Gia-rai		f	12B5				2026-03-23 14:00:40.77+00	2025-2026	\N	Làng Lung Prông, Đức Cơ ,Gia Lai
ebd03a81-7ee2-466c-9094-f8db1fbdc84e	NGUYỄN THẾ ĐẠT	10/03/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:42.25+00	2025-2026	\N	TDP 3 -Chư Ty - Đức Cơ - Gia Lai
5a05b740-9952-4b40-8b8c-de1e9757b22d	RƠ MAH HÚY	12/10/2008	Nữ	Gia-rai		f	12B6				2026-03-23 14:00:43.839+00	2025-2026	\N	Dơk Ngol - Ia Dơk - Đức Cơ - Gia Lai
344c216b-bf6e-492d-9694-b9358eb12621	NGUYỄN PHƯƠNG THẢO NGUYÊN	10/09/2008	Nữ	Kinh		f	12B6				2026-03-23 14:00:45.364+00	2025-2026	\N	TDP 9 - Chư Ty - Đức Cơ - Gia Lai
8646134a-4e2e-4470-873d-0ced8b7c3cb0	KHUẤT ANH TÚ	30/03/2008	Nam	Kinh		f	12B6				2026-03-23 14:00:48.588+00	2025-2026	\N	Ia Mang - Ia Dơk - Đức Cơ - Gia Lai
4ebe940f-0294-42fa-a80c-d3ff973e93d2	Nguyễn Thị Thùy Dung	13/04/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:50.083+00	2025-2026	\N	Thôn Ia tang, Xã Ia Dơk, Tỉnh Gia Lai
b4512934-dbd6-467e-91e6-0beea904a079	Vũ Hoàng Diệu Hiền	04/11/2008	Nữ	Kinh		f	12B7				2026-03-23 14:00:51.675+00	2025-2026	\N	Tổ dân phố 6-  Đức Cơ- Gia Lai
09a13ccc-4b17-4311-9346-273473f9a5e4	Kpuih H' Nhưng	11/10/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:54.608+00	2025-2026	\N	Làng Pnuk- Đức Cơ- Gia Lai
00aaab14-f21e-443c-a5e3-7d6be1c4909c	Rơ Mah Hà Trúc	08/09/2008	Nữ	Gia-rai		f	12B7				2026-03-23 14:00:56.154+00	2025-2026	\N	Làng Sung Kắt - xã Ia Dơk - Tỉnh Gia Lai
c2a04152-a093-4fd9-97e4-0d24c86f1175	Nguyễn Văn Định	27/10/2008	Nam	Kinh		f	12B8				2026-03-23 14:00:57.708+00	2025-2026	\N	Thôn Ia Kăm - Xã Ia Krêl - Gia Lai
04b0c602-ccdd-41cd-bbcf-c0c1812daeff	Lê Thị Trà My	05/06/2008	Nữ	Kinh		f	12B8				2026-03-23 14:00:59.27+00	2025-2026	\N	Tổ dân phố 3 - Xã  Đức Cơ - Gia Lai
06afd6ad-6d46-4c51-832c-c1ba2c04250d	Mai Văn Tâm	17/11/2007	Nam	Kinh		f	12B8				2026-03-23 14:01:00.858+00	2025-2026	\N	Tổ dân phố 6 - Xã Đức Cơ- Gia Lai
d8dfea21-94ff-4d5d-8ac4-2316e49d0410	Đặng Thị Khánh Uyên	30/09/2008	Nữ	Kinh		f	12B8				2026-03-23 14:01:02.361+00	2025-2026	\N	Tổ dân phố 6 - Chư Ty - Đức Cơ - Gia Lai
90946272-8103-4c43-a2d6-dc9b8adae117	Lê Khả Cơ	16/05/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:03.953+00	2025-2026	\N	Thôn Đoàn Kết, Ia Dơk, Gia Lai
6ee012f0-a2c0-4515-877a-288e91ba25b7	Lê Văn Phụng	26/06/2008	Nam	Kinh		f	12B9				2026-03-23 14:01:07.026+00	2025-2026	\N	Chư bồ II - Ia Dơk - Gia Lai
e0db9d99-c3a5-4c18-9449-d91de9b08fcd	Trần Nguyễn Gia Bảo	03/10/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:10.052+00	2025-2026	\N	TDP 1 - Xã Đức Cơ - Tỉnh Gia Lai
230b47e1-f234-4119-a156-4979bbf4490a	Kpuih Hiệp	24/09/2007	Nam	Gia-rai		f	12B10				2026-03-23 14:01:11.571+00	2025-2026	\N	Làng Nuk - Xã Đức Cơ - Tỉnh Gia Lai
b4f1e0ce-7df1-48da-94e7-aa28e4858a35	Nguyễn Văn Mạnh	07/10/2008	Nam	Kinh		f	12B10				2026-03-23 14:01:13.153+00	2025-2026	\N	Thôn Ia Tang - Xã Ia Dơk - Tỉnh Gia Lai
01183682-945d-470f-bc40-07df0a1e6950	Ksor Thịnh	07/08/2008	Nam	Gia-rai		f	12B10				2026-03-23 14:01:14.733+00	2025-2026	\N	Làng Krol - Xã Ia Krêl - Tỉnh Gia Lai
88d463c9-fde1-4ed1-8f30-96dc5dfe1e65	ĐÀO THỊ THANH THẢO	01/11/2008	Nữ	Kinh		t	12B6				2026-03-26 02:05:01.444+00	2025-2026		TDP 9 - Chư Ty - Đức Cơ - Gia lai
7afbc2dc-bd6a-4fcc-b48e-7a87f28b1dec	Đinh Thị Trúc Linh	11/09/2008	Nữ	Kinh		t	12B9				2026-03-26 02:05:03.847+00	2025-2026	HK2	TDP3, xã Đức Cơ - Gia Lai
fea6b89b-71fd-4031-bddc-2007e6e95b82	Phan Bảo Trâm	11/12/2008	Nữ	Kinh		t	12B9				2026-03-26 02:08:03.817+00	2025-2026	HK2	Tổ dân phố 3 - xã Đức Cơ - Gia Lai
50e22537-3dac-4c07-9451-3041a3e6e009	Phạm Thành Đạt	2008-04-11	Nam	Kinh		t	12B2				2026-03-26 02:12:07.131+00	2025-2026	HK2	Tổ Dân Phố 6, Xã Đức Cơ, Tỉnh Gia Lai
78efc992-8679-4f5b-8af3-c9c54a596aa2	Phan Thị Kiều Vy	2008-04-03	Nữ	Kinh		f	12B2				2026-03-26 02:12:35.226+00	2025-2026	HK2	TỔ DÂN PHỐ 2, Xã Đức Cơ, Tỉnh Gia Lai
f3744194-6c47-4042-a33a-015d40093649	Hồ Nguyễn Khánh Ly	21/07/2008	Nữ	Kinh		f	12B7				2026-03-28 05:18:57.996+00	2025-2026		Thôn Đoàn kết, Xã Ia Dơk,  Tỉnh Gia Lai
3dccb7ad-7e97-4961-bff3-48629141ce1a	Đỗ Công Tuấn	2008-02-06	Nam	Kinh		t	12B1	2025-04-22	0987802574		2026-03-26 13:05:30.157+00	2025-2026		Tổ 6 -Xã Đức Cơ - Tỉnh Gia Lai
6d5355ac-0641-4002-8f5a-6bb8454fb456	Hoàng Văn Phúc	2008-01-14	Nam	Kinh		t	12B1	2023-03-26	0376083663		2026-03-26 13:08:35.559+00	2025-2026		Thôn Thanh Tân - Xã Ia Krêl - Tỉnh Gia Lai
\.


--
-- Data for Name: namhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."namhoc" ("id", "tenNamHoc", "tenHocKy", "isDefault", "isLocked", "updatedAt") FROM stdin;
e27632bc-c3ce-41fa-97c8-f525e02b0376	2025-2026	HK2	t	f	2026-03-20 07:58:43.861+00
\.


--
-- Data for Name: phancong; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phancong" ("id", "hocKy", "tuan", "lopCham", "chamLop", "updatedAt", "namHoc") FROM stdin;
bb5c2702-2a81-40a2-ba37-b1eba7bb82f0	HK2	27	11C1	10A7	2026-03-25 14:46:46.627+00	2025-2026
9e533e70-f867-44c6-8640-6b10b8eeb6d5	HK2	27	11C2	10A8	2026-03-25 14:46:46.944+00	2025-2026
0e5ace42-ab3c-473a-bbdf-14b18f8754f8	HK2	27	11C3	10A9	2026-03-25 14:46:47.14+00	2025-2026
38b01720-a1a6-463f-99b7-9d0e89246fb7	HK2	27	11C4	10A10	2026-03-25 14:46:47.328+00	2025-2026
e8da959f-4d36-4104-95a7-2122b987851d	HK2	27	11C5	10A11	2026-03-25 14:46:47.518+00	2025-2026
df455d4f-97e7-4c3f-956d-b9b70953ba15	HK2	27	10A1	11C1	2026-03-25 14:46:47.701+00	2025-2026
de5b3485-2fa2-45d1-9439-55b383ee82b6	HK2	27	10A2	11C2	2026-03-25 14:46:47.895+00	2025-2026
bc517942-7cde-4fc1-9c56-ebd98054df19	HK2	27	10A3	11C3	2026-03-25 14:46:48.082+00	2025-2026
ac4a8d51-14f2-41cd-9508-2c98fae21bd7	HK2	27	10A4	11C4	2026-03-25 14:46:48.321+00	2025-2026
bceb8311-6abc-481a-83a4-f49f0d10bcd2	HK2	27	10A5	11C5	2026-03-25 14:46:48.501+00	2025-2026
481e4d55-5e36-42e1-81a9-7c6211f3a3ea	HK2	27	10A6	10A1	2026-03-25 14:46:48.671+00	2025-2026
1991d755-41ce-424e-ae6b-7bfdd4c1ea27	HK2	27	10A7	10A2	2026-03-25 14:46:48.844+00	2025-2026
0557026c-8385-472f-aa2d-c9dce2d05a83	HK2	27	10A8	10A3	2026-03-25 14:46:49.023+00	2025-2026
3c81ba3e-8721-491f-b1be-5d7bebfd513f	HK2	27	10A9	10A4	2026-03-25 14:46:49.243+00	2025-2026
36625db1-0b4b-47a7-8d7b-2e49708e1609	HK2	27	10A10	10A5	2026-03-25 14:46:49.42+00	2025-2026
fdca07bb-ba61-4a1e-8c5e-4ad3f3ce0df1	HK2	27	10A11	10A6	2026-03-25 14:46:49.6+00	2025-2026
078da010-b383-401b-9eae-982c6264ab23	HK2	27	11C6	12B4	2026-03-26 02:18:20.819+00	2025-2026
ece411df-7a11-403c-987f-e76c59b94f8c	HK2	27	11C7	12B5	2026-03-26 02:18:21.422+00	2025-2026
5ca01b7c-6691-447e-ad0c-6cde7d4ce23a	HK2	27	11C8	12B6	2026-03-26 02:18:21.609+00	2025-2026
b266e588-1a76-4cf5-9514-9f90193bef26	HK2	27	11C9	12B7	2026-03-26 02:18:21.829+00	2025-2026
29eb0f69-2e13-41cf-9476-adb21ff91b64	HK2	27	11C10	12B8	2026-03-26 02:18:22.037+00	2025-2026
6c9a3ffc-7f3f-4b44-ab85-ea1d2a26bffe	HK2	27	11C11	12B9	2026-03-26 02:18:22.241+00	2025-2026
b7f5c2b0-676f-438c-937d-5da6311fb580	HK2	27	11C12	12B10	2026-03-26 02:18:22.444+00	2025-2026
bc8d7884-b1aa-4935-a716-f8caf07e1764	HK2	27	12B1	11C6	2026-03-26 02:18:22.651+00	2025-2026
4ff135da-825d-47fa-9880-a87a0dd06b0c	HK2	27	12B2	11C7	2026-03-26 02:18:22.819+00	2025-2026
0383df8b-8770-4b76-9d02-620fffd3ad27	HK2	27	12B3	11C8	2026-03-26 02:18:23.139+00	2025-2026
f926724d-cdd1-4bf1-bfe6-9ab1ef9b23bd	HK2	27	12B4	11C9	2026-03-26 02:18:23.446+00	2025-2026
615163ed-aa6c-40e5-a299-bf4b459eb21b	HK2	27	12B5	11C10	2026-03-26 02:18:23.674+00	2025-2026
57bfd07c-f5c5-46a2-bcf4-5889b2f4c2a4	HK2	27	12B6	11C11	2026-03-26 02:18:23.879+00	2025-2026
742ce10f-a0cc-49e7-9ccf-1c7f0173acce	HK2	27	12B7	11C12	2026-03-26 02:18:24.081+00	2025-2026
ec4bcf52-fe1c-4e12-bca4-1e1c13b83266	HK2	27	12B8	12B1	2026-03-26 02:18:24.253+00	2025-2026
4b573d32-a90a-41f1-b6fa-70524b00dc8f	HK2	27	12B9	12B2	2026-03-26 02:18:24.437+00	2025-2026
bbc6df07-0fcc-4ad7-b138-9ce0ec80349f	HK2	27	12B10	12B3	2026-03-26 02:18:24.598+00	2025-2026
02748f05-c38c-47bd-91e3-f3d5653a31ea	HK2	28	10A1	11C2	2026-03-29 10:44:26.966+00	2025-2026
59dbe054-3336-4580-a6ca-b8669f7b0f3d	HK2	28	10A2	11C3	2026-03-29 10:44:27.336+00	2025-2026
5ec3794b-673e-4632-b354-5eba8eead2b6	HK2	28	10A3	11C4	2026-03-29 10:44:27.528+00	2025-2026
f85c9aa6-d037-4716-a346-e6606ac3d892	HK2	28	10A4	11C5	2026-03-29 10:44:27.728+00	2025-2026
67253054-bc90-4dca-bf7d-f99b40ada2ae	HK2	28	10A5	10A1	2026-03-29 10:44:28.119+00	2025-2026
8cca6b48-9bad-4d83-8516-5ad26adefa97	HK2	28	10A6	10A2	2026-03-29 10:44:28.333+00	2025-2026
fcb539a4-76eb-4a4a-af69-19fe13cc6e21	HK2	28	10A7	10A3	2026-03-29 10:44:28.542+00	2025-2026
8b6dc77e-7e94-44a9-a5ae-d25b8716695e	HK2	28	10A8	10A4	2026-03-29 10:44:28.756+00	2025-2026
9ffb3c93-3ab8-4ba4-95b2-f36af1c3c970	HK2	28	10A9	10A5	2026-03-29 10:44:28.945+00	2025-2026
0671edf8-b2d8-4695-91bf-41810404b8ab	HK2	28	10A10	10A6	2026-03-29 10:44:29.143+00	2025-2026
54cf218d-2ea1-4d66-aa31-417dd092fc1e	HK2	28	10A11	10A7	2026-03-29 10:44:29.343+00	2025-2026
6d8cf27c-24f1-40ed-ba79-5b88624b9483	HK2	28	11C1	10A8	2026-03-29 10:44:29.55+00	2025-2026
953b3bad-44a9-442a-9be6-754741092d80	HK2	28	11C2	10A9	2026-03-29 10:44:29.935+00	2025-2026
4ac91c11-2b66-4a7f-8106-df5f5c7b25d6	HK2	28	11C3	10A10	2026-03-29 10:44:30.149+00	2025-2026
f1a6e2ea-87a7-4467-9f01-3c1644c2320b	HK2	28	11C4	10A11	2026-03-29 10:44:30.521+00	2025-2026
4bbc84a4-f786-4215-b6e8-9a6d7f4d1737	HK2	28	11C5	11C1	2026-03-29 10:44:30.739+00	2025-2026
44770d99-cdca-4c38-a4fa-9bdf51a30727	HK2	28	11C6	12B5	2026-03-29 10:44:30.936+00	2025-2026
31c85b0e-a7a9-434a-a785-cb4477dd8b79	HK2	28	11C7	12B6	2026-03-29 10:44:31.202+00	2025-2026
2dc4612d-19c1-48d2-9d62-9a035f2c965d	HK2	28	11C8	12B7	2026-03-29 10:44:31.566+00	2025-2026
1b5dd9af-5774-4d07-ad5b-6c99df6d5860	HK2	28	11C9	12B8	2026-03-29 10:44:31.773+00	2025-2026
64bef5f3-7e55-4aa7-8305-ba16db758eb6	HK2	28	11C10	12B9	2026-03-29 10:44:31.97+00	2025-2026
ac4cab6a-aff7-4a9f-8859-691c3d65fd25	HK2	28	11C11	12B10	2026-03-29 10:44:32.165+00	2025-2026
f37e6cfa-4a2f-467f-a41d-a9ef1e5c1678	HK2	28	11C12	11C6	2026-03-29 10:44:32.364+00	2025-2026
481a7215-e0b6-41ec-b270-7218f4378c4c	HK2	28	12B1	11C7	2026-03-29 10:44:32.548+00	2025-2026
c5f6ea31-e9ff-4289-a8a9-95d83245e5a0	HK2	28	12B2	11C8	2026-03-29 10:44:32.712+00	2025-2026
55fef829-2f44-4f1e-aec7-48c8e82ae397	HK2	28	12B3	11C9	2026-03-29 10:44:32.883+00	2025-2026
20f133fb-5124-4145-a20f-615af31e3b30	HK2	28	12B4	11C10	2026-03-29 10:44:33.087+00	2025-2026
a35dd308-3271-4ae9-af33-582f6e41fef7	HK2	28	12B5	11C11	2026-03-29 10:44:33.276+00	2025-2026
ac3a6848-8183-4ece-a49e-865a916dbc6b	HK2	28	12B6	11C12	2026-03-29 10:44:33.47+00	2025-2026
ebe970bf-93a2-48f3-8e4e-399c3693b9a8	HK2	28	12B7	12B1	2026-03-29 10:44:33.68+00	2025-2026
8c02a5b7-31a8-430a-b690-7335e883a08f	HK2	28	12B8	12B2	2026-03-29 10:44:33.894+00	2025-2026
f97fe684-3472-4389-a573-1dc324aa6ae5	HK2	28	12B9	12B3	2026-03-29 10:44:34.092+00	2025-2026
6be6cd60-a603-4742-b663-9bfbefba5a8b	HK2	28	12B10	12B4	2026-03-29 10:44:34.293+00	2025-2026
81446360-cd6b-4fab-a330-a1718e749123	HK2	29	10A1	11C3	2026-03-29 10:44:34.489+00	2025-2026
9bc1f151-b903-4fe8-9674-b83b6fb6e6ad	HK2	29	10A2	11C4	2026-03-29 10:44:34.698+00	2025-2026
bb11a8ee-f00f-4017-a3dc-7e39e09fb9b8	HK2	29	10A3	11C5	2026-03-29 10:44:34.899+00	2025-2026
d3ec304d-1797-43cc-b9e8-056aac08a7d1	HK2	29	10A4	10A1	2026-03-29 10:44:35.102+00	2025-2026
c17cd7d2-bd8e-4d6a-b301-b95af81f5246	HK2	29	10A5	10A2	2026-03-29 10:44:35.939+00	2025-2026
a1c9314c-690c-4b5b-a60f-757bdf1951e3	HK2	29	10A6	10A3	2026-03-29 10:44:36.154+00	2025-2026
28d6bdad-7ba1-492c-bf9a-de8954cadc4d	HK2	29	10A7	10A4	2026-03-29 10:44:36.392+00	2025-2026
e88f0302-3c1a-4c60-b1ae-ef684ccf1ae6	HK2	29	10A8	10A5	2026-03-29 10:44:36.595+00	2025-2026
732aa77c-c5e8-40f2-8c84-1b2a977843b2	HK2	29	10A9	10A6	2026-03-29 10:44:36.811+00	2025-2026
7f25ac4f-30b4-4801-af5e-a6160482c610	HK2	29	10A10	10A7	2026-03-29 10:44:37.002+00	2025-2026
43bfeb37-df0e-49ca-8ad0-6a9e7cb81ca4	HK2	29	10A11	10A8	2026-03-29 10:44:37.269+00	2025-2026
e7ffcfb0-a65f-4ccb-9856-af8a70b6de40	HK2	29	11C1	10A9	2026-03-29 10:44:37.461+00	2025-2026
42232b6f-4fbc-415e-8adc-726c7a48824a	HK2	29	11C2	10A10	2026-03-29 10:44:37.644+00	2025-2026
f5126777-056b-4bfa-96a3-6acc1b38bfb7	HK2	29	11C3	10A11	2026-03-29 10:44:37.842+00	2025-2026
27359b91-ee1d-45ff-8f9a-ed6370442352	HK2	29	11C4	11C1	2026-03-29 10:44:38.034+00	2025-2026
cd6090ad-9647-45c1-b3f6-426bb9d7ab9b	HK2	29	11C5	11C2	2026-03-29 10:44:38.215+00	2025-2026
919e0683-de9e-42e0-bb70-f4ff0f850dcf	HK2	29	12B1	11C8	2026-03-29 10:44:39.833+00	2025-2026
196f525e-c627-4ea0-b3a9-e98ebdc605e2	HK2	29	12B9	12B4	2026-03-29 10:44:41.439+00	2025-2026
675df3c8-76f1-421b-875f-07717d229427	HK2	30	10A7	10A5	2026-03-29 10:44:43.07+00	2025-2026
1c6f4666-ba1a-46a7-a349-f264601072e4	HK2	30	11C4	11C2	2026-03-29 10:44:44.857+00	2025-2026
e94a8550-1b3b-42ec-9218-0a20e2721b50	HK2	30	11C12	11C8	2026-03-29 10:44:46.493+00	2025-2026
60fa19c8-5dcd-4f19-81a1-0b74401ba5c5	HK2	30	12B8	12B4	2026-03-29 10:44:48.195+00	2025-2026
ef2042ef-4ddd-47fb-81ed-8fd58678d773	HK2	29	11C6	12B6	2026-03-29 10:44:38.406+00	2025-2026
7ada613d-6989-45b5-82c8-aff2d0535a2a	HK2	29	12B2	11C9	2026-03-29 10:44:40.053+00	2025-2026
221ecfb9-d2cd-4a6d-a53c-91266a0b7729	HK2	29	12B10	12B5	2026-03-29 10:44:41.634+00	2025-2026
43eff2d0-6002-4915-b033-86e46b7d7d3b	HK2	30	10A8	10A6	2026-03-29 10:44:43.458+00	2025-2026
f9f1939a-ad19-4366-99a7-79ab8e35634a	HK2	30	11C5	11C3	2026-03-29 10:44:45.061+00	2025-2026
b7db7fb0-1962-414e-9580-94988262ba92	HK2	30	12B1	11C9	2026-03-29 10:44:46.711+00	2025-2026
545f6a77-cb03-4508-bc2d-d0c3298d7c98	HK2	30	12B9	12B5	2026-03-29 10:44:48.394+00	2025-2026
8e5f3d54-b670-415d-b9a5-81d063fd6738	HK2	29	11C7	12B7	2026-03-29 10:44:38.599+00	2025-2026
4df3ccab-fb29-48b4-a6ea-bef153d0c252	HK2	29	12B3	11C10	2026-03-29 10:44:40.261+00	2025-2026
0261d904-cf5b-4140-a4ce-9a377d61f390	HK2	30	10A1	11C4	2026-03-29 10:44:41.845+00	2025-2026
e6f85743-8e41-4662-a1b9-b26ee638b1cf	HK2	30	10A9	10A7	2026-03-29 10:44:43.68+00	2025-2026
5714480b-b780-4b7d-9311-92d9df3d7600	HK2	30	11C6	12B7	2026-03-29 10:44:45.276+00	2025-2026
18087244-6311-41c5-9e41-73b7467ae886	HK2	30	12B2	11C10	2026-03-29 10:44:46.961+00	2025-2026
9570d482-dcd9-447c-8730-9e7e1a75200f	HK2	30	12B10	12B6	2026-03-29 10:44:49.006+00	2025-2026
95b4b861-a408-48d0-b9f4-39152c232c76	HK2	29	11C8	12B8	2026-03-29 10:44:38.814+00	2025-2026
f6901942-d4d7-41b5-bb13-7e7d028c20ff	HK2	29	12B4	11C11	2026-03-29 10:44:40.473+00	2025-2026
814fce1c-7fed-4e58-a569-d1ddf4e6eca9	HK2	30	10A2	11C5	2026-03-29 10:44:42.077+00	2025-2026
7a9ea911-8823-4875-8a80-722d479b8239	HK2	30	10A10	10A8	2026-03-29 10:44:43.882+00	2025-2026
00791d60-20e7-4b75-8558-c60c7d89f1a3	HK2	30	11C7	12B8	2026-03-29 10:44:45.472+00	2025-2026
6adcecea-c6ff-4262-ba3c-399374cf9737	HK2	30	12B3	11C11	2026-03-29 10:44:47.162+00	2025-2026
c96679aa-aa87-4502-b1d4-0ddba76e00f6	HK2	29	11C9	12B9	2026-03-29 10:44:39.025+00	2025-2026
2f6d2879-fd7a-4ca8-a914-43aca1b117e1	HK2	29	12B5	11C12	2026-03-29 10:44:40.663+00	2025-2026
fbf65c1d-d1c9-4e07-bd3f-c0be4395dbf5	HK2	30	10A3	10A1	2026-03-29 10:44:42.272+00	2025-2026
b216e7d4-e78f-440c-aa98-f88671d76ef8	HK2	30	10A11	10A9	2026-03-29 10:44:44.067+00	2025-2026
86a8976d-c7bc-4167-b515-456576035f75	HK2	30	11C8	12B9	2026-03-29 10:44:45.68+00	2025-2026
5efb3b65-6139-442c-80f4-5671089077f6	HK2	30	12B4	11C12	2026-03-29 10:44:47.376+00	2025-2026
a4880666-4d49-4e9e-b754-ddb469fe394a	HK2	29	11C10	12B10	2026-03-29 10:44:39.217+00	2025-2026
6804dc11-7b3c-41f1-a086-d82ef704f30a	HK2	29	12B6	12B1	2026-03-29 10:44:40.862+00	2025-2026
341f2131-425d-46f2-9785-79b8b80b992b	HK2	30	10A4	10A2	2026-03-29 10:44:42.461+00	2025-2026
7cefbe6b-7918-498c-91a2-ae09f55a04e1	HK2	30	11C1	10A10	2026-03-29 10:44:44.264+00	2025-2026
5b97da3e-1622-44f9-8c13-86925b7c4131	HK2	30	11C9	12B10	2026-03-29 10:44:45.888+00	2025-2026
69ab4d88-2025-4bfc-810e-c947237d1728	HK2	30	12B5	12B1	2026-03-29 10:44:47.578+00	2025-2026
7b7aa57b-9813-4b02-8696-76ce83f7da82	HK2	29	11C11	11C6	2026-03-29 10:44:39.427+00	2025-2026
fecd5559-0313-490b-8874-584a31fcb435	HK2	29	12B7	12B2	2026-03-29 10:44:41.057+00	2025-2026
a6e4e706-4173-4a90-b8eb-e8d58d12a286	HK2	30	10A5	10A3	2026-03-29 10:44:42.659+00	2025-2026
3c7f927a-c872-412f-8f53-87960dd27331	HK2	30	11C2	10A11	2026-03-29 10:44:44.45+00	2025-2026
66f0a314-c9af-4c31-ba79-fd841057ad5c	HK2	30	11C10	11C6	2026-03-29 10:44:46.08+00	2025-2026
8becd255-c7ef-4a62-b0c6-66dd56ac974a	HK2	30	12B6	12B2	2026-03-29 10:44:47.789+00	2025-2026
e3813d85-3273-4fa1-8cc3-1852d3bdddd8	HK2	29	11C12	11C7	2026-03-29 10:44:39.633+00	2025-2026
e668ec0c-6f96-44a6-8b0d-fdb901670672	HK2	29	12B8	12B3	2026-03-29 10:44:41.251+00	2025-2026
33346540-09e3-40bf-9d7b-a6f2c08e8262	HK2	30	10A6	10A4	2026-03-29 10:44:42.854+00	2025-2026
907765bf-4251-43fb-86e2-324cd5511e67	HK2	30	11C3	11C1	2026-03-29 10:44:44.651+00	2025-2026
a49a824d-1793-4981-8b88-1c140b60a35f	HK2	30	11C11	11C7	2026-03-29 10:44:46.289+00	2025-2026
28625c45-c11d-4f1b-ba07-80c6ca64f6ed	HK2	30	12B7	12B3	2026-03-29 10:44:47.999+00	2025-2026
\.


--
-- Data for Name: phanquyen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."phanquyen" ("id", "doi_tuong", "tab_chuc_nang", "quyen_xem", "quyen_them", "quyen_sua", "quyen_xoa", "quyen_chi_doan_phu_trach", "ngay_cap_nhat", "nam_hoc", "quyen_xem_tat_ca_chi_doan") FROM stdin;
75	BT	baocao	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
76	DV	qlchidoan	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
70	BT	doanvien	t	t	t	t	t	2026-03-31 09:09:55.889+00	2025-2026	\N
71	BT	tieuchitd	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
72	BT	phancong	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
73	BT	chamdiem	t	t	t	t	t	2026-03-31 09:09:55.889+00	2025-2026	t
74	BT	namtuan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
1519	BGH	qlchidoan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	f
63	GVCN	doanvien	t	f	f	f	t	2026-03-31 09:09:55.889+00	2025-2026	\N
77	DV	doanvien	t	f	f	f	t	2026-03-31 09:09:55.889+00	2025-2026	\N
79	DV	baocao	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
80	DV	tieuchitd	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
171	BT	cauhinh	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
172	BT	trogiup	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
19	BTV	chamdiem	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
20	BTV	namtuan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
21	BTV	baocao	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
22	BTV	cauhinh	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
23	BTV	trogiup	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
14	BTV	qlchidoan	t	f	t	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
47	BGH	doanvien	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
48	BGH	tieuchitd	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
49	BGH	chamdiem	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
50	BGH	namtuan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
51	BGH	baocao	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
52	BCH	qlchidoan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
53	BCH	taikhoan	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
54	BCH	doanvien	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
55	BCH	tieuchitd	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
56	BCH	phancong	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
57	BCH	chamdiem	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
58	BCH	namtuan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
59	BCH	baocao	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
60	BCH	cauhinh	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
267	BGH	phancong	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
268	BGH	trogiup	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
269	GVCN	trogiup	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
15	BTV	taikhoan	f	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
16	BTV	doanvien	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
17	BTV	tieuchitd	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
18	BTV	phancong	t	t	t	t	f	2026-03-31 09:09:55.889+00	2025-2026	\N
61	BCH	trogiup	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
62	GVCN	qlchidoan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
64	GVCN	tieuchitd	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
65	GVCN	phancong	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
66	GVCN	chamdiem	t	f	f	f	t	2026-03-31 09:09:55.889+00	2025-2026	\N
67	GVCN	namtuan	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
68	GVCN	baocao	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	\N
69	BT	qlchidoan	t	f	t	f	t	2026-03-31 09:09:55.889+00	2025-2026	\N
78	DV	chamdiem	t	f	f	f	t	2026-03-31 09:09:55.889+00	2025-2026	\N
1620	DV	trogiup	t	f	f	f	f	2026-03-31 09:09:55.889+00	2025-2026	f
\.


--
-- Data for Name: qlchidoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."qlchidoan" ("id", "tenchidoan", "buoiHoc", "ban", "doanvien", "thanhnien", "tongso", "phonghoc", "bithu", "thongtinthem", "namHoc", "updatedAt", "hocKy") FROM stdin;
33250f94-6931-47dd-ac2f-bb4e8a5535b1	12B7	Sáng	XH	0	0	0	14	Trần Lê Ngọc Khánh		2025-2026	2026-03-26 02:07:00.431+00	HK1
61a554f0-87f5-4dbd-a152-22cebed82925	11C9	Sáng	XH	0	0	0	4			2025-2026	2026-03-23 13:44:53.524+00	HK1
b43602fc-3d2e-48a1-b281-4fa1b7aabef9	10A10	Chiều	XH	0	0	0	5	Hồ Thị Ngọc Trâm 		2025-2026	2026-03-26 01:50:54.926+00	HK1
159008c5-8420-44ac-a23f-ec704a3be66a	10A1	Chiều	TN	0	0	0	11			2025-2026	2026-03-25 14:30:33.788+00	HK1
87881984-264c-4c97-b336-69ef0999dd67	10A11	Chiều	XH	0	0	0	6			2025-2026	2026-03-25 14:31:12.568+00	HK1
84ee092b-3b6d-48aa-8324-f4eafda5b546	12B8	Sáng	XH	0	0	0	15	Quế Trân		2025-2026	2026-03-26 01:53:47.778+00	HK1
5ef21e40-6b45-40d8-a24d-6bee8c1f432c	11C10	Sáng	XH	0	0	0	5	Nguyễn Ngọc Tiên Nhi		2025-2026	2026-03-27 01:01:52.847+00	HK1
f7501580-cc9c-41c9-a00d-0f8c54c13bcb	11C1	Chiều	TN	0	0	0	12	Lê Minh Phương		2025-2026	2026-03-23 13:44:52.019+00	HK1
539248e4-4825-42e2-b5e1-52dd70ae3fba	12B9	Sáng	XH	0	0	0	16	Thành Tín		2025-2026	2026-03-26 01:51:51.215+00	HK1
fc4eb2ca-e3d5-4b57-8d93-0fd0f8587bfa	11C11	Sáng	XH	0	0	0	6	Bùi Thị Tường Vy		2025-2026	2026-03-26 02:00:39.26+00	HK1
36c971e3-f482-4703-a4fb-f3bff27485a1	10A2	Chiều	TN	0	0	0	10	Lê Hồ Hoài An		2025-2026	2026-03-26 02:00:52.494+00	HK1
44722561-7fa7-44ef-9a26-cdfeb098934f	12B10	Sáng	XH	0	0	0	17	Lê Tiến Công		2025-2026	2026-03-26 02:03:02.639+00	HK1
325ddee6-e5ad-47d5-8351-b12c1eb67acc	11C2	Chiều	TN	0	0	0	13	Nguyễn Thị Yến Nhi		2025-2026	2026-03-26 02:00:44.046+00	HK1
450ff56c-ab21-4927-a712-9e9e155646b7	11C12	Sáng	XH	0	0	0	7	Nguyễn Thị Ngọc Hân	\n	2025-2026	2026-03-26 02:00:43.495+00	HK1
13de192b-9820-42b1-9075-8354dc992675	10A3	Chiều	TN	0	0	0	9	Nguyễn Thị Trâm Anh		2025-2026	2026-03-26 02:00:58.164+00	HK1
8f89e1c2-c38c-45a6-9dad-b4fdde2153c3	12B1	Sáng	TN	0	0	0	8	Phạm Ngọc Gia Hân		2025-2026	2026-03-26 02:00:23.574+00	HK1
09d8ade5-bb92-46ab-98e7-3ab869d59f75	10A4	Chiều	TN	0	0	0	8	Phạm Hà Anh		2025-2026	2026-03-26 02:00:28.616+00	HK1
fdc18dde-9e98-4ceb-831f-2944f68998d4	11C3	Chiều	TN	0	0	0	14	Phạm Minh Anh		2025-2026	2026-03-26 02:00:39.592+00	HK1
65560ab5-035b-496a-9133-a50d9bf0a0d0	10A5	Chiều	XH	0	0	0	7			2025-2026	2026-03-25 14:31:04.437+00	HK1
c9981426-89cd-4565-8c8e-5f1119f30018	12B2	Sáng	TN	0	0	0	9	Hoàng Thị Thu Huyền		2025-2026	2026-03-26 02:01:29.419+00	HK1
b7b2f041-de5d-49db-8186-5dd8db250052	11C4	Chiều	TN	0	0	0	15	Cù Hoàng Gia An		2025-2026	2026-03-31 03:26:24.158+00	HK1
93ed547c-5b97-49e5-be05-b64ade9a6586	12B3	Sáng	TN	0	0	0	10			2025-2026	2026-03-23 13:44:54.519+00	HK1
846cdc56-d3b7-494e-b805-6e584dcd9392	10A6	Chiều	XH	0	0	0	1			2025-2026	2026-03-25 14:35:27.61+00	HK1
25d78477-f93d-401d-85b3-3a39ba2e83e7	11C5	Chiều	TN	0	0	0	16			2025-2026	2026-03-26 01:59:44.84+00	HK1
fce39a4b-0928-4944-b3bf-d8efe09ddaf3	12B4	Sáng	TN	0	0	0	11			2025-2026	2026-03-23 13:44:54.703+00	HK1
1d712008-dda7-4791-8b18-a2078c091830	11C6	Sáng	XH	0	0	0	1	Vũ Đỗ Thùy Lâm	31 Đoàn Viên ; 50 Thanh niên	2025-2026	2026-03-27 13:08:47.079+00	HK1
141be337-7bb7-4d92-bd8e-21330ef7702f	10A7	Chiều	XH	0	0	0	2	Phạm Khánh Chi		2025-2026	2026-03-26 02:00:31.468+00	HK1
02180031-0a4d-4aa7-b43b-0d3549779653	10A8	Chiều	XH	0	0	0	3			2025-2026	2026-03-25 14:35:12.401+00	HK1
642e5a53-7b49-4a42-8e3b-bd59a55fe4c8	12B5	Sáng	XH	0	0	0	12	Hoàng Thị Quỳnh Chi		2025-2026	2026-03-26 02:01:34.76+00	HK1
0c673b7d-6199-4fbd-b3ce-5a11324113b6	11C7	Sáng	XH	0	0	0	2	nguyễn hồng lai		2025-2026	2026-03-26 02:03:06.395+00	HK1
6d3e0c06-4ed8-460c-8ebc-67ade36f0276	11C8	Sáng	XH	0	0	0	3	Nguyễn Trung Hiếu 		2025-2026	2026-03-26 02:02:26.289+00	HK1
1c86cf6e-19bd-42ea-8cb0-8137cb63988a	12B6	Sáng	XH	0	0	0	13	Nguyễn Thanh Phương		2025-2026	2026-03-23 13:44:55.061+00	HK1
5d2969a5-0d68-4845-bcab-407f002e89b1	10A9	Chiều	XH	0	0	0	4			2025-2026	2026-03-25 14:35:05.657+00	HK1
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."settings" ("id", "title1", "title2", "diemSan", "aiPromptTemplate", "geminiapikey", "backupinterval", "lastbackupat") FROM stdin;
e9927605-e6b1-4173-87d2-443524dd8c98	Hệ thống quản lý điểm thi đua	Đoàn trường THPT Lê Hoàn	300	\N	AIzaSyCAQpi797lChw7ys_E_EO5EnvGkltrz55g	0	2026-03-25T22:39:00.140Z
\.


--
-- Data for Name: taikhoan; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."taikhoan" ("id", "username", "password", "fullName", "role", "chiDoan", "updatedAt", "namHoc") FROM stdin;
c9888d18-4209-43cd-8a33-c9f1383d02ac	ksorh’lea	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H’ Lê A	DV	10A7	2026-03-30 22:13:23.908+00	2025-2026
3c79c3df-6d25-4aba-86fa-aed8008dafab	rolankima	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Kim A	DV	10A9	2026-03-30 22:13:23.908+00	2025-2026
e4c01add-af77-43e0-b5aa-e2a75f31fb2a	donguyenthienai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Nguyễn Thiên Ái	DV	11C7	2026-03-30 22:13:23.908+00	2025-2026
6a69fe32-fd3d-4523-91a7-8a20cdcc040c	cuhoanggiaan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cù Hoàng Gia An	DV	11C4	2026-03-30 22:13:23.908+00	2025-2026
88ef0636-97f4-4852-87c9-58eb6d9732af	duongbinhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Bình An	DV	10A9	2026-03-30 22:13:23.908+00	2025-2026
63f1c2c0-84e1-4d9c-b985-89d8f7cb76fa	doanthingocan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Thị Ngọc An	DV	10A7	2026-03-30 22:13:23.908+00	2025-2026
a1ec383c-bb7f-407f-886b-97528299b5c6	hohuuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu An	DV	12B9	2026-03-30 22:13:23.909+00	2025-2026
c94e5cbd-0b15-4123-87fd-70b70c6fa2bc	hovanan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Văn An	DV	12B9	2026-03-30 22:13:23.909+00	2025-2026
5ff364b7-d036-4394-8bce-231e28d0dfff	hoxuanan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Xuân An	DV	10A3	2026-03-30 22:13:23.909+00	2025-2026
63ad5816-f3ab-4f83-a9d3-a4787512ba57	lehohoaian	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hồ Hoài An	DV	10A2	2026-03-30 22:13:23.909+00	2025-2026
8111a173-e821-40aa-be6c-16cdd6483a8d	lequangan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quang An	DV	12B2	2026-03-30 22:13:23.909+00	2025-2026
4585890f-06c4-40c2-8b6f-579978e99358	luongthilinhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Linh An	DV	11C8	2026-03-30 22:13:23.909+00	2025-2026
aae9cd74-b007-471a-9025-f6acd2546e85	nguyenhongan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồng An	DV	10A10	2026-03-30 22:13:23.909+00	2025-2026
77f1e486-7de0-47d0-8e2a-bee7f6f0df1e	nguyenngocan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc An	DV	12B1	2026-03-30 22:13:23.909+00	2025-2026
ea7dca4e-0a26-4d8c-82a6-ffc18ffe5f57	nguyentruongan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trường An	DV	10A3	2026-03-30 22:13:23.909+00	2025-2026
26ee3761-e997-4ee3-9d99-418dfee8abe6	tranthanhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thành An	DV	11C12	2026-03-30 22:13:23.909+00	2025-2026
eabfffd9-1706-4c81-bfa0-b8681232f912	duongnhuhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Như Hoàng Anh	DV	12B10	2026-03-30 22:13:23.909+00	2025-2026
dd881163-8345-423a-8ad1-05653f9dc9b4	damquynhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đàm Quỳnh Anh	DV	11C3	2026-03-30 22:13:23.909+00	2025-2026
a6a5a470-42af-451a-b3df-d7c1f17b784f	daoduyanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Duy Anh	DV	11C5	2026-03-30 22:13:23.909+00	2025-2026
02ae2e4f-7521-43df-bb05-1c7750b15df8	daoleminhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Lê Minh Anh	DV	11C4	2026-03-30 22:13:23.909+00	2025-2026
dae641da-2906-4f9e-9ef0-c4f67e753a1f	dautuananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đậu Tuấn Anh	DV	12B10	2026-03-30 22:13:23.909+00	2025-2026
554a713c-6ad7-4264-aa0a-6e14e5970a00	dinhducanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Đức Anh	DV	11C6	2026-03-30 22:13:23.909+00	2025-2026
a9870f12-020f-44ba-a827-e622ed6a3fbe	dinhhaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Hải Anh	DV	12B10	2026-03-30 22:13:23.909+00	2025-2026
e3680cec-ae17-4049-b827-2bc10506c8a0	dinhhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Hoàng Anh	DV	12B5	2026-03-30 22:13:23.909+00	2025-2026
0a10d73a-97d6-461e-b265-96b98e754f4b	dinhthingocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Ngọc Anh	DV	12B9	2026-03-30 22:13:23.909+00	2025-2026
a8fc031a-d7f1-4355-b92a-e097e3577463	dohanguyenanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Hạ Nguyên Anh	DV	11C6	2026-03-30 22:13:23.909+00	2025-2026
79d51ee5-9fef-481c-8d7f-d3864381a692	dovotuananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Võ Tuấn Anh	DV	12B4	2026-03-30 22:13:23.909+00	2025-2026
2fc5b6ab-b595-4773-87da-f8f5f895bfea	havinhhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Vĩnh Hoàng Anh	DV	11C5	2026-03-30 22:13:23.909+00	2025-2026
b608a963-90c2-4443-b3b4-2683bd95b7c1	hoangthikimanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Kim Ánh	DV	12B4	2026-03-30 22:13:23.909+00	2025-2026
2739f23b-2281-422a-ab5d-0f3d64e417cb	hoangvietanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Việt Anh	DV	12B5	2026-03-30 22:13:23.91+00	2025-2026
270fdb3a-3a40-4350-a1d6-f7e4b8c23bed	hongoctramanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Trâm Anh	DV	10A4	2026-03-30 22:13:23.91+00	2025-2026
54bdce65-6dd2-43f0-9858-6b8e6e3424dd	hoquynhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Quỳnh Anh	DV	11C5	2026-03-30 22:13:23.91+00	2025-2026
769f76a7-bbef-49e5-8ca6-becf82581747	hothilananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Lan Anh	DV	11C1	2026-03-30 22:13:23.91+00	2025-2026
fac301b6-4ea5-48e8-a9b8-66ec10f44329	hothinguyetanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Nguyệt Ánh	DV	10A11	2026-03-30 22:13:23.91+00	2025-2026
fcff16a0-61cb-4481-aa65-da50f91c51bb	huynhthingocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Thị Ngọc Anh	DV	10A3	2026-03-30 22:13:23.91+00	2025-2026
2ab64264-d929-455a-8625-09a156097e37	ksorh'hoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KSOR H' HOÀNG ANH	DV	12B6	2026-03-30 22:13:23.91+00	2025-2026
357cb4f8-f10e-40cb-928d-764ec390e56f	lecongngocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Công Ngọc Anh	DV	12B5	2026-03-30 22:13:23.91+00	2025-2026
78e2a03c-c8a1-4eb7-967a-3082c08dab3f	ledinhnamanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Nam Anh	DV	12B3	2026-03-30 22:13:23.91+00	2025-2026
4b6e2cad-d170-46fc-865e-39a1501678a2	lehoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hoàng Anh	DV	10A9	2026-03-30 22:13:23.91+00	2025-2026
271bb71f-4f01-486a-a5d2-e8a58cd02f06	leholananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hồ Lan Anh	DV	10A6	2026-03-30 22:13:23.91+00	2025-2026
03a7e52f-8ad7-4beb-aa19-62434b127af7	lekhatuananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Khả Tuấn Anh	DV	10A9	2026-03-30 22:13:23.91+00	2025-2026
92dcc256-6f5e-42f0-851e-edb509ffe076	lethihoaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hoài Anh	DV	10A2	2026-03-30 22:13:23.91+00	2025-2026
fc7140d0-141e-4e11-bf59-66b4dad26ec7	lethimaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Mai Anh	DV	10A6	2026-03-30 22:13:23.91+00	2025-2026
4f56bbe2-0afe-469b-a9cf-439f2d8e6d96	lethimaianh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Mai Anh	DV	10A11	2026-03-30 22:13:23.91+00	2025-2026
e455f50a-2c45-4e0c-be76-0a2d2705f974	lethithanhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thanh Ánh	DV	10A2	2026-03-30 22:13:23.91+00	2025-2026
01b46fb7-4318-443a-894b-cc860fcc7324	luonghaanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Hà Anh	DV	12B7	2026-03-30 22:13:23.91+00	2025-2026
3c965153-812f-48cc-bde0-b04b07ba3303	luongkimanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Kim Anh	DV	11C2	2026-03-30 22:13:23.91+00	2025-2026
02722842-33d6-432d-bd1c-04ee138beaf4	luongthihaanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Hà Anh	DV	10A6	2026-03-30 22:13:23.91+00	2025-2026
49b52e24-02e8-47c2-9eef-a886dfe267c9	luongthingocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Ngọc Ánh	DV	10A9	2026-03-30 22:13:23.91+00	2025-2026
05cc18af-e554-4dc7-b866-d5c7b2d582ce	lytramanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lý Trâm Anh	DV	12B3	2026-03-30 22:13:23.911+00	2025-2026
a5151cac-ee93-4aec-92a7-03f67b2bf4df	maquynhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mã Quỳnh Anh	DV	10A5	2026-03-30 22:13:23.911+00	2025-2026
68076460-b821-49c7-936f-e3ecf6aca3d7	nguyenhaanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hà Anh	DV	12B3	2026-03-30 22:13:23.911+00	2025-2026
6b5f8f50-e290-4cf4-a62b-fd9e828c8611	nguyenhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Anh	DV	12B1	2026-03-30 22:13:23.911+00	2025-2026
a9947a8c-ad33-4c56-aa1e-8868bac778bc	nguyenhoanganh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Anh	DV	12B5	2026-03-30 22:13:23.911+00	2025-2026
7dbe4a6d-ff20-4028-a983-7270689bbe80	nguyenhoquynhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồ Quỳnh Anh	DV	11C2	2026-03-30 22:13:23.911+00	2025-2026
812c105e-0742-4747-8e2a-2d5b2d842be1	nguyenkhacvietanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khắc Việt Anh	DV	11C4	2026-03-30 22:13:23.911+00	2025-2026
a5de7e30-f6ab-4eb2-89eb-32c560134612	nguyenmaiconganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Mai Công Anh	DV	11C1	2026-03-30 22:13:23.911+00	2025-2026
82e283c6-9099-4fc0-9cd8-bfd32530fd22	nguyenngananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngân Anh	DV	12B2	2026-03-30 22:13:23.911+00	2025-2026
c5b22745-75ce-4e4b-8581-9fd5cc7e6053	nguyenquanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Ánh	DV	10A2	2026-03-30 22:13:23.911+00	2025-2026
3963be36-3628-4dd3-a48c-1d8e2504bcbc	nguyenthimaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mai Anh	DV	10A5	2026-03-30 22:13:23.911+00	2025-2026
85294baa-59aa-4a7c-adf7-97397809fdd9	nguyenthingocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Anh	DV	11C2	2026-03-30 22:13:23.911+00	2025-2026
2e6f122c-3579-4fa8-b363-0a6d233a58b8	nguyenthingocanh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Anh	DV	12B7	2026-03-30 22:13:23.911+00	2025-2026
13a3568b-c78a-457c-a249-25048adcb5c5	nguyenthitramanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Trâm Anh	DV	10A3	2026-03-30 22:13:23.911+00	2025-2026
c5b31ab8-d55f-44d3-9264-4e9dae7385f3	nguyenthivananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Vân Anh	DV	11C7	2026-03-30 22:13:23.911+00	2025-2026
08544deb-9939-44d3-8a19-047813651e7a	nguyentuananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tuấn Anh	DV	10A2	2026-03-30 22:13:23.911+00	2025-2026
63d25386-dda8-4903-9128-91a2f37b9fbf	nguyentuananh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tuấn Anh	DV	12B1	2026-03-30 22:13:23.911+00	2025-2026
8de934ec-acee-429a-88ac-fb46caeb77c4	nguyenvuhaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Vũ Hải Anh	DV	11C10	2026-03-30 22:13:23.911+00	2025-2026
04af7d1b-eec4-4f43-a2fc-59c2cac8a8e7	nguyenxuananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Anh	DV	10A9	2026-03-30 22:13:23.911+00	2025-2026
06a72e68-efdd-4704-90c2-7695d1243dd6	phamduonganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Dương Anh	DV	10A1	2026-03-30 22:13:23.911+00	2025-2026
e31795e8-e81a-4fc0-85c4-c13fd946700a	phamdinhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Đình Ánh	DV	11C4	2026-03-30 22:13:23.911+00	2025-2026
ab83f8d2-ff45-4f00-9598-f37fdb7f06f7	phamhaanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Hà Anh	DV	10A4	2026-03-30 22:13:23.911+00	2025-2026
97a40f25-0ddc-4c31-844b-5054ab5caa24	phamminhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Minh Anh	DV	11C3	2026-03-30 22:13:23.911+00	2025-2026
332133d1-2881-4804-a06d-237a57f24ef7	phamnguyenvietanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Nguyễn Việt Anh	DV	11C5	2026-03-30 22:13:23.911+00	2025-2026
45112619-42f3-4d37-8c23-aed09ac4a301	phamthivananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	PHẠM THỊ VÂN ANH	DV	12B6	2026-03-30 22:13:23.911+00	2025-2026
b7f257e2-d98f-48c7-8993-0208a533dc83	phandinhhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Đình Hoàng Anh	DV	12B8	2026-03-30 22:13:23.911+00	2025-2026
78bda3a3-a497-4af2-9c2a-2f4fc518eca6	phanthingocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Ngọc Anh	DV	12B4	2026-03-30 22:13:23.911+00	2025-2026
6e70d820-7f0e-4a7b-b1eb-1cc40fc5744b	phantunganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Tùng Anh	DV	12B4	2026-03-30 22:13:23.911+00	2025-2026
518875f2-207d-4f62-95d6-095b9bf17296	rolananh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Anh	DV	10A9	2026-03-30 22:13:23.911+00	2025-2026
13a2c2a0-6720-4264-bbbf-83670ed68006	rolananh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Anh	DV	10A6	2026-03-30 22:13:23.911+00	2025-2026
4593aebd-d2ea-4644-ad0b-5290391cb460	trandinhhoanganh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đinh Hoàng Anh	DV	12B5	2026-03-30 22:13:23.911+00	2025-2026
0ab76383-32ae-479a-9c26-bddb5c0dc593	tranlengocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Lê Ngọc Anh	DV	11C9	2026-03-30 22:13:23.911+00	2025-2026
75d8f66d-e3ee-4422-9072-490d2b33d5ad	tranngocanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Ngọc Ánh	DV	12B10	2026-03-30 22:13:23.911+00	2025-2026
e74c93a3-e32a-4c0f-ad35-77ec7ef77810	trannguyenmaianh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Nguyễn Mai Anh	DV	11C9	2026-03-30 22:13:23.911+00	2025-2026
70a0e02f-26e5-41df-9996-ae5c2374e988	tranquynhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Quỳnh Anh	DV	10A2	2026-03-30 22:13:23.911+00	2025-2026
011248c6-6ea0-4856-85c9-84cac7cc93d5	vungocbaoanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Ngọc Bảo Anh	DV	10A8	2026-03-30 22:13:23.912+00	2025-2026
4bc1b9d5-7c78-4126-a674-cdcd6b66d775	vuthihaanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Hà Anh	DV	10A4	2026-03-30 22:13:23.912+00	2025-2026
4eb8f180-4cf3-463a-903d-ecdd719b309e	romahh'ayung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' AYưng	DV	12B10	2026-03-30 22:13:23.912+00	2025-2026
63524c52-1487-4541-a486-599652ef47c8	nguyengiaan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Gia Ân	DV	11C9	2026-03-30 22:13:23.912+00	2025-2026
30e7e1e2-c265-4a01-9db3-6893d40fe3ec	nguyenthihoaian	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hoài Ân	DV	11C1	2026-03-30 22:13:23.912+00	2025-2026
9ec21f45-d21f-41c9-8c04-9d5095ac76d7	rolanh'bach	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Bạch	DV	10A11	2026-03-30 22:13:23.912+00	2025-2026
f6bd9aea-003d-45af-bf4f-92fac3423e71	romahh'bach	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Bạch	DV	11C8	2026-03-30 22:13:23.912+00	2025-2026
5461d9dd-6430-4ebc-8f6f-06a09b745dd7	buiconggiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Công Gia Bảo	DV	11C2	2026-03-30 22:13:23.912+00	2025-2026
d40046ba-7627-4973-ba20-b958d2f203cb	buigiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Gia Bảo	DV	10A7	2026-03-30 22:13:23.912+00	2025-2026
5979e3e1-3295-4dbb-9090-fbb528aea541	caotrangiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Trần Gia Bảo	DV	10A11	2026-03-30 22:13:23.912+00	2025-2026
53b2d457-280a-48c3-b5fb-3936486ad886	duongvanbao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Văn Bảo	DV	12B7	2026-03-30 22:13:23.912+00	2025-2026
0ba5e1b2-0708-4f03-b60d-b1b0936deb13	danggiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Gia Bảo	DV	12B8	2026-03-30 22:13:23.912+00	2025-2026
58aeb09d-f61c-4611-ac87-6825c6b3b07f	dodinhbao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Đình Bảo	DV	11C6	2026-03-30 22:13:23.912+00	2025-2026
42ac5f0f-8e41-481f-9f7f-221262ae0170	haphamgiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Phạm Gia Bảo	DV	10A11	2026-03-30 22:13:23.912+00	2025-2026
05032bca-db52-4f4e-ab41-d408aef387c1	hoanggiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Gia Bảo	DV	12B8	2026-03-30 22:13:23.912+00	2025-2026
b5d58dd5-c281-4b0a-b4a9-37754c16f75a	huynhngocbao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Ngọc Bảo	DV	11C4	2026-03-30 22:13:23.912+00	2025-2026
17a4a315-48ee-4763-9606-c51d59eda7a7	rmahh'yuri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	R Mah H' Yu Ri	DV	11C8	2026-03-30 22:13:23.941+00	2025-2026
34d771d0-ff3e-4a25-aa39-04a0aa8801e5	romahyh’rila	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Y H’ RiLa	DV	10A6	2026-03-30 22:13:23.941+00	2025-2026
e001cc13-7cc3-4ba3-ad49-1897c9ab368f	rolanh’rubin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H’ Rubin	DV	10A8	2026-03-30 22:13:23.942+00	2025-2026
6ea0e50b-bbd2-4e91-8adc-b3c7e68178ef	siurun	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu Run	DV	11C6	2026-03-30 22:13:23.942+00	2025-2026
58e70c7e-8b7b-4a12-879a-0d3776f059a9	rmahh'lysa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RMAH H' LY SA	DV	12B6	2026-03-30 22:13:23.942+00	2025-2026
d5d982c6-6d4f-465b-a7d8-c841c9e8d999	siulisa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	SIU LI SA	DV	12B6	2026-03-30 22:13:23.942+00	2025-2026
f622f954-b1e0-43da-a5cb-719db0708652	kpuihsai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Sái	DV	10A8	2026-03-30 22:13:23.942+00	2025-2026
5456f6ac-ba5c-4ba0-b814-920831688d33	cungocsang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cù Ngọc Sáng	DV	11C7	2026-03-30 22:13:23.942+00	2025-2026
b9bd0eb7-a36a-4328-9ecb-ee15619c8c53	hoangthithanhsang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Thanh Sáng	DV	11C4	2026-03-30 22:13:23.942+00	2025-2026
76459c7c-5737-44ab-8dfd-760bb7032d71	kieutuansang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kiều Tuấn Sang	DV	11C10	2026-03-30 22:13:23.942+00	2025-2026
c9cb4510-a9ea-48cb-9df2-77035846db2c	nguyenvansang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Sang	DV	11C10	2026-03-30 22:13:23.942+00	2025-2026
d3aa8dcc-54df-49b4-ad82-2471d76a8490	nguyenxuansang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Sang	DV	11C2	2026-03-30 22:13:23.942+00	2025-2026
88b31e1b-17ac-4404-b2c5-fab27c0d1e2a	romahh'sarina	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Sarina	DV	10A9	2026-03-30 22:13:23.942+00	2025-2026
df4f0dac-a556-4419-bc58-9bc9ec7f912a	kpuihh'sen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Sen	DV	10A8	2026-03-30 22:13:23.942+00	2025-2026
41961a0b-7f66-482d-b81a-54df9b225de2	kpuihsen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Sen	DV	11C11	2026-03-30 22:13:23.942+00	2025-2026
5b5160e3-99b6-4ec4-b8cf-b0ad98aa5117	kpuihh'si	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Si	DV	12B5	2026-03-30 22:13:23.942+00	2025-2026
40976974-80f2-44d3-bf91-b64d2a523721	leducbao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đức Bảo	DV	11C11	2026-03-30 22:13:23.912+00	2025-2026
1105c31d-211f-496a-9e7d-ee39abfb6032	letrangiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Trần Gia Bảo	DV	11C7	2026-03-30 22:13:23.912+00	2025-2026
ef690dd2-e9f7-4ec7-a482-9d32ce658b9d	nguyendinhgiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Gia Bảo	DV	11C1	2026-03-30 22:13:23.912+00	2025-2026
07a897a0-f9af-450d-b0c5-79be6676b0fb	nguyensythebao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Sỹ Thế Bảo	DV	10A8	2026-03-30 22:13:23.912+00	2025-2026
e216db31-3f07-4325-afc8-087c0f0edf39	nguyentrinhgiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trịnh Gia Bảo	DV	12B1	2026-03-30 22:13:23.912+00	2025-2026
fbf3e853-de7c-44ce-a329-257deef93a14	phamlegiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Lê Gia Bảo	DV	10A2	2026-03-30 22:13:23.912+00	2025-2026
f942ab18-c778-4313-8d68-6b696ad72206	phanngocgiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Ngọc Gia Bảo	DV	12B2	2026-03-30 22:13:23.912+00	2025-2026
81692d47-5cf0-482e-9e19-0b4c525c9103	trangiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Bảo	DV	11C3	2026-03-30 22:13:23.912+00	2025-2026
98e1e0db-657c-4378-a718-31571dfbab8b	trangiabao1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Bảo	DV	12B3	2026-03-30 22:13:23.912+00	2025-2026
99e5e935-3f43-45f7-8393-35fbe4403cbc	trannguyengiabao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Nguyễn Gia Bảo	DV	12B10	2026-03-30 22:13:23.912+00	2025-2026
23cc9829-19dc-4d7c-a2c6-d3dce6ca6cd8	nguyenthanhbac	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thanh Bắc	DV	12B4	2026-03-30 22:13:23.912+00	2025-2026
26cc1303-7366-4dbf-b2b0-f526883c741b	hoanghoaibang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Hoài Băng	DV	11C4	2026-03-30 22:13:23.912+00	2025-2026
4f95de03-9b77-47b7-aa9c-67e5062c8274	honguyenkhanhbang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Nguyễn Khánh Băng	DV	10A3	2026-03-30 22:13:23.912+00	2025-2026
ce3a4103-c37e-485d-b06d-4c5e34ba008b	lethikhanhbang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Khánh Băng	DV	10A4	2026-03-30 22:13:23.912+00	2025-2026
4aacbbc1-848a-49f0-a2c1-661f3130415c	phamngockhanhbang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Ngọc Khánh Băng	DV	11C10	2026-03-30 22:13:23.912+00	2025-2026
da3fdc77-9c55-4b26-b242-e8c1aae319c6	kpuihban	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Bân	DV	10A3	2026-03-30 22:13:23.913+00	2025-2026
64bf0668-cca2-4d0f-96f0-f230bbb10423	romahh'bdit	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Bdít	DV	11C9	2026-03-30 22:13:23.913+00	2025-2026
730b4799-0484-4c1d-be0b-ba9bada630f2	phamvanbe	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Văn Bé	DV	10A1	2026-03-30 22:13:23.913+00	2025-2026
cb8672d9-0c67-4d91-9bbf-d9c080ea4f54	siuh'beo	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu H' Beo	DV	10A10	2026-03-30 22:13:23.913+00	2025-2026
f408dc1d-a81e-411e-b5d7-4a7f7955fea7	rolanh'sabet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Sa Bét	DV	11C6	2026-03-30 22:13:23.913+00	2025-2026
5261bd92-9031-4312-9c56-9328f0caee05	rahlanh'rubi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rah Lan H' Ru Bi	DV	12B7	2026-03-30 22:13:23.913+00	2025-2026
8c48d547-f2c1-4ade-862d-5742585ad80a	siuh'ximbi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu H' Xim Bi	DV	10A7	2026-03-30 22:13:23.913+00	2025-2026
c060cb35-529d-40a4-94e8-e946c7022d1f	hongocbich	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Bích	DV	11C3	2026-03-30 22:13:23.913+00	2025-2026
6910a8d2-0237-43cf-aadc-3bf35ae6b4d5	luongthingocbich	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lường Thị Ngọc Bích	DV	10A2	2026-03-30 22:13:23.913+00	2025-2026
799a11ea-2142-46fb-91dc-a13185418fef	rolanh'bich	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Bích	DV	10A6	2026-03-30 22:13:23.913+00	2025-2026
3d0a5d23-ab56-4d26-8a81-5e763be06e10	rolanh'bich1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Bích	DV	12B5	2026-03-30 22:13:23.913+00	2025-2026
48758e73-d7c3-40d1-a1af-d2173a08a3d2	trinhthihongbich	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Thị Hồng Bích	DV	11C8	2026-03-30 22:13:23.913+00	2025-2026
cec88460-fb2f-4615-a080-44b587272f6c	phamducbin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Đức Bin	DV	11C8	2026-03-30 22:13:23.913+00	2025-2026
067bfba1-50a9-4a35-89fa-77d35c8dd409	hoanggiabinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Gia Bình	DV	11C4	2026-03-30 22:13:23.913+00	2025-2026
d0693ee8-729e-49e7-9826-1f32237d7297	hoanghaibinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Hải Bình	DV	12B4	2026-03-30 22:13:23.913+00	2025-2026
01ff237a-6486-4cd8-a823-f64af8e9aae3	lethithanhbinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thanh Bình	DV	11C5	2026-03-30 22:13:23.913+00	2025-2026
67e806f5-93a5-4c40-a49c-aaa250d4ff91	lucvothaibinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LỤC VÕ THÁI BÌNH	DV	12B6	2026-03-30 22:13:23.913+00	2025-2026
965ffc9a-7893-42bb-a7d8-9ee6ef226982	luongthanhbinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thanh Bình	DV	10A1	2026-03-30 22:13:23.913+00	2025-2026
2c01a784-da46-4e02-9af3-c5ddbf864ce5	nguyenthibinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bình	DV	12B2	2026-03-30 22:13:23.913+00	2025-2026
d10c7604-9238-43bb-888f-f8b37a3c44b0	nguyentrongbinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trọng Bình	DV	11C4	2026-03-30 22:13:23.913+00	2025-2026
875429f7-805f-42ce-ae8a-150dd37f7808	nonghoangdiepbinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nông Hoàng Diệp Bình	DV	12B9	2026-03-30 22:13:23.913+00	2025-2026
a3c7ac19-cf18-4483-bdbc-861b3814fa3d	phankhanhhoabinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Khanh Hoà Bình	DV	11C7	2026-03-30 22:13:23.913+00	2025-2026
37e185c4-2953-43eb-bd3b-f6aa85e996db	romahbom	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Bom	DV	12B9	2026-03-30 22:13:23.913+00	2025-2026
b756283f-a3e1-48b7-b2d9-ba419cda7b06	vodangngoccham	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Đặng Ngọc Châm	DV	11C7	2026-03-30 22:13:23.913+00	2025-2026
479d8c77-ab74-4a9d-b95a-c3e410801c44	dangbaochau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Bảo Châu	DV	10A2	2026-03-30 22:13:23.913+00	2025-2026
0a81a383-80be-4218-86a1-50f9f3865a3f	lenguyengiangchau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nguyễn Giáng Châu	DV	11C3	2026-03-30 22:13:23.913+00	2025-2026
16900f49-8ed4-4a4a-af82-8a45cc0fb5e9	lethaichau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thái Châu	DV	12B10	2026-03-30 22:13:23.913+00	2025-2026
11cd1cfa-5a72-4164-af94-7b96e7d16e96	nguyenngocbaochau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Bảo Châu	DV	10A5	2026-03-30 22:13:23.913+00	2025-2026
c30f80ab-e5af-46ff-9013-2ab014c9ef80	hoangthiquynhchi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Quỳnh Chi	DV	12B5	2026-03-30 22:13:23.913+00	2025-2026
08177ebe-568e-4e9d-bb28-ccecd1a62d81	hongocquechi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Quế Chi	DV	12B5	2026-03-30 22:13:23.914+00	2025-2026
1b0b1c71-bf55-422e-a51e-b0fa059b0ec8	phamkhanhchi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Khánh Chi	DV	10A7	2026-03-30 22:13:23.914+00	2025-2026
7b723434-4826-49f1-84cc-e81235a5fc52	phamthikimchi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Kim Chi	DV	11C5	2026-03-30 22:13:23.914+00	2025-2026
7ea97d4b-c0df-4121-9dd7-bdaef1593f45	romahh'chi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Chi	DV	11C8	2026-03-30 22:13:23.914+00	2025-2026
724a901d-8e45-4452-b9f9-845235a2a37e	tranthikhanhchi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Khánh Chi	DV	11C8	2026-03-30 22:13:23.914+00	2025-2026
87dcea39-9b4a-4356-ac4e-5585daa7aae9	trinhphankimchi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Phan Kim Chi	DV	12B3	2026-03-30 22:13:23.914+00	2025-2026
2ce539a2-037d-42ab-ae81-2b116f787e65	nguyencongchien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Chiến	DV	12B10	2026-03-30 22:13:23.914+00	2025-2026
209d6457-9667-4db8-811d-2b31b0e09aef	phamngocchinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Ngọc Chính	DV	11C1	2026-03-30 22:13:23.914+00	2025-2026
c63ca403-c924-474b-bb65-c4fe13d4984f	tranthichinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Chính	DV	12B10	2026-03-30 22:13:23.914+00	2025-2026
244ba33c-9fde-4968-85ed-fb5f4a9aea63	kpuihh'chuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Chúc	DV	12B7	2026-03-30 22:13:23.914+00	2025-2026
b394595e-a685-45c5-aafe-b9e120b667f2	romahh'chuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Chúc	DV	10A11	2026-03-30 22:13:23.914+00	2025-2026
0f17058c-628d-4371-aa06-d45d95414ca2	rolanchun	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Chun	DV	10A5	2026-03-30 22:13:23.914+00	2025-2026
b9d493ae-277e-4249-968a-4a79dbac3a77	nguyenhuuchuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN HỮU CHỨC	DV	12B6	2026-03-30 22:13:23.914+00	2025-2026
16e33f20-94e5-4ce2-84db-2cfbdc76a9d2	nguyenngocchuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Chương	DV	12B4	2026-03-30 22:13:23.914+00	2025-2026
6cc8f918-df1f-48d5-89f7-063f29f42326	khuatduycong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Khuất Duy Công	DV	11C6	2026-03-30 22:13:23.914+00	2025-2026
0797580d-1858-4841-95b9-662280e85f6b	letiencong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Tiến Công	DV	12B10	2026-03-30 22:13:23.914+00	2025-2026
2281fad1-fa06-425e-9310-cd03193f6f9e	nguyenquangthanhcong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Thành Công	DV	12B1	2026-03-30 22:13:23.914+00	2025-2026
6876a677-e158-410b-88f3-4c693a6f07f2	nguyenthanhcong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thành Công	DV	11C5	2026-03-30 22:13:23.914+00	2025-2026
6118fc69-b4ce-4db5-9fd5-1993934cecee	lekhaco	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Khả Cơ	DV	12B9	2026-03-30 22:13:23.914+00	2025-2026
93e157ba-5c30-40ad-9fb1-08d4c10405e6	nguyenthikimcuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Kim Cúc	DV	10A2	2026-03-30 22:13:23.914+00	2025-2026
35d49270-c45b-4b53-a84e-bbc02f8a431c	mainguyenquoccuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Nguyễn Quốc Cường	DV	11C2	2026-03-30 22:13:23.914+00	2025-2026
3e3a127c-3126-4e61-9be9-81d86ab5c13b	nguyenvancuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Cường	DV	12B9	2026-03-30 22:13:23.914+00	2025-2026
40a918c0-a453-4e41-9ede-62eafff1ecbb	phanminhcuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Minh Cường	DV	11C1	2026-03-30 22:13:23.914+00	2025-2026
27aaf73b-7b7c-4d0b-9655-e9325bf4a593	lethanhdanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thành Danh	DV	12B2	2026-03-30 22:13:23.914+00	2025-2026
0ffd5756-71b5-470c-b472-d548c2d98621	nguyencongdanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Danh	DV	11C8	2026-03-30 22:13:23.914+00	2025-2026
1d824201-ba02-43c2-a95f-a3e56bd4de1f	nguyencongdan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Dân	DV	11C6	2026-03-30 22:13:23.914+00	2025-2026
c247868e-b240-4528-9266-7f845326bd3f	romahdau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Dấu	DV	12B9	2026-03-30 22:13:23.914+00	2025-2026
b25273fc-fb0d-4763-965c-1392ddaa68ef	nguyenhoanghandi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Hân Di	DV	10A6	2026-03-30 22:13:23.914+00	2025-2026
eabdcbdf-a97e-4e16-80ca-b6fe4dc1e715	phamhongdiem	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Hồng Diễm	DV	11C4	2026-03-30 22:13:23.914+00	2025-2026
43e4d99d-bac3-44f6-b74e-9a908717481c	hongocdien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Diễn	DV	11C2	2026-03-30 22:13:23.914+00	2025-2026
dfa6632c-f683-4758-92ec-cdd17969bddf	doanthingocdiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Thị Ngọc Diệp	DV	12B2	2026-03-30 22:13:23.914+00	2025-2026
76edcc2c-b2a3-43fb-bf7c-e6a9c505b8ca	ksorh'diep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Diệp	DV	12B9	2026-03-30 22:13:23.914+00	2025-2026
7f1cb3c5-d414-4232-9072-095ffd95498a	rlanh'diep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	R Lan H' Diệp	DV	12B5	2026-03-30 22:13:23.914+00	2025-2026
2cc5e161-da28-444d-9e41-4de5e2abe70c	kpuihh'dieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Diệu	DV	12B10	2026-03-30 22:13:23.914+00	2025-2026
1dda16e9-0230-4ccd-903d-744153bdd82e	nguyenthidieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diệu	DV	10A8	2026-03-30 22:13:23.914+00	2025-2026
9d5826c0-221d-41a1-9c37-b9983697d39d	rlanh'dieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RLAN H' DIỆU	DV	12B6	2026-03-30 22:13:23.914+00	2025-2026
3493c2f9-47d3-459c-bc54-a664d67fc05e	romahh'dieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Diệu	DV	12B10	2026-03-30 22:13:23.914+00	2025-2026
cd4309b7-52ea-4330-88d3-6ae7ac64d29a	siuh'diu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu H' Dịu	DV	11C12	2026-03-30 22:13:23.914+00	2025-2026
ca8d5152-d5a9-4602-91b5-af5941737bff	romahh'dulen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Dulen	DV	11C7	2026-03-30 22:13:23.914+00	2025-2026
04e7730f-1f95-4101-8366-6ce1f24ce5ec	buithithuydung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Thùy Dung	DV	10A2	2026-03-30 22:13:23.914+00	2025-2026
4dc8b489-ba4a-4a2a-9bf0-c21b0620be10	hoangletrungdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Lê Trung Dũng	DV	10A2	2026-03-30 22:13:23.914+00	2025-2026
a9526810-ee36-4b2c-8797-4259826d2d04	hoanhdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Anh Dũng	DV	10A4	2026-03-30 22:13:23.914+00	2025-2026
5eba6a63-6ef0-46fc-842b-2ae30a725ae4	honghiadung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Nghĩa Dũng	DV	11C2	2026-03-30 22:13:23.915+00	2025-2026
40fd3723-8080-4598-bdd9-d2031c709bb0	hothithuydung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thùy Dung	DV	12B6	2026-03-30 22:13:23.915+00	2025-2026
531a31cc-82c1-444e-9831-1e706162ceb3	ksordung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Dũng	DV	11C7	2026-03-30 22:13:23.915+00	2025-2026
22dcd678-5201-45c0-8b4d-f8a86230f3a7	leanhdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Anh Dũng	DV	11C4	2026-03-30 22:13:23.915+00	2025-2026
ea317201-2d70-4099-b6f1-d7b5ad89aead	ledinhdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Dụng	DV	11C10	2026-03-30 22:13:23.915+00	2025-2026
f3bfe6dd-0bdc-4775-a3f8-3443135d23f5	lequangdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quang Dũng	DV	10A4	2026-03-30 22:13:23.915+00	2025-2026
a77a899b-abc9-441b-bfea-f19be495b95f	letuandung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Tuấn Dũng	DV	12B4	2026-03-30 22:13:23.915+00	2025-2026
36dee5a6-76e3-4ef9-bd17-f8ef3cf6276b	maitandung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Tấn Dũng	DV	12B4	2026-03-30 22:13:23.915+00	2025-2026
129892c0-4066-43c3-9b51-8ce3ce641839	maitiendung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Tiến Dũng	DV	12B4	2026-03-30 22:13:23.915+00	2025-2026
5940f19d-c846-4697-917e-d8e34e1e45a2	nguyenanhdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Anh Dũng	DV	11C4	2026-03-30 22:13:23.915+00	2025-2026
f782a446-23c4-4b0a-89fb-6a8bf5c7631d	nguyendinhdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Dũng	DV	11C3	2026-03-30 22:13:23.915+00	2025-2026
e3e248cc-5770-49d1-8cd3-71dbfe5e4dde	nguyenquangdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Dũng	DV	11C7	2026-03-30 22:13:23.915+00	2025-2026
36f8d488-bb99-47b2-a111-729bf4059094	nguyensydung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Sỹ Dũng	DV	12B7	2026-03-30 22:13:23.915+00	2025-2026
af38d739-c1eb-4889-9525-6f53449e46c1	nguyenthithuydung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Dung	DV	12B7	2026-03-30 22:13:23.915+00	2025-2026
89ad02f4-ef29-499a-a253-8832464f13c8	ngosythem	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Sỹ Thêm	DV	12B9	2026-03-30 22:13:23.945+00	2025-2026
bfebf93a-c559-47ca-be5b-d4aaf76a04da	hoangbathien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Bá Thiên	DV	10A7	2026-03-30 22:13:23.945+00	2025-2026
11ce0576-ae8f-43ff-bac1-94f6d33cb689	hodienthien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Diên Thiện	DV	10A4	2026-03-30 22:13:23.945+00	2025-2026
14a09829-1383-4d30-af92-b5603d8c1c7d	lenamthien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nam Thiên	DV	12B7	2026-03-30 22:13:23.945+00	2025-2026
202f0b40-bc2e-4e46-bc50-3843d93594ea	vohoangngocthien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hoàng Ngọc Thiên	DV	10A4	2026-03-30 22:13:23.945+00	2025-2026
19b6e32b-11fb-4c4f-8afd-7806bade63fe	rolanh'thiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thiết	DV	10A5	2026-03-30 22:13:23.945+00	2025-2026
18546391-ec22-4f1c-be4e-cb073461093d	duongducthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Đức Thịnh	DV	10A1	2026-03-30 22:13:23.945+00	2025-2026
3c25c521-d7e5-456f-a52b-066823d3b338	hophucthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Phúc Thịnh	DV	12B5	2026-03-30 22:13:23.945+00	2025-2026
16da4fce-5a33-4d65-ad0d-bd07a6510380	ksorthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Thịnh	DV	12B10	2026-03-30 22:13:23.945+00	2025-2026
5863f0bb-0edb-4a0c-90e4-23dc8d0bcd27	letruongthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Trường Thịnh	DV	12B7	2026-03-30 22:13:23.945+00	2025-2026
7b81c1a3-4bab-4a06-bd88-045cd239d964	nguyenanhthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Anh Thịnh	DV	11C11	2026-03-30 22:13:23.945+00	2025-2026
8bb94206-674c-4b60-962f-60182205af32	phanngocthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Ngọc Thịnh	DV	10A1	2026-03-30 22:13:23.945+00	2025-2026
a4fdb5e2-45aa-4ba2-a2a4-5f4598fca0ba	quachducthinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	QUÁCH ĐỨC THỊNH	DV	12B6	2026-03-30 22:13:23.945+00	2025-2026
528ef5e9-8926-4439-b49e-164bc6a725b7	hoangthikimthoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Kim Thoa	DV	11C3	2026-03-30 22:13:23.946+00	2025-2026
faea638e-54e3-4ef2-856d-cc5e740bd120	rolanh'thoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thoại	DV	11C10	2026-03-30 22:13:23.946+00	2025-2026
e72ac883-09cf-4092-8e10-654c195e9929	nhuthikimdung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nhữ Thị Kim Dung	DV	10A11	2026-03-30 22:13:23.915+00	2025-2026
6c684d8c-578e-4a3d-87f8-3af4db541a23	phamthithuydung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Thùy Dung	DV	12B7	2026-03-30 22:13:23.915+00	2025-2026
7bca7b22-5a89-44aa-8ad2-62b36bce8362	phanvandung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Văn Dũng	DV	12B2	2026-03-30 22:13:23.915+00	2025-2026
39e710d6-f5df-4225-916f-a2ad395d75c7	daotuanduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Tuấn Duy	DV	11C1	2026-03-30 22:13:23.915+00	2025-2026
f58f6229-9605-4152-bfa1-43079b0bd8ff	nguyendinhngocduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đinh Ngọc Duy	DV	10A10	2026-03-30 22:13:23.915+00	2025-2026
ae374c6c-fc82-4924-b395-1c337f32a4a3	nguyenhoangducduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Đức Duy	DV	10A2	2026-03-30 22:13:23.915+00	2025-2026
0454ff35-3dcf-4675-ad53-234388be966f	nguyenhuuduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hữu Duy	DV	11C7	2026-03-30 22:13:23.915+00	2025-2026
eec88353-d041-4f93-8c1a-115d22f1e25d	nguyennhatduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Nhật Duy	DV	11C1	2026-03-30 22:13:23.915+00	2025-2026
69ec0c17-6020-472b-bc8b-fbb61271e8d4	nguyentrongcanhduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trọng Cảnh Duy	DV	12B3	2026-03-30 22:13:23.915+00	2025-2026
53cdf9a7-8cea-4e40-849d-ef94ac9a2539	phamkhanhduy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Khánh Duy	DV	12B9	2026-03-30 22:13:23.915+00	2025-2026
8395d2ad-3c32-4877-a913-b6d4d7671307	buithithuyduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Thùy Duyên	DV	11C1	2026-03-30 22:13:23.915+00	2025-2026
dfe27f2a-0dcd-41c4-b926-37387e94f501	luongthimyduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Mỹ Duyên	DV	11C8	2026-03-30 22:13:23.915+00	2025-2026
8df7aa99-fc43-4f79-be63-e90c15783c92	nguyenthiduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Duyên	DV	12B7	2026-03-30 22:13:23.915+00	2025-2026
bf7deeea-069c-44f9-8ed7-fa0867e7e420	nguyenthiduyen1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ DUYÊN	DV	12B6	2026-03-30 22:13:23.915+00	2025-2026
8e565629-3289-4d13-b4c6-1bba57177a75	nguyenthihongduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng Duyên	DV	11C2	2026-03-30 22:13:23.915+00	2025-2026
9aab854a-2aa5-4ecf-846c-2133188e85fc	nguyenthimyduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mỹ Duyên	DV	11C7	2026-03-30 22:13:23.915+00	2025-2026
945523ce-5bd6-4146-9b19-2076bdf53668	vuthiduyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Duyên	DV	11C6	2026-03-30 22:13:23.915+00	2025-2026
cc7c767e-2d24-4c51-a2ab-14f3d6627e89	ksordu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Dứ	DV	11C6	2026-03-30 22:13:23.915+00	2025-2026
d221a901-cd0d-4bdd-882f-cb9e3a9f7ef6	buiquangduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Quang Dương	DV	11C11	2026-03-30 22:13:23.915+00	2025-2026
1b1cd635-f086-409e-b25b-fbc5ae0c31c7	buithuyduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thùy Dương	DV	12B1	2026-03-30 22:13:23.916+00	2025-2026
af917af4-70f8-4d74-9145-5cb9ef9ba213	hothaiduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thái Dương	DV	12B4	2026-03-30 22:13:23.916+00	2025-2026
8e56e0ff-4b8f-4dd3-a631-353e20a15851	kpuihh'duong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Dương	DV	10A11	2026-03-30 22:13:23.916+00	2025-2026
a468d658-b2b9-4a87-a07e-91a90163be76	luongquocchienduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Quốc Chiến Dương	DV	12B5	2026-03-30 22:13:23.916+00	2025-2026
91b49e44-3d77-4fdd-8a96-dc1ad9c62f91	nguyenducduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Dương	DV	11C12	2026-03-30 22:13:23.916+00	2025-2026
6e9732bf-b557-477a-babe-cc03cc318bca	nguyenngocquynhduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Quỳnh Dương	DV	10A2	2026-03-30 22:13:23.916+00	2025-2026
1e4d37af-6888-4c8b-be08-9e251500bf73	nguyenquangduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Dương	DV	11C2	2026-03-30 22:13:23.916+00	2025-2026
7f33d88b-4ec2-4e60-8820-29a1ee84c0f0	truongdacduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Đắc Dương	DV	11C12	2026-03-30 22:13:23.916+00	2025-2026
6ac0334b-98db-472f-a10a-cd88078a3c96	vuthianhduong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Ánh Dương	DV	10A3	2026-03-30 22:13:23.916+00	2025-2026
cf98d412-3e8d-4f71-a458-2803bf6653e0	romahh'da	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Đa	DV	10A8	2026-03-30 22:13:23.916+00	2025-2026
8982ae7e-f75b-45f4-b74a-86acd2eecb07	hohuudai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Đại	DV	11C7	2026-03-30 22:13:23.916+00	2025-2026
06b642e9-57b6-4459-ae1e-8556c8979448	ledinhdai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Đại	DV	11C3	2026-03-30 22:13:23.916+00	2025-2026
e1265235-6819-4670-a5da-599bf9083908	nguyenthethanhdai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thế Thành Đại	DV	11C11	2026-03-30 22:13:23.916+00	2025-2026
e8b40e45-26ba-4107-a4f9-9d9ec547c72a	nguyentrannhatdang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Nhật Đang	DV	12B8	2026-03-30 22:13:23.916+00	2025-2026
d8a0109d-f8c7-421b-bb9e-3062a6226c01	lethianhdao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Anh Đào	DV	12B10	2026-03-30 22:13:23.916+00	2025-2026
8f77088f-2e8a-4947-8246-b0f2f1472914	maithianhdao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Anh Đào	DV	10A9	2026-03-30 22:13:23.916+00	2025-2026
b9cbd7f1-a22d-40d2-af21-55a73a255db0	buingocdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Ngọc Đạt	DV	10A1	2026-03-30 22:13:23.916+00	2025-2026
3f8e6385-d6e2-46a2-9fd8-7a187c1c9876	dangquangthanhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Quang Thành Đạt	DV	11C12	2026-03-30 22:13:23.916+00	2025-2026
025e3631-0cd1-4732-a83c-d86ca3a64045	dovietdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Viết Đạt	DV	10A4	2026-03-30 22:13:23.916+00	2025-2026
3310faf7-299d-4d70-a39f-fd105f4c586f	hatiendat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Tiến Đạt	DV	10A4	2026-03-30 22:13:23.916+00	2025-2026
3f1b8952-1467-4b29-a8af-03a1bcce0660	leducdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đức Đạt	DV	10A2	2026-03-30 22:13:23.916+00	2025-2026
d25b2f3b-c25d-4d4e-920e-adf8c22e645a	levandat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Đạt	DV	12B3	2026-03-30 22:13:23.916+00	2025-2026
bcb6f576-83d6-4af0-acb5-a9958438ca3a	levietdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Viết Đạt	DV	12B5	2026-03-30 22:13:23.916+00	2025-2026
ca984f2a-472b-40c0-a36d-8d18e7124fc5	maivantuandat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Văn Tuấn Đạt	DV	11C9	2026-03-30 22:13:23.916+00	2025-2026
5e1a515b-4d4a-4112-ae8e-60507b276272	nguyenphungdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phùng Đạt	DV	11C7	2026-03-30 22:13:23.916+00	2025-2026
ef8fde15-ec12-4903-aa6c-711b852cf3b7	nguyentandat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tấn Đạt	DV	11C1	2026-03-30 22:13:23.916+00	2025-2026
1fd17935-d71d-4799-ac98-bbf78d07d985	nguyenthanhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thành Đạt	DV	12B3	2026-03-30 22:13:23.916+00	2025-2026
537c32b5-e404-40e3-8e93-c28c00891fd3	nguyenthedat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THẾ ĐẠT	DV	12B6	2026-03-30 22:13:23.916+00	2025-2026
358879e0-1b82-41db-8444-f5995bb00bf5	nguyentiendat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tiến Đạt	DV	12B3	2026-03-30 22:13:23.916+00	2025-2026
ef110324-f63e-45f0-9fa4-8141e5a800d9	nguyentruongdacdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trương Đắc Đạt	DV	11C10	2026-03-30 22:13:23.916+00	2025-2026
976898b2-799b-4ea1-a4cf-88a389badbbc	phamthanhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thành Đạt	DV	12B2	2026-03-30 22:13:23.916+00	2025-2026
23279733-860e-4c49-ac7a-f9d74807fe8d	phantranthanhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Trần Thành Đạt	DV	11C8	2026-03-30 22:13:23.916+00	2025-2026
80b9b13c-b5c3-47d1-916b-1491abf42095	tongthanhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tống Thành Đạt	DV	11C12	2026-03-30 22:13:23.916+00	2025-2026
f3830a3a-6609-402f-a84b-ae7f7eafa82f	trantiendat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Tiến Đạt	DV	11C9	2026-03-30 22:13:23.916+00	2025-2026
cf04308a-3645-4875-b712-1bdcdb7732de	tranvandat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Đạt	DV	11C11	2026-03-30 22:13:23.916+00	2025-2026
1418e8d9-e50f-487d-9293-bb04568c1d49	vudinhdat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Đình Đạt	DV	12B3	2026-03-30 22:13:23.916+00	2025-2026
78b61e0b-f6d9-46ef-a612-c353b1d42c8c	builuonghaidang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Lương Hải Đăng	DV	11C10	2026-03-30 22:13:23.916+00	2025-2026
6f06e273-5548-4331-8bed-637f70be4476	gianghaidang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Giang Hải Đăng	DV	11C5	2026-03-30 22:13:23.917+00	2025-2026
c8a78dc4-1b6d-472f-9cb1-ebcba11de881	macphamhaidang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mạc Phạm Hải Đăng	DV	12B5	2026-03-30 22:13:23.917+00	2025-2026
c3b676b3-329e-4719-adb2-2a8e7f8958ce	nguyenhaidang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hải Đăng	DV	11C1	2026-03-30 22:13:23.917+00	2025-2026
3302780d-0217-46e6-9a3e-eb16bdb1c327	romahdiem	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Điềm	DV	11C8	2026-03-30 22:13:23.917+00	2025-2026
e1b81486-4e08-411c-be95-86a0ace2b2a5	rolandiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Điệp	DV	10A11	2026-03-30 22:13:23.917+00	2025-2026
562e144c-c297-4129-83ef-20adf91987dd	rolandiep1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Điệp	DV	11C9	2026-03-30 22:13:23.917+00	2025-2026
401df475-a10f-4d91-a148-7fe50884efaf	romahh'diep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Điệp	DV	12B7	2026-03-30 22:13:23.917+00	2025-2026
6888e300-c9a9-4636-a6b2-1619b66a75c2	nguyenvandinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Định	DV	12B8	2026-03-30 22:13:23.917+00	2025-2026
f5319a86-af14-4d17-9fd0-6877c2eb0bfd	caochandong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Chấn Đông	DV	11C6	2026-03-30 22:13:23.917+00	2025-2026
7c3f3216-f534-4e58-843f-95dfb3230055	ledaidong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đại Đồng	DV	12B8	2026-03-30 22:13:23.917+00	2025-2026
bbc90654-250f-487b-9e44-6684bb3083d1	ksorh'duin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Đuin	DV	10A8	2026-03-30 22:13:23.917+00	2025-2026
900d4d21-0156-4045-a043-d19d0c60c569	duongminhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Minh Đức	DV	12B1	2026-03-30 22:13:23.917+00	2025-2026
26644dd2-d309-4ec0-b271-b3ff2d7f699d	daogiaduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Gia Đức	DV	10A4	2026-03-30 22:13:23.917+00	2025-2026
3218699c-16bd-4e2a-a2ab-1e804f587140	haminhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Minh Đức	DV	12B1	2026-03-30 22:13:23.917+00	2025-2026
96758baf-03be-402a-94ff-275c43bc076c	hovanduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Văn Đức	DV	12B3	2026-03-30 22:13:23.917+00	2025-2026
762efaad-d7d0-4654-83fa-4efa9f854252	hovietduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Việt Đức	DV	10A2	2026-03-30 22:13:23.917+00	2025-2026
08a77ef8-f92a-4f80-ad2d-3c2e7d4d4c6d	ksordinhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Đinh Đức	DV	10A11	2026-03-30 22:13:23.917+00	2025-2026
ca12d68d-a1e3-4cf7-ade9-3f0dd9fc5da9	leanhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Anh Đức	DV	10A3	2026-03-30 22:13:23.917+00	2025-2026
714a8bf0-289b-40a9-852e-e515f98cb040	leduyduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Duy Đức	DV	11C9	2026-03-30 22:13:23.917+00	2025-2026
0bcdc156-a1d2-49ee-b5f5-afa2e6b8c729	ledinhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Đức	DV	12B7	2026-03-30 22:13:23.917+00	2025-2026
2cd053b9-dcae-4331-9795-07020557b56a	lethianhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LÊ THỊ ÁNH ĐỨC	DV	12B6	2026-03-30 22:13:23.917+00	2025-2026
404545bf-f9e0-4324-9499-997061791617	nguyenhuuduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hữu Đức	DV	11C5	2026-03-30 22:13:23.917+00	2025-2026
e4b02521-4769-4463-873e-b9c846ffff37	nguyenvietduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Việt Đức	DV	11C2	2026-03-30 22:13:23.917+00	2025-2026
b327c070-d5a6-492a-86a9-9535720dd097	phananhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Anh Đức	DV	10A3	2026-03-30 22:13:23.917+00	2025-2026
40a6885c-3682-412b-912d-98aa0eac4854	phantanduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Tấn Đức	DV	12B2	2026-03-30 22:13:23.917+00	2025-2026
4c2add67-ea4a-4370-86cb-25367afc018d	vuminhduc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Minh Đức	DV	11C1	2026-03-30 22:13:23.917+00	2025-2026
8f45ec62-887c-4043-b5b2-72d81a740509	nguyenhoanggia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Gia	DV	12B8	2026-03-30 22:13:23.917+00	2025-2026
6a850be6-3987-4536-8b62-61b18081ae38	trantrinhnhatgia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Trịnh Nhất Gia	DV	11C3	2026-03-30 22:13:23.917+00	2025-2026
d10d0eab-ecdd-40cb-9d47-4c3dfbc206b7	doanhagiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Hà Giang	DV	10A10	2026-03-30 22:13:23.917+00	2025-2026
7803d2c3-6bab-413f-852a-cec2bcef9965	ksorh'giang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Giang	DV	10A7	2026-03-30 22:13:23.917+00	2025-2026
658367a1-c4ec-4141-8c38-6b336c2ed518	leducgiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đức Giang	DV	12B1	2026-03-30 22:13:23.917+00	2025-2026
6cae45ea-447a-45bb-92cf-ff50f0cd94e3	lehuonggiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hương Giang	DV	10A3	2026-03-30 22:13:23.917+00	2025-2026
21077dbb-73fc-448d-bc98-4e5b67f9153e	nguyenthitragiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Trà Giang	DV	10A7	2026-03-30 22:13:23.917+00	2025-2026
fcf936a8-4fa7-47e5-95cd-236e9778b79f	tranthivangiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Vân Giang	DV	12B5	2026-03-30 22:13:23.917+00	2025-2026
472c87b4-ca02-4b59-95ca-a409acbd69b9	vohuonggiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hương Giang	DV	11C5	2026-03-30 22:13:23.917+00	2025-2026
c8d813df-7999-4e6d-a1ab-8dcbabf554a8	vungoctruonggiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Ngọc Trường Giang	DV	10A2	2026-03-30 22:13:23.917+00	2025-2026
f45d4504-98d0-4a17-b101-633723358608	vuthithanhgiang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Thanh Giang	DV	12B3	2026-03-30 22:13:23.917+00	2025-2026
d233c764-5c70-41c7-88a5-5959d4dd7b47	romahh’grinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H’ Grinh	DV	10A7	2026-03-30 22:13:23.918+00	2025-2026
2623cca7-5e23-42c4-9e76-eccd289b333c	romahh'phuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H'phương	DV	11C8	2026-03-30 22:13:23.918+00	2025-2026
05a67e96-1fac-4936-a84e-548027e92790	bachthingocha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bạch Thị Ngọc Hà	DV	10A4	2026-03-30 22:13:23.918+00	2025-2026
e0ac4ea3-14fa-4afa-aaf5-365c0862b3b5	damthithanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đàm Thị Thanh Hà	DV	10A6	2026-03-30 22:13:23.918+00	2025-2026
3ecf3c99-5002-42ad-98e9-15fc9c6c984b	hothingocha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Ngọc Hà	DV	11C6	2026-03-30 22:13:23.918+00	2025-2026
f88004a1-abbe-44db-ba4e-c47070914ab4	lenguyenhongha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nguyễn Hồng Hà	DV	12B3	2026-03-30 22:13:23.918+00	2025-2026
9b4b560f-0506-42e8-8bec-df24f3673c9d	lethivietha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Việt Hà	DV	11C2	2026-03-30 22:13:23.918+00	2025-2026
b868aae4-a093-49ef-a47f-226ece003c20	vuductien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Đức Tiến	DV	11C3	2026-03-30 22:13:23.949+00	2025-2026
15d04e4c-1805-4f4b-9a67-4e9cfb63dcc1	rolantiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Tiếp	DV	12B7	2026-03-30 22:13:23.949+00	2025-2026
c23896c1-fe3a-4ee3-8c69-b2a4fbf8f229	kpatieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpă Tiếu	DV	10A11	2026-03-30 22:13:23.949+00	2025-2026
904d7305-7ac3-4e18-99ec-6c244dadef12	kpuihylantina	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Y Lan Tina	DV	10A7	2026-03-30 22:13:23.949+00	2025-2026
660a0947-c91f-4a99-84e5-fa9f8502b2e3	buingoctinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Ngọc Tĩnh	DV	11C3	2026-03-30 22:13:23.949+00	2025-2026
7ec0c1b8-3ddd-4233-8731-24c0d95e61e4	hothitinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Tình	DV	12B5	2026-03-30 22:13:23.949+00	2025-2026
d7da7ca6-7c81-4b3c-bbe2-92422367f17e	kpuihh'tinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Tinh	DV	11C10	2026-03-30 22:13:23.949+00	2025-2026
2d5165e0-92d1-4870-bade-ed8ee0042f4c	leviettinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Viết Tình	DV	10A7	2026-03-30 22:13:23.949+00	2025-2026
647fb55e-1ff7-4751-8146-2884e218a829	luyentientinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Luyện Tiến Tình	DV	12B8	2026-03-30 22:13:23.949+00	2025-2026
72d71618-bc8c-4e5e-a99c-861a970ab7b2	nguyennhutinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Như Tình	DV	11C7	2026-03-30 22:13:23.95+00	2025-2026
2bce745d-b43f-49c5-b101-eafa05fb43b5	nguyensongtoan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Song Toàn	DV	10A9	2026-03-30 22:13:23.95+00	2025-2026
a83a94f9-a5d9-4c9e-af2b-c6bbcc65904a	duongthithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Thị Thùy Trang	DV	11C5	2026-03-30 22:13:23.95+00	2025-2026
c8efe833-34a7-4c97-a32d-fedb979be765	dangthihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thị Huyền Trang	DV	10A8	2026-03-30 22:13:23.95+00	2025-2026
dfc45a18-0252-47ca-a5cb-c4f1ca9fd20f	dinhthithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Thùy Trang	DV	10A5	2026-03-30 22:13:23.95+00	2025-2026
53866271-b5ae-495f-b0cb-abfd5ff5e6ae	dothihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Thị Huyền Trang	DV	11C8	2026-03-30 22:13:23.95+00	2025-2026
518b6d17-ab8b-4f67-a21a-41fa7f26fedd	nguyenhothanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồ Thanh Hà	DV	10A2	2026-03-30 22:13:23.918+00	2025-2026
a7b152a9-af67-47e0-b145-7952d39680f7	nguyenthanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thanh Hà	DV	11C5	2026-03-30 22:13:23.918+00	2025-2026
e525fca0-8571-4c67-a2ba-f58ad9a9ef14	nguyenthikhanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Khánh Hà	DV	10A11	2026-03-30 22:13:23.918+00	2025-2026
ca3331fb-35c4-419f-af47-3369de49844b	nguyenthithanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Hà	DV	10A8	2026-03-30 22:13:23.918+00	2025-2026
b2325aa7-a134-4af8-b182-3ba3867381e1	nguyenthuha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thu Hà	DV	11C1	2026-03-30 22:13:23.918+00	2025-2026
2d82ede8-fed3-4642-b788-b163bf9688db	nguyenxuanha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Hà	DV	11C10	2026-03-30 22:13:23.918+00	2025-2026
3f83f231-8ffe-48a7-8679-e94f5a51dde1	rochamh'ha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm H' Hà	DV	11C10	2026-03-30 22:13:23.918+00	2025-2026
d717b0e7-e646-456f-ba5f-67c401995326	romahh'ha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hạ	DV	10A8	2026-03-30 22:13:23.918+00	2025-2026
952718b9-5b5a-4f7a-ac4f-048ef5f79a77	romahh'ha1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hà	DV	12B8	2026-03-30 22:13:23.918+00	2025-2026
7cd473a8-ad24-4ed4-a7d7-5498774d4c58	trankhanhha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRẦN KHÁNH HÀ	DV	10A1	2026-03-30 22:13:23.918+00	2025-2026
ec20606d-f182-43e8-9c31-2831d89b1aa4	tranlethuha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRẦN LÊ THU HÀ	DV	12B6	2026-03-30 22:13:23.918+00	2025-2026
b6b4b866-904c-4147-8058-bd9503e666b0	tranthimyha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Mỹ Hạ	DV	11C8	2026-03-30 22:13:23.918+00	2025-2026
afeba88c-7b7c-44b2-a6ab-8e32e3aa8351	vuhaiha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Hải Hà	DV	11C4	2026-03-30 22:13:23.918+00	2025-2026
ae122b2b-573a-4166-b50a-3d9a44f5ae6e	hanquochai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hàn Quốc Hải	DV	10A7	2026-03-30 22:13:23.918+00	2025-2026
3e28cac8-3442-493b-800d-958d907de2f0	hongochai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Hải	DV	10A4	2026-03-30 22:13:23.918+00	2025-2026
fe250822-1743-4ed4-947e-ead3ab49725e	kpuihhai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Hải	DV	10A9	2026-03-30 22:13:23.918+00	2025-2026
962ee2d8-943a-43d7-846f-2b8b226689e1	kpuihh'han	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Han	DV	10A5	2026-03-30 22:13:23.918+00	2025-2026
afc80e0c-5f73-47f3-aae6-4db86607c5f3	doanthihonghanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Doãn Thị Hồng Hạnh	DV	11C12	2026-03-30 22:13:23.918+00	2025-2026
7aa2f7c6-73de-45a5-8e8b-01db61d09f11	hangochanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Ngọc Hạnh	DV	12B4	2026-03-30 22:13:23.918+00	2025-2026
fa2ffd63-1bb6-4011-b0ad-efa15134e8c1	hovinhhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Vĩnh Hạnh	DV	12B9	2026-03-30 22:13:23.918+00	2025-2026
eedab4c9-5481-45f1-be0a-95a9a29872b5	nguyenhonghanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồng Hạnh	DV	12B7	2026-03-30 22:13:23.918+00	2025-2026
c6c73dc6-1c56-43de-8257-a0ad0b02afe9	kpuihh'hao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KPUIH H' HAO	DV	12B6	2026-03-30 22:13:23.918+00	2025-2026
682dae34-867f-4436-a455-0ba9cd24980a	nguyenhao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN HÀO	DV	12B6	2026-03-30 22:13:23.918+00	2025-2026
9a76237f-f8ab-4648-b04c-ddb070260323	nguyenvanhao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Hào	DV	11C5	2026-03-30 22:13:23.918+00	2025-2026
796998c4-ca15-4826-b431-809403f9f508	romahh'hat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hát	DV	12B7	2026-03-30 22:13:23.918+00	2025-2026
0dc63b4c-4ba5-4713-9089-0d991cf83d1f	dinhthihang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Hằng	DV	10A9	2026-03-30 22:13:23.918+00	2025-2026
881b8e4f-f5d1-4b4a-a1da-8d9309c2a943	hoangthithuyhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	HOÀNG THỊ THÚY HẰNG	DV	12B6	2026-03-30 22:13:23.918+00	2025-2026
4b993bb5-f726-44e3-8103-6c92e7c6a4c1	lekhanhhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Khánh Hằng	DV	11C1	2026-03-30 22:13:23.918+00	2025-2026
48c0eb65-7977-438c-9908-8ee3046a5d10	lethithanhhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thanh Hằng	DV	12B5	2026-03-30 22:13:23.919+00	2025-2026
d2bd26a5-4b74-4d54-a45f-85702e1be5fc	luongthithuhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LƯƠNG THỊ THU HẰNG	DV	12B6	2026-03-30 22:13:23.919+00	2025-2026
44938273-e613-4bc8-836c-cdd3e873e764	nguyenduongthanhhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Dương Thanh Hằng	DV	10A8	2026-03-30 22:13:23.919+00	2025-2026
ce77075d-b0c0-485d-a4e1-88e48dca8ba6	nguyenthiminhhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Minh Hằng	DV	10A5	2026-03-30 22:13:23.919+00	2025-2026
aebaf307-8f23-45ac-a2f6-540d7885b51c	nguyenthithanhhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Hằng	DV	11C7	2026-03-30 22:13:23.919+00	2025-2026
d6348bf4-cca2-449b-9942-f471eb6b4dd0	phanthithuhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Thu Hằng	DV	10A8	2026-03-30 22:13:23.919+00	2025-2026
4c2ae244-155b-4b80-a77d-34ffb3ce27b5	tranthibichhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Bích Hằng	DV	12B2	2026-03-30 22:13:23.919+00	2025-2026
bbd73071-0e06-4531-9a67-46aee19a3aaf	dieugiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Diêu Gia Hân	DV	11C1	2026-03-30 22:13:23.919+00	2025-2026
c27d55fc-4baf-41c1-a806-f99da28c8297	duongbaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Bảo Hân	DV	10A7	2026-03-30 22:13:23.919+00	2025-2026
f4a4cf5e-2ae8-4b19-82d6-6b3fd64c9c29	daongochan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Ngọc Hân	DV	10A2	2026-03-30 22:13:23.919+00	2025-2026
27de9f85-d484-48fe-939e-181f2a0681a4	hagiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Gia Hân	DV	11C8	2026-03-30 22:13:23.919+00	2025-2026
6b540645-f917-4bf0-ad79-18b47e811cd0	ksorhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Hân	DV	10A9	2026-03-30 22:13:23.919+00	2025-2026
b60a9b48-5e74-4125-a365-b42b42314d3e	ksorngochan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Ngọc Hân	DV	12B10	2026-03-30 22:13:23.919+00	2025-2026
dfdff954-e6eb-463a-b379-cc212792fb1f	laihoangbaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lại Hoàng Bảo Hân	DV	11C12	2026-03-30 22:13:23.919+00	2025-2026
a23d9c86-0fa6-4447-833a-ff44d0a372ca	luonggiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Gia Hân	DV	12B10	2026-03-30 22:13:23.919+00	2025-2026
5bc1c3b4-c897-429a-a547-18d6d1ec0a7e	lygiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lý Gia Hân	DV	12B5	2026-03-30 22:13:23.919+00	2025-2026
7c58ae06-f783-45c7-b30d-595fb09b3561	nguyendiephan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Diệp Hân	DV	10A11	2026-03-30 22:13:23.919+00	2025-2026
24f9970a-d1c1-49e3-9f46-bbdfb30723ce	nguyengiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Gia Hân	DV	12B3	2026-03-30 22:13:23.919+00	2025-2026
ca6bf736-ecac-4db8-a528-9d6e846843b0	nguyenhoangbaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Bảo Hân	DV	11C3	2026-03-30 22:13:23.919+00	2025-2026
4b21f8cb-54a8-4b3f-91a8-da40d03832cd	nguyenngocbaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN NGỌC BẢO HÂN	DV	12B6	2026-03-30 22:13:23.919+00	2025-2026
a46b9a30-a23a-4ae6-9a46-27c8014c9836	nguyennubaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Nữ Bảo Hân	DV	10A8	2026-03-30 22:13:23.919+00	2025-2026
bb5da855-7d08-4633-b920-9b932968e740	nguyenthingochan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Hân	DV	11C12	2026-03-30 22:13:23.919+00	2025-2026
85f19d52-4949-4394-8b78-d7c4700bc788	phamngocgiahan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Ngọc Gia Hân	DV	12B1	2026-03-30 22:13:23.919+00	2025-2026
4b646045-5261-43d9-8e3c-0c185d301387	phamnguyenbaohan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Nguyễn Bảo Hân	DV	11C4	2026-03-30 22:13:23.919+00	2025-2026
8c88de8a-ed43-4022-b0da-fe78442d028c	romahh'han	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hần	DV	11C9	2026-03-30 22:13:23.919+00	2025-2026
0f567dd1-c472-4b82-83ab-c7b60d968c2e	romahhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Hân	DV	11C7	2026-03-30 22:13:23.919+00	2025-2026
1defbf5e-24ca-43f4-9cbf-9b7859a75114	hongochau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Hậu	DV	10A3	2026-03-30 22:13:23.919+00	2025-2026
b7b1df82-d8d9-4684-bbb2-b8f18bd91ada	nguyenconghau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Hậu	DV	10A1	2026-03-30 22:13:23.919+00	2025-2026
124defaa-8252-4c28-a882-ea648de5d437	nguyenphihau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phi Hậu	DV	10A7	2026-03-30 22:13:23.919+00	2025-2026
486bacfb-4d23-4f27-9721-40ea72b57134	phamconghau	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Công Hậu	DV	10A5	2026-03-30 22:13:23.919+00	2025-2026
6c53f7f8-b1af-4980-aab9-5d7049a9f5f0	dinhthithuyhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Thuý Hiền	DV	11C6	2026-03-30 22:13:23.919+00	2025-2026
f995eacc-328a-4736-8398-64b859a0bbed	lethihien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hiền	DV	12B9	2026-03-30 22:13:23.919+00	2025-2026
85d95601-5712-4a51-a5b4-bc6190e47eaa	lethithuhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thu Hiền	DV	12B4	2026-03-30 22:13:23.919+00	2025-2026
898ea72d-86b8-46ed-8700-ca00b6541e0f	nguyenhoangthuhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Thu Hiền	DV	11C2	2026-03-30 22:13:23.919+00	2025-2026
b27ffdd6-8127-4148-ad92-6c1d5adee51f	nguyenthanhhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thanh Hiền	DV	11C1	2026-03-30 22:13:23.92+00	2025-2026
d2997093-1fa8-4c79-927c-e7e961dc4458	nguyenthihien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hiền	DV	12B7	2026-03-30 22:13:23.92+00	2025-2026
7c75455c-c5bc-4afd-9f44-b5b69f85700d	nguyenthithuhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thu Hiền	DV	10A10	2026-03-30 22:13:23.92+00	2025-2026
0c0d6137-d303-479a-9449-33f109cad439	nguyenthithuhien1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thu Hiền	DV	12B7	2026-03-30 22:13:23.92+00	2025-2026
ed49bf81-674b-4019-b5d5-8344baedac5c	nguyenthuhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thu Hiền	DV	12B8	2026-03-30 22:13:23.92+00	2025-2026
4b47cf8b-005a-4eaf-8ce6-581ec7e6beab	voxuanhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Xuân Hiền	DV	10A5	2026-03-30 22:13:23.92+00	2025-2026
71bffe8c-3bad-421d-aa5c-63339238d025	vuhoangdieuhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Hoàng Diệu Hiền	DV	12B7	2026-03-30 22:13:23.92+00	2025-2026
26388c21-1cf2-48e9-9bd7-75b7d91b8cc0	vuongthihien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vương Thị Hiền	DV	12B4	2026-03-30 22:13:23.92+00	2025-2026
7fe3c694-407b-4e85-aff9-209c5f9d45d2	camtrunghiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cầm Trung Hiệp	DV	10A10	2026-03-30 22:13:23.92+00	2025-2026
d0835702-245c-424a-bdf1-dc26ecff9f6d	dauquangthoahiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đậu Quang Thỏa Hiệp	DV	11C11	2026-03-30 22:13:23.92+00	2025-2026
9f03f8fb-06fe-4e3b-ad94-1b05f516eded	kpuihhiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Hiệp	DV	12B10	2026-03-30 22:13:23.92+00	2025-2026
624a82ed-e1cd-4442-8271-e1624b1060bf	leminhhiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Minh Hiệp	DV	11C8	2026-03-30 22:13:23.92+00	2025-2026
7c529cc6-ee3d-45ab-be04-4994d2f6b469	nguyenxuanhiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Hiệp	DV	11C7	2026-03-30 22:13:23.92+00	2025-2026
e746bff8-06a7-4e21-9e07-80bad34c4a2a	romahh'hiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hiệp	DV	11C8	2026-03-30 22:13:23.92+00	2025-2026
76ecff3c-f87e-4695-8389-77770aa59023	hoangtrunghieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Trung Hiếu	DV	11C11	2026-03-30 22:13:23.92+00	2025-2026
6ca0399f-ec16-4962-a8c0-51b9a1b90c00	hoangvanhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Văn Hiếu	DV	11C2	2026-03-30 22:13:23.92+00	2025-2026
52d425f2-9c50-4034-831d-faac45b53ea8	leminhhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Minh Hiếu	DV	10A2	2026-03-30 22:13:23.92+00	2025-2026
225bdaee-4cc8-43eb-b580-885d2b6048f4	lephamconghieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Phạm Công Hiếu	DV	11C1	2026-03-30 22:13:23.92+00	2025-2026
3e5fe7ba-f4c3-4559-afbb-6c810eea323d	lequanghieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quang Hiếu	DV	11C12	2026-03-30 22:13:23.92+00	2025-2026
f12e285b-dfdf-467f-bd21-41edb84c37c3	maiduchieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Đức Hiếu	DV	11C9	2026-03-30 22:13:23.92+00	2025-2026
83bfb0e4-7156-48c2-8b71-6ca3d0a7e88a	ngoduchieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Đức Hiếu	DV	11C11	2026-03-30 22:13:23.92+00	2025-2026
b1567515-08b7-43bb-8fc8-74e7d04c2ee4	nguyenconghieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Hiếu	DV	12B10	2026-03-30 22:13:23.92+00	2025-2026
21f984e4-945f-4954-a423-a70eb91327b1	nguyendinhhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Hiếu	DV	10A8	2026-03-30 22:13:23.92+00	2025-2026
3027ddfe-17a1-4256-a098-fcea2c282ab8	nguyenduchieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Hiếu	DV	10A1	2026-03-30 22:13:23.92+00	2025-2026
b70efba4-7cc3-48b3-93e8-be3034c345ca	nguyenngochieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Hiếu	DV	11C9	2026-03-30 22:13:23.92+00	2025-2026
b0f79e6d-553a-4921-a6e8-04125221095d	nguyentrunghieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trung Hiếu	DV	11C4	2026-03-30 22:13:23.92+00	2025-2026
308fba46-285d-4d35-8d20-7a2362e017bb	nguyentrunghieu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trung Hiếu	DV	11C8	2026-03-30 22:13:23.92+00	2025-2026
df78c411-22eb-49df-82d7-29209a5c54b5	nguyenvanhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Hiếu	DV	10A1	2026-03-30 22:13:23.92+00	2025-2026
b0b427c8-9508-42a6-bc4a-6eaa64e74c4e	phamvanhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Văn Hiếu	DV	12B8	2026-03-30 22:13:23.92+00	2025-2026
12a985a9-15a3-419c-a9c4-e9de0403ccb5	tranminhhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Minh Hiếu	DV	11C11	2026-03-30 22:13:23.92+00	2025-2026
9d9a548a-7b11-4a1c-a20b-25add506ae52	tranminhhieu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRẦN MINH HIẾU	DV	12B6	2026-03-30 22:13:23.921+00	2025-2026
a742b7ce-b768-4717-b3ed-e30678ccc95f	truongvanhieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Văn Hiếu	DV	10A8	2026-03-30 22:13:23.921+00	2025-2026
3c740dcd-63a0-43be-aa06-b8c7b7f9a0a8	buimaihoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Mai Hoa	DV	11C9	2026-03-30 22:13:23.921+00	2025-2026
70041efb-9ca6-44a3-84ab-5ac57df35537	hothinhuhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Như Hoa	DV	10A11	2026-03-30 22:13:23.921+00	2025-2026
934b854c-996d-463e-a8fc-8ff058bac423	ksorhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Hòa	DV	11C9	2026-03-30 22:13:23.921+00	2025-2026
aa1c92e3-f2a0-4ae0-a21c-99667a5b77dd	nguyenkhanhhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khánh Hoà	DV	10A10	2026-03-30 22:13:23.921+00	2025-2026
b1130b39-c655-452a-9f50-cb09d4e2fc1d	phamkhanhhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Khánh Hoà	DV	11C12	2026-03-30 22:13:23.921+00	2025-2026
0e7a543c-8396-41b8-80e4-8e1dea21231e	hoangthithuhoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Thu Hoài	DV	10A5	2026-03-30 22:13:23.921+00	2025-2026
79a58664-396d-432a-9be3-33688ade19bd	vohuynhtrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Huỳnh Trung	DV	10A3	2026-03-30 22:13:23.952+00	2025-2026
ae44bc65-f3cb-42ab-9567-a91306d5382d	kpuihtruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Trực	DV	10A10	2026-03-30 22:13:23.952+00	2025-2026
4a4d8a23-974a-4f18-957f-adc0849d5d1f	letayhungtruong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Tây Hùng Trường	DV	11C9	2026-03-30 22:13:23.952+00	2025-2026
576470a5-677d-4132-ad1d-6c410884853f	habuicamtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Bùi Cẩm Tú	DV	10A6	2026-03-30 22:13:23.952+00	2025-2026
060a30d4-45bd-4b6c-a78e-5695975f58a7	hoanganhtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Anh Tú	DV	10A10	2026-03-30 22:13:23.952+00	2025-2026
4dcaf746-7a81-49f5-965e-887c761be0e3	khuatanhtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KHUẤT ANH TÚ	DV	12B6	2026-03-30 22:13:23.952+00	2025-2026
40e1d6c6-36ae-4ce8-80bb-0f02c0e5315d	lekhatuantu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Khả Tuấn Tú	DV	12B8	2026-03-30 22:13:23.952+00	2025-2026
4ab75180-6d49-4b47-b13d-97cc9d498904	levantuantu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Tuấn Tú	DV	10A10	2026-03-30 22:13:23.952+00	2025-2026
678fed63-9855-4ea7-826d-2efb8b30e423	luthanhtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lữ Thành Tú	DV	11C2	2026-03-30 22:13:23.952+00	2025-2026
ca966490-40dd-4229-9d85-ee3bf7d38b4a	nguyenthicamtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Cẩm Tú	DV	10A9	2026-03-30 22:13:23.952+00	2025-2026
3f7d8efb-6b0e-4b44-b7fa-c2b3842eee60	nguyenthicamtu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Cẩm Tú	DV	12B10	2026-03-30 22:13:23.952+00	2025-2026
4861c6de-6abd-4487-a37e-ae5d27614383	phananhtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	PHAN ANH TÚ	DV	12B6	2026-03-30 22:13:23.952+00	2025-2026
474ee748-d420-45dd-a97e-0c7714161f2e	trandinhtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đình Tú	DV	11C9	2026-03-30 22:13:23.952+00	2025-2026
5ac650c7-875e-4182-a5de-d508b413777c	tranxuantu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Xuân Tú	DV	11C5	2026-03-30 22:13:23.953+00	2025-2026
0f91339a-0aed-4c9e-99eb-0af1c285343c	hothithuhoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thu Hoài	DV	11C8	2026-03-30 22:13:23.921+00	2025-2026
94521fa2-b5f8-4fcf-8bf3-f14930e7f2ca	lethihoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hoài	DV	12B7	2026-03-30 22:13:23.921+00	2025-2026
37a01681-afa8-4f7f-adb9-d1906351b408	lethithuyhoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thúy Hoài	DV	10A1	2026-03-30 22:13:23.921+00	2025-2026
a77b9beb-27e9-4b74-b636-d42cc6a099d6	nguyenthithanhhoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Hoài	DV	11C6	2026-03-30 22:13:23.921+00	2025-2026
b0d05e1f-a1cf-4e46-9391-c71dc51c1e2a	nguyenthithuhoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thu Hoài	DV	11C6	2026-03-30 22:13:23.921+00	2025-2026
d7e031f2-9a50-4a0f-a3df-47e7fe95ab90	rolanh'hoai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Hoài	DV	11C6	2026-03-30 22:13:23.921+00	2025-2026
bdc10580-e75c-45af-9bca-6a541e5f52bc	buiviethoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Việt Hoàng	DV	10A3	2026-03-30 22:13:23.921+00	2025-2026
1d7c9a90-8eb9-4328-8c39-5401b3da64cb	chauthanhhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Châu Thanh Hoàng	DV	12B9	2026-03-30 22:13:23.921+00	2025-2026
a42f0d15-7ee4-449b-a4a8-ca0f08ee2335	dongochoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Ngọc Hoàng	DV	12B4	2026-03-30 22:13:23.921+00	2025-2026
d1ae189e-ab74-4ef8-83ac-6a0ee3ab56c7	hohuyhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Huy Hoàng	DV	10A11	2026-03-30 22:13:23.921+00	2025-2026
71d96d5b-a635-4b20-99bd-ba7d5dbcc387	leminhhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Minh Hoàng	DV	10A6	2026-03-30 22:13:23.921+00	2025-2026
5e83a375-66ab-4ed2-89e0-3b9183912e6d	maivanhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Văn Hoàng	DV	12B1	2026-03-30 22:13:23.921+00	2025-2026
0ab11ad5-5f02-4029-bc31-9a68f9216cb6	maivannguyenhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Văn Nguyên Hoàng	DV	10A3	2026-03-30 22:13:23.921+00	2025-2026
871e2eb7-9f55-4f1a-b36d-86f3fabc279a	nguyendanghoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đăng Hoàng	DV	10A4	2026-03-30 22:13:23.921+00	2025-2026
abbc4f33-6b51-4aef-b7ef-f0555c8a297b	nguyenduchoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Hoàng	DV	12B1	2026-03-30 22:13:23.921+00	2025-2026
d0c27aaa-c63a-48c8-82fd-6ba872aac373	nguyenhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng	DV	11C4	2026-03-30 22:13:23.921+00	2025-2026
12458b42-eb04-4245-b5d8-c5759e3394a8	nguyenhokhaihoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồ Khải Hoàng	DV	11C4	2026-03-30 22:13:23.921+00	2025-2026
cc4d9e2c-1ba6-42b4-b7fd-b4025ca6d326	nguyenhuyhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Huy Hoàng	DV	12B10	2026-03-30 22:13:23.921+00	2025-2026
d663bcc0-0bfe-4f98-a05c-1b5ce309b794	nguyenminhhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Minh Hoàng	DV	11C6	2026-03-30 22:13:23.921+00	2025-2026
d83bce28-7cb5-4537-97ce-73b903c2c10a	nguyensyhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Sỹ Hoàng	DV	11C9	2026-03-30 22:13:23.921+00	2025-2026
ad2e5438-b198-431d-80fc-1c301ca1c819	nguyenthiminhhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Minh Hoàng	DV	11C5	2026-03-30 22:13:23.921+00	2025-2026
5bf79d2a-29c3-4356-a3ad-f1c2e8dd18d4	nguyenvannguyenhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Nguyên Hoàng	DV	11C11	2026-03-30 22:13:23.922+00	2025-2026
20cbda14-8bed-4c98-9623-a27fa7acd645	nguyenviethoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Việt Hoàng	DV	10A6	2026-03-30 22:13:23.922+00	2025-2026
04bdcae0-463c-455b-8a52-460d9d678aca	phamtuanhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Tuấn Hoàng	DV	12B2	2026-03-30 22:13:23.922+00	2025-2026
1b79227b-be05-4bd8-8b7c-d0b50614e5ea	phanconghoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Công Hoàng	DV	11C6	2026-03-30 22:13:23.922+00	2025-2026
2f2eac83-c251-43e4-8ecb-a5794d24776c	tranbahoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Bá Hoàng	DV	10A10	2026-03-30 22:13:23.922+00	2025-2026
0d95c036-fa7d-45c8-a5fa-87a551f3eac5	tranduchoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đức Hoàng	DV	10A8	2026-03-30 22:13:23.922+00	2025-2026
1f997a0f-6043-4e8f-abd5-94a94f6150be	tranlehuyhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Lê Huy Hoàng	DV	12B2	2026-03-30 22:13:23.922+00	2025-2026
79b9b42f-1a37-4256-994a-9ee89232345c	vohuuhoang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hữu Hoàng	DV	10A9	2026-03-30 22:13:23.922+00	2025-2026
885da685-553f-4d50-a81e-57c66acaf89b	lethianhhong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Ánh Hồng	DV	11C1	2026-03-30 22:13:23.922+00	2025-2026
8bdacb76-9cbc-46c2-a12e-e9258a75d189	nguyenthihong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng	DV	10A6	2026-03-30 22:13:23.922+00	2025-2026
02b075c9-0078-4e73-9ff9-09470ff35de3	hoangthihop	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Hợp	DV	11C7	2026-03-30 22:13:23.922+00	2025-2026
29819a9a-e178-44d5-95db-e72aa1068b28	vovanhuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Văn Huân	DV	11C4	2026-03-30 22:13:23.922+00	2025-2026
b73022e8-128d-4005-9319-b9427e82cab3	hathikimhue	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Thị Kim Huệ	DV	10A2	2026-03-30 22:13:23.922+00	2025-2026
781d0a8e-8a3d-4043-bec8-60aeef1ffafb	kpuihh'hui	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KPUIH H' HÚI	DV	12B6	2026-03-30 22:13:23.922+00	2025-2026
4604f15c-3e40-4f3d-b587-000473460d3b	nguyenkhachung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khắc Hùng	DV	12B3	2026-03-30 22:13:23.922+00	2025-2026
d66e0e86-3c86-4400-94ce-3564ffa78fd8	nguyenngochung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Hùng	DV	12B10	2026-03-30 22:13:23.922+00	2025-2026
5b7cfa87-8deb-457b-a4b6-7972f0240d76	nguyenvanquochung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Quốc Hùng	DV	10A2	2026-03-30 22:13:23.922+00	2025-2026
45107cc6-6a88-4dd7-a45f-6ee747311739	phamdinhhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Đình Hùng	DV	12B7	2026-03-30 22:13:23.922+00	2025-2026
45785eb8-3ac4-4847-a178-8eac5a80a852	phanconghung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Công Hùng	DV	11C12	2026-03-30 22:13:23.922+00	2025-2026
307a18df-ee3f-4e31-98d1-6c2f86c0335c	siudotuanhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu Đỗ Tuấn Hùng	DV	11C3	2026-03-30 22:13:23.922+00	2025-2026
4516471a-29a0-4646-b27a-b21857c7adc8	vodaihung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Đại Hùng	DV	10A3	2026-03-30 22:13:23.922+00	2025-2026
ce8bf8d3-0efa-4ec4-ad01-eb86feb08bb1	vuongtienhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vương Tiến Hùng	DV	12B5	2026-03-30 22:13:23.922+00	2025-2026
ef74d687-927d-4fff-9fb7-b700625d99ef	duongconghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Công Huy	DV	12B3	2026-03-30 22:13:23.922+00	2025-2026
a546bef8-737c-4fab-a4ad-d550abfc8ee7	hosyhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Sỹ Huy	DV	12B2	2026-03-30 22:13:23.922+00	2025-2026
8941a9a5-de0a-4067-bce6-4e4117370e24	hosyhuy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Sỹ Huy	DV	12B2	2026-03-30 22:13:23.922+00	2025-2026
e89d59e0-c59c-45e2-a5c9-c2a5ebf9921a	hoviettuonghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Viết Tường Huy	DV	10A6	2026-03-30 22:13:23.922+00	2025-2026
5c45e22b-d122-433e-afec-98b6d94945b8	ledinhhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Huy	DV	10A5	2026-03-30 22:13:23.922+00	2025-2026
fe7a54c0-574a-4a50-8b75-8b87b895adf1	luonghoanghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Hoàng Huy	DV	10A11	2026-03-30 22:13:23.922+00	2025-2026
deac62e4-bb6c-4c64-b5b4-0a9aa7f50ea0	luongquochuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lường Quốc Huy	DV	11C5	2026-03-30 22:13:23.922+00	2025-2026
dc2f88d6-a36e-45ea-abb8-e8c19547eabd	luongtrunghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Trung Huy	DV	12B5	2026-03-30 22:13:23.922+00	2025-2026
dc3d15e6-51e1-4bc0-9a56-1c7625400985	nguyendanghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đăng Huy	DV	10A4	2026-03-30 22:13:23.922+00	2025-2026
731c7ac8-cc5e-48fa-b5ae-d66d4686252b	nguyenhoanggiahuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Gia Huy	DV	11C12	2026-03-30 22:13:23.922+00	2025-2026
f15bcb12-1ffa-4a3e-890a-f24b9f9e2751	nguyenhuuhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hữu Huy	DV	10A11	2026-03-30 22:13:23.922+00	2025-2026
3670a247-fcb9-4840-ac5e-53edd2d1767b	nguyenquanghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Huy	DV	11C10	2026-03-30 22:13:23.922+00	2025-2026
92ed90ba-48ca-42d6-98d1-09d35c0eeb96	nguyenquanghuy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Huy	DV	11C7	2026-03-30 22:13:23.922+00	2025-2026
2860c13a-3d05-4caf-8d09-16f1517d972f	nguyenquanghuy2	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Huy	DV	12B1	2026-03-30 22:13:23.923+00	2025-2026
4f2b6817-b7cd-4bfc-b288-8e0bc6ee35ef	nguyentrangiahuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Gia Huy	DV	12B1	2026-03-30 22:13:23.923+00	2025-2026
d3088d73-0b52-4398-81fb-76688347987e	nguyenvanhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Huy	DV	10A4	2026-03-30 22:13:23.923+00	2025-2026
8452fcd5-3022-4a55-b30e-3728a91b3716	nguyenvanhuy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Huy	DV	11C3	2026-03-30 22:13:23.923+00	2025-2026
b2493a67-ce65-44e4-91ae-dc80addf433d	phanlequochuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Lê Quốc Huy	DV	10A9	2026-03-30 22:13:23.923+00	2025-2026
7a7a2468-8f3f-49ca-bd4e-8ea33df35c9a	phantanhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Tấn Huy	DV	11C5	2026-03-30 22:13:23.923+00	2025-2026
f418f400-369f-4388-95b5-8679eaa8068f	romahhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RƠ MAH HÚY	DV	12B6	2026-03-30 22:13:23.923+00	2025-2026
2bde82d3-0277-437e-8dc9-387f778dc2ec	tranquanghuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Quang Huy	DV	12B2	2026-03-30 22:13:23.923+00	2025-2026
7c5ca1cc-43f9-4cd5-b5e1-19380b673aad	vodinhhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Đình Huy	DV	10A4	2026-03-30 22:13:23.923+00	2025-2026
52dc1f09-4f9e-4962-8f75-3931f7f55fa6	vuquochuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Quốc Huy	DV	11C10	2026-03-30 22:13:23.923+00	2025-2026
6cf73c91-fa4d-477a-8c3d-9662cbb23810	dinhngockhanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Ngọc Khánh Huyền	DV	10A1	2026-03-30 22:13:23.923+00	2025-2026
4612429c-b9c0-41b4-bac3-829adc9f59b1	hoangthithanhthanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Thanh Thanh Huyền	DV	10A6	2026-03-30 22:13:23.923+00	2025-2026
a7217ea1-485a-4a25-8283-3cbc7c247597	hoangthithuhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Thu Huyền	DV	12B2	2026-03-30 22:13:23.923+00	2025-2026
f5a69eaf-b76a-436b-925b-94eba2478e41	lethiluuhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Lưu Huyền	DV	10A11	2026-03-30 22:13:23.923+00	2025-2026
e93461d8-a992-46c3-b97f-28fc8f70489e	lethuhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thu Huyền	DV	10A3	2026-03-30 22:13:23.923+00	2025-2026
fc8b1756-d288-4576-b51d-df784122e3c7	nguyenlethuhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Thu Huyền	DV	10A8	2026-03-30 22:13:23.923+00	2025-2026
462589ef-5080-4f12-b45e-3c0e636fbc35	nguyenthanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thanh Huyền	DV	11C3	2026-03-30 22:13:23.923+00	2025-2026
076e4509-3a43-44c3-94ca-e49b2a9bee1c	nguyenthikhanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ KHÁNH HUYỀN	DV	12B6	2026-03-30 22:13:23.923+00	2025-2026
81a9f6fa-de3b-4c13-9841-3d908ef7a31a	nguyenthithuhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thu Huyền	DV	12B4	2026-03-30 22:13:23.923+00	2025-2026
50cd949b-d8ff-4c6d-8db5-82174c453e16	phanngockhanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Ngọc Khánh Huyền	DV	11C6	2026-03-30 22:13:23.923+00	2025-2026
43a5e974-2f81-4598-81bb-d1305f454a7b	rochamh'huyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm H' Huyền	DV	10A6	2026-03-30 22:13:23.923+00	2025-2026
e4ddea11-3fc9-44b3-a671-dc4e474d0a95	trankhanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Khánh Huyền	DV	11C6	2026-03-30 22:13:23.923+00	2025-2026
6d955b98-c7e9-41e4-b411-16f01f071208	tranngochuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Ngọc Huyền	DV	10A8	2026-03-30 22:13:23.923+00	2025-2026
3a45efab-846f-4617-be7a-b4ae9c8cc7b7	tranthikhanhhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Khánh Huyền	DV	10A5	2026-03-30 22:13:23.923+00	2025-2026
012ca900-47a1-4e29-a598-c882fb679550	tranthingochuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Ngọc Huyền	DV	10A7	2026-03-30 22:13:23.923+00	2025-2026
b6a39743-0e3f-4b2d-9a2c-720d99fb2f92	mainguyentuanhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Nguyễn Tuấn Hưng	DV	11C7	2026-03-30 22:13:23.923+00	2025-2026
d369c80f-c2d0-40b1-bb55-80ad222b8cf0	nguyenhonhathung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồ Nhật Hưng	DV	11C12	2026-03-30 22:13:23.923+00	2025-2026
424fc374-be13-4046-80d2-e5f0279af66e	nguyenngochung1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Hưng	DV	11C8	2026-03-30 22:13:23.923+00	2025-2026
f985fcf4-e753-4bdf-a557-884160447655	nguyenphungtuanhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phùng Tuấn Hưng	DV	10A4	2026-03-30 22:13:23.923+00	2025-2026
e8921063-22ca-4356-b7a8-08b5ea52a1e1	phamquochung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Quốc Hưng	DV	10A1	2026-03-30 22:13:23.923+00	2025-2026
b1446693-4474-4ed2-b6d9-cb9493652e04	trangiahung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Hưng	DV	12B9	2026-03-30 22:13:23.923+00	2025-2026
a57d3660-34af-418b-90d3-f8de3af764c0	voduyhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Duy Hưng	DV	12B9	2026-03-30 22:13:23.923+00	2025-2026
6278ea43-ca3d-4cae-98d8-825257e2c5b1	camthihuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cầm Thị Hường	DV	11C9	2026-03-30 22:13:23.923+00	2025-2026
eb42eb74-fee2-4435-9238-14b11405e7f1	daoduyhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Duy Hưởng	DV	12B2	2026-03-30 22:13:23.923+00	2025-2026
7bdbddb2-ce09-4d1b-8e5c-5f8cabd1a32d	dangthuhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thu Hường	DV	12B4	2026-03-30 22:13:23.924+00	2025-2026
49b5ae73-121e-4be9-9d21-2b1fa33df9d1	dinhthihuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Hương	DV	12B4	2026-03-30 22:13:23.924+00	2025-2026
47a6e6bf-053b-4351-8c84-2881d7c03b29	dinhthinhahuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Nhã Hương	DV	10A2	2026-03-30 22:13:23.924+00	2025-2026
f4909b5d-2608-4d68-ae18-0f1b770792a6	hathilanhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Thị Lan Hương	DV	12B7	2026-03-30 22:13:23.924+00	2025-2026
70fbb719-74f8-4efc-a804-3016b3206640	hoangthicuchuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Cúc Hương	DV	10A6	2026-03-30 22:13:23.924+00	2025-2026
51d18e2d-63a1-495e-9aee-a9c179533fcd	hohoanghuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hoàng Hưởng	DV	11C5	2026-03-30 22:13:23.924+00	2025-2026
08638e39-1d7e-47f0-9b0a-3d2057022c9a	lethilanhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Lan Hương	DV	11C10	2026-03-30 22:13:23.924+00	2025-2026
1e0bac6b-dfb8-4227-80ad-753e9a7827d4	lethithuhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thu Hương	DV	10A7	2026-03-30 22:13:23.924+00	2025-2026
642a4b28-7049-4a7f-84c3-433a6eeed565	nguyenngocgianghuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Giáng Hương	DV	12B1	2026-03-30 22:13:23.924+00	2025-2026
c72b2fc1-a75b-44e8-8fbf-412044f11534	nguyenthihuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hương	DV	10A8	2026-03-30 22:13:23.924+00	2025-2026
53b5b0dc-81e3-475f-a9fb-ede974f06e38	truongvucamtu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Vũ Cẩm Tú	DV	11C4	2026-03-30 22:13:23.953+00	2025-2026
636e09ae-ac90-4a81-b33b-a9cd2b32993a	docongtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Công Tuấn	DV	12B1	2026-03-30 22:13:23.953+00	2025-2026
882c9911-876f-4917-94b8-41d532b3cc10	hanquoctuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hàn Quốc Tuấn	DV	10A5	2026-03-30 22:13:23.953+00	2025-2026
e2d82c85-f014-4f01-9894-32b55060db21	hoanganhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Anh Tuấn	DV	11C7	2026-03-30 22:13:23.953+00	2025-2026
f6b266fb-d95e-485b-9fe0-b56bf0bf4894	hosytuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Sỹ Tuấn	DV	10A11	2026-03-30 22:13:23.953+00	2025-2026
4ac35f25-11a2-46c2-8492-f8bf8e645a61	leanhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Anh Tuấn	DV	11C2	2026-03-30 22:13:23.953+00	2025-2026
2bf54ce8-d19a-4cd5-b2d7-d2b9fc3fac3e	ledinhanhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Anh Tuấn	DV	10A7	2026-03-30 22:13:23.953+00	2025-2026
117ea204-24a2-43c6-a91d-5c04f3f7f29f	lehoangtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hoàng Tuấn	DV	11C3	2026-03-30 22:13:23.953+00	2025-2026
f8a5c1f4-f363-4d16-ab95-388ac0bb1ba5	levananhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Anh Tuấn	DV	12B5	2026-03-30 22:13:23.953+00	2025-2026
edeaaa5d-c0c8-404b-8dbe-c4be24135f28	nguyendinhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Tuân	DV	10A2	2026-03-30 22:13:23.953+00	2025-2026
c6bfb578-bc12-4685-ba34-39c89430f445	nguyenkhacanhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khắc Anh Tuấn	DV	10A3	2026-03-30 22:13:23.953+00	2025-2026
83ee3a15-c2bd-4fe0-bc6e-769f5635fe9b	nguyenquoctuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quốc Tuấn	DV	12B8	2026-03-30 22:13:23.953+00	2025-2026
729229d2-62db-4b78-9740-f3c23fbea163	nguyenvantuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Tuấn	DV	11C11	2026-03-30 22:13:23.953+00	2025-2026
f28afa01-db4b-445e-b418-631471424d96	phannguyenanhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Nguyễn Anh Tuấn	DV	11C9	2026-03-30 22:13:23.953+00	2025-2026
3915bb90-8daa-4de8-a119-01a0b8690990	nguyenthilanhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Lan Hương	DV	11C3	2026-03-30 22:13:23.924+00	2025-2026
525f488d-7b9c-4b8a-aaa3-1ab42f9bf95f	rolanh'huong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Hường	DV	10A10	2026-03-30 22:13:23.924+00	2025-2026
4689d601-3493-4476-ab49-2facf9ce5401	tranthilanhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Lan Hương	DV	12B3	2026-03-30 22:13:23.924+00	2025-2026
2362c6dd-7e70-4f60-877a-e2b07e38104c	doquanghuu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Quang Hữu	DV	11C10	2026-03-30 22:13:23.924+00	2025-2026
33b52b1b-5a66-42d0-93de-d4b442f712fa	r'mahhy-lia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	R' Mah Hy-lia	DV	11C9	2026-03-30 22:13:23.924+00	2025-2026
5da66952-3559-4cbd-99fa-2a1cb31fad4b	romahh'hyung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Hyưng	DV	11C10	2026-03-30 22:13:23.924+00	2025-2026
40069566-c674-4a80-a5c9-8dbb2de5ba5b	rmahh'jin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RMah H' Jin	DV	11C6	2026-03-30 22:13:23.924+00	2025-2026
8435e1a5-c140-4c62-a0de-b1109215d7c0	romahh'jin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Jin	DV	10A8	2026-03-30 22:13:23.924+00	2025-2026
d68d7067-d378-4abd-b217-2b5e20190bf7	nguyennhatkha	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Nhật Kha	DV	10A8	2026-03-30 22:13:23.924+00	2025-2026
ef531d58-4472-4be6-9553-4d754c64fa4c	lequangkhai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quang Khải	DV	11C1	2026-03-30 22:13:23.924+00	2025-2026
44cd20b3-3eee-44e8-ac34-0f4aab05a2d3	lehuukhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hữu Khang	DV	10A7	2026-03-30 22:13:23.924+00	2025-2026
ec2bf18a-8dac-4b68-9e27-c3da3c39d257	nguyenthekhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thế Khang	DV	11C3	2026-03-30 22:13:23.924+00	2025-2026
c7607134-caee-48c6-96e9-7e6f67eded5b	phannguyenkhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Nguyên Khang	DV	11C2	2026-03-30 22:13:23.924+00	2025-2026
b644f4ef-424e-4b84-aa80-6e7f854c8c87	rolankhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Khàng	DV	10A11	2026-03-30 22:13:23.924+00	2025-2026
01139585-3012-40a6-97c9-4903a7caf260	siuchamkhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu Châm Khang	DV	11C10	2026-03-30 22:13:23.924+00	2025-2026
a5c1116b-0d28-4187-a45e-5ef190a2d965	vunguyenankhang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Nguyễn An Khang	DV	11C12	2026-03-30 22:13:23.924+00	2025-2026
da2bd1b3-a56d-44e5-b1bb-9df4c77937f7	daovietkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Viết Khánh	DV	10A1	2026-03-30 22:13:23.924+00	2025-2026
ad33da41-d847-486d-8980-7e7002428b7f	ledinhkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Khánh	DV	10A6	2026-03-30 22:13:23.924+00	2025-2026
28152251-59f5-4278-a8e6-8f339176b735	lekhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Khanh	DV	12B10	2026-03-30 22:13:23.924+00	2025-2026
bceeae31-2207-4776-ad7d-175ed20107f2	levankhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Khánh	DV	12B7	2026-03-30 22:13:23.924+00	2025-2026
5a690e4d-9e3b-4953-bac9-a1ab3dcbf1dc	luuthiphuongkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lưu Thị Phương Khanh	DV	10A5	2026-03-30 22:13:23.924+00	2025-2026
48a18a5a-af50-4dfd-9392-e4682a6ca618	maixuankhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Xuân Khánh	DV	11C12	2026-03-30 22:13:23.924+00	2025-2026
2393030b-b5dc-41bd-ac4b-eeecfa60a204	nguyenduykhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Duy Khánh	DV	10A6	2026-03-30 22:13:23.924+00	2025-2026
517a3303-0de8-4966-ba41-9ce4c392ab30	nguyenducnhatkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Nhật Khánh	DV	11C1	2026-03-30 22:13:23.924+00	2025-2026
451244b2-c851-4edd-bf89-7111b03e1789	nguyenhoanggiakhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Gia Khánh	DV	11C5	2026-03-30 22:13:23.925+00	2025-2026
359a2241-4794-4b5b-aed0-cd09c52dd686	nguyenphungkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phùng Khánh	DV	11C12	2026-03-30 22:13:23.925+00	2025-2026
a5f4b0b6-8ca7-46f5-8347-7f5b537b4b2e	phamdinhkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Đình Khánh	DV	11C2	2026-03-30 22:13:23.925+00	2025-2026
0c80609c-c675-4082-87b7-8dea92db063e	tranlengockhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Lê Ngọc Khánh	DV	12B7	2026-03-30 22:13:23.925+00	2025-2026
a014ca9e-398a-407f-bb1b-08c0b995e15d	tranthienkhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thiên Khánh	DV	11C2	2026-03-30 22:13:23.925+00	2025-2026
446b613a-06f3-42c6-8716-686b26b619c0	tranvankhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Khánh	DV	10A7	2026-03-30 22:13:23.925+00	2025-2026
6e00aa2c-ddc3-48a3-b582-6b84caca174e	votrangiakhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Trần Gia Khánh	DV	10A10	2026-03-30 22:13:23.925+00	2025-2026
13c804bc-ac3c-4529-a782-30301a2c48e2	rolanhkham	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H Khâm	DV	12B8	2026-03-30 22:13:23.925+00	2025-2026
b44f7a40-5d43-4404-b1ff-8b150d9bfcd4	rolanakhien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan A Khiển	DV	10A11	2026-03-30 22:13:23.925+00	2025-2026
87e5108f-fe52-4066-b43c-949d15a9be6b	rolankhiep	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Khiếp	DV	10A9	2026-03-30 22:13:23.925+00	2025-2026
0c89aff7-106a-44e9-881e-1661c6e7a404	khuatanhkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Khuất Anh Khoa	DV	10A9	2026-03-30 22:13:23.925+00	2025-2026
0eca612a-2440-4693-8cff-fbc69134aee7	kpuihkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Khoa	DV	12B7	2026-03-30 22:13:23.925+00	2025-2026
82c43a73-56be-46f2-9489-1496c44928dd	nguyendangkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đăng Khoa	DV	11C6	2026-03-30 22:13:23.925+00	2025-2026
d2b6c861-67fc-4127-ac94-9da464307ecf	nguyentrongkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trọng Khoa	DV	10A9	2026-03-30 22:13:23.925+00	2025-2026
4622bef3-1ae4-4ecf-8c3f-ab59a25ed564	trananhkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Anh Khoa	DV	11C3	2026-03-30 22:13:23.925+00	2025-2026
bab359b5-e3a0-4466-bfb7-b22c7eeb7cfb	trandangkhoa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đăng Khoa	DV	10A4	2026-03-30 22:13:23.925+00	2025-2026
d0011d10-cac3-41cc-981e-290098d6b4ea	donggiakhoi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đồng Gia Khôi	DV	11C3	2026-03-30 22:13:23.925+00	2025-2026
27dbb179-1626-41ce-98a2-a528ef604809	nguyentranminhkhoi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Minh Khôi	DV	12B5	2026-03-30 22:13:23.925+00	2025-2026
ffd97854-f551-48c7-a80a-cae4342cbf16	ksorkhoi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Khởi	DV	12B10	2026-03-30 22:13:23.925+00	2025-2026
2f197de1-eaaf-496f-b4a0-4e3cd7fe8e1f	kpuihkhruin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Khruin	DV	10A11	2026-03-30 22:13:23.925+00	2025-2026
62d587dd-05da-407b-b442-c9e5a7f4a2bf	caothuckhue	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thục Khuê	DV	10A11	2026-03-30 22:13:23.925+00	2025-2026
e47c70aa-67d3-4360-9132-bf81b16efbd2	ksorh'khue	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Khuê	DV	10A6	2026-03-30 22:13:23.925+00	2025-2026
1196c296-2b94-4a16-b384-75cb82c68f5d	kpuihkhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Khuyên	DV	11C6	2026-03-30 22:13:23.925+00	2025-2026
f6084e38-3cf1-4d51-8233-94fc6c277ff1	rolanh'khuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Khuyên	DV	10A8	2026-03-30 22:13:23.925+00	2025-2026
2ac73a47-315e-4a1a-96a5-09f2ffcf1b3f	nguyenvutuankiem	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Vũ Tuấn Kiểm	DV	10A10	2026-03-30 22:13:23.925+00	2025-2026
05841a7e-4f88-4edb-b4d9-e496544347eb	buihuukien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Hữu Kiên	DV	10A9	2026-03-30 22:13:23.925+00	2025-2026
1914a2ae-abf8-487a-89f7-b4a26e66c4be	lengockien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LÊ NGỌC KIÊN	DV	12B6	2026-03-30 22:13:23.925+00	2025-2026
8f8498ed-1949-4ef7-b334-f224d19cfb63	nguyenquangkien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Kiên	DV	10A1	2026-03-30 22:13:23.925+00	2025-2026
c19599da-e11e-483c-80eb-a4ae689fff08	trandoankien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Doãn Kiên	DV	10A8	2026-03-30 22:13:23.925+00	2025-2026
327a7b9e-dd78-4c2b-ade0-66fe6154a99a	kpuihkiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Kiệt	DV	10A10	2026-03-30 22:13:23.925+00	2025-2026
1802daa8-048b-4599-943e-4b04adc1092e	luongnguyenanhkiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Nguyễn Anh Kiệt	DV	12B3	2026-03-30 22:13:23.925+00	2025-2026
0757be8b-313a-4e17-adf9-7f9bf65412ac	mavankiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mã Văn Kiệt	DV	10A7	2026-03-30 22:13:23.925+00	2025-2026
5b3901ef-929b-4f46-8043-989ca530bb40	nguyentuankiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tuấn Kiệt	DV	10A9	2026-03-30 22:13:23.926+00	2025-2026
cf2ce2a4-48f8-47f5-9e3a-3de24cad8c1d	nguyenvanquockiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Quốc Kiệt	DV	10A6	2026-03-30 22:13:23.926+00	2025-2026
3f96a8d3-38e7-46c2-b905-bd223e62b10a	phamngoccaokiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Ngọc Cao Kiệt	DV	10A5	2026-03-30 22:13:23.926+00	2025-2026
7943d31e-1d96-4bfd-8a13-ea882c49f921	romahkiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Kiệt	DV	10A10	2026-03-30 22:13:23.926+00	2025-2026
0bf1b2b0-e761-4243-8a40-967a4ec00336	hothithuykieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thúy Kiều	DV	11C9	2026-03-30 22:13:23.926+00	2025-2026
c2e68439-cfbb-4e59-8014-2dc9cdb6752b	lethithuykieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thúy Kiều	DV	12B10	2026-03-30 22:13:23.926+00	2025-2026
8788bb0c-8e88-4ca3-9acc-ce43781b3b1e	nguyenanhky	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Anh Kỳ	DV	11C2	2026-03-30 22:13:23.926+00	2025-2026
aacf6718-63e2-4198-8371-92be272f9c92	nguyenhonglai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hồng Lai	DV	11C7	2026-03-30 22:13:23.926+00	2025-2026
9a1d9ee6-40ac-4902-95c7-aa410693ed99	daoquachhalan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Quách Hạ Lan	DV	11C6	2026-03-30 22:13:23.926+00	2025-2026
bd3a6000-8bff-4a49-a69d-5777b0a67bae	dohalan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Hà Lan	DV	11C7	2026-03-30 22:13:23.926+00	2025-2026
9eab1f33-a7a4-445d-9664-186d2991dd41	nguyenngoclan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Lan	DV	10A3	2026-03-30 22:13:23.926+00	2025-2026
8dd97e81-5ad0-45a2-8b1a-bbb5dcd4212b	nguyenthimailan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mai Lan	DV	11C8	2026-03-30 22:13:23.926+00	2025-2026
78956886-8f9b-4718-a0ae-6755abd80b97	romahh'lan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Lan	DV	12B7	2026-03-30 22:13:23.926+00	2025-2026
d7521d66-c74b-475a-8c29-7c7ceb6b8f3a	tranthingoclan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Ngọc Lan	DV	11C9	2026-03-30 22:13:23.926+00	2025-2026
67b6bebf-25aa-4674-a7cf-d3f8f65d41c8	romahh'lang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Lang	DV	11C7	2026-03-30 22:13:23.926+00	2025-2026
56b5087e-9d66-445c-ae25-8b1b854a2342	kpuihh'lak	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Lăk	DV	10A5	2026-03-30 22:13:23.926+00	2025-2026
938457a4-dc6e-473e-8c39-7bb1d1e469ad	dodinhlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Đình Lâm	DV	12B8	2026-03-30 22:13:23.926+00	2025-2026
8adec379-00c3-464e-9d7a-841a2362d41e	hathanhlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Thanh Lâm	DV	10A10	2026-03-30 22:13:23.926+00	2025-2026
0ca72c6d-69e0-4935-ac74-0e51f0a657b1	hoangtunglam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Tùng Lâm	DV	10A11	2026-03-30 22:13:23.926+00	2025-2026
d5971d09-e526-4d3a-9ab3-2063d9b2a58e	ledinhlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Lâm	DV	10A4	2026-03-30 22:13:23.926+00	2025-2026
cfdeb37f-369a-4495-9a44-fe4e568f3dc4	maithanhlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thanh Lâm	DV	12B2	2026-03-30 22:13:23.926+00	2025-2026
f2035e21-d869-41dc-aa40-b6c160eb4a26	nguyenhailam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hải Lâm	DV	12B7	2026-03-30 22:13:23.926+00	2025-2026
7d04264b-ceeb-46c6-85c5-8bc8db102251	nguyenvanlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Lâm	DV	11C11	2026-03-30 22:13:23.926+00	2025-2026
7af5d484-735c-4189-b8e5-d3053cdccb60	phanngoclam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Ngọc Lâm	DV	11C2	2026-03-30 22:13:23.926+00	2025-2026
6e6c98db-4ab5-4308-8295-9ef71a6a447b	rolanlam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Lâm	DV	11C8	2026-03-30 22:13:23.926+00	2025-2026
3cd9b248-47ed-46b2-9f85-d6a40bbeddbb	vudothuylam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Đỗ Thùy Lâm	DV	11C6	2026-03-30 22:13:23.926+00	2025-2026
7d0707b5-e8df-4d9c-8d99-876fa8a1a975	doanthimyle	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Thị Mỹ Lệ	DV	11C7	2026-03-30 22:13:23.926+00	2025-2026
3d1a2db0-4891-410a-b2c5-2612a0735dda	rochamh'le	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm H' Lệ	DV	12B7	2026-03-30 22:13:23.926+00	2025-2026
c464ebfb-c072-4018-9785-ef671e9d1729	romahh'le	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Lệ	DV	11C9	2026-03-30 22:13:23.926+00	2025-2026
276d7b51-4f31-4083-b819-26aa97b10bfd	siuh'li-ya	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu H' Li-ya	DV	11C7	2026-03-30 22:13:23.926+00	2025-2026
0f90fc8a-bc36-4442-a5d8-aeb335ed79b9	ksorh'lia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KSOR H' LIA	DV	11C11	2026-03-30 22:13:23.927+00	2025-2026
b4102cea-d65b-4159-a5d6-db0fa1ebd5fc	romahliem	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Liêm	DV	11C6	2026-03-30 22:13:23.927+00	2025-2026
e6a24346-fe4a-46d8-9dc7-6e60e4388706	romahh'lien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Liên	DV	10A5	2026-03-30 22:13:23.927+00	2025-2026
b93a739f-6058-4023-8d67-2387e702b054	kpuihh'lin	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Lin	DV	10A7	2026-03-30 22:13:23.927+00	2025-2026
6a4a6a04-a60a-4f80-8123-3d5a85f2d8c0	buithikhanhlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Khánh Linh	DV	10A5	2026-03-30 22:13:23.927+00	2025-2026
768c2643-1982-4816-97a7-615069cf9c83	buithimylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Mỹ Linh	DV	10A6	2026-03-30 22:13:23.927+00	2025-2026
89735822-089e-4d80-bcf5-2282e3606580	chuthithanhlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Chu Thị Thanh Linh	DV	10A7	2026-03-30 22:13:23.927+00	2025-2026
b27348ca-6655-46dd-b67a-b710d3058e9e	daothithuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Thị Thùy Linh	DV	10A5	2026-03-30 22:13:23.927+00	2025-2026
596a4f59-fcf1-4b25-9669-6c44eb131990	danghophuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Hồ Phương Linh	DV	10A9	2026-03-30 22:13:23.927+00	2025-2026
13334410-a157-42e5-ae79-4048922dbb55	dangthihalinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thị Hà Linh	DV	11C6	2026-03-30 22:13:23.927+00	2025-2026
6d35ef4f-a457-4126-a102-2b2e96b1566b	dangthuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thùy Linh	DV	11C8	2026-03-30 22:13:23.927+00	2025-2026
2f8e2b5a-7541-41c9-b293-f9d784beaaa1	dinhthithuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Thùy Linh	DV	11C8	2026-03-30 22:13:23.927+00	2025-2026
e367a758-ddc8-4da8-a094-1baa47b56122	dinhthitruclinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Trúc Linh	DV	12B9	2026-03-30 22:13:23.927+00	2025-2026
ece3e61f-d587-4e2e-85a5-abf10ba0271e	hoangthikhanhlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Khánh Linh	DV	12B10	2026-03-30 22:13:23.927+00	2025-2026
a1445617-a231-4358-a2cd-44383c8f74e0	phantrongtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Trọng Tuấn	DV	11C5	2026-03-30 22:13:23.953+00	2025-2026
c6010e99-8080-4069-82bb-aa314862ae96	romahtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Tuấn	DV	12B5	2026-03-30 22:13:23.953+00	2025-2026
632a06be-ad99-4b26-aef7-449e4bc8b8a1	trannguyentuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Nguyên Tuấn	DV	11C2	2026-03-30 22:13:23.953+00	2025-2026
b5d217b3-0544-46ea-a49a-0195f9a9747d	trinhdinhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Đình Tuấn	DV	11C5	2026-03-30 22:13:23.953+00	2025-2026
c86efeed-ca25-40c4-9720-225a51544676	vuhoangminhtuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Hoàng Minh Tuấn	DV	10A6	2026-03-30 22:13:23.953+00	2025-2026
d050b6fd-e325-493a-8e05-d0c0275faeda	rolanh'tue	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RƠ LAN H' TUỆ	DV	12B6	2026-03-30 22:13:23.953+00	2025-2026
64c89116-c15c-4c0e-85b6-4877d3283c1d	romahh'tue	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Tuệ	DV	12B5	2026-03-30 22:13:23.953+00	2025-2026
1b21e69e-01ae-4bdc-978d-c6dbecdad245	caodangquangtung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Đăng Quang Tùng	DV	11C2	2026-03-30 22:13:23.953+00	2025-2026
3459bbdf-b9da-47ac-bd5e-afb838db2218	phandinhtung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Đình Tùng	DV	10A9	2026-03-30 22:13:23.953+00	2025-2026
b70f8181-b544-486b-b6e0-8550ac38724b	tongminhtung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tống Minh Tùng	DV	10A11	2026-03-30 22:13:23.953+00	2025-2026
f597bec1-4948-4f7d-97c4-621994acab43	vusontung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Sơn Tùng	DV	11C2	2026-03-30 22:13:23.953+00	2025-2026
cb7bda01-51e9-409c-b9dd-ef4b72434392	mathikimtuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mã Thị Kim Tuyến	DV	11C11	2026-03-30 22:13:23.953+00	2025-2026
de674486-bf94-47df-8e23-b3e387854797	maitrungtuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Trung Tuyển	DV	11C8	2026-03-30 22:13:23.953+00	2025-2026
d6c6aebb-6651-47d5-9572-18edbe6ba915	tuthingoctuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Từ Thị Ngọc Tuyên	DV	12B3	2026-03-30 22:13:23.953+00	2025-2026
b5efc8dc-cf04-4d0c-a350-3a156ed0b123	kpuihh'tuyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Tuyết	DV	11C9	2026-03-30 22:13:23.953+00	2025-2026
1ea513b2-5aa9-4d7d-9581-4835166d64e3	holephuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Lê Phương Linh	DV	12B5	2026-03-30 22:13:23.927+00	2025-2026
fc809f5c-b683-4ddf-baaa-e837717a7045	hothimylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Mỹ Linh	DV	10A5	2026-03-30 22:13:23.927+00	2025-2026
b7e50aac-903e-4304-a065-237a2e1426ea	ksormailinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Mai Linh	DV	11C8	2026-03-30 22:13:23.927+00	2025-2026
31878df7-b924-43e5-b98b-f08bd57942af	lethithuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thùy Linh	DV	10A7	2026-03-30 22:13:23.927+00	2025-2026
43ec10ff-80dd-4eae-baec-37621d74894b	lethithuylinh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LÊ THỊ THÙY LINH	DV	12B6	2026-03-30 22:13:23.927+00	2025-2026
941b1dee-68ef-45a1-b38f-174f3a67216e	luthimylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lữ Thị Mỹ Linh	DV	10A3	2026-03-30 22:13:23.927+00	2025-2026
087e5346-dab5-4bcf-b16d-94a3c9cd6ac6	luongvohalinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Võ Hà Linh	DV	10A3	2026-03-30 22:13:23.927+00	2025-2026
8140ceda-85c6-4efa-9baa-f934cc0eebf4	ngoduclinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Đức Linh	DV	12B4	2026-03-30 22:13:23.927+00	2025-2026
7d8e9245-ef72-4051-bc21-02ae9ef9155f	ngophamthuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Phạm Thùy Linh	DV	11C9	2026-03-30 22:13:23.927+00	2025-2026
8fb1a8c1-90cc-428d-9aa7-f5c60875a2a3	nguyenkhanhlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khánh Linh	DV	10A1	2026-03-30 22:13:23.927+00	2025-2026
098d144e-f999-4035-b5b6-809d2496c8b9	nguyenledieulinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Diệu Linh	DV	12B9	2026-03-30 22:13:23.927+00	2025-2026
456f200f-178e-4dd6-8b66-8f293519b674	nguyenngochonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Hồng Linh	DV	12B4	2026-03-30 22:13:23.927+00	2025-2026
0a0a4591-03c9-4000-b52c-f3572303c319	nguyenphamphuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phạm Phương Linh	DV	11C1	2026-03-30 22:13:23.927+00	2025-2026
da5e2e24-836c-4ef0-9f47-543cff52758d	nguyenthidieulinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diệu Linh	DV	12B1	2026-03-30 22:13:23.927+00	2025-2026
6a6ec7dd-138c-4b8f-b259-1171227bdd9a	nguyenthimailinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mai Linh	DV	11C10	2026-03-30 22:13:23.928+00	2025-2026
62e44cda-4ad1-4c88-82c3-308858c2e51c	nguyenthingoclinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Linh	DV	11C6	2026-03-30 22:13:23.928+00	2025-2026
fb26ec2e-0d03-43b4-8fbe-38577dee2cb6	nguyenthiphuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ PHƯƠNG LINH	DV	12B6	2026-03-30 22:13:23.928+00	2025-2026
8fd6374b-d337-4b87-9253-111aae709910	nguyenthithuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Linh	DV	10A7	2026-03-30 22:13:23.928+00	2025-2026
20da59df-8423-481d-8cd3-e53a0ce9a6ec	nguyenthithuylinh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Linh	DV	11C12	2026-03-30 22:13:23.928+00	2025-2026
99a47fdd-c1a3-4fa0-9cce-b133b4a34972	nguyentranthuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Thùy Linh	DV	11C3	2026-03-30 22:13:23.928+00	2025-2026
41843531-1b23-4b8d-8866-7ed6daaa5a0e	nguyenvietlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Việt Linh	DV	12B3	2026-03-30 22:13:23.928+00	2025-2026
89d136e7-312e-47d8-a65f-738773b0ab6c	phamlegialinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Lê Gia Linh	DV	10A2	2026-03-30 22:13:23.928+00	2025-2026
eab12c0f-09f2-4da8-96f9-1d075734c566	phamnguyenhoanglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Nguyễn Hoàng Linh	DV	11C11	2026-03-30 22:13:23.928+00	2025-2026
e658851e-b3d7-42a9-a135-ee2adb2c6590	phamnguyennhatlinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Nguyễn Nhật Linh	DV	10A11	2026-03-30 22:13:23.928+00	2025-2026
76b4ab90-8d8c-42ed-b1c6-8059364f6b02	phamthuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thùy Linh	DV	11C5	2026-03-30 22:13:23.928+00	2025-2026
37f83429-e3fa-478b-9aa5-b469b090d5a6	quachthuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Quách Thùy Linh	DV	10A4	2026-03-30 22:13:23.928+00	2025-2026
2098602d-c9cc-4ec9-8a30-fb5a99c90d00	siuphuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu Phương Linh	DV	10A11	2026-03-30 22:13:23.928+00	2025-2026
40cb7008-f920-45d0-8907-a03a0bc2e6f6	thuyngoclinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thủy Ngọc Lĩnh	DV	11C2	2026-03-30 22:13:23.928+00	2025-2026
6c0dd4d7-c82e-44b0-b8a8-4f3306a6385e	tranthithuylinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thùy Linh	DV	10A3	2026-03-30 22:13:23.928+00	2025-2026
bb2ee2d5-07f8-4a17-907e-801a42e73b84	vithiphuonglinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vi Thị Phương Linh	DV	10A10	2026-03-30 22:13:23.928+00	2025-2026
cd417d47-9dfb-4eef-86f9-aec65fa157a7	dinhmailoan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Mai Loan	DV	11C6	2026-03-30 22:13:23.928+00	2025-2026
29709e87-32f9-464f-b9a7-c6f97bbae4d5	hoangngocbaolong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Ngọc Bảo Long	DV	11C7	2026-03-30 22:13:23.928+00	2025-2026
a4f597d2-d91c-44ac-b609-db25d8fea65c	hoangnguyenbaolong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Nguyễn Bảo Long	DV	11C10	2026-03-30 22:13:23.928+00	2025-2026
7069f4e2-693c-4910-b427-bfafe18a9c7f	kimngoclong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kim Ngọc Long	DV	11C12	2026-03-30 22:13:23.928+00	2025-2026
9f2cbe67-6e8c-4f20-9f59-079a0695635f	luongphilong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Phi Long	DV	11C4	2026-03-30 22:13:23.928+00	2025-2026
2a0a6f0f-6e89-4f96-9629-87d0ec5c0a56	maixuanlong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Xuân Long	DV	11C4	2026-03-30 22:13:23.928+00	2025-2026
b13b068d-9f2a-4328-bdaa-bde4f70e98d3	nguyenphilong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phi Long	DV	10A1	2026-03-30 22:13:23.928+00	2025-2026
f631c1fa-dd7f-4273-8bfc-2092532dc408	nguyenquanglong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quang Long	DV	11C3	2026-03-30 22:13:23.928+00	2025-2026
666c086b-470e-447a-970e-7e9da6139c51	nguyenthanhlong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thành Long	DV	10A9	2026-03-30 22:13:23.928+00	2025-2026
9e90f358-6c53-4e2e-827a-bd740efd8db2	phamsyhoanglong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Sỹ Hoàng Long	DV	10A10	2026-03-30 22:13:23.928+00	2025-2026
849fdcf7-1b1e-4d16-87fa-4307184e4c0b	phanminhbaolong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Minh Bảo Long	DV	11C2	2026-03-30 22:13:23.928+00	2025-2026
3a5dff52-b91a-42a4-9156-3effe4996469	phanvanlong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Văn Long	DV	12B2	2026-03-30 22:13:23.929+00	2025-2026
b0beaf96-66b4-421b-b8f9-3c91114366dc	phungchilong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phùng Chí Long	DV	11C10	2026-03-30 22:13:23.929+00	2025-2026
d47f8e05-be06-4185-b618-bcaa7ede5440	tangvanhailong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tăng Văn Hải Long	DV	11C5	2026-03-30 22:13:23.929+00	2025-2026
081e1028-c792-4f35-b665-246837337f20	tranvanlong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Long	DV	11C6	2026-03-30 22:13:23.929+00	2025-2026
383cdf46-1b86-48c6-ad15-6730c5c92431	trinhhoanglong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Hoàng Long	DV	12B10	2026-03-30 22:13:23.929+00	2025-2026
6fa51a13-a2b8-47e3-89d3-b53481b41a4d	truonggialong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Gia Long	DV	11C3	2026-03-30 22:13:23.929+00	2025-2026
533ddda3-1758-4dc5-b513-be34f3f9f5ee	vutienlong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Tiến Long	DV	11C4	2026-03-30 22:13:23.929+00	2025-2026
cb3e4238-b25e-403b-9f44-b34271d848c8	buivanloc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Văn Lộc	DV	11C1	2026-03-30 22:13:23.929+00	2025-2026
72997236-6aff-4c85-94d5-b0aa66e349b6	duonghuuloc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Hữu Lộc	DV	11C10	2026-03-30 22:13:23.929+00	2025-2026
f7d9c572-3258-46c7-a166-142dd0f46a65	dinhquangloc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Quang Lộc	DV	12B8	2026-03-30 22:13:23.929+00	2025-2026
376994ef-6625-4dfa-a4fe-ff98d9801243	hohuuloc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Lộc	DV	12B6	2026-03-30 22:13:23.929+00	2025-2026
9ef18999-28a8-4bfa-bbc3-77967226b33d	phamgiabaoloc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Gia Bảo Lộc	DV	11C6	2026-03-30 22:13:23.929+00	2025-2026
e2f73671-5e67-4750-a0d7-516c1b43c808	nguyentanloi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tấn Lợi	DV	11C4	2026-03-30 22:13:23.929+00	2025-2026
09307502-ba92-47f6-950f-34dc311656da	nguyentrankhanhloi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Khánh Lợi	DV	12B3	2026-03-30 22:13:23.929+00	2025-2026
7467d195-bdd8-4e9f-b6e1-63e5ce877920	trananloi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần An Lợi	DV	12B4	2026-03-30 22:13:23.929+00	2025-2026
cca0cf64-d2cb-4886-a142-dd79440d1a75	buithanhluan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thanh Luân	DV	10A2	2026-03-30 22:13:23.929+00	2025-2026
ab304f5c-fe71-456b-a268-3d47480f478d	doanngovuluan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Ngô Vũ Luân	DV	11C11	2026-03-30 22:13:23.929+00	2025-2026
88707fc1-d8a1-455d-9216-b81b47822ea1	ngothikimluan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Thị Kim Luân	DV	10A8	2026-03-30 22:13:23.929+00	2025-2026
1463b07c-f7c4-49ae-b934-97a947e19aae	phanvuthanhluan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Vũ Thành Luân	DV	12B4	2026-03-30 22:13:23.929+00	2025-2026
b6e71296-0edb-4709-8bc4-c85c38948d0e	romahluy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Luy	DV	12B9	2026-03-30 22:13:23.929+00	2025-2026
9118b2ba-2152-45a6-8b2b-cab229e72544	huathiluuluyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hứa Thị Lưu Luyến	DV	11C7	2026-03-30 22:13:23.929+00	2025-2026
f4a8ba97-e70d-432e-b45a-d357f744b804	nguyenhoanghuuluong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN HOÀNG HỮU LƯỢNG	DV	12B6	2026-03-30 22:13:23.929+00	2025-2026
8d05ecbc-d42c-4301-9718-b321e0e35adf	nguyenthiluong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Lượng	DV	11C6	2026-03-30 22:13:23.929+00	2025-2026
7202a4bc-a862-40ef-bae3-fcab982835aa	tranducluong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đức Lương	DV	10A1	2026-03-30 22:13:23.929+00	2025-2026
70587a61-5ad7-4351-8dd6-0205b0ba0db7	honguyenkhanhly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Nguyễn Khánh Ly	DV	12B7	2026-03-30 22:13:23.929+00	2025-2026
18c0b96d-4619-4aee-9f05-a389d9fe8049	hothikhanhly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Khánh Ly	DV	10A1	2026-03-30 22:13:23.929+00	2025-2026
dad055de-a8af-4e85-a8f3-133b74b3d06d	ngothikhanhly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Thị Khánh Ly	DV	11C9	2026-03-30 22:13:23.929+00	2025-2026
e1782ed8-04a2-4a60-b587-0065a2f01140	nguyenthibaoly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bảo Ly	DV	12B3	2026-03-30 22:13:23.93+00	2025-2026
0452d51d-e232-430b-8bf7-c95851eb4350	nguyenthilyly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ly Ly	DV	10A8	2026-03-30 22:13:23.93+00	2025-2026
cd5afc3e-7081-4e08-96a5-2b200e50402e	nguyenthimaily	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mai Ly	DV	11C3	2026-03-30 22:13:23.93+00	2025-2026
9d40a9b7-86a7-48b9-8acf-8a98f18aab16	phanthithuyly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Thúy Ly	DV	11C6	2026-03-30 22:13:23.93+00	2025-2026
84a05e5e-9c85-4caf-8c2e-7555f4e0fa6f	tranhaily	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Hải Ly	DV	12B4	2026-03-30 22:13:23.93+00	2025-2026
fdbfde39-4e96-4053-acc2-75d1c9af000d	tranthikhanhly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Khánh Ly	DV	10A7	2026-03-30 22:13:23.93+00	2025-2026
6c20e8cc-4dbc-4516-b363-361007718dbf	vuthuly	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thu Ly	DV	12B7	2026-03-30 22:13:23.93+00	2025-2026
4c9b62d2-11c4-47a9-98fe-6f386f678528	rolanh'lyna	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Lyna	DV	11C7	2026-03-30 22:13:23.93+00	2025-2026
fadd9214-5726-46cc-b146-a84318ec6f4e	rolanh'lysa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Lysa	DV	11C9	2026-03-30 22:13:23.93+00	2025-2026
9d903094-e630-44c6-8c4a-71d6657f8fc8	caothithanhmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thị Thanh Mai	DV	12B1	2026-03-30 22:13:23.93+00	2025-2026
7915fdbf-1c7a-4f5d-8544-040d773b9dbe	camthiquynhmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cầm Thị Quỳnh Mai	DV	11C3	2026-03-30 22:13:23.93+00	2025-2026
748cb764-901d-4025-bb74-5902959bd694	dothingocmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Thị Ngọc Mai	DV	11C3	2026-03-30 22:13:23.93+00	2025-2026
634f720a-8f9b-4172-8c38-2cf927628650	hoangthimai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Mai	DV	12B9	2026-03-30 22:13:23.93+00	2025-2026
d64646e9-aca6-40ed-8d48-c743c13841aa	lebuixuanmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Bùi Xuân Mai	DV	11C5	2026-03-30 22:13:23.93+00	2025-2026
00c7dff8-72bc-4906-96cd-fd7d72b1d86b	lethimai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Mai	DV	12B2	2026-03-30 22:13:23.93+00	2025-2026
39063c93-a10b-4b7c-9f3b-37eb95fe30d3	lethixuanmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Xuân Mai	DV	11C11	2026-03-30 22:13:23.93+00	2025-2026
1d69cf9a-acf7-455d-88f9-b86877b5a47e	nguyenlequynhmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Quỳnh Mai	DV	11C5	2026-03-30 22:13:23.93+00	2025-2026
5defbee5-9144-42a0-a79c-d1b12eb72efe	nguyenngocmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Mai	DV	12B8	2026-03-30 22:13:23.93+00	2025-2026
bd292b84-7431-4ff7-9876-29100166c5e7	phamsaomai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Sao Mai	DV	11C5	2026-03-30 22:13:23.93+00	2025-2026
7b5bfffa-f225-4f1a-b5de-a30fb5123bc7	rolanhoamai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Hoa Mai	DV	12B10	2026-03-30 22:13:23.93+00	2025-2026
d545a346-6cd4-44fa-a27e-fb3770763b8f	romahthithanhmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Thị Thanh Mai	DV	10A6	2026-03-30 22:13:23.93+00	2025-2026
06151af4-2028-428a-948a-e38739c10512	tranlexuanmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Lê Xuân Mai	DV	11C2	2026-03-30 22:13:23.93+00	2025-2026
789070e8-6999-45a1-927d-3986ff7afc85	tranthingocmai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Ngọc Mai	DV	10A9	2026-03-30 22:13:23.93+00	2025-2026
65616f16-4c0f-446b-9c94-cac9ef552cd9	dodinhmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Đình Mạnh	DV	12B1	2026-03-30 22:13:23.93+00	2025-2026
a9556223-cf29-4ebe-bb4d-84c508646286	hohuumanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Mạnh	DV	11C12	2026-03-30 22:13:23.93+00	2025-2026
4155bfd3-7f61-45ea-9bb2-8536e2db5c1e	nguyenducmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Mạnh	DV	11C8	2026-03-30 22:13:23.931+00	2025-2026
353eefb0-e80b-4f22-a3eb-6ebdbaf34506	nguyenlemanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Mạnh	DV	11C5	2026-03-30 22:13:23.931+00	2025-2026
d9e579ca-c476-4171-bf99-c585a7b158a5	nguyenvanmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Mạnh	DV	11C11	2026-03-30 22:13:23.931+00	2025-2026
8224db99-2fb9-4dc9-8dcc-f1313596bae4	nguyenvanmanh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Mạnh	DV	12B10	2026-03-30 22:13:23.931+00	2025-2026
fa64e091-19f8-4468-b15a-440ec3a8ca0b	tangvanmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tăng Văn Mạnh	DV	11C9	2026-03-30 22:13:23.931+00	2025-2026
5017d6fe-054c-4090-b1e3-0b666078cf9b	tranvanmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Mạnh	DV	10A9	2026-03-30 22:13:23.931+00	2025-2026
a2422fac-6424-444f-a69f-8cedfdf3d51a	vantienmanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Văn Tiến Mạnh	DV	11C1	2026-03-30 22:13:23.931+00	2025-2026
f35732b4-67c5-42fc-b622-6d8af8713a35	lethihongtuyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hồng Tuyết	DV	11C4	2026-03-30 22:13:23.953+00	2025-2026
ff61ced4-a192-4585-8135-2b915d884d62	maigiangtuyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Giang Tuyết	DV	10A8	2026-03-30 22:13:23.953+00	2025-2026
e9debee8-265d-43b7-8fac-3d9ff981bdc7	maithianhtuyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Ánh Tuyết	DV	11C7	2026-03-30 22:13:23.953+00	2025-2026
75ab274e-2f38-43be-8a67-fdf6811dbe97	nguyenthikimtuyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Kim Tuyết	DV	11C7	2026-03-30 22:13:23.953+00	2025-2026
2818c4c7-2e61-4497-918d-49c8dbc9ba07	nguyenkhactuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khắc Tường	DV	11C7	2026-03-30 22:13:23.954+00	2025-2026
db959154-166e-4ebb-ab48-d660813031f6	romahh'ury	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Ury	DV	10A7	2026-03-30 22:13:23.954+00	2025-2026
c82deea9-c6eb-4dad-a350-f2c644611092	romahh'ut	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Út	DV	12B5	2026-03-30 22:13:23.954+00	2025-2026
a9c1daa9-4b68-4505-8379-951c75c06e1b	dangthikhanhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thị Khánh Uyên	DV	12B8	2026-03-30 22:13:23.954+00	2025-2026
e7bc447b-340f-4857-9fe7-cc3ec3d709f1	honguyenthucuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Nguyễn Thục Uyên	DV	10A3	2026-03-30 22:13:23.954+00	2025-2026
8a6b7109-e4e4-4f5a-9ab9-2ad27c2bc680	kpuihh'uyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Uyên	DV	10A8	2026-03-30 22:13:23.954+00	2025-2026
c95eb692-8535-4a88-bc15-ce82abef6122	ksorh'uyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Uyên	DV	12B5	2026-03-30 22:13:23.954+00	2025-2026
4b3bc0a6-989a-4c9e-996f-fd79b24f7fb2	lathitouyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lã Thị Tố Uyên	DV	11C5	2026-03-30 22:13:23.954+00	2025-2026
38383e6f-a28b-431a-9674-0269e13c515f	lebaouyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Bảo Uyên	DV	11C9	2026-03-30 22:13:23.954+00	2025-2026
9acc8181-7997-4125-b35f-e9e7fc6a4080	vodaimanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Đại Mạnh	DV	10A3	2026-03-30 22:13:23.931+00	2025-2026
f0959122-779b-40f5-91c3-74fd8ebd8f0e	kpamathe	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpă Mathê	DV	11C12	2026-03-30 22:13:23.931+00	2025-2026
2941e9bd-6c82-42ca-ba5f-618d3c5192ba	rochamh'man	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm H' Mẫn	DV	10A6	2026-03-30 22:13:23.931+00	2025-2026
af25cfa3-c67a-4e0c-bf5c-b6f16c7ee120	damcanhminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đàm Cảnh Minh	DV	12B4	2026-03-30 22:13:23.931+00	2025-2026
3e7e4ca8-1a23-4861-a422-8744e44d8b88	daoquangminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Quang Minh	DV	11C1	2026-03-30 22:13:23.931+00	2025-2026
a12b1920-fede-4f54-a41c-03d46b3686b9	leanhminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Anh Minh	DV	11C11	2026-03-30 22:13:23.931+00	2025-2026
49666a4e-f2e3-4e7f-ab50-0d70828efdfe	lengochoangminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Ngọc Hoàng Minh	DV	10A2	2026-03-30 22:13:23.931+00	2025-2026
6824fb23-cca3-4edf-bfe7-ece9f59d13d5	nguyenhoangbaominh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Bảo Minh	DV	10A1	2026-03-30 22:13:23.931+00	2025-2026
5c3a14d1-7b90-42a0-ab91-4130dedc1ae1	nguyenhoangminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Minh	DV	10A11	2026-03-30 22:13:23.931+00	2025-2026
f169edce-a9f8-4a5a-806f-d4c54b5ccbe9	nguyennhatminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Nhật Minh	DV	12B3	2026-03-30 22:13:23.931+00	2025-2026
a1ac4315-fe1b-48b6-a972-f1b749ca6e5f	nguyenthaominh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thảo Minh	DV	10A3	2026-03-30 22:13:23.931+00	2025-2026
55da8e22-b942-453a-8375-658b713d8e7d	nguyenvuducminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Vũ Đức Minh	DV	12B1	2026-03-30 22:13:23.931+00	2025-2026
64b301a3-f3e7-45a9-b2bc-87d3a0d788c2	phamgiaminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Gia Minh	DV	10A8	2026-03-30 22:13:23.931+00	2025-2026
5945a1ea-1beb-45da-babd-37f28409b8ab	phandinhminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Đình Minh	DV	11C6	2026-03-30 22:13:23.931+00	2025-2026
fb030f9a-d8c6-4eb6-851a-3e8859be8ed1	phantranyenminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Trần Yến Minh	DV	11C3	2026-03-30 22:13:23.931+00	2025-2026
76681dd4-8af0-4207-9404-8441a96de305	trannhatminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Nhật Minh	DV	10A11	2026-03-30 22:13:23.931+00	2025-2026
4d469f84-3a8d-4626-a9bf-3437a1874c42	vohoangminh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hoàng Minh	DV	12B4	2026-03-30 22:13:23.931+00	2025-2026
3d3db2b0-a03f-45ce-acc0-e9aa77a0a3b3	ksorh'mlan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Mlan	DV	11C6	2026-03-30 22:13:23.931+00	2025-2026
cebe0bd5-f59e-41dd-b2c2-6bc7bfe26e61	romahsimo	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Si Mô	DV	11C10	2026-03-30 22:13:23.931+00	2025-2026
efc1797c-0858-4d12-906d-dc19722f321b	rolanh'munh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	RƠ LAN H' MƯNH	DV	12B6	2026-03-30 22:13:23.931+00	2025-2026
b88b8057-0dbb-4ee6-93c4-b2ccc7aedb35	caothitramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thị Trà My	DV	12B2	2026-03-30 22:13:23.931+00	2025-2026
9df7d60a-6ed7-418a-84db-8c72a6c85e2a	doanthitramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Thị Trà My	DV	10A2	2026-03-30 22:13:23.931+00	2025-2026
dc20e0d9-c58e-4225-b8ee-44670a470ffa	dothihaimy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Thị Hải My	DV	11C6	2026-03-30 22:13:23.932+00	2025-2026
5df92231-bab8-4b35-b5d1-ae1248a7e73f	hathitramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Thị Trà My	DV	12B4	2026-03-30 22:13:23.932+00	2025-2026
79cf7bd8-300a-42fb-8bf7-c1a50c415514	hoangthidieumy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Diệu My	DV	12B7	2026-03-30 22:13:23.932+00	2025-2026
ee1f5aaa-9cf6-4d76-9693-fdb4c16f8900	hoangyenmy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Yến My	DV	11C9	2026-03-30 22:13:23.932+00	2025-2026
8ce7aed8-6679-4a2f-83d0-b8e76ece5bb8	huynhnguyentramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Nguyễn Trà My	DV	11C3	2026-03-30 22:13:23.932+00	2025-2026
7c684220-8774-450c-9b36-1d11f59a2d58	huynhthidiemmy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Thị Diễm My	DV	11C11	2026-03-30 22:13:23.932+00	2025-2026
878ec52d-7110-4d3f-abad-7236b530f38d	ledieumy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Diệu My	DV	12B3	2026-03-30 22:13:23.932+00	2025-2026
8e0a417b-c7bc-4e1f-b93e-68ec30982832	lehoangkieumy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hoàng Kiều My	DV	10A5	2026-03-30 22:13:23.932+00	2025-2026
f569c8e9-06b1-41ce-a393-d7dfc6089aa4	lenguyentramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nguyễn Trà My	DV	11C7	2026-03-30 22:13:23.932+00	2025-2026
672bc119-4237-4fec-937c-717251dbced1	lephuongthaomy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Phương Thảo My	DV	11C4	2026-03-30 22:13:23.932+00	2025-2026
2870e3b0-de68-4388-8437-2cfc14e326a1	lethimy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LÊ THỊ MỸ	DV	12B6	2026-03-30 22:13:23.932+00	2025-2026
38a6795e-ac84-474e-bd67-b198a38751e3	lethitramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Trà My	DV	10A7	2026-03-30 22:13:23.932+00	2025-2026
77449ec4-77ba-4084-91d7-6b96360f4167	lethitramy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Trà My	DV	11C9	2026-03-30 22:13:23.932+00	2025-2026
46de4952-8898-4dd7-8be6-b520f53fc073	lethitramy2	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Trà My	DV	12B8	2026-03-30 22:13:23.932+00	2025-2026
d3f420be-0c07-4849-ad26-28bf04398f60	nguyenhathaomy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hà Thảo My	DV	10A5	2026-03-30 22:13:23.932+00	2025-2026
134920f1-4b14-496e-93af-4a33f335a838	nguyenhathaomy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hà Thảo My	DV	12B8	2026-03-30 22:13:23.932+00	2025-2026
71a8feff-d088-4351-9126-04ee8de600e9	nguyenhoaidiemmy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoài Diễm My	DV	10A6	2026-03-30 22:13:23.932+00	2025-2026
f1504195-bbec-484e-ab2f-ed2e2d42e276	nguyenletramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lệ Trà My	DV	11C9	2026-03-30 22:13:23.932+00	2025-2026
525fad2c-e304-4168-a87d-08d69ccd23b5	nguyenphantramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phan Trà My	DV	10A6	2026-03-30 22:13:23.932+00	2025-2026
c02eca2c-505a-484b-9b0c-e92738d25a20	phanthanhtramy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thanh Trà My	DV	11C9	2026-03-30 22:13:23.932+00	2025-2026
104f1fc8-c841-47b4-89a4-9d4bbff79419	rochamthaomy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm Thảo My	DV	10A10	2026-03-30 22:13:23.932+00	2025-2026
8ff1b41e-6e95-410c-9776-7430dbc18e2f	truongthithuna	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Thị Thu Na	DV	12B8	2026-03-30 22:13:23.932+00	2025-2026
a19dd93c-1ae0-4493-80b5-a3eda4c796a6	dangbaonam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Bảo Nam	DV	11C11	2026-03-30 22:13:23.932+00	2025-2026
35d47570-6b41-4819-aacd-2151cb99808c	doanvannam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Văn Nam	DV	10A8	2026-03-30 22:13:23.932+00	2025-2026
d6c995de-47ef-43e8-98c8-be8e6ba5e815	hanhatnam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Nhật Nam	DV	11C4	2026-03-30 22:13:23.932+00	2025-2026
670e5ed5-821c-4bc8-b4ba-231d4359231d	hoanglengocnam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Lê Ngọc Nam	DV	11C3	2026-03-30 22:13:23.932+00	2025-2026
552291a0-69a6-4367-8c73-84594f620235	hoangvannam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Văn Nam	DV	11C2	2026-03-30 22:13:23.932+00	2025-2026
f436093f-6f77-497a-95d4-df29ee3cc3ed	lebaonam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Bảo Nam	DV	10A10	2026-03-30 22:13:23.932+00	2025-2026
5f5f248b-301e-4fbd-a3cc-cb42779b3929	nguyenvanbaonam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Bảo Nam	DV	10A11	2026-03-30 22:13:23.933+00	2025-2026
e706d8a8-bd5a-4e10-8255-49ac33a6aedb	phamquangnam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Quang Nam	DV	10A10	2026-03-30 22:13:23.933+00	2025-2026
d4c3aa06-474e-4ff2-9861-3b09000a2431	phamtrongbaonam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	PHẠM TRỌNG BẢO NAM	DV	10A9	2026-03-30 22:13:23.933+00	2025-2026
36e4ba84-8efe-40a2-ac52-8d0ea2fdee45	tangngocnam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tăng Ngọc Nam	DV	12B4	2026-03-30 22:13:23.933+00	2025-2026
fa998542-fa96-4597-89dc-c009f9f5c3d7	tranvanbaonam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Bảo Nam	DV	10A8	2026-03-30 22:13:23.933+00	2025-2026
13b71d00-b9ec-4e42-b13d-91bfdcdc9be4	rolanh’nasi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H’ Nasi	DV	10A9	2026-03-30 22:13:23.933+00	2025-2026
70ae868b-bba3-447d-bacc-102bad8e62e8	romahh’anne	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H’ An ne	DV	10A5	2026-03-30 22:13:23.933+00	2025-2026
9011b916-c6a4-4da7-aff5-f67964959d91	ksornet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Net	DV	11C8	2026-03-30 22:13:23.933+00	2025-2026
f5c6b901-5d52-4e61-96b9-96b26a4e745a	hothithuynga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thúy Nga	DV	12B8	2026-03-30 22:13:23.933+00	2025-2026
37223748-4ca5-4c6e-b598-b8da75d20955	hothunga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thu Nga	DV	10A1	2026-03-30 22:13:23.933+00	2025-2026
174b862b-1dcf-444b-9396-b9ddb086da0f	hothuynga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thúy Nga	DV	11C12	2026-03-30 22:13:23.933+00	2025-2026
a21b086d-1c85-4d7c-bfc0-d522019ed878	lethinga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Nga	DV	11C10	2026-03-30 22:13:23.933+00	2025-2026
3af7e6a5-e690-46a9-992a-13945928c0fa	nguyenthiquynhnga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Quỳnh Nga	DV	12B4	2026-03-30 22:13:23.933+00	2025-2026
e492aa4a-f383-49ed-842c-501fd9a1af39	nguyenthitonga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Tố Nga	DV	10A5	2026-03-30 22:13:23.933+00	2025-2026
d7a8d077-94c1-4267-a35d-cd268d6ad33a	trinhthihangnga	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Thị Hằng Nga	DV	10A1	2026-03-30 22:13:23.933+00	2025-2026
31937ae4-4663-4bdd-9c57-8384b35a6133	nguyenlucngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lục Ngạn	DV	10A1	2026-03-30 22:13:23.933+00	2025-2026
b49e606e-6e26-457d-b605-225fc55ead97	kpuihh'ngat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Ngát	DV	11C11	2026-03-30 22:13:23.933+00	2025-2026
985b18c1-1333-4250-a794-b5b70c83ec1f	romahh'ngam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Ngâm	DV	11C8	2026-03-30 22:13:23.933+00	2025-2026
09064c53-6e25-4c16-b754-f0a09cafc6bf	dothituyetngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Thị Tuyết Ngân	DV	12B5	2026-03-30 22:13:23.933+00	2025-2026
cb9761a0-a76a-4823-839d-e72f95fe4e7a	hoangbaongan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Bảo Ngân	DV	11C12	2026-03-30 22:13:23.933+00	2025-2026
9ea93d31-e934-4e92-860e-d1b537ac35f2	hohoaingan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hoài Ngân	DV	12B7	2026-03-30 22:13:23.933+00	2025-2026
e3f6dff1-1008-486d-a208-0812f38515e5	kpuihngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Ngân	DV	12B8	2026-03-30 22:13:23.933+00	2025-2026
70a80fca-1ef9-4994-96e2-8e8f25618c63	lediemquynhngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Diễm Quỳnh Ngân	DV	11C8	2026-03-30 22:13:23.933+00	2025-2026
9b358c33-97cd-44ff-9684-104da89a3ccf	nguyenthikimngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Kim Ngân	DV	10A3	2026-03-30 22:13:23.933+00	2025-2026
5cb578a8-2ba0-497d-bb2c-7940144d8cc1	nguyenthithanhngan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Ngân	DV	10A6	2026-03-30 22:13:23.933+00	2025-2026
b5f422d8-dd20-41c0-aec8-7a78eddc2c6a	nguyenthithanhngan1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Ngân	DV	11C9	2026-03-30 22:13:23.933+00	2025-2026
432cd15f-bd14-4cca-afc7-56f43d732b7a	truongnukieungan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Nữ Kiều Ngân	DV	10A3	2026-03-30 22:13:23.933+00	2025-2026
d1a900a6-4783-451e-9095-cb3239179cdb	dinhthainghia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thái Nghĩa	DV	12B7	2026-03-30 22:13:23.934+00	2025-2026
7ec2316e-b057-4953-8389-b15fc7db914a	hodainghia	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Đại Nghĩa	DV	10A3	2026-03-30 22:13:23.934+00	2025-2026
b063f783-4b05-4654-a20c-4bf3e4de89f8	romahh'ngiet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Ngiêt	DV	10A9	2026-03-30 22:13:23.934+00	2025-2026
28f49ab6-3180-4b01-ae26-636397a24adc	bachthibaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bạch Thị Bảo Ngọc	DV	11C11	2026-03-30 22:13:23.934+00	2025-2026
a5805c6b-04bc-4d8e-ad6b-e017c1b30c7e	buiphanbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Phan Bảo Ngọc	DV	11C5	2026-03-30 22:13:23.934+00	2025-2026
f0dbc3e4-457e-4f04-8613-f97ef1b1af80	chunguyenbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Chu Nguyễn Bảo Ngọc	DV	12B4	2026-03-30 22:13:23.934+00	2025-2026
5d40635f-480a-4cb9-beef-dc9e6fb17032	dinhthibaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Bảo Ngọc	DV	11C5	2026-03-30 22:13:23.934+00	2025-2026
e903f804-7464-4fe1-868c-510012619e4b	dokhanhngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Khánh Ngọc	DV	12B7	2026-03-30 22:13:23.934+00	2025-2026
25206893-d512-4b5c-835a-10bfa47fdc7c	hanhungoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Như Ngọc	DV	10A6	2026-03-30 22:13:23.934+00	2025-2026
06fffe46-9ca3-4847-a983-6cb503f336c9	lehoangmyngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hoàng Mỹ Ngọc	DV	10A1	2026-03-30 22:13:23.934+00	2025-2026
73b365a4-a6dd-40b2-9d8c-e747f7a37bbe	lenguyenhongngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nguyễn Hồng Ngọc	DV	10A3	2026-03-30 22:13:23.934+00	2025-2026
dde619a1-33f9-4cc3-8ee4-98de919c80d1	lethibaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Bảo Ngọc	DV	10A1	2026-03-30 22:13:23.934+00	2025-2026
17fc442c-c5ba-42f2-b0f8-e0f8ccecbb08	lethibaongoc1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Bảo Ngọc	DV	11C4	2026-03-30 22:13:23.934+00	2025-2026
bfd3b622-541c-4b72-9ea2-30074bb68d85	lethibichngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Bích Ngọc	DV	11C10	2026-03-30 22:13:23.934+00	2025-2026
81cf07f7-132a-4cca-9007-a542f62ddd42	lethihongngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hồng Ngọc	DV	11C3	2026-03-30 22:13:23.934+00	2025-2026
d0ccea57-e97f-49ba-a807-9eff2f29db37	nguyenbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Bảo Ngọc	DV	10A4	2026-03-30 22:13:23.934+00	2025-2026
f937f2b7-65d6-492b-8374-5c7804de3761	nguyencongngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Công Ngọc	DV	11C3	2026-03-30 22:13:23.934+00	2025-2026
43eb78dd-943d-4228-a4d3-547e51004ff7	nguyenhoangbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Bảo Ngọc	DV	10A10	2026-03-30 22:13:23.934+00	2025-2026
5a4f7a5e-b719-4917-a34f-76016da8e7ce	nguyenthibaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bảo Ngọc	DV	11C4	2026-03-30 22:13:23.934+00	2025-2026
1258b7ba-837f-48b2-9ad4-422316c73497	nguyenthibichngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bích Ngọc	DV	10A10	2026-03-30 22:13:23.934+00	2025-2026
46419430-8ffd-40a4-add3-8f21757107b2	nguyenthibichngoc1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bích Ngọc	DV	12B1	2026-03-30 22:13:23.934+00	2025-2026
8f482053-2062-48ee-8da9-61c16a72f408	nguyenthihongngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng Ngọc	DV	12B5	2026-03-30 22:13:23.934+00	2025-2026
fddd5282-2de9-4f6f-837a-296ec438bbaa	nguyenthihongngoc1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ HỒNG NGỌC	DV	12B6	2026-03-30 22:13:23.934+00	2025-2026
6652257d-5126-48ce-89e3-bd1450bea43e	lethiphuonguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Phương Uyên	DV	10A7	2026-03-30 22:13:23.954+00	2025-2026
76a4db11-9d1b-4ca3-90d9-48a4bf4d43e4	nguyenthiminhuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Minh Uyên	DV	12B1	2026-03-30 22:13:23.954+00	2025-2026
e7590ec4-956d-4e83-983c-7f786f3fa3c8	romahh'uyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Uyên	DV	11C9	2026-03-30 22:13:23.954+00	2025-2026
870ef5ef-6564-4118-ac58-2d6d8e4cde65	thaihoangmyuyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thái Hoàng Mỹ Uyên	DV	12B8	2026-03-30 22:13:23.954+00	2025-2026
2f4b8af5-7f4e-48fc-a251-6dc87e9aaf9f	trantouyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Tố Uyên	DV	11C8	2026-03-30 22:13:23.954+00	2025-2026
25a49024-ef3f-422a-9a25-d68bed68717c	kpuihlanvan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Lan Văn	DV	10A9	2026-03-30 22:13:23.954+00	2025-2026
aef0f192-ce58-4b75-be85-027429f1d482	nguyendinhvan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Văn	DV	12B2	2026-03-30 22:13:23.954+00	2025-2026
9e5e36c1-2b12-4eae-9790-3c6d43590cab	hothithanhvan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thanh Vân	DV	11C8	2026-03-30 22:13:23.954+00	2025-2026
7392a32b-255d-4885-8e0a-f0746dcae5ce	nguyenthibichvan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Bích Vân	DV	11C8	2026-03-30 22:13:23.954+00	2025-2026
29805401-422a-4beb-8326-80e955c1c5cc	romahh'van	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Vân	DV	12B7	2026-03-30 22:13:23.954+00	2025-2026
43d8add7-87c8-4339-9014-660da647c33e	ksorh've	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Vệ	DV	11C7	2026-03-30 22:13:23.954+00	2025-2026
8baeffb8-ec65-4b8f-b567-7899d2866014	nguyenhoangvi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Vi	DV	10A2	2026-03-30 22:13:23.954+00	2025-2026
6294d43c-358e-4d64-89f9-bd2f9bd17ab8	nguyentrivi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trí Vĩ	DV	11C3	2026-03-30 22:13:23.954+00	2025-2026
0be0b030-24a0-4827-a9d9-d61d96f4ca7f	romahh'vi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Vị	DV	12B7	2026-03-30 22:13:23.954+00	2025-2026
e7b821e2-673c-4f6d-9387-d28888bf3826	nguyenthikhanhngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Khánh Ngọc	DV	12B7	2026-03-30 22:13:23.934+00	2025-2026
4de744af-0b00-4575-9f9e-4d12307c1724	nguyenthithanhngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thanh Ngọc	DV	10A6	2026-03-30 22:13:23.934+00	2025-2026
5b5873cf-8fe7-41f4-b9a3-b34318422a06	phamthanhbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thanh Bảo Ngọc	DV	11C1	2026-03-30 22:13:23.934+00	2025-2026
69a5a33d-f760-417c-a93a-99594ad60ea9	phamthinhungoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Như Ngọc	DV	10A10	2026-03-30 22:13:23.935+00	2025-2026
fa215e8c-cac9-44c3-bdbd-153ee2e7acd6	phanbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Bảo Ngọc	DV	11C1	2026-03-30 22:13:23.935+00	2025-2026
0229cb3d-c985-4986-aafb-e0fd49919350	taotranbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Tào Trần Bảo Ngọc	DV	12B5	2026-03-30 22:13:23.935+00	2025-2026
ef57e96d-c522-4665-b7db-ed18872e4baf	tranbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Bảo Ngọc	DV	11C1	2026-03-30 22:13:23.935+00	2025-2026
cc1aaee5-749d-4e22-84da-c24fb72a8041	trinhthibichngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Thị Bích Ngọc	DV	11C3	2026-03-30 22:13:23.935+00	2025-2026
0727b64f-cc29-408b-a0f6-6841bedaf6ba	truonganhngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Anh Ngọc	DV	12B9	2026-03-30 22:13:23.935+00	2025-2026
782e2fc2-48a8-4e66-a021-2b054d315fc3	votranbaongoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Trần Bảo Ngọc	DV	10A4	2026-03-30 22:13:23.935+00	2025-2026
30fa4f95-458a-4cc4-af8c-7c5742b48e00	vuphuongyenngoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Phương Yến Ngọc	DV	12B7	2026-03-30 22:13:23.935+00	2025-2026
370d4712-d8e2-46ab-971d-368d199f69eb	kpuihh'ngon	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Ngon	DV	10A8	2026-03-30 22:13:23.935+00	2025-2026
0d637f6e-0c9f-40b0-a4f0-8399fbb20e05	builetrungnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Lê Trung Nguyên	DV	12B9	2026-03-30 22:13:23.935+00	2025-2026
4922da31-ce45-467f-9838-382d1043bc9e	buivanhoangnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Văn Hoàng Nguyên	DV	11C5	2026-03-30 22:13:23.935+00	2025-2026
a33f7690-2e26-4ff1-bfad-0c6b85ff0fc7	hanthihongnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hàn Thị Hồng Nguyên	DV	10A5	2026-03-30 22:13:23.935+00	2025-2026
0cd71d7d-6fb6-4c9d-8eed-c7ba00288144	hothanhnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thanh Nguyên	DV	10A10	2026-03-30 22:13:23.935+00	2025-2026
2a2bef71-d5da-4d66-9951-c78492786678	hothinguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Nguyên	DV	11C7	2026-03-30 22:13:23.935+00	2025-2026
d81d5a8b-a288-42db-831c-95c539d9af34	kpuihnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Nguyên	DV	10A9	2026-03-30 22:13:23.935+00	2025-2026
812f4582-ccda-49c6-9685-a5811c09f6c4	levothanhnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Võ Thanh Nguyên	DV	12B3	2026-03-30 22:13:23.935+00	2025-2026
f0d2073e-6791-4152-8b02-9965fcec9785	luuthithaonguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lưu Thị Thảo Nguyên	DV	11C6	2026-03-30 22:13:23.935+00	2025-2026
3150c8b1-fd29-4106-ac2b-f2ac27448788	maithanhnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thanh Nguyên	DV	11C12	2026-03-30 22:13:23.935+00	2025-2026
cee6a3a2-33a2-468b-a2e8-2adff2a7618c	ngothithaonguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Thị Thảo Nguyên	DV	11C7	2026-03-30 22:13:23.935+00	2025-2026
dffd3d70-93ef-47e6-ad84-10389dcf62cb	nguyenphuongthaonguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN PHƯƠNG THẢO NGUYÊN	DV	12B6	2026-03-30 22:13:23.935+00	2025-2026
cae94acd-0ab0-4cf6-b3f9-460913caf506	nguyensynguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Sỹ Nguyên	DV	10A6	2026-03-30 22:13:23.935+00	2025-2026
3d5ace32-e842-4548-889a-79077276977a	phamthaonguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thảo Nguyên	DV	11C8	2026-03-30 22:13:23.935+00	2025-2026
1c481b1d-ac87-430e-ad6c-9903042f1e30	rochamtrungnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm Trung Nguyên	DV	12B10	2026-03-30 22:13:23.935+00	2025-2026
f3e769e8-2db3-4317-a666-ce692b833419	romahnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Nguyên	DV	10A11	2026-03-30 22:13:23.935+00	2025-2026
e6c33c04-2555-4375-9e7e-ef2eb4846edd	tranducnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đức Nguyên	DV	10A4	2026-03-30 22:13:23.935+00	2025-2026
a5f57e40-5c4f-433b-afdf-96b6aa9b5782	vophuocnguyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Phước Nguyên	DV	10A11	2026-03-30 22:13:23.935+00	2025-2026
97712c81-f0de-4801-b4b2-38eaafadc399	duongthinhunguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Thị Như Nguyệt	DV	10A5	2026-03-30 22:13:23.936+00	2025-2026
ba748146-7fa1-4855-b59c-e7e7bfbdbf53	donhunguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Như Nguyệt	DV	10A2	2026-03-30 22:13:23.936+00	2025-2026
c0758bef-b71f-4f2f-9ab9-86d3db1ccd21	hominhnguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Minh Nguyệt	DV	11C2	2026-03-30 22:13:23.936+00	2025-2026
ae271c4e-3312-4d0d-ae50-a90b9b8ad2c9	hothinguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Nguyệt	DV	11C6	2026-03-30 22:13:23.936+00	2025-2026
0cbadd83-41ec-4893-9207-f3ac5500805c	nguyenminhnguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Minh Nguyệt	DV	10A7	2026-03-30 22:13:23.936+00	2025-2026
7e3fede0-6a27-485c-b671-d43feb80b452	nguyenthianhnguyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ánh Nguyệt	DV	12B3	2026-03-30 22:13:23.936+00	2025-2026
e0d6d2a0-44fa-4280-a40d-9999839954ad	kpuihh'nhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Nhàn	DV	12B10	2026-03-30 22:13:23.936+00	2025-2026
3ec2065e-dcfd-41b1-ab52-62677719a383	kpuihnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Nhan	DV	12B9	2026-03-30 22:13:23.936+00	2025-2026
65d27e1a-d19d-441b-b70c-1964f1eca214	tranthithanhnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thanh Nhàn	DV	12B5	2026-03-30 22:13:23.936+00	2025-2026
bd8592fc-ec9e-4c26-bb17-a14e0bf91d3f	kpuihh'nhanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Nhanh	DV	10A6	2026-03-30 22:13:23.936+00	2025-2026
e5dc2ca6-6107-4d9d-b30e-21af2870d899	caoanhnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Anh Nhân	DV	10A1	2026-03-30 22:13:23.936+00	2025-2026
49c3c59f-2098-4f6c-ad9a-84b07c72a14a	dinhtrongnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Trọng Nhân	DV	12B5	2026-03-30 22:13:23.936+00	2025-2026
077eaa7c-3eea-4da9-8f1f-7363260e4c69	nguyenthanhnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thành Nhân	DV	12B1	2026-03-30 22:13:23.936+00	2025-2026
47b4ef7b-3ef0-4440-bf57-b6dc36f82442	phanthanhnhan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thanh Nhân	DV	11C2	2026-03-30 22:13:23.936+00	2025-2026
a3652a8b-76b4-4dfe-9ec5-b89ec7fbf490	hodiennhat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Diên Nhật	DV	11C8	2026-03-30 22:13:23.936+00	2025-2026
30bd305a-53de-400e-a5cf-7d840b5b7786	hotrongnhat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Trọng Nhật	DV	10A9	2026-03-30 22:13:23.936+00	2025-2026
72c0621b-7fe4-4b3f-80a7-a33ba05ffea0	levothanhnhat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Võ Thanh Nhật	DV	10A1	2026-03-30 22:13:23.936+00	2025-2026
705cad50-982c-4ffc-96ea-2e391d326b14	ngoquangnhat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Quang Nhật	DV	10A11	2026-03-30 22:13:23.936+00	2025-2026
ee979bc4-201a-4efa-985d-bffa2ead3074	vuquangnhat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Quang Nhật	DV	11C8	2026-03-30 22:13:23.936+00	2025-2026
9f3ade29-3f85-4bc3-ab97-98094805b439	puihh'nhe	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	PUIH H' NHE	DV	12B6	2026-03-30 22:13:23.936+00	2025-2026
f9f5ab1e-d2f9-4da0-844d-42245f996a9c	buithitunhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Tú Nhi	DV	12B1	2026-03-30 22:13:23.936+00	2025-2026
5bab15c6-4a25-414f-9b23-4fe71f078c33	buithiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Yến Nhi	DV	11C3	2026-03-30 22:13:23.936+00	2025-2026
bda71587-0838-4f9f-b4e1-3d6323275db9	caothiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thị Yến Nhi	DV	12B3	2026-03-30 22:13:23.936+00	2025-2026
41262901-4374-4580-ae0a-023c676050dd	dangthiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	ĐẶNG THỊ YẾN NHI	DV	12B6	2026-03-30 22:13:23.936+00	2025-2026
86b48442-626a-4475-bc02-50a54616d8b0	dinhthiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Yến Nhi	DV	12B1	2026-03-30 22:13:23.936+00	2025-2026
9c2d471a-ea27-45fe-a971-03140a437a3f	dobaonhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Bảo Nhi	DV	10A8	2026-03-30 22:13:23.936+00	2025-2026
58612924-428c-4e0e-b928-614890c4b1d0	hoangmainhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Mai Nhi	DV	10A4	2026-03-30 22:13:23.936+00	2025-2026
19ee0d79-60b3-4501-9284-093dbce16973	hobaoyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Bảo Yến Nhi	DV	11C4	2026-03-30 22:13:23.936+00	2025-2026
3649a97b-0749-4299-88f0-efd1c32c8cb8	hothiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Yến Nhi	DV	10A4	2026-03-30 22:13:23.936+00	2025-2026
33ea78ac-7fde-4104-bfd0-a71bceb2e226	hotuyetnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Tuyết Nhi	DV	11C7	2026-03-30 22:13:23.936+00	2025-2026
8e5a0ddc-a987-4596-8422-27a09871f760	ksorhanhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Hà Nhi	DV	10A8	2026-03-30 22:13:23.936+00	2025-2026
09bfa75b-6d81-40b8-a300-5d90f7b490a2	luongthiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Yến Nhi	DV	11C11	2026-03-30 22:13:23.937+00	2025-2026
c6dd9437-93d2-410f-8b90-9e41f1c270b7	maithiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Yến Nhi	DV	12B4	2026-03-30 22:13:23.937+00	2025-2026
21e90b25-0151-45dc-a15e-8771569f49ec	maivoyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Võ Yến Nhi	DV	10A9	2026-03-30 22:13:23.937+00	2025-2026
056eb621-47e1-4feb-bb73-4086e1530632	nguyenleyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Yến Nhi	DV	11C5	2026-03-30 22:13:23.937+00	2025-2026
0b74298b-25aa-4ac3-878b-4e862aa75867	nguyenthigianhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Gia Nhi	DV	11C6	2026-03-30 22:13:23.937+00	2025-2026
02eee6f2-090f-4a0f-bf24-956a48b1c071	nguyenthilinhnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Linh Nhi	DV	12B5	2026-03-30 22:13:23.937+00	2025-2026
ebfc0c7b-8793-4d59-b58b-e37b47f2c56a	nguyenthinguyetnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Nguyệt Nhi	DV	12B1	2026-03-30 22:13:23.937+00	2025-2026
ba138df4-fdce-41a3-94a2-af54948638c4	nguyenthiquynhnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Quỳnh Nhi	DV	11C3	2026-03-30 22:13:23.937+00	2025-2026
13b6894d-d3a8-40ab-a51b-f559a735a73e	nguyenthiquynhnhi1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Quỳnh Nhi	DV	11C6	2026-03-30 22:13:23.937+00	2025-2026
0b664e05-e985-43b3-8954-5eabefac04ef	nguyenthiyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Yến Nhi	DV	11C2	2026-03-30 22:13:23.937+00	2025-2026
8d9ae71c-50fb-424c-b6e1-8541d017546f	nguyenyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Yến Nhi	DV	11C2	2026-03-30 22:13:23.937+00	2025-2026
937378f1-3ba3-4173-acbb-e68dfcbe971a	nongleyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nông Lê Yến Nhi	DV	11C4	2026-03-30 22:13:23.937+00	2025-2026
b2c793fd-abdf-44d5-81e9-55026d76bd45	phamlegianhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Lê Gia Nhi	DV	12B1	2026-03-30 22:13:23.937+00	2025-2026
c42c841b-7cae-4b59-a7d1-781353034d39	phamlehoainhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Lê Hoài Nhi	DV	12B2	2026-03-30 22:13:23.937+00	2025-2026
857af85f-0c73-4af0-9c69-4f3ce568bf9c	phantrangianhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Trần Gia Nhi	DV	11C1	2026-03-30 22:13:23.937+00	2025-2026
108e940c-480c-4a1f-adb1-1629c4036ae5	thieuhoangyennhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thiều Hoàng Yến Nhi	DV	11C7	2026-03-30 22:13:23.937+00	2025-2026
9a6f98e2-74e1-4f78-93ee-e7144a52522e	tranbaonhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRẦN BẢO NHI	DV	12B6	2026-03-30 22:13:23.937+00	2025-2026
ff6f2bee-9a90-4f45-b077-a14a91e5d445	tranlinhnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Linh Nhi	DV	11C6	2026-03-30 22:13:23.937+00	2025-2026
68d06d0d-4f43-4559-b798-4e9ba0893a80	ylinhnhi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Y Linh Nhi	DV	12B9	2026-03-30 22:13:23.937+00	2025-2026
b556bd02-79c6-4b72-b9c1-c3e530f0fc51	hothinhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Nhung	DV	11C7	2026-03-30 22:13:23.937+00	2025-2026
cecfc0bf-19b9-4c9e-8df9-7c65c39dc118	lethihongnhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hồng Nhung	DV	12B9	2026-03-30 22:13:23.937+00	2025-2026
afc20e4e-0e89-4f13-a819-43ff7db95b62	ngothituyetnhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Thị Tuyết Nhung	DV	11C2	2026-03-30 22:13:23.937+00	2025-2026
536ef503-0271-418c-a58d-120645088b90	nguyenthihongnhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng Nhung	DV	12B5	2026-03-30 22:13:23.937+00	2025-2026
7aff40ab-769a-443e-be80-f8872fd60397	rolannhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Nhung	DV	12B7	2026-03-30 22:13:23.937+00	2025-2026
25e038df-8e98-446f-97ff-1cdaf4d08c78	truongthihongnhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRƯƠNG THỊ HỒNG NHUNG	DV	12B6	2026-03-30 22:13:23.937+00	2025-2026
fbcd4f52-93b8-4546-b78e-3f10452825ca	kpuihh'nhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Nhuy	DV	10A7	2026-03-30 22:13:23.937+00	2025-2026
4bc8f60f-bc8a-42fe-ac05-13e6a6115de2	daotrangianhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Trần Gia Như	DV	12B8	2026-03-30 22:13:23.937+00	2025-2026
770709a8-3e36-4724-bb5a-e8593c9e71ea	dinhthiquynhnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Quỳnh Như	DV	11C7	2026-03-30 22:13:23.937+00	2025-2026
42c51907-0ddd-46cb-b99c-2d2faec15f23	doquynhtonhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Quỳnh Tố Như	DV	12B9	2026-03-30 22:13:23.937+00	2025-2026
dcf20144-4b3f-42d5-9ad3-9a926053e17a	hothinhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Như	DV	10A2	2026-03-30 22:13:23.937+00	2025-2026
f40223ac-fb9c-4109-8850-8c2d7c2524c8	hotrangianhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Trần Gia Như	DV	10A3	2026-03-30 22:13:23.937+00	2025-2026
b18fbe76-d073-426f-ad3b-e89d4e3144a5	kpuihh'nhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Như	DV	12B7	2026-03-30 22:13:23.937+00	2025-2026
77972dca-26bf-4f9e-861d-3292940b3c21	bithu_10A8	$argon2id$v=19$m=65536,t=3,p=4$3GeoPx27U33crGmrrg2h9Q$Fg1omrQdXPHhVrp1jtzxuvnbYs8EO0zIRBJuKxnVAK0		BT	10A8	2026-03-25 22:50:22.949+00	2025-2026
51a97a71-e214-45ab-8e56-6458871ad4dd	bithu_11C1	$argon2id$v=19$m=65536,t=3,p=4$A3XXNTpZA5bf51zYZMZaqA$ZQSM0IylrwQvmF73M9LiAvQRRTjU22VxIvNfiwPtz9E		BT	11C1	2026-03-25 22:50:25.715+00	2025-2026
7e0bbf8f-e01f-42da-ad82-166f1caf827f	lequynhnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quỳnh Như	DV	11C9	2026-03-30 22:13:23.938+00	2025-2026
315cca99-e267-48fd-acce-74be2ff037b5	bithu_11C7	$argon2id$v=19$m=65536,t=3,p=4$WuwlC5YtKf5l7fk5IX2DKg$W95oNZ7DZAovgGLR/Y2AQa/rThGXbH34lepjnvYOHuY		BT	11C7	2026-03-26 01:46:55.69+00	2025-2026
7cdd95f2-0938-4c22-91e4-ed7f4a8d0dda	bithu_11C11	$argon2id$v=19$m=65536,t=3,p=4$hsBXN5UF1e42vzkf/jtPTw$WwuBsKernL+Rv8bUlewnxlRMneGHnEnp5Yb2uqawsis		BT	11C11	2026-03-26 01:47:55.212+00	2025-2026
6129c974-ea5f-4821-b089-89554b4b8e3e	bithu_12B5	$argon2id$v=19$m=65536,t=3,p=4$TN+S1fbDGXfL26tyRRnfpQ$1Z4Vys9vMAX4pKOnnsRYAA1n8cLeXO1lesdzfUhfsz0		BT	12B5	2026-03-26 01:48:13.355+00	2025-2026
5bcc6ff1-04ca-4382-8e9d-9d5088618a45	bithu_10A2	$argon2id$v=19$m=65536,t=3,p=4$LFVEVH1t8Q5OIoTijmbPTQ$Dn0T1OiL9Nkn2dYnQ/Vy22EKWDNrWx3UunweU7N4SLs		BT	10A2	2026-03-26 01:48:25.261+00	2025-2026
4d727e7b-1763-4580-818f-bbc5e5b19a95	letamnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Tâm Như	DV	12B1	2026-03-30 22:13:23.938+00	2025-2026
b66c4eb0-f86b-44d6-8412-0284d85177bf	nguyenhoaibaonhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoài Bảo Như	DV	11C8	2026-03-30 22:13:23.938+00	2025-2026
dedb3c37-c720-4007-9a49-c2fb5ef47463	nguyenngocbaonhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Bảo Như	DV	10A6	2026-03-30 22:13:23.938+00	2025-2026
1ffc8ebf-0702-4cff-8e47-cb96ef853e42	nguyenngocphuongnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Phương Như	DV	12B3	2026-03-30 22:13:23.938+00	2025-2026
62af8dea-36be-46bc-9c18-484f72ab0e50	bithu_12B9	$argon2id$v=19$m=65536,t=3,p=4$7Xcd9oalzWnzxsFVOwKRSg$uuLzfv8L1qUPyv6vu1CUzCMfnoIBYKMwXzOcd3aGa/A	Nguyễn Thành Tín	BT	12B9	2026-03-26 09:08:21.479+00	2025-2026
edfbd9cb-15c5-42f8-b51a-e6d90f02fb0b	Letrungthanhbtv	$argon2id$v=19$m=65536,t=3,p=4$7aDAvPslz8ibeTD/gb9zjg$bQfwrr3EqOBNqZoxgyF77g2nIZNcM5T7qm3gjWtbbIg	Lê Trung Thành -Bí thư ĐT	BTV	\N	2026-03-26 07:42:27.886+00	2025-2026
23b47baa-9fa2-4128-9a0b-6e0e98d7afe6	nguyenthiquynhnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Quỳnh Như	DV	10A5	2026-03-30 22:13:23.938+00	2025-2026
f4c98b47-92ed-41db-a9e3-569569e8f1fd	Gvcn_10A5	$argon2id$v=19$m=65536,t=3,p=4$sHHlYl7eNThVeLGWawK9SQ$rijlS4TNHnTj2EYqjdEpR/rfImy+HRHe5/sprBaogfI	Gvcn_10A5	GVCN	10A5	2026-03-26 07:50:55.761+00	2025-2026
12c52550-1a7b-4b65-a49e-19598297f2a3	Gvcn_10A10	$argon2id$v=19$m=65536,t=3,p=4$0RpQoXUwseObPUR7GXk8aA$NkURLFwlaryGLCPHoCWzqU3POIy8qouYHpCjg8tWpQg	Gvcn_10A10	GVCN	10A10	2026-03-26 07:50:58.417+00	2025-2026
45c20cf2-86b1-4be7-ba1c-b3d9af9882c7	Gvcn_11C4	$argon2id$v=19$m=65536,t=3,p=4$+PBDAWIjeB24JhvAXCjHyw$KJkfxQrN5O8UaYNvRWV5tmi4ZSZWVhEZ9hqQ3HPqiqA	Gvcn_11C4	GVCN	11C4	2026-03-26 07:51:01.078+00	2025-2026
7d906d49-15aa-408c-a859-881b7004ddf9	Gvcn_11C9	$argon2id$v=19$m=65536,t=3,p=4$xrAbv7JuHFRtfqL607bQXg$0m+1BJs0b/f7Pclu0IqAaP9SPGbv9TX4GgyAuTglX44	Gvcn_11C9	GVCN	11C9	2026-03-26 07:51:03.551+00	2025-2026
adad3346-2913-457e-bc44-71ab77e57644	Gvcn_12B2	$argon2id$v=19$m=65536,t=3,p=4$Mv0A7DEZnWF8BhlB/uHa+w$evUT/51ks3M1b6P2qrkXRw/AR0utwtTEvLCc5Q3P/EM	Gvcn_12B2	GVCN	12B2	2026-03-26 07:51:06.014+00	2025-2026
a9bad279-3cdc-4762-9b5f-cd6d5c1a2608	Leminhphuongbtv	$argon2id$v=19$m=65536,t=3,p=4$Y5lYDc9Had+EJM/PWm5qJg$c8+0lKGVEPdXzzpdycZ0PxEtEIEL7ZARyIXE2HljcBo	Lê Minh Phương BTV	BTV	\N	2026-03-28 22:36:04.141+00	2025-2026
bdbc9f67-cba9-473d-ae13-196065e1fbba	Admin	$argon2id$v=19$m=65536,t=3,p=4$RqimiH+e/jHVLJHaIl051A$gJLELmgI+X9dLd1V8DVI1loZaY7HL5iGKp3eq62fNkY	Hồ Hữu Thế - QT	Admin		2026-03-30 02:39:01.017+00	\N
ac221abf-4d52-4b1c-bc73-28bd249f67fe	trangianhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Như	DV	11C3	2026-03-30 22:13:23.938+00	2025-2026
83651e15-767f-4b22-9951-1d5fba7fec29	trangianhu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Như	DV	11C2	2026-03-30 22:13:23.938+00	2025-2026
7df29e0f-1182-49ff-a6ce-6942db8d9cc7	vohoyenvi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hồ Yến Vi	DV	11C1	2026-03-30 22:13:23.954+00	2025-2026
6b6886f9-f9ad-493d-b4bc-4bb751d0afb5	romahh'vien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Viên	DV	10A10	2026-03-30 22:13:23.954+00	2025-2026
54f0a833-7353-4975-beba-8e12af81d6e2	siuvien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	SIU VIÊN	DV	12B6	2026-03-30 22:13:23.954+00	2025-2026
1b7ae1f2-044b-4a20-a30a-4ddb55920a61	hoducviet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Đức Việt	DV	12B10	2026-03-30 22:13:23.954+00	2025-2026
a2e97755-1dd5-4f7f-b0f7-fc215dab683f	luongvietviet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lường Viết Việt	DV	11C8	2026-03-30 22:13:23.954+00	2025-2026
185d0fec-ff15-40e5-91d1-ec0c383008df	nguyenquocviet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quốc Việt	DV	12B10	2026-03-30 22:13:23.954+00	2025-2026
61328c8d-74d4-4316-843d-245cfc4697d1	nguyenxuanviet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Việt	DV	12B4	2026-03-30 22:13:23.954+00	2025-2026
a0d90654-7acc-4e1c-bebf-4c36ba1e0074	phamnguyenviet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Nguyên Việt	DV	12B2	2026-03-30 22:13:23.954+00	2025-2026
9a7f5ec3-ea39-4c45-accf-792d1daf748c	nguyentienvinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tiến Vinh	DV	11C10	2026-03-30 22:13:23.954+00	2025-2026
7b4ec4d6-02f8-4c21-9585-8dde57d3f78d	thieuquangvinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thiều Quang Vinh	DV	10A3	2026-03-30 22:13:23.955+00	2025-2026
3c9b6497-f12c-4d0e-bb36-d43e78db087f	ksorkyvong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Kỳ Vọng	DV	11C7	2026-03-30 22:13:23.955+00	2025-2026
bef99eab-e057-458f-a6c9-b644cb6d39e6	ksorlongvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Long Vũ	DV	11C7	2026-03-30 22:13:23.955+00	2025-2026
7afcd063-f9bd-403d-a65b-0e98c4a6574e	nguyenngocvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Vũ	DV	12B7	2026-03-30 22:13:23.955+00	2025-2026
cba523de-9e65-4277-90d4-5b9e28926904	nguyenquachuyvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quách Uy Vũ	DV	10A3	2026-03-30 22:13:23.955+00	2025-2026
1f1554a1-3450-4e27-b193-f13873f9a191	nguyentruonganhvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trương Anh Vũ	DV	12B8	2026-03-30 22:13:23.955+00	2025-2026
aaab4cac-f07f-4de1-9560-a75535db4c19	phamminhvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Minh Vũ	DV	12B3	2026-03-30 22:13:23.955+00	2025-2026
9a76efd4-ee9b-4584-b330-054d9c0594f8	phanhoanvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Hoàn Vũ	DV	12B4	2026-03-30 22:13:23.955+00	2025-2026
dd9eda17-d454-457d-b499-f3c1d9b7299e	romahvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Vũ	DV	11C9	2026-03-30 22:13:23.955+00	2025-2026
f6928bf2-9d79-43d3-a733-80e272355af3	trandouyvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đỗ Uy Vũ	DV	10A4	2026-03-30 22:13:23.955+00	2025-2026
735242b8-c790-4fea-8cdd-a8ba1471b0dd	truongminhvu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Minh Vũ	DV	12B9	2026-03-30 22:13:23.955+00	2025-2026
aa7a82de-bb20-4e6a-ae38-08be482cb911	phanquocvuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Quốc Vương	DV	10A10	2026-03-30 22:13:23.955+00	2025-2026
9fbc5b37-cace-4ff4-9793-ad610b10c7b2	buithituongvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Tường Vy	DV	10A3	2026-03-30 22:13:23.955+00	2025-2026
ba87412d-64d9-4a80-8d0a-2bd0d56a68d8	buithituongvy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Tường Vy	DV	11C11	2026-03-30 22:13:23.955+00	2025-2026
85c9543e-c42c-4756-bc2b-ca361b07ffab	dangthithaovy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thị Thảo Vy	DV	10A7	2026-03-30 22:13:23.955+00	2025-2026
34c8bd13-505f-4a1d-a5bc-7c67a930bbce	doantuongvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Tường Vy	DV	10A1	2026-03-30 22:13:23.955+00	2025-2026
d36ec04c-130c-470d-abcf-2cb8bf64b85c	hoanguyenvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Uyên Vy	DV	12B3	2026-03-30 22:13:23.955+00	2025-2026
9dfcf56c-5b1f-441c-940b-f9222efb8c7f	lenguyenthaovy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Nguyễn Thảo Vy	DV	12B8	2026-03-30 22:13:23.955+00	2025-2026
60789f3c-753c-4b9e-a6d3-8cfc496422c8	lethaovy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thảo Vy	DV	11C8	2026-03-30 22:13:23.955+00	2025-2026
e9e46a0a-2b48-4828-81b4-c4d2c58bd271	lethihavy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Hạ Vy	DV	10A6	2026-03-30 22:13:23.955+00	2025-2026
8cc37bc5-ce6d-4f3d-8c84-69108c76faaa	lethiyenvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Yến Vy	DV	12B2	2026-03-30 22:13:23.955+00	2025-2026
b2ce6fbd-1c17-4829-b8b9-a2efbe95e8cb	vanvoanhtho	$argon2id$v=19$m=65536,t=3,p=4$w/+sV2RjaGuKMH75G/5Biw$YthFceHdAVZRI5YitJ7RWNEyK2EcJh85iiM4XC7kwoU	Văn Võ Anh Thơ	DV	11C7	2026-03-30 23:19:17.166+00	2025-2026
0953cb21-d62b-45f0-a4be-c343ee22dc03	trinhtamnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Tâm Như	DV	12B1	2026-03-30 22:13:23.938+00	2025-2026
0156e43f-13a7-4194-81c9-b002f5299c89	truongnguyenquynhnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Nguyễn Quỳnh Như	DV	11C4	2026-03-30 22:13:23.938+00	2025-2026
3e993bd3-c466-4d02-b8ef-360cb0223d86	vuthituyetnhu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Tuyết Như	DV	10A8	2026-03-30 22:13:23.938+00	2025-2026
015514e5-5d90-448a-9639-88412190dcd4	kpuihh'nhung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Nhưng	DV	12B7	2026-03-30 22:13:23.938+00	2025-2026
9e725952-d867-4d74-b33b-b37d2f67aa19	dinhnhuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Nhương	DV	10A6	2026-03-30 22:13:23.938+00	2025-2026
721f428c-2762-4dd7-9e89-b0481c9928fd	ksorh'zani	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor H' Za Ni	DV	10A5	2026-03-30 22:13:23.938+00	2025-2026
6d330005-a293-4d5d-82bb-bd95018df076	romahh'nie	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Niê	DV	10A10	2026-03-30 22:13:23.938+00	2025-2026
ef9e4b77-cc24-4d18-9514-a61835a4515f	siuenny	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu En Ny	DV	10A7	2026-03-30 22:13:23.938+00	2025-2026
9f075705-01ae-4e63-b473-67f5947f672f	buinuvyoanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Nữ Vy Oanh	DV	11C1	2026-03-30 22:13:23.938+00	2025-2026
59fd497d-4047-4c90-a0b6-5b007180a2ed	hoangthikimoanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Kim Oanh	DV	11C3	2026-03-30 22:13:23.938+00	2025-2026
c7cfdf8b-0a30-45a2-b629-4b0de54c611e	luongthikieuoanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lường Thị Kiều Oanh	DV	10A8	2026-03-30 22:13:23.938+00	2025-2026
3c6ba3a7-a864-475c-8cce-b006f2a4f2af	nguyenthikimoanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Kim Oanh	DV	11C2	2026-03-30 22:13:23.938+00	2025-2026
ee19772d-772c-4c78-9b8e-40b66dc5ad57	phamthioanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Oanh	DV	10A5	2026-03-30 22:13:23.938+00	2025-2026
85c2fa41-183b-4dcb-b067-afe6fff4fffa	nguyentaiphat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tài Phát	DV	11C6	2026-03-30 22:13:23.938+00	2025-2026
8e78c0d9-15c3-427d-9a4b-7b17980a1067	nguyentanphat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Tấn Phát	DV	11C1	2026-03-30 22:13:23.938+00	2025-2026
297ddc5f-1a20-49f5-ad31-51e3ebe9f5c2	trangiaphat	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Gia Phát	DV	11C2	2026-03-30 22:13:23.938+00	2025-2026
1df2da7c-e442-4df4-8905-17bb815848e4	dohaphi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Hà Phi	DV	12B1	2026-03-30 22:13:23.938+00	2025-2026
c6d8eedd-eaa8-4e25-b2eb-4bda5fdd6da1	maihoangphi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Hoàng Phi	DV	11C10	2026-03-30 22:13:23.938+00	2025-2026
c37e62a8-0b6e-43a5-89a4-5eab4f1586e4	romahphien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Phiên	DV	12B5	2026-03-30 22:13:23.938+00	2025-2026
59c356e4-24ce-4ac5-9556-fb54e6ac620c	hohuuminhphong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Minh Phong	DV	10A11	2026-03-30 22:13:23.938+00	2025-2026
673a20d9-2d1a-49ed-b1c5-2583722c8265	nguyendinhphong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Phong	DV	10A9	2026-03-30 22:13:23.938+00	2025-2026
045f096d-12ae-4cde-a62b-443b00cf1688	trandangphong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đăng Phong	DV	11C12	2026-03-30 22:13:23.938+00	2025-2026
09d33272-9ab9-4b1c-a1f1-2c6da286a576	hoanglamphu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Lâm Phú	DV	10A4	2026-03-30 22:13:23.939+00	2025-2026
32c1de57-4465-48e3-abce-014038706eb4	lequangphu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Quang Phú	DV	10A2	2026-03-30 22:13:23.939+00	2025-2026
0b8a9860-48b9-4e77-9e0f-3366769ddc99	hoangvanphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Văn Phúc	DV	12B1	2026-03-30 22:13:23.939+00	2025-2026
82be9347-73b1-4512-be39-aca3e62220b9	hothibaophuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Bảo Phúc	DV	12B1	2026-03-30 22:13:23.939+00	2025-2026
29a29936-2294-46f9-b976-f0b49e225946	huynhvanphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Văn Phúc	DV	11C3	2026-03-30 22:13:23.939+00	2025-2026
484587aa-9163-482e-9e7c-ddb09eda65ca	nguyenvanphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Phúc	DV	11C4	2026-03-30 22:13:23.939+00	2025-2026
477f9a9b-d9fb-4508-9b08-8eb6c0e0c25d	phimanhphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phí Mạnh Phúc	DV	12B5	2026-03-30 22:13:23.939+00	2025-2026
38a7386e-e031-40fd-8bcc-573b8f0a0494	vanduchoangphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Văn Đức Hoàng Phúc	DV	12B10	2026-03-30 22:13:23.939+00	2025-2026
eea872ac-cda0-4800-b4ad-c7492681389a	vohothanhphuc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hồ Thanh Phúc	DV	10A2	2026-03-30 22:13:23.939+00	2025-2026
b3270b2e-b122-415d-a957-90679f96cff6	levanphung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Phụng	DV	12B9	2026-03-30 22:13:23.939+00	2025-2026
106e29e9-bed5-4f50-aa99-8787eec88e65	chudangnhatphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Chu Đặng Nhật Phương	DV	11C12	2026-03-30 22:13:23.939+00	2025-2026
3aaf6dea-3527-4fca-a0b5-c8faacb8655e	duonglethaophuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Lê Thảo Phương	DV	12B2	2026-03-30 22:13:23.939+00	2025-2026
086dd4ec-5371-4416-b88e-a8feebdd8979	dangthithuphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Thị Thu Phương	DV	10A1	2026-03-30 22:13:23.939+00	2025-2026
900d6098-98b0-4484-9719-67f0174d4ddd	doanngocnamphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Ngọc Nam Phương	DV	11C12	2026-03-30 22:13:23.939+00	2025-2026
6afd4f16-3fe6-4300-9713-1dbdabae1791	lehoanghaphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hoàng Hạ Phương	DV	12B8	2026-03-30 22:13:23.939+00	2025-2026
0ae9b6e7-d014-4c3e-87b0-5aa13259b6b6	leminhphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Minh Phương	DV	11C1	2026-03-30 22:13:23.939+00	2025-2026
e03132da-21e2-40f2-bb5b-87bd4a99b18c	lethimaiphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Mai Phương	DV	12B4	2026-03-30 22:13:23.939+00	2025-2026
1385bf3c-2064-4d5a-b3bc-cb5981540c0b	lethithuphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thu Phương	DV	11C5	2026-03-30 22:13:23.939+00	2025-2026
abdc56c1-10c8-4c0c-80e4-106e03524034	lethiuyenphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Uyên Phương	DV	10A3	2026-03-30 22:13:23.939+00	2025-2026
ed9fd8f6-e090-4113-92db-e762ac28da3a	luonghuuphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Hữu Phương	DV	10A9	2026-03-30 22:13:23.939+00	2025-2026
10450b41-4f82-47a1-a5ed-d95970aa2b4f	nguyenanhphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Anh Phương	DV	12B2	2026-03-30 22:13:23.939+00	2025-2026
b67c0383-8018-434f-97f0-a71d6eb2bc44	nguyenngocnhaphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Nhã Phương	DV	11C1	2026-03-30 22:13:23.939+00	2025-2026
427bd7fe-eeb7-462c-9b39-d41729e4d8d5	nguyenthanhphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THANH PHƯƠNG	DV	12B6	2026-03-30 22:13:23.939+00	2025-2026
25b1e804-5d50-45dc-a57d-3e5f6cd99e48	nguyenthidiemphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diễm Phương	DV	10A10	2026-03-30 22:13:23.939+00	2025-2026
5a14bd1f-debb-42ef-a3ab-06c665830f6b	nguyenthihongphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng Phương	DV	12B7	2026-03-30 22:13:23.939+00	2025-2026
c89916d1-6e55-4e10-a04e-c93849c4b777	nguyenthilinhphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Linh Phương	DV	11C5	2026-03-30 22:13:23.939+00	2025-2026
ec76de50-236d-4667-b854-726760f49c6c	nguyenthingocphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Phượng	DV	12B7	2026-03-30 22:13:23.939+00	2025-2026
95918977-350f-4c7c-8abc-59d584572b1a	nguyenthiphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Phương	DV	12B4	2026-03-30 22:13:23.939+00	2025-2026
33677cf2-e03e-4e7e-8fe0-554a34eddef5	vuminhphuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Minh Phương	DV	11C11	2026-03-30 22:13:23.94+00	2025-2026
5105e873-debb-475c-a19a-104ad3c43d42	rochamh'plil	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm H' Plil	DV	11C8	2026-03-30 22:13:23.94+00	2025-2026
201593b8-f9a9-429b-bd98-5da9301f0590	puihply	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	PUIH PLÝ	DV	12B6	2026-03-30 22:13:23.94+00	2025-2026
99471020-7e21-4faf-be91-f469027127b1	dobaoquang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Bảo Quang	DV	10A1	2026-03-30 22:13:23.94+00	2025-2026
1af0785f-3eb8-4adf-8ca6-628ba90a37d4	hohuuquang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Quang	DV	10A1	2026-03-30 22:13:23.94+00	2025-2026
30a18dbe-adf5-4166-8f10-0b046da2d660	laiminhquang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lại Minh Quang	DV	10A4	2026-03-30 22:13:23.94+00	2025-2026
ec7d61b9-7f8d-4a04-9e38-d10939f52f44	tranminhquang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Minh Quang	DV	12B4	2026-03-30 22:13:23.94+00	2025-2026
3774f8d2-b7e9-4523-8515-ce2f49afecee	buiminhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Minh Quân	DV	11C5	2026-03-30 22:13:23.94+00	2025-2026
42518d96-bcd0-44a5-9b52-840d1ad955a5	caonhuhoangquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Nhữ Hoàng Quân	DV	11C1	2026-03-30 22:13:23.94+00	2025-2026
923237a1-256e-46ef-b8a2-e3c201364f50	dangduyquocquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Duy Quốc Quân	DV	11C12	2026-03-30 22:13:23.94+00	2025-2026
5ccd9f02-2d58-4327-8647-5402e2d32102	dautienquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đậu Tiến Quân	DV	12B5	2026-03-30 22:13:23.94+00	2025-2026
4ad6ce60-6f0d-4918-b63a-77905b899507	doananhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Anh Quân	DV	12B1	2026-03-30 22:13:23.94+00	2025-2026
761742a4-3ca6-4d20-b714-5735209b5668	bithu_10A9	$argon2id$v=19$m=65536,t=3,p=4$V3PFfXJ7jpYoYZEvl8jU6g$6ervUF7/aEDNXzRf31/h6fPm4eCL78k/iAuE4m5owh0		BT	10A9	2026-03-25 22:50:23.631+00	2025-2026
60780226-b402-4d18-b821-745106ed39d2	bithu_11C8	$argon2id$v=19$m=65536,t=3,p=4$bDCtS1TTYPF1cP0RXl1i7Q$wD8xuXTXN6ou+nqJyJFl4E5kFDAmoBEnzLiMkteAXj8		BT	11C8	2026-03-26 01:44:34.537+00	2025-2026
ccaa778a-bd26-4e1a-a93a-e9c76f4e034f	bithu_11C2	$argon2id$v=19$m=65536,t=3,p=4$UxvUSbrNyJuRKA5zUrtcog$l6L832BJY4AMDWShUIVK8IzOU1QOZFaLYveMuB2XHSg		BT	11C2	2026-03-26 01:48:51.313+00	2025-2026
a7a41eb7-b7fb-455c-9649-d1b26269cca1	bithu_11C12	$argon2id$v=19$m=65536,t=3,p=4$kFEYeCJRUvBtHaG07EDeiQ$Euh17bWZ8jAGyBEfJK5qC4qtUEo8oDH642PyL2I89RM		BT	11C12	2026-03-26 01:49:04.039+00	2025-2026
fe1ed425-96ce-49db-96b5-57f36b7acd91	Tranthithuytam	$argon2id$v=19$m=65536,t=3,p=4$bkPCIo+4RA3SG6cN1PFGKQ$sXwdHUWz4LBsxqAaQa54NQsVQeTOrhv1HGejsiXVwMM	Trần Thị Thủy Tâm - Phó BT ĐT	BTV	\N	2026-03-26 07:42:51.396+00	2025-2026
a640ae9c-f460-45a2-bbce-d695cb8a5a27	bithu_12B10	$argon2id$v=19$m=65536,t=3,p=4$I7Z54mCMJW1b7prOY54njA$7Gnx/875KxojIk5eQgVvkheIzH3G1HKtTgRUSdcZnbI		BT	12B10	2026-03-26 01:49:57.084+00	2025-2026
3b820cc7-a8fe-4484-9296-cfb04733eb39	Gvcn_10A1	$argon2id$v=19$m=65536,t=3,p=4$kpIubLtfeEKjZfMIzF5v8Q$5VQEugREE+kGdVxEKvpvqxy3/CF7Hs4euvHzcIWySX4	Gvcn_10A1	GVCN	10A1	2026-03-26 07:50:53.416+00	2025-2026
11577c51-bc19-4466-8229-6db40261f160	bithu_10A3	$argon2id$v=19$m=65536,t=3,p=4$Zi3xl56DI2dbI/OKwF06IQ$7naRS48qdHGt7zinlCqqjDaa/2CNWLTHQqxLETedJ9o		BT	10A3	2026-03-26 02:08:47.797+00	2025-2026
4ddeba70-9b17-4e3d-ae90-ba1816ffcc75	Nguyenanhducbtv	$argon2id$v=19$m=65536,t=3,p=4$dDnpDR6ARTsfblW0TOq7bA$9Slsfi2pP5kA2SJIXwy9tr4RASgNHI6hen70+u0aBE0	Nguyễn Đức Anh (Người phát triển PM)	BTV	\N	2026-03-26 07:34:29.394+00	2025-2026
e3a81c23-23a8-44a5-808f-67481b325e98	Gvcn_10A6	$argon2id$v=19$m=65536,t=3,p=4$i4aOD4gxDETu6/Qc5tc3nw$LnesL3Av8IBHl3Pj29x43PWBuv+3qDUpoaeKzEvZOJg	Gvcn_10A6	GVCN	10A6	2026-03-26 07:50:56.273+00	2025-2026
e15f72e1-f19f-4fc2-8952-bfb7a5487e06	Gvcn_10A11	$argon2id$v=19$m=65536,t=3,p=4$rlUV+qejtx6X4w2N9I5Pag$ryPqefi3Utm5RQpCgcit5OcEi3Y1lPp84l/8tQAcQ+I	Gvcn_10A11	GVCN	10A11	2026-03-26 07:50:58.952+00	2025-2026
d6499295-635b-4f2c-9c4e-4792a4509466	Gvcn_11C5	$argon2id$v=19$m=65536,t=3,p=4$DjnJBQ4tmglfS/KyIWqXtA$2kRuh7qsMgARBAF6+uPjgb3QH1GpT8ryt2x7rlO50RY	Gvcn_11C5	GVCN	11C5	2026-03-26 07:51:01.606+00	2025-2026
b2a635a7-03db-4ffa-b6bc-2a48a6a3c9ed	Gvcn_11C10	$argon2id$v=19$m=65536,t=3,p=4$Kw1LloyGHAVE/8XZE4hWyw$QFa2Piaf2xGAmwbPPqapwAcNgoyC+h9vqTCDy94Kg30	Gvcn_11C10	GVCN	11C10	2026-03-26 07:51:04.061+00	2025-2026
14bc749a-f69d-47da-b7d5-f441d590fcde	hoangminhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Minh Quân	DV	10A11	2026-03-30 22:13:23.94+00	2025-2026
a5e69d22-4004-493e-b2db-dd260742772f	hoangquanghaiquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Quang Hải Quân	DV	11C10	2026-03-30 22:13:23.94+00	2025-2026
22360194-1d36-4929-b5cc-e62b1c38beb7	hokhacanhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hô Khắc Anh Quân	DV	10A1	2026-03-30 22:13:23.94+00	2025-2026
a255d25e-9fac-4106-9cb0-cba67d124834	hosyquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Sỹ Quân	DV	10A1	2026-03-30 22:13:23.94+00	2025-2026
ebfb6871-7255-490a-8d52-b4cece415ff7	maitienquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Tiến Quân	DV	10A5	2026-03-30 22:13:23.94+00	2025-2026
ee55c33c-3a7a-4850-9455-3fc83da72972	ngotriquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Trí Quân	DV	10A10	2026-03-30 22:13:23.94+00	2025-2026
b3f7863a-67b8-47f5-a807-c036aaffb78a	nguyenmanhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Mạnh Quân	DV	12B7	2026-03-30 22:13:23.94+00	2025-2026
b41df4db-ef61-4497-a389-5c1b9e3e4837	nguyenngocanhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Anh Quân	DV	10A3	2026-03-30 22:13:23.94+00	2025-2026
367ec726-6e3b-4707-a1fa-b9b8b88395b4	phamvanquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Văn Quân	DV	11C4	2026-03-30 22:13:23.94+00	2025-2026
34fc7aae-03fe-427d-bc03-2d8fc4f9361c	trananhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Anh Quân	DV	10A9	2026-03-30 22:13:23.94+00	2025-2026
339493f1-1ece-44f8-940e-1f8b895a9045	tranducquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đức Quân	DV	10A10	2026-03-30 22:13:23.94+00	2025-2026
3e02f13a-8adf-4ae3-ae0d-c8e8174f24cf	trankhanhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Khánh Quân	DV	12B4	2026-03-30 22:13:23.94+00	2025-2026
92128db3-74a2-4acd-bdb5-5032967cfab0	tranminhquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Minh Quân	DV	12B4	2026-03-30 22:13:23.94+00	2025-2026
541fe091-8341-4a4b-9c58-78d23981d07d	trantrungquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Trung Quân	DV	11C6	2026-03-30 22:13:23.94+00	2025-2026
592aba2a-67c1-45ab-94e5-9d9e9ac01179	trinhquocquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Quốc Quân	DV	11C10	2026-03-30 22:13:23.94+00	2025-2026
b5ba462c-7f3f-4f08-a84e-b494bb0f9142	vuvanquan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Văn Quân	DV	12B10	2026-03-30 22:13:23.941+00	2025-2026
93a1a613-1025-429d-85bc-619a83c013e5	kpuihh'que	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Quế	DV	10A10	2026-03-30 22:13:23.941+00	2025-2026
ac9bdef2-e1c6-4df9-8eac-8b453d5c7b87	nguyenchiquoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Chí Quốc	DV	12B2	2026-03-30 22:13:23.941+00	2025-2026
7a41f43c-ae4a-4f25-8f51-aa1ad7f6a693	tranngocquoc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Ngọc Quốc	DV	12B5	2026-03-30 22:13:23.941+00	2025-2026
a97c07cc-32d3-4ec9-9358-9eef47cf807d	dinhhongquy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Hồng Quy	DV	10A2	2026-03-30 22:13:23.941+00	2025-2026
8be6738b-01ec-4780-9fef-1811b0e49ab7	lethequy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thế Quý	DV	10A11	2026-03-30 22:13:23.941+00	2025-2026
4e076efb-c5e7-47cd-9869-e24418e89499	caothucquyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thục Quyên	DV	12B8	2026-03-30 22:13:23.941+00	2025-2026
b923cd50-3761-434a-8f7b-05624b0455e9	duongthihongquyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Thị Hồng Quyên	DV	10A4	2026-03-30 22:13:23.941+00	2025-2026
7e826591-10e2-4551-81d8-3a9ec2da7cd0	hoanglongquyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Long Quyền	DV	12B6	2026-03-30 22:13:23.941+00	2025-2026
b73b1f3b-7878-4394-b832-b80bfcb51fe7	nguyenvanquyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Quyền	DV	12B3	2026-03-30 22:13:23.941+00	2025-2026
65a972d6-18e8-42fb-a02b-f2c6f3f8ee4e	rolanaiquyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Ai Quyết	DV	11C4	2026-03-30 22:13:23.941+00	2025-2026
61f09e83-a3c6-4cde-88a3-65505c537205	siuquyet	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Siu Quyết	DV	11C9	2026-03-30 22:13:23.941+00	2025-2026
300e392a-0e8e-4432-896d-9e70e3ebef1b	chuthiquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Chu Thị Quỳnh	DV	11C11	2026-03-30 22:13:23.941+00	2025-2026
020e38e6-b9bc-4333-bc54-920ac86e9042	khieuthinhuquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Khiếu Thị Như Quỳnh	DV	11C5	2026-03-30 22:13:23.941+00	2025-2026
a845140d-8490-4d5b-b2a5-21a250781bc0	nguyenthidiemquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diễm Quỳnh	DV	11C2	2026-03-30 22:13:23.941+00	2025-2026
b4ab31bb-5306-41f2-9926-4fa22886bbad	nguyenthidiemquynh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diễm Quỳnh	DV	12B2	2026-03-30 22:13:23.941+00	2025-2026
db1d922b-26f7-4e45-bc17-c43a02f94efa	nguyenthinhuquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Như Quỳnh	DV	10A4	2026-03-30 22:13:23.941+00	2025-2026
d65e30b4-a052-46a9-a38f-95497a25beae	nguyenthinhuquynh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Như Quỳnh	DV	10A6	2026-03-30 22:13:23.941+00	2025-2026
8306bdc8-8bae-4f2c-bd27-ce88544d8cbf	phamvunhuquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Vũ Như Quỳnh	DV	10A1	2026-03-30 22:13:23.941+00	2025-2026
7920a5ea-db27-43cf-af0e-37d27318ad5e	romahh'quynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Quỳnh	DV	10A7	2026-03-30 22:13:23.941+00	2025-2026
c7398618-bcca-478f-8466-3e00a91ce52e	romahh'quynh1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Quỳnh	DV	12B8	2026-03-30 22:13:23.941+00	2025-2026
25da0f2c-1461-4320-a518-43b01884df97	tranthidiemquynh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Diễm Quỳnh	DV	11C11	2026-03-30 22:13:23.941+00	2025-2026
20b5a58f-4412-41d1-89cd-9cd9249358b9	rolanh'reny	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Rêny	DV	11C6	2026-03-30 22:13:23.941+00	2025-2026
2dab198d-5775-4fc8-9366-bac8dc1544c2	rolanh'siu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Siu	DV	10A8	2026-03-30 22:13:23.942+00	2025-2026
74258403-ce34-4316-aeb7-55b24473511e	kpuihh'soa	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Soa	DV	12B5	2026-03-30 22:13:23.942+00	2025-2026
bc409f91-ed4d-4f75-b6c4-05c831b54caf	romahh’sori	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H’ Sôri	DV	10A8	2026-03-30 22:13:23.942+00	2025-2026
0613beb0-8317-4c72-9395-0ccccc12f7ec	rolanaso	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan A Sở	DV	10A5	2026-03-30 22:13:23.942+00	2025-2026
ce499070-7fcb-4865-bcf8-27854dc7b61c	caothaison	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cao Thái Sơn	DV	11C11	2026-03-30 22:13:23.942+00	2025-2026
f61923a7-2608-4157-8443-1b6bbc20406d	maivanson	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Văn Sơn	DV	12B9	2026-03-30 22:13:23.942+00	2025-2026
122e38fe-b9e9-4944-9ed7-7af7f98bdad4	romahh'sorka	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Sơrka	DV	11C7	2026-03-30 22:13:23.942+00	2025-2026
d0779bd5-f0fa-4314-9494-7602b63020c0	kpuihsua	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Sữa	DV	10A7	2026-03-30 22:13:23.942+00	2025-2026
74052341-ffa8-4f2b-8f43-606ac79e582b	nguyenkhanhsuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khánh Sương	DV	11C4	2026-03-30 22:13:23.942+00	2025-2026
d9e73507-47a3-4492-82a0-2d662f25ce38	rolanh’suong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H’ Sương	DV	10A6	2026-03-30 22:13:23.942+00	2025-2026
48f5f205-37a7-497b-ab6a-dc5375a44d7b	hovietsy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Viết Sỹ	DV	10A11	2026-03-30 22:13:23.942+00	2025-2026
c9047629-9e0c-4f66-92dd-37c40bc13202	ngoducsy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Đức Sỹ	DV	12B1	2026-03-30 22:13:23.942+00	2025-2026
cee13eb9-9332-4340-ae48-8e0e33e9bab2	nguyenvansy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Sỹ	DV	12B8	2026-03-30 22:13:23.942+00	2025-2026
62248849-c8c5-4d12-8cfc-063233e614a7	buiductai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Đức Tài	DV	12B9	2026-03-30 22:13:23.942+00	2025-2026
33e1d06d-c980-4063-b347-b263d496b2e9	hovantai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Văn Tài	DV	10A4	2026-03-30 22:13:23.942+00	2025-2026
1d59a51d-30f1-4f21-8303-bcc7a49dc66a	hovinhduytai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Vĩnh Duy Tài	DV	11C5	2026-03-30 22:13:23.943+00	2025-2026
6b061e39-b025-4630-9fc3-f5c104bf946e	ledinhtai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đình Tài	DV	10A10	2026-03-30 22:13:23.943+00	2025-2026
e34b5089-371f-4348-b680-e76543ce31d8	nguyentutai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Từ Tài	DV	12B10	2026-03-30 22:13:23.943+00	2025-2026
bfd6a1b5-6e4b-4343-a956-3737918bd886	nguyenvantai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Văn Tài	DV	11C10	2026-03-30 22:13:23.943+00	2025-2026
71e15bfa-422d-4a3b-9949-b8e8b2a7d8ea	tranductai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Đức Tài	DV	12B9	2026-03-30 22:13:23.943+00	2025-2026
a4504287-0e2e-4eb7-9bb1-e4fa6f0c7ea9	voduytai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Duy Tài	DV	12B2	2026-03-30 22:13:23.943+00	2025-2026
b34ff8d1-4b0c-4a16-acb9-4c8a228cf8a4	doanthimytam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Thị Mỹ Tâm	DV	12B10	2026-03-30 22:13:23.943+00	2025-2026
bd2d89fb-feb2-40e7-84d0-a40234598815	hothanhtam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thanh Tâm	DV	11C3	2026-03-30 22:13:23.943+00	2025-2026
12e04441-5717-4a42-a5c0-323439d61e80	leduongnhattam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Dương Nhất Tâm	DV	10A2	2026-03-30 22:13:23.943+00	2025-2026
80f9d95e-b1d4-4c4f-b166-9da4ff7c54c4	maivantam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Văn Tâm	DV	12B8	2026-03-30 22:13:23.943+00	2025-2026
850d5788-b859-4c42-90bc-e79f099c03a4	nguyenthimytam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Mỹ Tâm	DV	11C8	2026-03-30 22:13:23.943+00	2025-2026
d6b500c1-fc15-46d3-96a1-50eff2b66a9c	nguyentrongtam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trọng Tâm	DV	11C10	2026-03-30 22:13:23.943+00	2025-2026
30923c4a-4f86-4d4c-9943-75f2ae3abe77	rolanh'tam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Tâm	DV	11C6	2026-03-30 22:13:23.943+00	2025-2026
90423de8-1cc5-4687-bdfd-9d5af49d747a	tranthimytam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Mỹ Tâm	DV	12B3	2026-03-30 22:13:23.943+00	2025-2026
4e3f6538-ac08-4645-bf46-158cc4e36625	tranthituetam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Tuệ Tâm	DV	10A4	2026-03-30 22:13:23.943+00	2025-2026
a652f4ce-a476-4164-9644-941301e7f06e	hoangthuytan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thủy Tần	DV	11C1	2026-03-30 22:13:23.943+00	2025-2026
1710e739-3ff7-4f51-9944-fa60a90fe217	nguyencanhtan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Cảnh Tân	DV	12B4	2026-03-30 22:13:23.943+00	2025-2026
00b8d2a7-2172-4f38-a239-fbc4e515155a	nguyenkhactan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Khắc Tân	DV	11C11	2026-03-30 22:13:23.943+00	2025-2026
b17afcee-fcd4-4977-bb51-8a19c15ee094	nguyennhattan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Nhật Tân	DV	11C3	2026-03-30 22:13:23.943+00	2025-2026
c8f70883-d932-4653-b151-f165174903f5	buisinhthai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Sinh Thái	DV	10A11	2026-03-30 22:13:23.943+00	2025-2026
4df2a80c-a5b3-4ee0-9a9b-f93da9259ecd	lengocthai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Ngọc Thái	DV	11C2	2026-03-30 22:13:23.943+00	2025-2026
184c9bab-cd4d-4220-93f5-d39a6717c321	tranvanthai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Thái	DV	10A5	2026-03-30 22:13:23.943+00	2025-2026
ff7976c0-8408-429f-85a5-d813f0b049e6	truongdinhcamthai	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Đình Cảm Thái	DV	10A3	2026-03-30 22:13:23.943+00	2025-2026
68f57ed5-d4da-474f-88c3-01cab630bd78	culegiathanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Cù Lê Gia Thanh	DV	11C1	2026-03-30 22:13:23.943+00	2025-2026
fbaef8b3-9498-4e80-a92b-025f9613df78	hangocthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hà Ngọc Thành	DV	10A9	2026-03-30 22:13:23.943+00	2025-2026
1c7b2701-9413-48a5-8d54-914976b61cf9	hothanhthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thanh Thanh	DV	12B5	2026-03-30 22:13:23.943+00	2025-2026
8f052a70-c5c1-4378-b519-581bc8582789	leducthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đức Thành	DV	10A2	2026-03-30 22:13:23.944+00	2025-2026
0fa9a5f0-e6ec-4cea-8329-8e840167ba1c	lehuuthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hữu Thành	DV	12B2	2026-03-30 22:13:23.944+00	2025-2026
9b176dd6-6231-482d-8351-444d7d3d7b37	lephuthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Phú Thành	DV	11C4	2026-03-30 22:13:23.944+00	2025-2026
e57bd34b-f228-4a1c-9e86-60de9a68f0b7	nguyenngoclanthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Lan Thanh	DV	10A1	2026-03-30 22:13:23.944+00	2025-2026
46eb1ff6-e14b-458e-adc5-c7495fdcec5a	nguyenphungthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phùng Thành	DV	10A6	2026-03-30 22:13:23.944+00	2025-2026
a6053f01-f8cb-46f1-9663-013e9a019d2c	nguyenxuanthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Thành	DV	11C5	2026-03-30 22:13:23.944+00	2025-2026
c30229d8-9809-4ef1-9383-d4f6e5866cfc	phanchithanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Chí Thành	DV	12B5	2026-03-30 22:13:23.944+00	2025-2026
4449ee11-d05d-4e58-8598-c6c5e864a863	rolanlethanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan Lê Thành	DV	10A7	2026-03-30 22:13:23.944+00	2025-2026
8faa11f9-e5aa-44f3-840b-0e41c04788d5	romahathanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah A Thanh	DV	11C11	2026-03-30 22:13:23.944+00	2025-2026
1cd36c42-b39c-4022-818e-2f204ec60ea6	tranthilethanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Lệ Thanh	DV	12B3	2026-03-30 22:13:23.944+00	2025-2026
e7dad4f6-7bcc-4ec0-84fc-94c4ede174a5	vovanthanh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Văn Thành	DV	10A2	2026-03-30 22:13:23.944+00	2025-2026
f4a23986-b5f2-428c-853e-481a12fd84d1	buithithao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Thảo	DV	10A7	2026-03-30 22:13:23.944+00	2025-2026
fa4a4f68-9aeb-4422-b663-2c5cd2c2df3a	daothithanhthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	ĐÀO THỊ THANH THẢO	DV	12B6	2026-03-30 22:13:23.944+00	2025-2026
33acb64b-bdd7-45ed-94f7-14fe2f6049ab	dangphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Phương Thảo	DV	10A8	2026-03-30 22:13:23.944+00	2025-2026
27df73c9-3c94-41da-9b88-b326efe72f4e	dinhhoangthuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Hoàng Thu Thảo	DV	12B1	2026-03-30 22:13:23.944+00	2025-2026
abf1d0f5-d0c6-4726-ac1a-ba0038e6de5e	dothithanhthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ Thị Thanh Thảo	DV	11C9	2026-03-30 22:13:23.944+00	2025-2026
ab8f83a4-5777-46d8-900c-292c0db60e33	hoangthiphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Phương Thảo	DV	12B1	2026-03-30 22:13:23.944+00	2025-2026
e89636dc-aa9a-452b-bd3d-5d4097022950	hothuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thu Thảo	DV	10A5	2026-03-30 22:13:23.944+00	2025-2026
616b6c53-2558-4436-a04b-37a471626ec8	huynhnguyenphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Huỳnh Nguyễn Phương Thảo	DV	10A3	2026-03-30 22:13:23.944+00	2025-2026
97aaa944-4f8b-4d3b-accb-2e0ef475579f	lucphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lục Phương Thảo	DV	10A6	2026-03-30 22:13:23.944+00	2025-2026
911a5d24-66d7-4ef2-a279-bf4176879d9e	luuthiphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lưu Thị Phương Thảo	DV	12B10	2026-03-30 22:13:23.944+00	2025-2026
8d2acf0d-abb8-41a6-89b2-fa9f16b97236	bithu_12B1	$argon2id$v=19$m=65536,t=3,p=4$tflNqp7LwGXimaImr8SsqQ$Xa8S2XcQrP41nKCvR3rrBSE/V2mOA2IIhLTkM/ZCJ+A		BT	12B1	2026-03-26 01:45:27.42+00	2025-2026
d2b5682e-c0cf-4b5a-8ceb-6632603741d2	Huynhhuuthua	$argon2id$v=19$m=65536,t=3,p=4$fyLjH3McJxxG6Gy/U7o0LQ$838WcZCQxrmNZmx005Te7pmWeBvdIv+JDiUtBUaKp7Q	Huỳnh Hữu Thừa - Hiệu trưởng	BGH	\N	2026-03-26 07:41:42.74+00	2025-2026
437a976a-822d-42a0-a8f0-4b78907e752e	bithu_12B7	$argon2id$v=19$m=65536,t=3,p=4$LJYQSjXRrSMgWyEFB56yVQ$UyDCo+zJ46xqXsykMcxz6ua5bu7l3ik8opYagtmEd/I		BT	12B7	2026-03-26 01:46:01.624+00	2025-2026
103d82c0-7d34-4be4-ac94-6e9376cfd9ce	bithu_11C3	$argon2id$v=19$m=65536,t=3,p=4$VZ1GDASwpOrPN+tYOkqYcg$59m8bDg9Qk90M75IoKKuqnXYdEHj9sIoPrNfEjp9W+s		BT	11C3	2026-03-26 01:46:25.807+00	2025-2026
e5c6b90c-1c95-41e3-863f-60646a4546b5	bithu_10A10	$argon2id$v=19$m=65536,t=3,p=4$/pEH6owgFSbrSDinvY7fig$nEPhrx/KpHYDownCj3FUD3xrDY7n8LlyR0G+T60j+aI		BT	10A10	2026-03-26 01:47:06.766+00	2025-2026
9c05960f-b5ff-41c0-b108-215c607d3ffa	bithu_10A4	$argon2id$v=19$m=65536,t=3,p=4$yHWUTVXNFGY136MCgLS95A$4Lmi6Nu7X7hMaqqw1PTiHHT2VCYpd+amyAeQ6sjNWM4		BT	10A4	2026-03-26 01:53:24.895+00	2025-2026
845094a2-9598-4bfd-92ee-c3c6222e15fd	Hohuuthe	$argon2id$v=19$m=65536,t=3,p=4$tWphk1rIxZ1nxxcFeMay1A$ba2WpgAWgFwD2oNSXacUCHvcXFCWRV57tF3slTyn2kg	Hồ Hữu Thế - Phó BT ĐT	BTV	\N	2026-03-26 07:43:18.052+00	2025-2026
27a7d29b-53a3-43e1-a6b0-389dae9e60da	bithu_11C9	$argon2id$v=19$m=65536,t=3,p=4$MqbIBfVZvxa97z7DZKJCLQ$Mc1ZOXzE+W6ehQu61Le4hLT+C+1bp8UCeMCnMvQlgas	‎	BT	11C9	2026-03-26 11:11:10.629+00	2025-2026
3ea26a0a-b95f-43de-ba98-35009781834b	Gvcn_10A2	$argon2id$v=19$m=65536,t=3,p=4$EpoClxH6h1JXzuz4qkXz4A$kXWskXq+TdZ3Ro1PnWxhaukmqw2EkryNAgVCJN6IiAA	Gvcn_10A2	GVCN	10A2	2026-03-26 07:50:54.032+00	2025-2026
92c5df43-82f5-4fab-b122-98b03f6431e9	Gvcn_10A7	$argon2id$v=19$m=65536,t=3,p=4$WyLBtaYtA/MxnNSzncFbbw$+bnC/D7Nn7Qau7CzFn6KBgbaY/+fiqw/LYcubJx6RPs	Gvcn_10A7	GVCN	10A7	2026-03-26 07:50:56.786+00	2025-2026
40780f5f-81a5-4c1e-9428-0fe45011c0ac	Gvcn_11C1	$argon2id$v=19$m=65536,t=3,p=4$dTwetzUp8Lmcs+71sEbM8Q$ZIBnc31DRCrgH/8fOkrhWEBE4QApMow7wnsQ/hKim8A	Gvcn_11C1	GVCN	11C1	2026-03-26 07:50:59.554+00	2025-2026
b01ae546-4954-45c5-9a68-251275abbcbe	Gvcn_11C6	$argon2id$v=19$m=65536,t=3,p=4$MomNc3qtigLJH5OKO72y6g$WSxq2Ullw8P6wk8mH5ZPJUaz4e8xvj+C/k5MxDNQRM0	Gvcn_11C6	GVCN	11C6	2026-03-26 07:51:02.122+00	2025-2026
15cb7e9f-b103-44a8-9047-e6f13e1d3711	Gvcn_11C11	$argon2id$v=19$m=65536,t=3,p=4$fe/xt68eCku7GQQIKSzl3w$1oX+uRVoflNJ+tTELWU/8ibT0PBqtGxKZpsJWCLoml0	Gvcn_11C11	GVCN	11C11	2026-03-26 07:51:04.472+00	2025-2026
5212fa94-8e10-47fb-bedb-7ffb83648b71	Gvcn_12B3	$argon2id$v=19$m=65536,t=3,p=4$NlicK2QePmAeLpULd7u9OQ$Bd3JvlrFPLsPUfzoQgIIbAROX2Tmq3DYfETK0t/3Yw0	Gvcn_12B3	GVCN	12B3	2026-03-26 07:51:06.522+00	2025-2026
ecd168f8-ff32-4496-930a-f2566dc8784c	Gvcn_12B4	$argon2id$v=19$m=65536,t=3,p=4$w6UgCUjM9YmESi/58ZpVcw$8eVqlLX7IY1h3TzjyvMfXB1fzGNJft+Mmt6v5eaC6tI	Gvcn_12B4	GVCN	12B4	2026-03-26 07:51:06.928+00	2025-2026
ffe2f048-7a71-4667-86ab-25f71a9ff503	Gvcn_12B9	$argon2id$v=19$m=65536,t=3,p=4$hIdI3Enbs/RKLk57J2DzuQ$Cv47DRkRaPeKg0EaYdb9ikbmLjVs/q/uWvLyqWIuFws	Gvcn_12B9	GVCN	12B9	2026-03-26 07:51:09.178+00	2025-2026
43ade008-5345-400d-ad15-30d06dc6f916	maithithao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Thảo	DV	12B10	2026-03-30 22:13:23.944+00	2025-2026
4f04d3be-b077-408f-85fd-06dc31bf62d9	nguyenhuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hương Thảo	DV	12B1	2026-03-30 22:13:23.944+00	2025-2026
2728ffd0-f46e-4a5a-acb0-7f5362a1b919	nguyenthidieuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ DIỆU THẢO	DV	12B6	2026-03-30 22:13:23.944+00	2025-2026
f8b24f0b-6dc2-4944-a34a-e2d21b7bda61	nguyenthithao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thảo	DV	10A9	2026-03-30 22:13:23.944+00	2025-2026
a73d8331-b9b3-4788-9b23-6d5a8a6ba21c	phanthiphuongthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Phương Thảo	DV	10A8	2026-03-30 22:13:23.944+00	2025-2026
66c98d82-c515-4215-afa6-59fb8aa70c12	phanthiphuongthao1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Phương Thảo	DV	12B5	2026-03-30 22:13:23.945+00	2025-2026
42f68ecc-62c4-4b64-9814-2eb407de3d05	tranthithao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thảo	DV	12B8	2026-03-30 22:13:23.945+00	2025-2026
0d5e3321-1a61-421a-8294-d3b7479387cf	vohanhthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hạnh Thảo	DV	10A1	2026-03-30 22:13:23.945+00	2025-2026
5f436f59-6acf-4add-97c6-6c00bc39a0d1	volethanhthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Lê Thanh Thảo	DV	10A4	2026-03-30 22:13:23.945+00	2025-2026
6c2f6199-8ef5-4ca8-921f-a53374975bdd	vudieuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Diệu Thảo	DV	11C12	2026-03-30 22:13:23.945+00	2025-2026
bd4ac2cf-c01e-490b-9d02-d8955e847b17	vuthithuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Thu Thảo	DV	12B10	2026-03-30 22:13:23.945+00	2025-2026
cb3ee0bf-ef95-4f4d-a5b4-24d09779b380	vuthuthao	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thu Thảo	DV	10A9	2026-03-30 22:13:23.945+00	2025-2026
2c82ef05-8129-49b6-8f20-42465e472362	maithitham	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Thắm	DV	10A11	2026-03-30 22:13:23.945+00	2025-2026
72b8bfcc-8c55-4a41-9960-7e4278f1f8f1	nguyenthihongtham	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hồng Thắm	DV	10A10	2026-03-30 22:13:23.945+00	2025-2026
cc249400-f753-4461-ba48-6eb723ab26fc	buisythang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Sỹ Thắng	DV	10A9	2026-03-30 22:13:23.945+00	2025-2026
a8038cdf-4b86-4e2a-80f2-aad7966b09bc	dinhducthang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Đức Thắng	DV	11C7	2026-03-30 22:13:23.945+00	2025-2026
199e19df-c6f4-4162-9a7e-04e79684b04e	hohuuthang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Hữu Thắng	DV	10A8	2026-03-30 22:13:23.945+00	2025-2026
e33b19ae-4b35-4035-88e1-608ae96c9728	nguyenducthang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đức Thắng	DV	12B1	2026-03-30 22:13:23.945+00	2025-2026
d2e6f19c-46a1-4801-a25c-118dc0c7a00c	nguyenhuuthang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hữu Thắng	DV	12B4	2026-03-30 22:13:23.945+00	2025-2026
f1eed202-4ec8-47a6-83be-b31053e8fa2e	nguyenxuanthang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Thắng	DV	10A10	2026-03-30 22:13:23.945+00	2025-2026
e8322dd6-ab61-4a14-94f1-7dac9ac6b69f	ksortheo	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	KSOR THEO	DV	12B6	2026-03-30 22:13:23.945+00	2025-2026
99fea43d-cf82-4225-84ea-34e781a4b661	tranhongthe	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Hồng Thế	DV	10A1	2026-03-30 22:13:23.945+00	2025-2026
38acf8db-6241-4d95-9a76-8d2a001758d4	ngothaovy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ngô Thảo Vy	DV	11C6	2026-03-30 22:13:23.955+00	2025-2026
3c92a5c5-334f-4fb1-ba9a-00611c3adf9a	nguyenlevy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Vy	DV	12B1	2026-03-30 22:13:23.955+00	2025-2026
4f40c7c0-d64f-4da1-afa2-38338d22c59c	phanthikieuvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Kiều Vy	DV	12B2	2026-03-30 22:13:23.955+00	2025-2026
ce2827c2-abf8-4d60-9cee-131886ec3d27	tranthikieuvy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Kiều Vy	DV	11C9	2026-03-30 22:13:23.955+00	2025-2026
29fcf240-27f3-486a-872f-5c33a59ac4f4	romahh'xari	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Xari	DV	11C6	2026-03-30 22:13:23.955+00	2025-2026
f3f65865-3eb1-480a-bbb5-d5d5a33e8ec8	romahxam	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Xâm	DV	10A10	2026-03-30 22:13:23.955+00	2025-2026
146e6230-8f64-476a-b761-c34882f0e871	buithanhxuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thanh Xuân	DV	11C8	2026-03-30 22:13:23.955+00	2025-2026
dd30ff3c-e554-4de7-aa15-b542baf04916	romahh'xuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Xuân	DV	11C8	2026-03-30 22:13:23.955+00	2025-2026
89a26466-d75e-4bd7-b485-945ebe97bc31	chaungocnhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Châu Ngọc Như Ý	DV	11C1	2026-03-30 22:13:23.956+00	2025-2026
ad7540c5-bef1-4789-8e29-635948a64e86	nguyenngocnhuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Như Ý	DV	11C1	2026-03-30 22:13:23.956+00	2025-2026
f6d2d3ed-edec-4f9f-bf2d-65905c8bc31c	nguyenngocnhuy1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Như Ý	DV	11C4	2026-03-30 22:13:23.956+00	2025-2026
f22a09f2-1011-4b46-87b4-47828b0531ae	romahh'y-su-in	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Y-Su-In	DV	12B7	2026-03-30 22:13:23.956+00	2025-2026
30e0c7d6-a2cb-4773-b222-ea4c1f229999	danghaiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Hải Yến	DV	11C9	2026-03-30 22:13:23.956+00	2025-2026
254e554e-87f9-486c-9798-8308f095167f	hoangthihaiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Hải Yến	DV	11C7	2026-03-30 22:13:23.956+00	2025-2026
2fed508b-07c6-48b8-8be0-e7a4bb3af080	hothingocyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Ngọc Yến	DV	12B7	2026-03-30 22:13:23.956+00	2025-2026
4186d5ee-fe55-4879-9048-4eb679ad4f17	kpuihh'yen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Yên	DV	10A5	2026-03-30 22:13:23.956+00	2025-2026
0d43a7c9-5885-4583-a817-2f08e9343752	nguyenngocthong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Thông	DV	11C7	2026-03-30 22:13:23.946+00	2025-2026
164948f7-36f0-402a-a811-1e80b85967bc	buithianhtho	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Anh Thơ	DV	11C2	2026-03-30 22:13:23.946+00	2025-2026
dd425fc0-83e8-40c6-bdf5-e20823f44752	hothianhtho	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Anh Thơ	DV	11C3	2026-03-30 22:13:23.946+00	2025-2026
fe70e681-0c10-4d81-955a-8a7045f9ebba	vothianhtho	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Thị Anh Thơ	DV	10A3	2026-03-30 22:13:23.946+00	2025-2026
6994eb3c-9256-41c1-b8af-e0436686cec7	buithilythu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Bùi Thị Lý Thu	DV	10A1	2026-03-30 22:13:23.946+00	2025-2026
6466f294-aba2-48f4-bd00-ff5a8cf30c4e	lethixuanthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Xuân Thu	DV	12B2	2026-03-30 22:13:23.946+00	2025-2026
09fc1676-a2d7-4ca2-9eb4-eb44d6a6b155	nguyenhienthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hiền Thu	DV	10A10	2026-03-30 22:13:23.946+00	2025-2026
2527be84-1d57-4265-8070-c4922972167f	nguyenthikimthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Kim Thu	DV	12B9	2026-03-30 22:13:23.946+00	2025-2026
a3477f49-3479-4cab-9619-248d714e95d5	hodienthuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Diên Thuận	DV	10A2	2026-03-30 22:13:23.946+00	2025-2026
69ce852a-0939-438d-be4e-eb53477eb612	luongvietthuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lường Viết Thuận	DV	11C9	2026-03-30 22:13:23.946+00	2025-2026
71fc67df-3011-41ea-89de-328cfe8bd5e0	nguyenthiaithuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ái Thuận	DV	11C3	2026-03-30 22:13:23.946+00	2025-2026
a4928fd7-5508-42dc-87d2-aee9ea3019b0	phamthibichthuan	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Bích Thuận	DV	11C8	2026-03-30 22:13:23.946+00	2025-2026
17bc260e-3691-41eb-804b-4397b9c77ed2	duongthithanhthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Thị Thanh Thúy	DV	10A7	2026-03-30 22:13:23.946+00	2025-2026
fade9d56-0ce6-48f1-8abd-3355910cb1b2	dangnguyenthuthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Nguyễn Thu Thủy	DV	12B8	2026-03-30 22:13:23.946+00	2025-2026
b4c217ee-e8b6-4086-a9db-87490cd126ab	dinhthithanhthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đinh Thị Thanh Thùy	DV	12B1	2026-03-30 22:13:23.946+00	2025-2026
82b77981-7ca3-4184-97d5-9ce1b343d633	hoangthithanhthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Thanh Thúy	DV	11C11	2026-03-30 22:13:23.946+00	2025-2026
4fa0fbbc-0c4e-4044-afcd-ef89528ca411	kpuihthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Thuy	DV	10A8	2026-03-30 22:13:23.946+00	2025-2026
08171746-f3ae-43e2-b461-1f37078baf6a	nguyenthibichthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN THỊ BÍCH THỦY	DV	12B6	2026-03-30 22:13:23.946+00	2025-2026
331ee924-63e8-4829-aadc-f6381d8e0fda	romahh'thuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Thủy	DV	10A5	2026-03-30 22:13:23.946+00	2025-2026
54bf89e6-bc10-42d2-bf51-42a87877f8b8	tranthithuthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thu Thủy	DV	10A7	2026-03-30 22:13:23.946+00	2025-2026
670faf08-882e-4a86-83aa-36c1be55e252	truongthithanhthuy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRƯƠNG THỊ THANH THỦY	DV	12B6	2026-03-30 22:13:23.946+00	2025-2026
2b7055b6-374d-4ef0-a1c3-796a5a9a8621	danganhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Anh Thư	DV	11C5	2026-03-30 22:13:23.946+00	2025-2026
e16babf6-2d90-4750-9ea7-2bcd1a46dacf	dauthianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đậu Thị Anh Thư	DV	10A6	2026-03-30 22:13:23.946+00	2025-2026
dee90ef1-4a3b-44a8-9a2d-12e66839a313	doananhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Anh Thư	DV	12B2	2026-03-30 22:13:23.947+00	2025-2026
a3a5f91d-3391-4b3b-9c50-20fb1988ab19	doantrananhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Trần Anh Thư	DV	11C10	2026-03-30 22:13:23.947+00	2025-2026
6ceea848-fa9a-41da-b6b1-5713525b0029	hoanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Anh Thư	DV	11C10	2026-03-30 22:13:23.947+00	2025-2026
8ba33ccd-c041-46ae-89a3-8320279175a5	hongocanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Ngọc Anh Thư	DV	12B8	2026-03-30 22:13:23.947+00	2025-2026
64f13545-5615-4f66-a729-a6e1d9f8ff36	hothianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Anh Thư	DV	11C4	2026-03-30 22:13:23.947+00	2025-2026
d7051c84-265d-47e0-b9dd-8c7c3212031b	kpuihh'thu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Thứ	DV	11C12	2026-03-30 22:13:23.947+00	2025-2026
79b81bbf-568a-4934-b7ce-144ff66b3aaf	lethianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Anh Thư	DV	10A6	2026-03-30 22:13:23.947+00	2025-2026
c3f2c5c2-6837-4eef-a707-d75d87a2b251	lethiminhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Minh Thư	DV	12B9	2026-03-30 22:13:23.947+00	2025-2026
53c6d3fb-a926-4930-8395-52da4ce048b8	lethingocthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Ngọc Thư	DV	11C1	2026-03-30 22:13:23.947+00	2025-2026
d2a4fbac-1c80-4b93-b1c4-9410975af7cb	nguyenanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Anh Thư	DV	11C9	2026-03-30 22:13:23.947+00	2025-2026
05cebb99-22a2-4010-ba67-a9ea2cf6aa9f	nguyenbuianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Bùi Anh Thư	DV	12B2	2026-03-30 22:13:23.947+00	2025-2026
e06f8487-3352-44b2-81de-b126889d5399	nguyenbuianhthu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN BÙI ANH THƯ	DV	12B6	2026-03-30 22:13:23.947+00	2025-2026
89fef6c4-e392-4b51-86a4-e6b874006fd1	nguyenhoanganhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Anh Thư	DV	10A2	2026-03-30 22:13:23.947+00	2025-2026
d21f6fbc-32a8-40ad-b964-6c6c2f4218a6	nguyenlebaothu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Lê Bảo Thư	DV	10A7	2026-03-30 22:13:23.947+00	2025-2026
239ef15b-cefd-44d3-887c-a54cfb01138e	nguyenngocanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Anh Thư	DV	10A7	2026-03-30 22:13:23.947+00	2025-2026
30b76a3a-9999-4670-bebe-4b466e15b993	nguyenthianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Anh Thư	DV	12B3	2026-03-30 22:13:23.947+00	2025-2026
ee474b5b-3e0a-40d6-9691-0085ff526472	nguyenthiminhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Minh Thư	DV	11C1	2026-03-30 22:13:23.947+00	2025-2026
6c331be6-4ce5-48b0-9bed-3623f37de446	phamanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Anh Thư	DV	11C5	2026-03-30 22:13:23.947+00	2025-2026
050269d3-bf5c-4501-b864-b3ea64897fa0	phamanhthu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Anh Thư	DV	12B4	2026-03-30 22:13:23.948+00	2025-2026
9b003a12-eaee-45ae-9929-93813d5efabd	phamhoanganhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Hoàng Anh Thư	DV	11C3	2026-03-30 22:13:23.948+00	2025-2026
9c0c40af-56b6-4ab3-b74b-b5ad167596e9	phamthianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Anh Thư	DV	10A3	2026-03-30 22:13:23.948+00	2025-2026
7d7414ab-8b08-415a-8166-d42c5b152cef	phamtrananhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Trần Anh Thư	DV	11C12	2026-03-30 22:13:23.948+00	2025-2026
ac3b6bf0-c6af-4c92-b23a-bbf1e9c53441	rolanh'thu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thư	DV	10A6	2026-03-30 22:13:23.948+00	2025-2026
e0221361-4389-4976-be84-25c49d61f689	rolanh'thu1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thư	DV	10A9	2026-03-30 22:13:23.948+00	2025-2026
4a2d11ee-5bf3-4cd1-8f61-6944a15b76d7	rolanh'thu2	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thư	DV	11C7	2026-03-30 22:13:23.948+00	2025-2026
f8d50532-db65-4b7e-a1cb-ef3245de396e	trananhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Anh Thư	DV	10A6	2026-03-30 22:13:23.948+00	2025-2026
08bf151c-f263-4fec-ae79-5b9c09859862	tranhoanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Hồ Anh Thư	DV	11C11	2026-03-30 22:13:23.948+00	2025-2026
6c64138e-6ad1-4892-b2a3-078049873b97	tranminhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Minh Thư	DV	12B3	2026-03-30 22:13:23.948+00	2025-2026
a0dd80e6-6d4f-403e-9d35-994f14f8b13f	tranthianhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Anh Thư	DV	11C12	2026-03-30 22:13:23.948+00	2025-2026
841462c9-c5e4-4f91-bd30-b1ff5ab5a349	tranvuanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Vũ Anh Thư	DV	10A5	2026-03-30 22:13:23.948+00	2025-2026
462c8c2c-c117-497f-a886-b0b7e40a5535	trinhtamthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Tâm Thư	DV	11C2	2026-03-30 22:13:23.948+00	2025-2026
ca86ad98-35d7-41a5-b988-d8f1bcd13993	voanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Anh Thư	DV	10A2	2026-03-30 22:13:23.948+00	2025-2026
7e332952-fbac-4647-af32-a71e31a09f7a	vohuynhthienthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Huỳnh Thiên Thư	DV	10A4	2026-03-30 22:13:23.948+00	2025-2026
0b85f866-3fb5-48fe-a72b-4a842ec70a99	vuhoanhthu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Hồ Anh Thư	DV	12B5	2026-03-30 22:13:23.948+00	2025-2026
493c9e3d-ac8e-42a6-9262-e4b090cc1f75	nguyenlehoaithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	NGUYỄN LÊ HOÀI THƯƠNG	DV	12B6	2026-03-30 22:13:23.948+00	2025-2026
85463b59-e79e-4a0b-a241-74d8cfcd70d8	nguyenthithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thương	DV	11C4	2026-03-30 22:13:23.948+00	2025-2026
05a5a43b-68ed-4f31-928f-63e412810fee	nguyenthitramthuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Trầm Thương	DV	12B1	2026-03-30 22:13:23.948+00	2025-2026
baaf5978-51b3-4dad-9222-302f0ec88025	phamlehoaithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Lê Hoài Thương	DV	11C11	2026-03-30 22:13:23.948+00	2025-2026
4d51d6c0-31a1-41e9-b1a4-c53f8db6486c	rolanh'thuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thương	DV	10A6	2026-03-30 22:13:23.948+00	2025-2026
256a15f8-eb31-40e2-b163-d1ed7affdd85	bithu_10A5	$argon2id$v=19$m=65536,t=3,p=4$W8Y/BJEhutaKxkyiQx/RNA$3/YuWXYYbljEOdX82gpQXydwSCxuDpR4F6bbIzvGSmk		BT	10A5	2026-03-25 22:50:20.854+00	2025-2026
c91ec7de-9f26-4549-bc61-4bc606d736ee	bithu_11C4	$argon2id$v=19$m=65536,t=3,p=4$UqQXg1xoiLEQWJDkuPL2MQ$B3uLX1vqxbZHjMXvWFAPM/cyhqLxNGC6iv6kP4DnRGU		BT	11C4	2026-03-25 22:50:27.773+00	2025-2026
2c242149-e440-477e-a203-2b92e6fe60d0	bithu_12B4	$argon2id$v=19$m=65536,t=3,p=4$2uU3+ztge/ykHbTWYCQzlw$8fJ4Ng7XfltU2tZO7s8+pIP5hkt/j++TsnSumjsBOms		BT	12B4	2026-03-25 22:50:35.926+00	2025-2026
11abefbb-e34f-40e6-9dcf-3c13e8bb370f	bithu_12B2	$argon2id$v=19$m=65536,t=3,p=4$jl1wPCJGoIJv7Ss0mXi6BQ$ffG/yzG91o++9Z+uCgdqNIKB2MITli+te1yiF4u/m2Q		BT	12B2	2026-03-26 01:47:58.435+00	2025-2026
63f04d67-8c04-4f79-a9fe-3506b70a8a1f	Vothile	$argon2id$v=19$m=65536,t=3,p=4$EKI5cqTLnRDdhSj+71hFYw$VWbig1mvlgj6N6hvuuyNijh++ETjKWhUJwiWflJrmBE	Võ Thị Lệ -Phó HT	BGH	\N	2026-03-26 07:40:45.246+00	2025-2026
06040034-f82b-4ea1-8830-d56203b30e48	Gvcn_10A3	$argon2id$v=19$m=65536,t=3,p=4$Knvx8ykWXz3CG1jBu5fTFw$3cwEGlIzKhdQ3r7iiNr0CiN6+qSYYGF2NtGzX2PEd5M	Gvcn_10A3	GVCN	10A3	2026-03-26 07:50:54.653+00	2025-2026
5f56334c-d447-438b-8b4b-c71fedbcde9a	Gvcn_10A8	$argon2id$v=19$m=65536,t=3,p=4$yoC1gXK1UtQDV2wQn+6Jsg$Hze9mLmk27EfWGJlHNt5t/EtqeinUWBNLMDi0D4Nsf4	Gvcn_10A8	GVCN	10A8	2026-03-26 07:50:57.298+00	2025-2026
83b597af-f265-49f3-94cc-f8edbc2ea0d1	Gvcn_11C2	$argon2id$v=19$m=65536,t=3,p=4$f9vbxb2GrJJ5rzdCu2Yy+A$YDon4cuzQ2pA4JnVwEPc03r62CCK4MjCrq2MbU9VRBM	Gvcn_11C2	GVCN	11C2	2026-03-26 07:51:00.058+00	2025-2026
bd4b4e29-002b-4d54-9d1b-8a754a5a0a2a	Gvcn_11C7	$argon2id$v=19$m=65536,t=3,p=4$qrddSQWib1k2vLII7t4k3Q$M0c/Jml49kuLJC9WmLd/+IMW8K70nIRiA4z76s14Uws	Gvcn_11C7	GVCN	11C7	2026-03-26 07:51:02.631+00	2025-2026
ca954223-15bb-4800-addd-0c3ca67fd99a	Gvcn_11C12	$argon2id$v=19$m=65536,t=3,p=4$K8NO4CJYHfZ1rFVmcW9k7g$A4szXd0YIPuLHg1F8xYD1lrI8sIXLXzTsIaIF7KNKQI	Gvcn_11C12	GVCN	11C12	2026-03-26 07:51:04.983+00	2025-2026
77beb4a3-e51f-4639-922b-905392b47ec5	Gvcn_12B5	$argon2id$v=19$m=65536,t=3,p=4$ubrlE9W+zDkLKoGMloCvqQ$afFZzq9wLBorO+WOcRzJRZ3laKt7zMfg6NAQuSCZoag	Gvcn_12B5	GVCN	12B5	2026-03-26 07:51:07.335+00	2025-2026
fc327a9a-1c1f-4138-9e0b-e170445810c2	Gvcn_12B7	$argon2id$v=19$m=65536,t=3,p=4$2yRMgoP/ia+qil/+FGsqVA$w+m0UANIawID06bOslmZNmXRT7NTOBPm2sjxtnrM0NQ	Gvcn_12B7	GVCN	12B7	2026-03-26 07:51:08.245+00	2025-2026
780a6547-2a54-429b-a538-9e9225ad089b	Gvcn_12B10	$argon2id$v=19$m=65536,t=3,p=4$zUsPfsaEbR44b7w0JubW6g$eh7KNCfmyzVgnAjaT5KKqy069hqw+DgURZ7f8brpHEI	Gvcn_12B10	GVCN	12B10	2026-03-26 07:51:09.695+00	2025-2026
34d551c4-fcbd-48a6-83f6-7597d4ff47fe	bithu_11C10	$argon2id$v=19$m=65536,t=3,p=4$/Hx0gOt8gghVoYR3EL1k3Q$zLeA9tN3Y3bkIzN8S8ldz5HUcRXMkdvXp6KjQmrMFKU	Nguyễn Ngọc Tiên Nhi	BT	11C10	2026-03-27 01:14:02.783+00	2025-2026
cb2e575b-2104-4180-9095-ba73d37b7ad6	romahphamthithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Phạm Thị Thương	DV	10A8	2026-03-30 22:13:23.948+00	2025-2026
78f70884-9b18-469b-ac4a-2da821e1bc2b	romahthuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Măh Thương	DV	10A5	2026-03-30 22:13:23.948+00	2025-2026
20c4217b-6266-4e4a-a8fa-7cf888c3efb9	truongthihoaithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Thị Hoài Thương	DV	11C8	2026-03-30 22:13:23.949+00	2025-2026
afd1a89e-7a53-4813-afab-87783219582e	vohoaithuong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hoài Thương	DV	12B2	2026-03-30 22:13:23.949+00	2025-2026
33754090-fd5e-41a4-8378-1e4fde0e1d02	nguyenvutructhy	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Vũ Trúc Thy	DV	11C7	2026-03-30 22:13:23.949+00	2025-2026
0b69bcf4-9a33-4f39-99c6-08540d110ef5	daonguyenlamtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đào Nguyễn Lâm Tiên	DV	10A9	2026-03-30 22:13:23.949+00	2025-2026
fa5ac070-eafb-424a-a1f6-cf4e2c465b35	dangdinhtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Đình Tiến	DV	11C1	2026-03-30 22:13:23.949+00	2025-2026
e78f2ecb-3c1b-417d-a886-f8c8497f1d24	dangviettien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đặng Việt Tiến	DV	10A2	2026-03-30 22:13:23.949+00	2025-2026
d205ff9c-97f4-428a-b432-9991a3b3d971	doanhuynhmanhtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đoàn Huỳnh Mạnh Tiến	DV	12B3	2026-03-30 22:13:23.949+00	2025-2026
14ff007a-a7c0-45d9-93b4-6e38ef4c5066	hovinhtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Vĩnh Tiến	DV	11C4	2026-03-30 22:13:23.949+00	2025-2026
17dccc66-16da-4dd2-812b-f9e220ae74a2	ledoanthithuytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Đoàn Thị Thủy Tiên	DV	11C8	2026-03-30 22:13:23.949+00	2025-2026
e2d73a42-d08c-4204-97b7-f986f6b461e1	lethithuytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thủy Tiên	DV	11C8	2026-03-30 22:13:23.949+00	2025-2026
b5b45105-bccd-4379-99bf-ae8c95bf08cb	levantien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Văn Tiến	DV	11C10	2026-03-30 22:13:23.949+00	2025-2026
86b96098-66e8-4dc2-8ea0-7b05e7c9e4f7	lexuantien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Xuân Tiến	DV	12B5	2026-03-30 22:13:23.949+00	2025-2026
62794848-26f9-42a6-bf0f-e08d85e1aec4	luongthithuytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Thủy Tiên	DV	12B9	2026-03-30 22:13:23.949+00	2025-2026
7474cb59-f3cd-4c3f-b012-fb3671954b06	nguyenduytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Duy Tiến	DV	10A8	2026-03-30 22:13:23.949+00	2025-2026
911c1309-9d64-4457-bee7-59622a694792	nguyendinhtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Đình Tiến	DV	12B7	2026-03-30 22:13:23.949+00	2025-2026
82d3b898-0202-4316-bfeb-a2342e67d7d6	nguyenxuantien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Xuân Tiến	DV	12B8	2026-03-30 22:13:23.949+00	2025-2026
3c307c8a-c3e5-4e95-9173-48451d7e0f8d	trantrongtien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Trọng Tiến	DV	10A4	2026-03-30 22:13:23.949+00	2025-2026
589f92b0-38ed-41e8-a3ff-1fa869794b37	trinhthuytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Thủy Tiên	DV	11C6	2026-03-30 22:13:23.949+00	2025-2026
791fb94c-7f6b-4635-9ddd-afacc1c253df	truongaimytien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	TRƯƠNG ÁI MỸ TIÊN	DV	12B6	2026-03-30 22:13:23.949+00	2025-2026
4efaae86-502c-4872-b2fe-761a562b8826	vovantien	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Văn Tiến	DV	10A4	2026-03-30 22:13:23.949+00	2025-2026
9c71314e-8af7-47ee-881f-fd7ca628b4d6	nguyenthihaiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hải Yến	DV	10A8	2026-03-30 22:13:23.956+00	2025-2026
a2222ad2-294f-4b31-8805-a00451324b70	nguyenthihaiyen1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hải Yến	DV	12B5	2026-03-30 22:13:23.956+00	2025-2026
ba606f11-bce2-473f-a341-c4188120ef77	nguyenthihaiyen2	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Hải Yến	DV	12B9	2026-03-30 22:13:23.956+00	2025-2026
2c8b331b-0d42-4f55-8ba6-a5a7815711e2	nguyenthingocyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Yến	DV	12B7	2026-03-30 22:13:23.956+00	2025-2026
a7bec467-5dce-4cc4-84ef-1fd9c12b19fa	nguyenthiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Yến	DV	11C9	2026-03-30 22:13:23.956+00	2025-2026
fe66c269-4a43-4997-88e2-a6c9ba7c40df	phamngohoangyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Ngô Hoàng Yến	DV	11C7	2026-03-30 22:13:23.956+00	2025-2026
da138b5c-60bf-4eb2-94db-760168cfc74c	phanthiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Thị Yến	DV	11C1	2026-03-30 22:13:23.956+00	2025-2026
9ef176f9-57f7-4bb5-b583-1615c5141cec	tranthibaoyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Bảo Yến	DV	10A5	2026-03-30 22:13:23.956+00	2025-2026
def71723-be96-4767-a24e-d9fd94a2f395	tranthihaiyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Hải Yến	DV	12B9	2026-03-30 22:13:23.956+00	2025-2026
eb24e674-f55e-4232-9139-68e60310edd6	truongthihongyen	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Thị Hồng Yến	DV	10A5	2026-03-30 22:13:23.956+00	2025-2026
c4285952-3978-45e4-a827-356a61ccd1de	romahh'yumi	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Yumi	DV	12B8	2026-03-30 22:13:23.956+00	2025-2026
3034033e-6587-4291-bfb5-466855392f49	rochamzaka	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm Zaka	DV	10A7	2026-03-30 22:13:23.956+00	2025-2026
49db569c-4af3-4f08-9fae-01b2042d311b	bithu_12B6	$argon2id$v=19$m=65536,t=3,p=4$wKACyI/+euZwb6Ons8qm3A$8aMSrOHn+tBMqo01f+w3wUFswa9xiimo5YOStmSTnu8	Nguyễn Thanh Phương 	BT	12B6	2026-03-31 09:35:59.64+00	2025-2026
a49a7529-68d5-4640-bd63-d84ff1a4ef56	hoangngochuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Ngọc Huyền Trang	DV	11C9	2026-03-30 22:13:23.95+00	2025-2026
1b1c0fdf-b766-4fc1-b4de-eda51ae422b4	hoangthicaotrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Cao Trang	DV	11C9	2026-03-30 22:13:23.95+00	2025-2026
bfd9b6b6-d2c2-4d11-b608-3cc20031481f	honguyenkhanhtrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Nguyễn Khánh Trang	DV	10A1	2026-03-30 22:13:23.95+00	2025-2026
fcec37fe-735f-43f3-bf4c-9257c9955083	hothihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Huyền Trang	DV	10A5	2026-03-30 22:13:23.95+00	2025-2026
46341fa6-0594-42da-bf80-8459a809fdcc	hothingoctrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Ngọc Trang	DV	10A5	2026-03-30 22:13:23.95+00	2025-2026
fa4eda10-d473-462f-95c7-78a7a75116b3	hothithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Thùy Trang	DV	10A1	2026-03-30 22:13:23.95+00	2025-2026
6327021a-1142-499b-b938-84b1165067c8	ksornguyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Ksor Nguyễn Tráng	DV	10A6	2026-03-30 22:13:23.95+00	2025-2026
6c507f27-e4be-41d8-b2fd-f6dc062568ee	lethihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	LÊ THỊ HUYỀN TRANG	DV	12B6	2026-03-30 22:13:23.95+00	2025-2026
7e21d29f-ee2a-4b8c-9aa4-006e18cc453c	lethingoctrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Ngọc Trang	DV	12B5	2026-03-30 22:13:23.95+00	2025-2026
a208f4d5-73bf-4ad7-9dbf-0b97d72d3efd	lethiquynhtrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Quỳnh Trang	DV	11C11	2026-03-30 22:13:23.95+00	2025-2026
cedafe01-bb8f-4820-900d-9a503e7a0ddb	lethithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Thùy Trang	DV	10A1	2026-03-30 22:13:23.95+00	2025-2026
b996f4a8-0244-4476-a0d6-43c7c7aade4a	luongthidoantrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thị Đoan Trang	DV	11C9	2026-03-30 22:13:23.95+00	2025-2026
e00e20db-55a5-447d-aa64-f98f58f7ab8a	luuthithutrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lưu Thị Thu Trang	DV	11C9	2026-03-30 22:13:23.95+00	2025-2026
8ff34621-4887-465a-9567-4308fd8b066d	maithihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Mai Thị Huyền Trang	DV	11C10	2026-03-30 22:13:23.95+00	2025-2026
8b1b3b8f-400a-4fc3-b553-7805797e9f83	nguyenhuynhyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Huỳnh Yến Trang	DV	11C1	2026-03-30 22:13:23.95+00	2025-2026
6feda975-9903-4c59-9d4e-886af9714920	nguyenthihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Huyền Trang	DV	10A1	2026-03-30 22:13:23.95+00	2025-2026
32f079b8-1194-4ac5-83eb-52260680d54a	nguyenthiquynhtrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Quỳnh Trang	DV	11C9	2026-03-30 22:13:23.95+00	2025-2026
cac8b496-9845-4435-b107-f69c20f52b3d	nguyenthithaotrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thảo Trang	DV	10A4	2026-03-30 22:13:23.95+00	2025-2026
f6b36e0a-a3b4-47b7-817f-52a477557109	nguyenthithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Trang	DV	10A4	2026-03-30 22:13:23.95+00	2025-2026
ee325cc9-f24c-4242-9c29-c00da1c36efb	nguyenthithuytrang1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Trang	DV	11C4	2026-03-30 22:13:23.95+00	2025-2026
8bc11b5a-cb42-4cb2-b22a-652538b7cc37	nguyenthithuytrang2	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Thùy Trang	DV	12B4	2026-03-30 22:13:23.95+00	2025-2026
b2f0bad8-e4cc-4445-9f62-e60dc9ef0350	nguyentranhuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Trần Huyền Trang	DV	10A1	2026-03-30 22:13:23.95+00	2025-2026
5142c370-74aa-4c5d-aa6a-57424c9f67e5	phamthihuyentrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Huyền Trang	DV	12B5	2026-03-30 22:13:23.95+00	2025-2026
3eed9aca-6674-4bfb-bddf-6a45fd1c825e	phamthihuyentrang1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Thị Huyền Trang	DV	12B3	2026-03-30 22:13:23.95+00	2025-2026
f2efc949-455c-4777-9a09-afda96bac4f0	rochamvubaotrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Châm Vũ Bảo Trang	DV	10A6	2026-03-30 22:13:23.95+00	2025-2026
5b2792c7-858c-49e8-aef9-6677d6872a8c	rolanh'thuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Lan H' Thuỳ Trang	DV	12B5	2026-03-30 22:13:23.95+00	2025-2026
ba2758aa-ae68-4aa3-8eaf-3131636eb438	romahh’trang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H’ Trang	DV	12B8	2026-03-30 22:13:23.95+00	2025-2026
cbcdd51a-5dee-4461-bba4-1d918e1f774f	trancaothuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Cao Thùy Trang	DV	12B3	2026-03-30 22:13:23.95+00	2025-2026
7261c4ed-4381-4b31-ab55-45337760cdb1	tranthithutrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thu Trang	DV	10A3	2026-03-30 22:13:23.951+00	2025-2026
d20f874b-f3a0-45d2-b2d4-fbe8b0495155	trinhngockhanhtrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Ngọc Khánh Trang	DV	11C7	2026-03-30 22:13:23.951+00	2025-2026
9c488cda-1082-4788-96ae-db167caefc1b	vuthithuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thị Thùy Trang	DV	11C2	2026-03-30 22:13:23.951+00	2025-2026
8bd11ea1-1492-4c6c-b036-70fe66337aaa	vuthuytrang	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Vũ Thùy Trang	DV	11C3	2026-03-30 22:13:23.951+00	2025-2026
4e674eca-2d43-49b6-af0b-d3dd9454dde4	duongquynhtram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Dương Quỳnh Trâm	DV	12B5	2026-03-30 22:13:23.951+00	2025-2026
df91a58f-361d-46fc-9b84-aed95a30a5d6	hoangthibaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Bảo Trâm	DV	12B9	2026-03-30 22:13:23.951+00	2025-2026
a2d1665a-3b2f-4e28-97e0-653da44d5646	hothingoctram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Ngọc Trâm	DV	10A10	2026-03-30 22:13:23.951+00	2025-2026
fe9f6bfd-0c21-4fb0-8dc6-7e9e1f5c050c	kpuihh'tram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Trâm	DV	10A6	2026-03-30 22:13:23.951+00	2025-2026
0e4a0ab7-36d1-4d5d-97f3-bccb46aed3ad	lengocbaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Ngọc Bảo Trâm	DV	11C6	2026-03-30 22:13:23.951+00	2025-2026
42a4eea9-4ca2-400e-b182-00beb651d6e0	nguyenhoangbaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hoàng Bảo Trâm	DV	11C1	2026-03-30 22:13:23.951+00	2025-2026
b8562e77-a18e-415c-a0dc-75b4be4a0c6b	nguyenngocbaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Bảo Trâm	DV	11C11	2026-03-30 22:13:23.951+00	2025-2026
5c2048af-acaf-45af-a800-315fa053a77a	nguyenthingoctram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Ngọc Trâm	DV	12B2	2026-03-30 22:13:23.951+00	2025-2026
984f21e9-75b7-4fb3-82ad-d22acb785463	nguyenthitram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Trâm	DV	12B5	2026-03-30 22:13:23.951+00	2025-2026
f6f31d9d-5d29-46de-89d9-c64ff0950404	phanbaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Bảo Trâm	DV	12B9	2026-03-30 22:13:23.951+00	2025-2026
c17d6950-f78f-4e6c-8edd-eab2821f590c	tranthithuytram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Thị Thùy Trâm	DV	11C4	2026-03-30 22:13:23.951+00	2025-2026
73a34513-09d8-4af0-840a-f655c3bac52e	vohoaibaotram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Hoài Bảo Trâm	DV	11C2	2026-03-30 22:13:23.951+00	2025-2026
b1fa77e8-c5bd-4824-8a7d-c09828283c66	vongocminhtram	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Ngọc Minh Trâm	DV	10A3	2026-03-30 22:13:23.951+00	2025-2026
2d21fee9-9acc-42eb-961b-f15724e34623	hoangthiquetran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Thị Quế Trân	DV	12B8	2026-03-30 22:13:23.951+00	2025-2026
64ece2c5-e799-48b1-88f9-8714d443b790	kpuihtran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Trần	DV	11C12	2026-03-30 22:13:23.951+00	2025-2026
83b3ae8a-0b4c-4b13-8a9d-60548e78540b	lethihuyentran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Thị Huyền Trân	DV	11C11	2026-03-30 22:13:23.951+00	2025-2026
426c857b-d9be-4f4f-9360-2b740c24272d	nguyenbaotran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Bảo Trân	DV	10A7	2026-03-30 22:13:23.951+00	2025-2026
a48b9820-4f83-4a3d-b7fa-0e1988308c79	nguyenngocquynhtran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Quỳnh Trân	DV	10A4	2026-03-30 22:13:23.951+00	2025-2026
ab75eb41-a456-4bac-9c27-013592ed91a5	nguyenphanbaotran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phan Bảo Trân	DV	11C2	2026-03-30 22:13:23.951+00	2025-2026
6646d72c-94c8-4056-965d-a24de34feed1	romahtran	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Trân	DV	12B5	2026-03-30 22:13:23.951+00	2025-2026
dee09a36-abec-4106-bd37-1ceb82d29070	kpuihtri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih Trí	DV	11C8	2026-03-30 22:13:23.951+00	2025-2026
ad643aa7-5262-4bc4-ab20-f32c0567d52a	nguyenminhtri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Minh Trí	DV	10A3	2026-03-30 22:13:23.951+00	2025-2026
38c50950-a217-42cb-bf66-8d0e2130daaf	nguyenminhtri1	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Minh Trí	DV	10A2	2026-03-30 22:13:23.951+00	2025-2026
cf0fc671-9e38-48f2-8944-1ec9611acac8	nguyenphamductri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Phạm Đức Trí	DV	11C2	2026-03-30 22:13:23.951+00	2025-2026
77cd0ee2-7b7b-4ccc-aa71-e45939292fae	traminhtri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trà Minh Trí	DV	11C4	2026-03-30 22:13:23.951+00	2025-2026
4aacb315-f522-4fd2-a363-c3b3f252210c	tranminhtri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Minh Trí	DV	11C5	2026-03-30 22:13:23.951+00	2025-2026
714d37d5-1c72-44e3-ba77-7c8b46d4d82c	trinhlamtri	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trịnh Lâm Trí	DV	12B2	2026-03-30 22:13:23.951+00	2025-2026
62704c7f-a728-4a95-959f-8c59db4c61f1	doantrieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Đỗ An Triều	DV	10A2	2026-03-30 22:13:23.951+00	2025-2026
8b141529-aa10-4929-8f13-98b1dd1f0429	nguyenvinhtrieu	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Vĩnh Triều	DV	10A11	2026-03-30 22:13:23.951+00	2025-2026
981822cc-58b6-42dc-bab4-1e1f4623f4ba	hothimaitrinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hồ Thị Mai Trinh	DV	11C6	2026-03-30 22:13:23.951+00	2025-2026
b8623a2a-3200-433e-92cc-4084ef383c62	kpuihh'trinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Kpuih H' Trinh	DV	10A5	2026-03-30 22:13:23.951+00	2025-2026
0a95b060-b84f-4448-830b-6bc34d6b56a6	bithu_10A6	$argon2id$v=19$m=65536,t=3,p=4$qPn/AoJvU0yj4VAcSDHpOw$mju2qWuF70QfMKV6Yr6Zbbkev07QzsCfMxhTcT7KxeI		BT	10A6	2026-03-25 22:50:21.553+00	2025-2026
31fac42a-cfde-44bb-a58f-ffa1aad1eabf	bithu_11C5	$argon2id$v=19$m=65536,t=3,p=4$Kv1mbfbiYSL2Ls8wh1S4zQ$7JXQLckscr5glHYubdAsJyyxws/IBUMxV9H4yzGuOcU		BT	11C5	2026-03-25 22:50:28.467+00	2025-2026
77c59f8f-f43b-4762-8f39-e49f8c11c227	bithu_12B3	$argon2id$v=19$m=65536,t=3,p=4$DMD+b2awGzGArajfZwWF5w$7HNbFuELqJx2FhAqX871U7rbFbhc2c4Ia0ZoBRbaPBU		BT	12B3	2026-03-25 22:50:35.244+00	2025-2026
d8f987cf-8769-4de1-b121-e6b65bd23eba	bithu_12B8	$argon2id$v=19$m=65536,t=3,p=4$lSeVDEKS1zu0yyIQc+Daxg$sY/wm33Z6QTTj9N+MYRSn5bGy2SUGcyiRPToFoWvTkI		BT	12B8	2026-03-26 01:44:29.971+00	2025-2026
3f1f29dd-7b75-4a94-a85d-149b6ce0c8cd	Nguyenvanteo	$argon2id$v=19$m=65536,t=3,p=4$Bj0HapoiS9UH+WrHcCLSvA$axU8lB87xHPVL7mbYcTFUDuu8Vx9wIbxxg3Z2UzAMTM	Nguyễn Văn Tèo - Phó HT	BGH	\N	2026-03-26 07:41:24.036+00	2025-2026
47afe4f5-491b-4312-9e63-ece3692731c0	Gvcn_10A4	$argon2id$v=19$m=65536,t=3,p=4$0SsJqh3nqDCx999tpQC8VA$+Cmcf4bc8iAPFQ0IlzN1nPC1mHEgiOL/Oo2I8Z3WCtU	Gvcn_10A4	GVCN	10A4	2026-03-26 07:50:55.252+00	2025-2026
0386b6b1-a643-4db4-a820-992bf9b6fa57	Gvcn_10A9	$argon2id$v=19$m=65536,t=3,p=4$XoLHePprxO8kcigzS8Jvnw$rRc7zwYz6VDjAq5fP0Mq0QzDkJHipMWfIce2RQqXcq0	Gvcn_10A9	GVCN	10A9	2026-03-26 07:50:57.905+00	2025-2026
55291c41-2d3f-4fe4-93f6-5e0fd8bb234c	Gvcn_11C3	$argon2id$v=19$m=65536,t=3,p=4$V6GTcsxOzrrrwky4U0wjeQ$M0DmUDwDsJhIrNojFZ0tB9O3Jn1SN2sM8MGAIfWZxF4	Gvcn_11C3	GVCN	11C3	2026-03-26 07:51:00.567+00	2025-2026
378bbbb6-fe7e-4289-b001-05349b688af3	Gvcn_11C8	$argon2id$v=19$m=65536,t=3,p=4$tcsE2gi/CbqrVhPwyV+HRg$YK+j4q38xGPQu8MF/dXtvqMnOa05T9vw5mWErB5EO0c	Gvcn_11C8	GVCN	11C8	2026-03-26 07:51:03.141+00	2025-2026
c1ceebce-b38a-47c8-a578-60e87b58f413	Gvcn_12B1	$argon2id$v=19$m=65536,t=3,p=4$fIC5mm2nNguVGOEyevX8Vw$C8UKsxb6ozmyEdBQKnpiJ34KCCU3IFFMOb2pBmGEi4Q	Gvcn_12B1	GVCN	12B1	2026-03-26 07:51:05.499+00	2025-2026
75f8d31b-ec40-4bbe-b3e4-da1ed590315e	Gvcn_12B6	$argon2id$v=19$m=65536,t=3,p=4$UFN/KKTmZxL581/VT2XNOA$Q5LTiUDwB82MrV4wNSWyZzgAtlAWkfyKwInvlXkAE2E	Gvcn_12B6	GVCN	12B6	2026-03-26 07:51:07.748+00	2025-2026
ab620939-db21-475a-a651-fa64ac0c00bd	Gvcn_12B8	$argon2id$v=19$m=65536,t=3,p=4$U8LBxVlIM1e04w/2Zzq7jA$ezffi/N64Rs6LJM3N7IG9YkhrHWFHnDZX3JtX+/WqB0	Gvcn_12B8	GVCN	12B8	2026-03-26 07:51:08.668+00	2025-2026
faf551e3-c757-4078-a239-fa5823211ee0	Nguyengiahanbtv	$argon2id$v=19$m=65536,t=3,p=4$w+X6XyZlE1xqKRaCOb3V2g$oe7AMmeni3pBDapc1WuMe+DhgZPCSTKD10TS7whA+7o	Nguyễn Gia Hân (BTV)	BTV	\N	2026-03-29 07:58:50.656+00	2025-2026
46e7e738-7ef0-479e-9be9-0ef4eb4d2a1b	nguyenthidieutrinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Thị Diệu Trinh	DV	11C4	2026-03-30 22:13:23.951+00	2025-2026
5a31a9a3-3758-41e0-a049-dc4ad97741cd	romahh'trinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Trinh	DV	10A5	2026-03-30 22:13:23.952+00	2025-2026
c52a4326-d1b7-41db-84cd-259a400576a9	thaitutrinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thái Tú Trinh	DV	12B9	2026-03-30 22:13:23.952+00	2025-2026
cb4b4a3a-e009-45c1-a5c9-1ee99bc23f79	truongphuongtrinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trương Phương Trinh	DV	11C4	2026-03-30 22:13:23.952+00	2025-2026
67cae04f-0ab3-4eb0-886a-d6243778356f	vothikieutrinh	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Võ Thị Kiều Trinh	DV	10A9	2026-03-30 22:13:23.952+00	2025-2026
f2ca8e8a-0d05-4c3b-8aba-7e3cef9a0c23	luongquoctrong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Quốc Trọng	DV	10A10	2026-03-30 22:13:23.952+00	2025-2026
2db9f308-5a7e-4592-985f-9aabf8283ffd	nguyenquoctrong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Quốc Trọng	DV	10A1	2026-03-30 22:13:23.952+00	2025-2026
b40fa086-bc3d-4ccb-b218-50fc022e3248	phanvantrong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phan Văn Trọng	DV	10A4	2026-03-30 22:13:23.952+00	2025-2026
adc17326-18fe-4c0f-a333-639a628b5a07	quyendinhtrong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Quyền Đình Trọng	DV	12B7	2026-03-30 22:13:23.952+00	2025-2026
e2a809c1-ff54-45c2-970f-d52577bc5dee	tranvantrong	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Trần Văn Trọng	DV	10A4	2026-03-30 22:13:23.952+00	2025-2026
7c92e38e-b29e-49f4-9b95-b33e6b8f3f46	lehongtruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Hồng Trúc	DV	11C2	2026-03-30 22:13:23.952+00	2025-2026
901acc19-52ff-4be4-8b13-747c1486689f	luongthanhtruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lương Thanh Trúc	DV	12B3	2026-03-30 22:13:23.952+00	2025-2026
97d8b856-5f33-4c71-85b7-d299f0435e89	nguyenhuynhnhutruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Huỳnh Như Trúc	DV	10A4	2026-03-30 22:13:23.952+00	2025-2026
faf30ce5-df5c-40d8-a7f1-d7f09380461c	romahh'truc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah H' Trúc	DV	12B7	2026-03-30 22:13:23.952+00	2025-2026
d4942c09-c116-40e8-b778-6ea838972809	romahhatruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Rơ Mah Hà Trúc	DV	12B7	2026-03-30 22:13:23.952+00	2025-2026
2622c6fc-7e39-41b8-b5e2-5ab2d36c9519	thieuthanhtruc	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Thiều Thanh Trúc	DV	11C3	2026-03-30 22:13:23.952+00	2025-2026
6313ee18-3ccf-404e-98ad-361b09b3e9d1	hoangkhuongkientrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Khương Kiên Trung	DV	12B3	2026-03-30 22:13:23.952+00	2025-2026
40fa75ce-ed32-48af-91ea-e59671410460	hoangnguyenthanhtrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Hoàng Nguyễn Thành Trung	DV	11C6	2026-03-30 22:13:23.952+00	2025-2026
1e367529-f2c5-483b-af1a-b16201731792	letrananhtrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Lê Trần Anh Trung	DV	10A9	2026-03-30 22:13:23.952+00	2025-2026
147f571f-6690-452f-ae56-4445ec3a4465	nguyenhuutrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Hữu Trung	DV	11C5	2026-03-30 22:13:23.952+00	2025-2026
c2a5d82d-d007-4b62-b71c-bcaa149a22c8	nguyenngoctrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Nguyễn Ngọc Trung	DV	10A5	2026-03-30 22:13:23.952+00	2025-2026
df289a45-d116-43a9-b23e-527c23856add	phamductrung	$argon2id$v=19$m=65536,t=3,p=4$mdN2pGAauPVHMwkIC4CROg$M+lHz5BdzZ9HJgOi7XQAIp7USdiJSOFR2KC+CMe8z/c	Phạm Đức Trung	DV	10A2	2026-03-30 22:13:23.952+00	2025-2026
9faae225-ab41-4e22-b462-3a137401fbc4	bithu_10A11	$argon2id$v=19$m=65536,t=3,p=4$MLDoZZ9arqRjHzqpZsg/JQ$mGCQ2iqo/xzmyAlOEuCKIsf/0NjROs4ah8urKEPW+BU		BT	10A11	2026-03-25 22:50:25.036+00	2025-2026
734e9d70-6e1a-4a93-84e5-9d17a246e14b	bithu_11C6	$argon2id$v=19$m=65536,t=3,p=4$JwfdXe1VSp/Ulwkc8pzMgQ$MzQjpZ/mnIOOgAr8sbHLHN5yo8jFH1xyjbZgmSmuDBY		BT	11C6	2026-03-25 22:50:29.143+00	2025-2026
ec9ff6f8-a593-4657-9804-724c9725f226	bithu_10A1	$argon2id$v=19$m=65536,t=3,p=4$2qLe4ZVdDnPJXHpmmXOGGQ$eojbgI/HffxvIIkMRcYb53GBJZUjy+w7iN70zYuVNLk		BT	10A1	2026-03-26 13:59:48.407+00	2025-2026
694f19ef-c392-40bd-97ca-2f8856567c6c	bithu_10A7	$argon2id$v=19$m=65536,t=3,p=4$3pv1Jp1RPce0QJTYhkyeDg$BPL4sG5+SEWhysUTMGk7NvuR3qTXWRmckjRmw+hFWcs		BT	10A7	2026-03-26 01:56:59.593+00	2025-2026
\.


--
-- Data for Name: tieuchitd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tieuchitd" ("id", "maTieuChi", "tenTieuChi", "moTa", "loaiTieuChi", "diemTru", "diemCong", "ghiChu", "updatedAt", "hocKy", "namHoc") FROM stdin;
6121938d-5362-415b-a19a-cd92017b1f1a	TC01	Đi học muộn		Vi phạm	2	0		2026-03-26 09:06:53.056+00	HK2	2025-2026
9a409ba0-fa63-4059-a575-590e71170760	TC20	Học sinh để xe không đúng quy định		Vi phạm	10	0		2026-03-28 22:42:37.684+00	HK2	2025-2026
644b6841-2c8c-49b1-9b25-1533c35464ef	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-03-26 13:38:47.75+00	HK2	2025-2026
f227e7b5-d461-473a-98b8-4ed43e475b7a	TC01	Đi học muộn		Vi phạm	2	0		2026-03-27 03:27:21.684+00	HK1	2025-2026
a7c8acbe-6275-4b44-9b44-2861c8220254	TC02	Cúp tiết		Vi phạm	5	0		2026-03-27 03:27:22.217+00	HK1	2025-2026
7859e009-5ffe-4f07-ae8f-8a3567f17dbf	TC03	Cúp chào cờ		Vi phạm	5	0		2026-03-27 03:27:22.437+00	HK1	2025-2026
17e79f77-18c7-4375-99f4-e926b3e70e96	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-03-27 03:27:22.815+00	HK1	2025-2026
66819621-23a7-4a5b-890c-14d187b115bb	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-03-27 03:27:23.222+00	HK1	2025-2026
0ce2ba3c-82f1-47ef-ae4c-b72d6571e9e0	TC06	Không sơ vin		Vi phạm	5	0		2026-03-27 03:27:23.616+00	HK1	2025-2026
186bb01e-3440-41f2-b51a-aac506767f1b	TC07	Không bảng tên		Vi phạm	5	0		2026-03-27 03:27:23.849+00	HK1	2025-2026
b9da23aa-6bbc-4aeb-8cb3-e2376d4ad85e	TC08	Sai đồng phục		Vi phạm	5	0		2026-03-27 03:27:24.176+00	HK1	2025-2026
62853a7d-98a5-4d19-8d22-a262f0cff4e2	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-03-27 03:27:24.455+00	HK1	2025-2026
dc6ec70f-a5fa-49ff-af7d-44ccdd98e94f	TC02	Cúp tiết		Vi phạm	5	0		2026-03-26 00:02:34.693+00	HK2	2025-2026
1e5ccee2-5fea-43f7-adb8-80c40c2d48b3	TC03	Cúp chào cờ		Vi phạm	5	0		2026-03-26 00:02:35.313+00	HK2	2025-2026
5db70949-da3e-4b2b-9386-08844741ad73	TC04	Trốn sinh hoạt 15p		Vi phạm	2	0		2026-03-26 00:02:35.727+00	HK2	2025-2026
4a0b7bce-477d-447f-8d86-e6f7ac1fcb87	TC05	Ở ngoài khi trống vào lớp		Vi phạm	2	0		2026-03-26 00:02:36.141+00	HK2	2025-2026
3f412ea8-2090-4318-9148-2781affcb6e3	TC06	Không sơ vin		Vi phạm	5	0		2026-03-26 00:02:36.501+00	HK2	2025-2026
78df2cce-5e8b-47cc-a43d-c44a17193d87	TC07	Không bảng tên		Vi phạm	5	0		2026-03-26 00:02:36.709+00	HK2	2025-2026
81636cfb-4a71-45b4-8ea4-1b1a5c4d6dfe	TC08	Sai đồng phục		Vi phạm	5	0		2026-03-26 00:02:36.945+00	HK2	2025-2026
69e324e2-e200-4644-8e27-abcc4d5259b1	TC09	Không đeo huy hiệu đoàn		Vi phạm	5	0		2026-03-26 00:02:37.366+00	HK2	2025-2026
074b9a06-facd-4b63-bd73-54becfb392a3	TC10	Không quai dép		Vi phạm	5	0		2026-03-26 00:02:37.774+00	HK2	2025-2026
da9a99f3-6dd0-44c8-bbf6-74bee1234bc9	TC11	Đi dép lê		Vi phạm	5	0		2026-03-26 00:02:38.182+00	HK2	2025-2026
adbf6277-a811-44b1-84de-5baf637d7fed	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-03-26 00:02:38.419+00	HK2	2025-2026
94904158-61fc-4bd3-83a2-025bd9fdf339	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-03-26 00:02:38.623+00	HK2	2025-2026
9922e34f-bba1-4364-8da3-41e18e042cc4	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-03-26 00:02:38.817+00	HK2	2025-2026
a836829a-ebdc-4edf-8026-cb0d553d59a7	TC15	Sơn móng tay		Vi phạm	5	0		2026-03-26 00:02:39.019+00	HK2	2025-2026
0fb0ed08-7aeb-4d45-b48f-41868ebd0321	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-03-26 00:02:39.233+00	HK2	2025-2026
a3f18089-1817-457c-939a-befb9b4164f5	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-03-26 00:02:39.453+00	HK2	2025-2026
4859e9ec-f616-4091-bac6-caab425ffc7d	TC18	chở quá số người qui định		Vi phạm	30	0		2026-03-26 00:02:39.748+00	HK2	2025-2026
a5163c43-593d-4bc6-8bcd-45582dc93dac	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-03-26 00:02:39.953+00	HK2	2025-2026
6fe268f3-4df1-4d2d-976c-c80cb842a931	TC21	Hút thuốc lá		Vi phạm	30	0		2026-03-26 00:02:40.354+00	HK2	2025-2026
ae096e57-021e-49ba-b5e8-de25ae4e01a5	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-03-26 00:02:40.568+00	HK2	2025-2026
e3e14373-9693-4bd3-9097-2b891fab6433	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-03-26 00:02:40.777+00	HK2	2025-2026
80b929f4-4b73-43e5-b651-86c585fadda3	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-03-26 00:02:40.994+00	HK2	2025-2026
6316a904-0880-4725-94f4-ff19b7811b50	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-03-26 00:02:41.195+00	HK2	2025-2026
a071f87d-496c-42b8-aec0-6d8dffed321d	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-03-26 00:02:41.797+00	HK2	2025-2026
a4076a19-c24b-4fa8-98e6-d130c3c8c888	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-03-26 00:02:41.992+00	HK2	2025-2026
e971a925-a4ab-41a9-a1bf-0af16f1b14fc	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-03-26 00:02:42.2+00	HK2	2025-2026
d596cd00-023c-483b-a4b5-970a0aaea5e6	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-03-26 00:02:42.402+00	HK2	2025-2026
05d3a525-1635-4cd1-9ece-03c7afebb35d	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-03-26 00:02:42.617+00	HK2	2025-2026
adec745d-93a3-4590-844d-b482f652419a	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-03-26 00:02:42.828+00	HK2	2025-2026
7cbb496b-a8ea-4c0d-9af8-5b1b04bdad19	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-03-26 00:02:43.034+00	HK2	2025-2026
bf725a5c-fedc-447a-804e-355f3b486679	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-03-26 00:02:43.221+00	HK2	2025-2026
5d0df134-a231-484a-bb38-a3d9e2b71a5a	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-03-26 00:02:43.541+00	HK2	2025-2026
1f42f1c4-3f83-4c2d-83a0-cbc93f8d3657	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-03-26 00:02:43.752+00	HK2	2025-2026
54fe6115-7784-4e24-ac30-f6a32725a413	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-03-26 00:02:43.974+00	HK2	2025-2026
17ac07d6-48a8-4ee7-9191-f08ad5292d3b	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-03-26 00:02:44.176+00	HK2	2025-2026
e75bbb25-dbb4-4178-8fe1-f9a115da4fa8	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-03-26 00:02:44.386+00	HK2	2025-2026
20133d4f-abde-487c-81c4-3f6a39cc5234	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-03-26 00:02:44.767+00	HK2	2025-2026
ba44cd63-1b39-4bc6-9e43-1507bc0145e2	TC40	Đi chấm trễ		Vi phạm	2	0		2026-03-26 00:02:44.971+00	HK2	2025-2026
083d192e-ec8e-44a7-b49c-395e2fcf0c3c	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-03-26 00:02:45.381+00	HK2	2025-2026
21d7b12e-ed05-4092-b839-5fa5ea6d7aa8	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-03-26 00:02:45.892+00	HK2	2025-2026
6c7b2e0e-e368-44ed-8877-ad1c9c55ff80	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-03-26 00:02:46.113+00	HK2	2025-2026
3b0cc5d6-4e89-45b7-835b-a4c6c417f3cd	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-03-26 00:02:46.322+00	HK2	2025-2026
67da46ac-afdb-4916-a736-1042f414af63	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-03-26 00:02:46.529+00	HK2	2025-2026
2ab65d28-61a5-4cfc-8895-e823ef900573	TC10	Không quai dép		Vi phạm	5	0		2026-03-27 03:27:24.863+00	HK1	2025-2026
160fe479-8cd6-4d96-8f2a-b1fbfab90ced	TC20	Học sinh để xe không đúng quy định		Vi phạm	30	0		2026-03-27 03:27:26.764+00	HK1	2025-2026
35ca3edd-79da-49ee-b42b-3824a14634ca	TC30	Không sinh hoạt 15’ đầu giờ		Vi phạm	10	0		2026-03-27 03:27:28.375+00	HK1	2025-2026
068deeab-d18d-4df1-9793-7fd8980bd598	TC40	Đi chấm trễ		Vi phạm	2	0		2026-03-27 03:27:29.899+00	HK1	2025-2026
484018b2-56aa-48c6-bcea-acdce91360d6	TC11	Đi dép lê		Vi phạm	5	0		2026-03-27 03:27:25.181+00	HK1	2025-2026
e2a9a267-03b3-4bb7-a2b8-479b825c2b43	TC21	Hút thuốc lá		Vi phạm	30	0		2026-03-27 03:27:26.937+00	HK1	2025-2026
288e5ad6-ee59-4dc7-8c18-e8f69e1e1752	TC31	Không sinh hoạt chi đoàn cuối tháng		Vi phạm	10	0		2026-03-27 03:27:28.534+00	HK1	2025-2026
4d94581a-aa5b-4b06-8d4a-a801d5186b09	TC41	Vắng học có lí do (1 tiết)		Vi phạm	0.25	0		2026-03-27 03:27:30.066+00	HK1	2025-2026
b3239b98-03e7-4431-aa00-669de580de20	TC12	Để tóc dài, nhuộm, uốn, tóc cắt không đúng qui định đối với nam		Vi phạm	5	0		2026-03-27 03:27:25.337+00	HK1	2025-2026
feebe392-ac90-403c-a6b9-b4ec2d3e4a4d	TC22	Tham gia gây gỗ đánh nhau		Vi phạm	30	0		2026-03-27 03:27:27.113+00	HK1	2025-2026
a89089c1-f1fb-4ea1-8d75-8041d775939d	TC32	Không cất ghế ngồi chào cờ 		Vi phạm	10	0		2026-03-27 03:27:28.671+00	HK1	2025-2026
2f03e0e1-5c9e-4992-9571-0510b58ca42d	TC42	Vắng học có lí do (2 tiết)		Vi phạm	0.5	0		2026-03-27 03:27:30.232+00	HK1	2025-2026
b34d683b-ecc4-47ed-9fb6-ea435a2815ea	TC13	Học sinh nữ nhuộm tóc, trang điểm, đối với học sinh nữ đeo quá 1 cái/tai và sỏ khuyên ở các vị trí khác ngoài tai.		Vi phạm	5	0		2026-03-27 03:27:25.512+00	HK1	2025-2026
512833ab-33c9-4c21-985f-efbb341b4728	TC23	Mang hung khí, tàng trữ, sử dụng các chất kích thích gây nghiện, gây cháy nổ, các vật dụng nguy hiểm		Vi phạm	30	0		2026-03-27 03:27:27.276+00	HK1	2025-2026
c1beab83-95ed-46d1-abe6-d29be9bc9ddd	TC33	Xếp hàng chào cờ chậm hoặc không đúng qui định		Vi phạm	10	0		2026-03-27 03:27:28.81+00	HK1	2025-2026
8299c451-bf7e-4070-b77e-6894277f7b99	TC43	Vắng học có lí do (3 tiết)		Vi phạm	0.75	0		2026-03-27 03:27:30.389+00	HK1	2025-2026
c3561322-7a30-418c-8e3b-c4eedeb4aaae	TC14	Học sinh nam đeo hoa tai		Vi phạm	5	0		2026-03-27 03:27:25.757+00	HK1	2025-2026
aee6a59f-62df-42ec-b7ce-16881e6735c3	TC24	Có thái độ vô lễ với CB, CNV nhà trường: 		Vi phạm	30	0		2026-03-27 03:27:27.441+00	HK1	2025-2026
51f2556c-557b-4a51-86f4-d8846f2ff1c3	TC34	Đối với các bài thi do cấp trên phát động		Vi phạm	1	0		2026-03-27 03:27:28.969+00	HK1	2025-2026
65ae0928-5d52-4f98-b854-38dbc7d0e06f	TC44	Vắng học có lí do (4 tiết)		Vi phạm	1	0		2026-03-27 03:27:30.546+00	HK1	2025-2026
469b66bc-7135-4dc0-9866-9e849cf8cce0	TC15	Sơn móng tay		Vi phạm	5	0		2026-03-27 03:27:25.946+00	HK1	2025-2026
3d5db440-ea8a-409c-82d3-031e60e9d20c	TC25	Học sinh có thái độ không chuẩn mực (lời nói, hành động) với CBGV, NV và bạn học		Vi phạm	10	0		2026-03-27 03:27:27.625+00	HK1	2025-2026
6edfc343-3702-48a9-8241-b65dfcf0f53c	TC35	Vắng học không có lý do		Vi phạm	5	0		2026-03-27 03:27:29.128+00	HK1	2025-2026
50d57011-07c8-48e2-a3f7-efcda0f5fa66	TC45	Vắng học có lí do (5 tiết)		Vi phạm	1.25	0		2026-03-27 03:27:30.689+00	HK1	2025-2026
f3d27821-d1fc-4280-97c0-eaadc8311ea3	TC16	Mặc áo khoác ngoài		Vi phạm	5	0		2026-03-27 03:27:26.116+00	HK1	2025-2026
b74a2da6-436a-4945-9c36-a3cb505ec19f	TC26	Vệ sinh muộn 		Vi phạm	5	0		2026-03-27 03:27:27.776+00	HK1	2025-2026
fec831a3-40d7-44b2-9a8a-0178ad6f0b51	TC36	Học sinh vào lớp muộn trong giữa các tiết học 		Vi phạm	0.5	0		2026-03-27 03:27:29.287+00	HK1	2025-2026
f8335471-9ed3-4fbd-a762-c2a35d7dfc81	TC46	Mang ĐT lên trường		Vi phạm	30	0		2026-03-27 03:27:30.841+00	HK1	2025-2026
abd9fb8a-c28f-4028-af0d-eb7bf981a6dd	TC17	Không đội mũ bảo hiểm		Vi phạm	30	0		2026-03-27 03:27:26.299+00	HK1	2025-2026
62a0917b-bbde-44bf-84b1-5e32eb619b3a	TC27	Lớp trực nhật bẩn		Vi phạm	5	0		2026-03-27 03:27:27.925+00	HK1	2025-2026
afa978a2-456b-4c3c-beef-3d1cdd2f2568	TC37	Học sinh không nghiêm túc trong giờ học		Vi phạm	3	0		2026-03-27 03:27:29.433+00	HK1	2025-2026
f9920d76-b760-4980-87e1-efe2e93373f6	TC18	chở quá số người qui định		Vi phạm	30	0		2026-03-27 03:27:26.452+00	HK1	2025-2026
f0db0d72-f917-4323-8828-59f3793bc044	TC28	Học sinh vứt rác không đúng qui định 		Vi phạm	10	0		2026-03-27 03:27:28.069+00	HK1	2025-2026
8d4e49cf-be84-42f8-b28a-6ac9c05466c9	TC38	Lớp không tham gia trực cổng		Vi phạm	2	0		2026-03-27 03:27:29.584+00	HK1	2025-2026
2bb79d17-8bec-495a-bd11-653b46626a2f	TC19	đi xe phân khối lớn đến trường		Vi phạm	30	0		2026-03-27 03:27:26.612+00	HK1	2025-2026
5041ef8e-50ac-47f8-af0d-8edf8d79d0c3	TC29	Mang quà vặt lên lớp		Vi phạm	10	0		2026-03-27 03:27:28.216+00	HK1	2025-2026
f9777ed8-b6b1-42d5-98d9-1c7c6ff00b6a	TC39	Lớp không tham gia trực 15p		Vi phạm	2	0		2026-03-27 03:27:29.736+00	HK1	2025-2026
d091f956-6820-41b2-8a0d-2a207a5fa858	BC01	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Khác	0	0		2026-03-28 11:02:19.252+00	HK2	2025-2026
f6fcab11-85e2-4b1b-89d1-067e6040c3f9	TC47	Học sinh tham gia đăng bài có nội dung xuyên tạc nói xấu nhà nước, cơ quan chức năng, đơn vị, xúc phạm nhân phẩm danh dự người khác vi phạm pháp luật, gây mất đoàn kết (nếu có bằng chứng).		Vi phạm	50	0		2026-03-28 22:42:11.448+00	HK2	2025-2026
6cf3db85-2591-4f81-a217-118f7cec2e04	BC02	Báo cáo chi đoàn trong tuần qua không có vi phạm nào.		Vi phạm	0	0		2026-03-31 02:52:03.335+00	HK2	2025-2026
\.


--
-- Data for Name: tuanhoc; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."tuanhoc" ("id", "namHoc", "hocKy", "tuan", "tuNgay", "denNgay", "isDefault", "isLocked", "updatedAt") FROM stdin;
63f4c8cf-8de6-4afc-b40d-68097a2f221e	2025-2026	HK2	29	2026-04-06	2026-04-12	f	f	2026-03-29 10:45:54.379+00
6848847d-981e-4fd4-abcf-fc0c456ce34f	2025-2026	HK2	30	2026-04-13	2026-04-19	f	f	2026-03-29 10:46:17.924+00
d9e6a1f5-50cf-4685-96d0-66e927db11f7	2025-2026	HK2	27	2026-03-23	2026-03-29	f	f	2026-03-30 09:24:12.138+00
78e5a384-d173-4b38-91eb-88e5513a1cc5	2025-2026	HK2	28	2026-03-30	2026-04-05	t	f	2026-03-29 13:42:27.818+00
\.


--
-- Data for Name: messages_2026_03_28; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_03_28" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_03_29; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_03_29" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_03_30; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_03_30" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_03_31; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_03_31" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_04_01; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_04_01" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_04_02; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_04_02" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: messages_2026_04_03; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."messages_2026_04_03" ("topic", "extension", "payload", "event", "private", "updated_at", "inserted_at", "id") FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."schema_migrations" ("version", "inserted_at") FROM stdin;
20211116024918	2026-03-19 15:25:09
20211116045059	2026-03-19 15:25:15
20211116050929	2026-03-19 15:25:23
20211116051442	2026-03-19 15:25:24
20211116212300	2026-03-19 15:25:27
20211116213355	2026-03-19 15:25:28
20211116213934	2026-03-19 15:25:29
20211116214523	2026-03-19 15:25:30
20211122062447	2026-03-19 15:25:31
20211124070109	2026-03-19 15:25:31
20211202204204	2026-03-19 15:25:32
20211202204605	2026-03-19 15:25:33
20211210212804	2026-03-19 15:25:35
20211228014915	2026-03-19 15:25:36
20220107221237	2026-03-19 15:25:37
20220228202821	2026-03-19 15:25:37
20220312004840	2026-03-19 15:25:38
20220603231003	2026-03-19 15:25:39
20220603232444	2026-03-19 15:25:40
20220615214548	2026-03-19 15:25:41
20220712093339	2026-03-19 15:25:42
20220908172859	2026-03-19 15:25:42
20220916233421	2026-03-19 15:25:43
20230119133233	2026-03-19 15:25:44
20230128025114	2026-03-19 15:25:45
20230128025212	2026-03-19 15:25:46
20230227211149	2026-03-19 15:25:47
20230228184745	2026-03-19 15:25:48
20230308225145	2026-03-19 15:25:49
20230328144023	2026-03-19 15:25:50
20231018144023	2026-03-19 15:25:52
20231204144023	2026-03-19 15:25:53
20231204144024	2026-03-19 15:25:54
20231204144025	2026-03-19 15:25:55
20240108234812	2026-03-19 15:25:55
20240109165339	2026-03-19 15:25:56
20240227174441	2026-03-19 15:25:58
20240311171622	2026-03-19 15:25:59
20240321100241	2026-03-19 15:26:01
20240401105812	2026-03-19 15:26:04
20240418121054	2026-03-19 15:26:05
20240523004032	2026-03-19 15:26:07
20240618124746	2026-03-19 15:26:08
20240801235015	2026-03-19 15:26:09
20240805133720	2026-03-19 15:26:10
20240827160934	2026-03-19 15:26:10
20240919163303	2026-03-19 15:26:12
20240919163305	2026-03-19 15:26:14
20241019105805	2026-03-19 15:26:16
20241030150047	2026-03-19 15:26:22
20241108114728	2026-03-19 15:26:24
20241121104152	2026-03-19 15:26:24
20241130184212	2026-03-19 15:26:25
20241220035512	2026-03-19 15:26:26
20241220123912	2026-03-19 15:26:27
20241224161212	2026-03-19 15:26:27
20250107150512	2026-03-19 15:26:28
20250110162412	2026-03-19 15:26:29
20250123174212	2026-03-19 15:26:30
20250128220012	2026-03-19 15:26:31
20250506224012	2026-03-19 15:26:31
20250523164012	2026-03-19 15:26:32
20250714121412	2026-03-19 15:26:33
20250905041441	2026-03-19 15:26:33
20251103001201	2026-03-19 15:26:34
20251120212548	2026-03-19 15:26:35
20251120215549	2026-03-19 15:26:36
20260218120000	2026-03-19 15:26:37
\.


--
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: supabase_admin
--

COPY "realtime"."subscription" ("id", "subscription_id", "entity", "filters", "claims", "created_at", "action_filter") FROM stdin;
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type") FROM stdin;
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."migrations" ("id", "name", "hash", "executed_at") FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2026-03-19 14:09:39.717327
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2026-03-19 14:09:39.757383
2	storage-schema	f6a1fa2c93cbcd16d4e487b362e45fca157a8dbd	2026-03-19 14:09:39.765658
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2026-03-19 14:09:39.798337
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2026-03-19 14:09:39.867443
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2026-03-19 14:09:39.876337
6	change-column-name-in-get-size	ded78e2f1b5d7e616117897e6443a925965b30d2	2026-03-19 14:09:39.886572
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2026-03-19 14:09:39.898144
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2026-03-19 14:09:39.907131
9	fix-search-function	af597a1b590c70519b464a4ab3be54490712796b	2026-03-19 14:09:39.916352
10	search-files-search-function	b595f05e92f7e91211af1bbfe9c6a13bb3391e16	2026-03-19 14:09:39.925415
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2026-03-19 14:09:39.935197
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2026-03-19 14:09:39.945424
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2026-03-19 14:09:39.954644
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2026-03-19 14:09:39.963569
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2026-03-19 14:09:39.993224
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2026-03-19 14:09:40.003402
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2026-03-19 14:09:40.012594
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2026-03-19 14:09:40.022304
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2026-03-19 14:09:40.038143
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2026-03-19 14:09:40.047631
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2026-03-19 14:09:40.058432
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2026-03-19 14:09:40.079058
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2026-03-19 14:09:40.094949
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2026-03-19 14:09:40.105353
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2026-03-19 14:09:40.114926
26	objects-prefixes	215cabcb7f78121892a5a2037a09fedf9a1ae322	2026-03-19 14:09:40.125618
27	search-v2	859ba38092ac96eb3964d83bf53ccc0b141663a6	2026-03-19 14:09:40.134157
28	object-bucket-name-sorting	c73a2b5b5d4041e39705814fd3a1b95502d38ce4	2026-03-19 14:09:40.142802
29	create-prefixes	ad2c1207f76703d11a9f9007f821620017a66c21	2026-03-19 14:09:40.151222
30	update-object-levels	2be814ff05c8252fdfdc7cfb4b7f5c7e17f0bed6	2026-03-19 14:09:40.159561
31	objects-level-index	b40367c14c3440ec75f19bbce2d71e914ddd3da0	2026-03-19 14:09:40.168245
32	backward-compatible-index-on-objects	e0c37182b0f7aee3efd823298fb3c76f1042c0f7	2026-03-19 14:09:40.176589
33	backward-compatible-index-on-prefixes	b480e99ed951e0900f033ec4eb34b5bdcb4e3d49	2026-03-19 14:09:40.184914
34	optimize-search-function-v1	ca80a3dc7bfef894df17108785ce29a7fc8ee456	2026-03-19 14:09:40.194761
35	add-insert-trigger-prefixes	458fe0ffd07ec53f5e3ce9df51bfdf4861929ccc	2026-03-19 14:09:40.20326
36	optimise-existing-functions	6ae5fca6af5c55abe95369cd4f93985d1814ca8f	2026-03-19 14:09:40.21181
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2026-03-19 14:09:40.220303
38	iceberg-catalog-flag-on-buckets	02716b81ceec9705aed84aa1501657095b32e5c5	2026-03-19 14:09:40.229748
39	add-search-v2-sort-support	6706c5f2928846abee18461279799ad12b279b78	2026-03-19 14:09:40.245169
40	fix-prefix-race-conditions-optimized	7ad69982ae2d372b21f48fc4829ae9752c518f6b	2026-03-19 14:09:40.253547
41	add-object-level-update-trigger	07fcf1a22165849b7a029deed059ffcde08d1ae0	2026-03-19 14:09:40.262334
42	rollback-prefix-triggers	771479077764adc09e2ea2043eb627503c034cd4	2026-03-19 14:09:40.271041
43	fix-object-level	84b35d6caca9d937478ad8a797491f38b8c2979f	2026-03-19 14:09:40.279502
44	vector-bucket-type	99c20c0ffd52bb1ff1f32fb992f3b351e3ef8fb3	2026-03-19 14:09:40.28834
45	vector-buckets	049e27196d77a7cb76497a85afae669d8b230953	2026-03-19 14:09:40.297727
46	buckets-objects-grants	fedeb96d60fefd8e02ab3ded9fbde05632f84aed	2026-03-19 14:09:40.316757
47	iceberg-table-metadata	649df56855c24d8b36dd4cc1aeb8251aa9ad42c2	2026-03-19 14:09:40.325856
48	iceberg-catalog-ids	e0e8b460c609b9999ccd0df9ad14294613eed939	2026-03-19 14:09:40.334356
49	buckets-objects-grants-postgres	072b1195d0d5a2f888af6b2302a1938dd94b8b3d	2026-03-19 14:09:40.355625
50	search-v2-optimised	6323ac4f850aa14e7387eb32102869578b5bd478	2026-03-19 14:09:40.365056
51	index-backward-compatible-search	2ee395d433f76e38bcd3856debaf6e0e5b674011	2026-03-19 14:09:40.805019
52	drop-not-used-indexes-and-functions	5cc44c8696749ac11dd0dc37f2a3802075f3a171	2026-03-19 14:09:40.808193
53	drop-index-lower-name	d0cb18777d9e2a98ebe0bc5cc7a42e57ebe41854	2026-03-19 14:09:40.832329
54	drop-index-object-level	6289e048b1472da17c31a7eba1ded625a6457e67	2026-03-19 14:09:40.837364
55	prevent-direct-deletes	262a4798d5e0f2e7c8970232e03ce8be695d5819	2026-03-19 14:09:40.84041
56	fix-optimized-search-function	cb58526ebc23048049fd5bf2fd148d18b04a2073	2026-03-19 14:09:40.851784
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: supabase_admin
--

COPY "vault"."secrets" ("id", "name", "description", "secret", "key_id", "nonce", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1, false);


--
-- Name: phanquyen_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."phanquyen_id_seq"', 1671, true);


--
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: supabase_admin
--

SELECT pg_catalog.setval('"realtime"."subscription_id_seq"', 1, false);


--
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "amr_id_pk" PRIMARY KEY ("id");


--
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."audit_log_entries"
    ADD CONSTRAINT "audit_log_entries_pkey" PRIMARY KEY ("id");


--
-- Name: custom_oauth_providers custom_oauth_providers_identifier_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_identifier_key" UNIQUE ("identifier");


--
-- Name: custom_oauth_providers custom_oauth_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."custom_oauth_providers"
    ADD CONSTRAINT "custom_oauth_providers_pkey" PRIMARY KEY ("id");


--
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."flow_state"
    ADD CONSTRAINT "flow_state_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_pkey" PRIMARY KEY ("id");


--
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_provider_id_provider_unique" UNIQUE ("provider_id", "provider");


--
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."instances"
    ADD CONSTRAINT "instances_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_authentication_method_pkey" UNIQUE ("session_id", "authentication_method");


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_last_challenged_at_key" UNIQUE ("last_challenged_at");


--
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_code_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_code_key" UNIQUE ("authorization_code");


--
-- Name: oauth_authorizations oauth_authorizations_authorization_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_authorization_id_key" UNIQUE ("authorization_id");


--
-- Name: oauth_authorizations oauth_authorizations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_client_states oauth_client_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_client_states"
    ADD CONSTRAINT "oauth_client_states_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_clients"
    ADD CONSTRAINT "oauth_clients_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_pkey" PRIMARY KEY ("id");


--
-- Name: oauth_consents oauth_consents_user_client_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_client_unique" UNIQUE ("user_id", "client_id");


--
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id");


--
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_token_unique" UNIQUE ("token");


--
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_entity_id_key" UNIQUE ("entity_id");


--
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_pkey" PRIMARY KEY ("id");


--
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_pkey" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_pkey" PRIMARY KEY ("id");


--
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_pkey" PRIMARY KEY ("id");


--
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_providers"
    ADD CONSTRAINT "sso_providers_pkey" PRIMARY KEY ("id");


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_phone_key" UNIQUE ("phone");


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."users"
    ADD CONSTRAINT "users_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_challenges webauthn_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_pkey" PRIMARY KEY ("id");


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_pkey" PRIMARY KEY ("id");


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."activity_logs"
    ADD CONSTRAINT "activity_logs_pkey" PRIMARY KEY ("id");


--
-- Name: chamdiem chamdiem_pkey2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."chamdiem"
    ADD CONSTRAINT "chamdiem_pkey2" PRIMARY KEY ("id");


--
-- Name: doanvien doanvien_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."doanvien"
    ADD CONSTRAINT "doanvien_pkey" PRIMARY KEY ("id");


--
-- Name: namhoc namhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."namhoc"
    ADD CONSTRAINT "namhoc_pkey" PRIMARY KEY ("id");


--
-- Name: phancong phancong_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phancong"
    ADD CONSTRAINT "phancong_pkey" PRIMARY KEY ("id");


--
-- Name: phanquyen phanquyen_doi_tuong_tab_namhoc_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_doi_tuong_tab_namhoc_unique" UNIQUE ("doi_tuong", "tab_chuc_nang", "nam_hoc");


--
-- Name: phanquyen phanquyen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."phanquyen"
    ADD CONSTRAINT "phanquyen_pkey" PRIMARY KEY ("id");


--
-- Name: qlchidoan qlchidoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."qlchidoan"
    ADD CONSTRAINT "qlchidoan_pkey" PRIMARY KEY ("id");


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."settings"
    ADD CONSTRAINT "settings_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_pkey" PRIMARY KEY ("id");


--
-- Name: taikhoan taikhoan_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."taikhoan"
    ADD CONSTRAINT "taikhoan_username_key" UNIQUE ("username");


--
-- Name: tieuchitd tieuchitd_matieuchi_namhoc_hocky_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_matieuchi_namhoc_hocky_unique" UNIQUE ("maTieuChi", "namHoc", "hocKy");


--
-- Name: tieuchitd tieuchitd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tieuchitd"
    ADD CONSTRAINT "tieuchitd_pkey" PRIMARY KEY ("id");


--
-- Name: tuanhoc tuanhoc_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "public"."tuanhoc"
    ADD CONSTRAINT "tuanhoc_pkey" PRIMARY KEY ("id");


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE ONLY "realtime"."messages"
    ADD CONSTRAINT "messages_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_03_28 messages_2026_03_28_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_03_28"
    ADD CONSTRAINT "messages_2026_03_28_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_03_29 messages_2026_03_29_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_03_29"
    ADD CONSTRAINT "messages_2026_03_29_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_03_30 messages_2026_03_30_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_03_30"
    ADD CONSTRAINT "messages_2026_03_30_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_03_31 messages_2026_03_31_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_03_31"
    ADD CONSTRAINT "messages_2026_03_31_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_04_01 messages_2026_04_01_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_04_01"
    ADD CONSTRAINT "messages_2026_04_01_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_04_02 messages_2026_04_02_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_04_02"
    ADD CONSTRAINT "messages_2026_04_02_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: messages_2026_04_03 messages_2026_04_03_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."messages_2026_04_03"
    ADD CONSTRAINT "messages_2026_04_03_pkey" PRIMARY KEY ("id", "inserted_at");


--
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."subscription"
    ADD CONSTRAINT "pk_subscription" PRIMARY KEY ("id");


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: supabase_admin
--

ALTER TABLE ONLY "realtime"."schema_migrations"
    ADD CONSTRAINT "schema_migrations_pkey" PRIMARY KEY ("version");


--
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_analytics"
    ADD CONSTRAINT "buckets_analytics_pkey" PRIMARY KEY ("id");


--
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets"
    ADD CONSTRAINT "buckets_pkey" PRIMARY KEY ("id");


--
-- Name: buckets_vectors buckets_vectors_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."buckets_vectors"
    ADD CONSTRAINT "buckets_vectors_pkey" PRIMARY KEY ("id");


--
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_name_key" UNIQUE ("name");


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."migrations"
    ADD CONSTRAINT "migrations_pkey" PRIMARY KEY ("id");


--
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_pkey" PRIMARY KEY ("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_pkey" PRIMARY KEY ("id");


--
-- Name: vector_indexes vector_indexes_pkey; Type: CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_pkey" PRIMARY KEY ("id");


--
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "audit_logs_instance_id_idx" ON "auth"."audit_log_entries" USING "btree" ("instance_id");


--
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "confirmation_token_idx" ON "auth"."users" USING "btree" ("confirmation_token") WHERE (("confirmation_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: custom_oauth_providers_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_created_at_idx" ON "auth"."custom_oauth_providers" USING "btree" ("created_at");


--
-- Name: custom_oauth_providers_enabled_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_enabled_idx" ON "auth"."custom_oauth_providers" USING "btree" ("enabled");


--
-- Name: custom_oauth_providers_identifier_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_identifier_idx" ON "auth"."custom_oauth_providers" USING "btree" ("identifier");


--
-- Name: custom_oauth_providers_provider_type_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "custom_oauth_providers_provider_type_idx" ON "auth"."custom_oauth_providers" USING "btree" ("provider_type");


--
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_current_idx" ON "auth"."users" USING "btree" ("email_change_token_current") WHERE (("email_change_token_current")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "email_change_token_new_idx" ON "auth"."users" USING "btree" ("email_change_token_new") WHERE (("email_change_token_new")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "factor_id_created_at_idx" ON "auth"."mfa_factors" USING "btree" ("user_id", "created_at");


--
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "flow_state_created_at_idx" ON "auth"."flow_state" USING "btree" ("created_at" DESC);


--
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_email_idx" ON "auth"."identities" USING "btree" ("email" "text_pattern_ops");


--
-- Name: INDEX "identities_email_idx"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."identities_email_idx" IS 'Auth: Ensures indexed queries on the email column';


--
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "identities_user_id_idx" ON "auth"."identities" USING "btree" ("user_id");


--
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_auth_code" ON "auth"."flow_state" USING "btree" ("auth_code");


--
-- Name: idx_oauth_client_states_created_at; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_oauth_client_states_created_at" ON "auth"."oauth_client_states" USING "btree" ("created_at");


--
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "idx_user_id_auth_method" ON "auth"."flow_state" USING "btree" ("user_id", "authentication_method");


--
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_challenge_created_at_idx" ON "auth"."mfa_challenges" USING "btree" ("created_at" DESC);


--
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "mfa_factors_user_friendly_name_unique" ON "auth"."mfa_factors" USING "btree" ("friendly_name", "user_id") WHERE (TRIM(BOTH FROM "friendly_name") <> ''::"text");


--
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "mfa_factors_user_id_idx" ON "auth"."mfa_factors" USING "btree" ("user_id");


--
-- Name: oauth_auth_pending_exp_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_auth_pending_exp_idx" ON "auth"."oauth_authorizations" USING "btree" ("expires_at") WHERE ("status" = 'pending'::"auth"."oauth_authorization_status");


--
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_clients_deleted_at_idx" ON "auth"."oauth_clients" USING "btree" ("deleted_at");


--
-- Name: oauth_consents_active_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_client_idx" ON "auth"."oauth_consents" USING "btree" ("client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_active_user_client_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_active_user_client_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "client_id") WHERE ("revoked_at" IS NULL);


--
-- Name: oauth_consents_user_order_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "oauth_consents_user_order_idx" ON "auth"."oauth_consents" USING "btree" ("user_id", "granted_at" DESC);


--
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_relates_to_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("relates_to");


--
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "one_time_tokens_token_hash_hash_idx" ON "auth"."one_time_tokens" USING "hash" ("token_hash");


--
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "one_time_tokens_user_id_token_type_key" ON "auth"."one_time_tokens" USING "btree" ("user_id", "token_type");


--
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "reauthentication_token_idx" ON "auth"."users" USING "btree" ("reauthentication_token") WHERE (("reauthentication_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "recovery_token_idx" ON "auth"."users" USING "btree" ("recovery_token") WHERE (("recovery_token")::"text" !~ '^[0-9 ]*$'::"text");


--
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id");


--
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_instance_id_user_id_idx" ON "auth"."refresh_tokens" USING "btree" ("instance_id", "user_id");


--
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_parent_idx" ON "auth"."refresh_tokens" USING "btree" ("parent");


--
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_session_id_revoked_idx" ON "auth"."refresh_tokens" USING "btree" ("session_id", "revoked");


--
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "refresh_tokens_updated_at_idx" ON "auth"."refresh_tokens" USING "btree" ("updated_at" DESC);


--
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_providers_sso_provider_id_idx" ON "auth"."saml_providers" USING "btree" ("sso_provider_id");


--
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_created_at_idx" ON "auth"."saml_relay_states" USING "btree" ("created_at" DESC);


--
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_for_email_idx" ON "auth"."saml_relay_states" USING "btree" ("for_email");


--
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "saml_relay_states_sso_provider_id_idx" ON "auth"."saml_relay_states" USING "btree" ("sso_provider_id");


--
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_not_after_idx" ON "auth"."sessions" USING "btree" ("not_after" DESC);


--
-- Name: sessions_oauth_client_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_oauth_client_id_idx" ON "auth"."sessions" USING "btree" ("oauth_client_id");


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sessions_user_id_idx" ON "auth"."sessions" USING "btree" ("user_id");


--
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_domains_domain_idx" ON "auth"."sso_domains" USING "btree" ("lower"("domain"));


--
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_domains_sso_provider_id_idx" ON "auth"."sso_domains" USING "btree" ("sso_provider_id");


--
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "sso_providers_resource_id_idx" ON "auth"."sso_providers" USING "btree" ("lower"("resource_id"));


--
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "sso_providers_resource_id_pattern_idx" ON "auth"."sso_providers" USING "btree" ("resource_id" "text_pattern_ops");


--
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "unique_phone_factor_per_user" ON "auth"."mfa_factors" USING "btree" ("user_id", "phone");


--
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "user_id_created_at_idx" ON "auth"."sessions" USING "btree" ("user_id", "created_at");


--
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "users_email_partial_key" ON "auth"."users" USING "btree" ("email") WHERE ("is_sso_user" = false);


--
-- Name: INDEX "users_email_partial_key"; Type: COMMENT; Schema: auth; Owner: supabase_auth_admin
--

COMMENT ON INDEX "auth"."users_email_partial_key" IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_email_idx" ON "auth"."users" USING "btree" ("instance_id", "lower"(("email")::"text"));


--
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_instance_id_idx" ON "auth"."users" USING "btree" ("instance_id");


--
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "users_is_anonymous_idx" ON "auth"."users" USING "btree" ("is_anonymous");


--
-- Name: webauthn_challenges_expires_at_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_expires_at_idx" ON "auth"."webauthn_challenges" USING "btree" ("expires_at");


--
-- Name: webauthn_challenges_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_challenges_user_id_idx" ON "auth"."webauthn_challenges" USING "btree" ("user_id");


--
-- Name: webauthn_credentials_credential_id_key; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE UNIQUE INDEX "webauthn_credentials_credential_id_key" ON "auth"."webauthn_credentials" USING "btree" ("credential_id");


--
-- Name: webauthn_credentials_user_id_idx; Type: INDEX; Schema: auth; Owner: supabase_auth_admin
--

CREATE INDEX "webauthn_credentials_user_id_idx" ON "auth"."webauthn_credentials" USING "btree" ("user_id");


--
-- Name: idx_activity_logs_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_created_at" ON "public"."activity_logs" USING "btree" ("created_at" DESC);


--
-- Name: idx_activity_logs_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "idx_activity_logs_user_id" ON "public"."activity_logs" USING "btree" ("user_id");


--
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "ix_realtime_subscription_entity" ON "realtime"."subscription" USING "btree" ("entity");


--
-- Name: messages_inserted_at_topic_index; Type: INDEX; Schema: realtime; Owner: supabase_realtime_admin
--

CREATE INDEX "messages_inserted_at_topic_index" ON ONLY "realtime"."messages" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_03_28_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_03_28_inserted_at_topic_idx" ON "realtime"."messages_2026_03_28" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_03_29_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_03_29_inserted_at_topic_idx" ON "realtime"."messages_2026_03_29" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_03_30_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_03_30_inserted_at_topic_idx" ON "realtime"."messages_2026_03_30" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_03_31_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_03_31_inserted_at_topic_idx" ON "realtime"."messages_2026_03_31" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_04_01_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_04_01_inserted_at_topic_idx" ON "realtime"."messages_2026_04_01" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_04_02_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_04_02_inserted_at_topic_idx" ON "realtime"."messages_2026_04_02" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: messages_2026_04_03_inserted_at_topic_idx; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE INDEX "messages_2026_04_03_inserted_at_topic_idx" ON "realtime"."messages_2026_04_03" USING "btree" ("inserted_at" DESC, "topic") WHERE (("extension" = 'broadcast'::"text") AND ("private" IS TRUE));


--
-- Name: subscription_subscription_id_entity_filters_action_filter_key; Type: INDEX; Schema: realtime; Owner: supabase_admin
--

CREATE UNIQUE INDEX "subscription_subscription_id_entity_filters_action_filter_key" ON "realtime"."subscription" USING "btree" ("subscription_id", "entity", "filters", "action_filter");


--
-- Name: bname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bname" ON "storage"."buckets" USING "btree" ("name");


--
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "bucketid_objname" ON "storage"."objects" USING "btree" ("bucket_id", "name");


--
-- Name: buckets_analytics_unique_name_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "buckets_analytics_unique_name_idx" ON "storage"."buckets_analytics" USING "btree" ("name") WHERE ("deleted_at" IS NULL);


--
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_multipart_uploads_list" ON "storage"."s3_multipart_uploads" USING "btree" ("bucket_id", "key", "created_at");


--
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name" ON "storage"."objects" USING "btree" ("bucket_id", "name" COLLATE "C");


--
-- Name: idx_objects_bucket_id_name_lower; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "idx_objects_bucket_id_name_lower" ON "storage"."objects" USING "btree" ("bucket_id", "lower"("name") COLLATE "C");


--
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE INDEX "name_prefix_search" ON "storage"."objects" USING "btree" ("name" "text_pattern_ops");


--
-- Name: vector_indexes_name_bucket_id_idx; Type: INDEX; Schema: storage; Owner: supabase_storage_admin
--

CREATE UNIQUE INDEX "vector_indexes_name_bucket_id_idx" ON "storage"."vector_indexes" USING "btree" ("name", "bucket_id");


--
-- Name: messages_2026_03_28_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_03_28_inserted_at_topic_idx";


--
-- Name: messages_2026_03_28_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_03_28_pkey";


--
-- Name: messages_2026_03_29_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_03_29_inserted_at_topic_idx";


--
-- Name: messages_2026_03_29_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_03_29_pkey";


--
-- Name: messages_2026_03_30_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_03_30_inserted_at_topic_idx";


--
-- Name: messages_2026_03_30_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_03_30_pkey";


--
-- Name: messages_2026_03_31_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_03_31_inserted_at_topic_idx";


--
-- Name: messages_2026_03_31_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_03_31_pkey";


--
-- Name: messages_2026_04_01_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_04_01_inserted_at_topic_idx";


--
-- Name: messages_2026_04_01_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_04_01_pkey";


--
-- Name: messages_2026_04_02_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_04_02_inserted_at_topic_idx";


--
-- Name: messages_2026_04_02_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_04_02_pkey";


--
-- Name: messages_2026_04_03_inserted_at_topic_idx; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_inserted_at_topic_index" ATTACH PARTITION "realtime"."messages_2026_04_03_inserted_at_topic_idx";


--
-- Name: messages_2026_04_03_pkey; Type: INDEX ATTACH; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER INDEX "realtime"."messages_pkey" ATTACH PARTITION "realtime"."messages_2026_04_03_pkey";


--
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: supabase_admin
--

CREATE TRIGGER "tr_check_filters" BEFORE INSERT OR UPDATE ON "realtime"."subscription" FOR EACH ROW EXECUTE FUNCTION "realtime"."subscription_check_filters"();


--
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "enforce_bucket_name_length_trigger" BEFORE INSERT OR UPDATE OF "name" ON "storage"."buckets" FOR EACH ROW EXECUTE FUNCTION "storage"."enforce_bucket_name_length"();


--
-- Name: buckets protect_buckets_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_buckets_delete" BEFORE DELETE ON "storage"."buckets" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects protect_objects_delete; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "protect_objects_delete" BEFORE DELETE ON "storage"."objects" FOR EACH STATEMENT EXECUTE FUNCTION "storage"."protect_delete"();


--
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: supabase_storage_admin
--

CREATE TRIGGER "update_objects_updated_at" BEFORE UPDATE ON "storage"."objects" FOR EACH ROW EXECUTE FUNCTION "storage"."update_updated_at_column"();


--
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."identities"
    ADD CONSTRAINT "identities_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_amr_claims"
    ADD CONSTRAINT "mfa_amr_claims_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_challenges"
    ADD CONSTRAINT "mfa_challenges_auth_factor_id_fkey" FOREIGN KEY ("factor_id") REFERENCES "auth"."mfa_factors"("id") ON DELETE CASCADE;


--
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."mfa_factors"
    ADD CONSTRAINT "mfa_factors_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_authorizations oauth_authorizations_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_authorizations"
    ADD CONSTRAINT "oauth_authorizations_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_client_id_fkey" FOREIGN KEY ("client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: oauth_consents oauth_consents_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."oauth_consents"
    ADD CONSTRAINT "oauth_consents_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."one_time_tokens"
    ADD CONSTRAINT "one_time_tokens_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."refresh_tokens"
    ADD CONSTRAINT "refresh_tokens_session_id_fkey" FOREIGN KEY ("session_id") REFERENCES "auth"."sessions"("id") ON DELETE CASCADE;


--
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_providers"
    ADD CONSTRAINT "saml_providers_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_flow_state_id_fkey" FOREIGN KEY ("flow_state_id") REFERENCES "auth"."flow_state"("id") ON DELETE CASCADE;


--
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."saml_relay_states"
    ADD CONSTRAINT "saml_relay_states_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_oauth_client_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_oauth_client_id_fkey" FOREIGN KEY ("oauth_client_id") REFERENCES "auth"."oauth_clients"("id") ON DELETE CASCADE;


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sessions"
    ADD CONSTRAINT "sessions_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."sso_domains"
    ADD CONSTRAINT "sso_domains_sso_provider_id_fkey" FOREIGN KEY ("sso_provider_id") REFERENCES "auth"."sso_providers"("id") ON DELETE CASCADE;


--
-- Name: webauthn_challenges webauthn_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_challenges"
    ADD CONSTRAINT "webauthn_challenges_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE ONLY "auth"."webauthn_credentials"
    ADD CONSTRAINT "webauthn_credentials_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;


--
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."objects"
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads"
    ADD CONSTRAINT "s3_multipart_uploads_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets"("id");


--
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."s3_multipart_uploads_parts"
    ADD CONSTRAINT "s3_multipart_uploads_parts_upload_id_fkey" FOREIGN KEY ("upload_id") REFERENCES "storage"."s3_multipart_uploads"("id") ON DELETE CASCADE;


--
-- Name: vector_indexes vector_indexes_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE ONLY "storage"."vector_indexes"
    ADD CONSTRAINT "vector_indexes_bucket_id_fkey" FOREIGN KEY ("bucket_id") REFERENCES "storage"."buckets_vectors"("id");


--
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."audit_log_entries" ENABLE ROW LEVEL SECURITY;

--
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."flow_state" ENABLE ROW LEVEL SECURITY;

--
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."identities" ENABLE ROW LEVEL SECURITY;

--
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."instances" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_amr_claims" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_challenges" ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."mfa_factors" ENABLE ROW LEVEL SECURITY;

--
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."one_time_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."refresh_tokens" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."saml_relay_states" ENABLE ROW LEVEL SECURITY;

--
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."schema_migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sessions" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_domains" ENABLE ROW LEVEL SECURITY;

--
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."sso_providers" ENABLE ROW LEVEL SECURITY;

--
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: supabase_auth_admin
--

ALTER TABLE "auth"."users" ENABLE ROW LEVEL SECURITY;

--
-- Name: activity_logs Admins can view all activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Admins can view all activity logs" ON "public"."activity_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."taikhoan"
  WHERE (("taikhoan"."id" = "auth"."uid"()) AND ("taikhoan"."role" = 'Admin'::"text")))));


--
-- Name: doanvien Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."doanvien" FOR DELETE USING (true);


--
-- Name: namhoc Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."namhoc" FOR DELETE USING (true);


--
-- Name: phancong Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."phancong" FOR DELETE USING (true);


--
-- Name: qlchidoan Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."qlchidoan" FOR DELETE USING (true);


--
-- Name: settings Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."settings" FOR DELETE USING (true);


--
-- Name: taikhoan Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."taikhoan" FOR DELETE USING (true);


--
-- Name: tieuchitd Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."tieuchitd" FOR DELETE USING (true);


--
-- Name: tuanhoc Allow public delete access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public delete access" ON "public"."tuanhoc" FOR DELETE USING (true);


--
-- Name: doanvien Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."doanvien" FOR INSERT WITH CHECK (true);


--
-- Name: namhoc Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."namhoc" FOR INSERT WITH CHECK (true);


--
-- Name: phancong Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."phancong" FOR INSERT WITH CHECK (true);


--
-- Name: qlchidoan Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."qlchidoan" FOR INSERT WITH CHECK (true);


--
-- Name: settings Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."settings" FOR INSERT WITH CHECK (true);


--
-- Name: taikhoan Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."taikhoan" FOR INSERT WITH CHECK (true);


--
-- Name: tieuchitd Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."tieuchitd" FOR INSERT WITH CHECK (true);


--
-- Name: tuanhoc Allow public insert access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public insert access" ON "public"."tuanhoc" FOR INSERT WITH CHECK (true);


--
-- Name: doanvien Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."doanvien" FOR SELECT USING (true);


--
-- Name: namhoc Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."namhoc" FOR SELECT USING (true);


--
-- Name: phancong Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."phancong" FOR SELECT USING (true);


--
-- Name: qlchidoan Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."qlchidoan" FOR SELECT USING (true);


--
-- Name: settings Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."settings" FOR SELECT USING (true);


--
-- Name: taikhoan Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."taikhoan" FOR SELECT USING (true);


--
-- Name: tieuchitd Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."tieuchitd" FOR SELECT USING (true);


--
-- Name: tuanhoc Allow public read access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public read access" ON "public"."tuanhoc" FOR SELECT USING (true);


--
-- Name: doanvien Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."doanvien" FOR UPDATE USING (true);


--
-- Name: namhoc Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."namhoc" FOR UPDATE USING (true);


--
-- Name: phancong Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."phancong" FOR UPDATE USING (true);


--
-- Name: qlchidoan Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."qlchidoan" FOR UPDATE USING (true);


--
-- Name: settings Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."settings" FOR UPDATE USING (true);


--
-- Name: taikhoan Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."taikhoan" FOR UPDATE USING (true);


--
-- Name: tieuchitd Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."tieuchitd" FOR UPDATE USING (true);


--
-- Name: tuanhoc Allow public update access; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Allow public update access" ON "public"."tuanhoc" FOR UPDATE USING (true);


--
-- Name: activity_logs Authenticated users can insert activity logs; Type: POLICY; Schema: public; Owner: postgres
--

CREATE POLICY "Authenticated users can insert activity logs" ON "public"."activity_logs" FOR INSERT TO "authenticated" WITH CHECK (true);


--
-- Name: activity_logs; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."activity_logs" ENABLE ROW LEVEL SECURITY;

--
-- Name: doanvien; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."doanvien" ENABLE ROW LEVEL SECURITY;

--
-- Name: namhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."namhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: phancong; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."phancong" ENABLE ROW LEVEL SECURITY;

--
-- Name: qlchidoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."qlchidoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."settings" ENABLE ROW LEVEL SECURITY;

--
-- Name: taikhoan; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."taikhoan" ENABLE ROW LEVEL SECURITY;

--
-- Name: tieuchitd; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tieuchitd" ENABLE ROW LEVEL SECURITY;

--
-- Name: tuanhoc; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE "public"."tuanhoc" ENABLE ROW LEVEL SECURITY;

--
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: supabase_realtime_admin
--

ALTER TABLE "realtime"."messages" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_analytics" ENABLE ROW LEVEL SECURITY;

--
-- Name: buckets_vectors; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."buckets_vectors" ENABLE ROW LEVEL SECURITY;

--
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."migrations" ENABLE ROW LEVEL SECURITY;

--
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."objects" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads" ENABLE ROW LEVEL SECURITY;

--
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."s3_multipart_uploads_parts" ENABLE ROW LEVEL SECURITY;

--
-- Name: vector_indexes; Type: ROW SECURITY; Schema: storage; Owner: supabase_storage_admin
--

ALTER TABLE "storage"."vector_indexes" ENABLE ROW LEVEL SECURITY;

--
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: postgres
--

CREATE PUBLICATION "supabase_realtime" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";

--
-- Name: supabase_realtime_messages_publication; Type: PUBLICATION; Schema: -; Owner: supabase_admin
--

CREATE PUBLICATION "supabase_realtime_messages_publication" WITH (publish = 'insert, update, delete, truncate');


ALTER PUBLICATION "supabase_realtime_messages_publication" OWNER TO "supabase_admin";

--
-- Name: supabase_realtime_messages_publication messages; Type: PUBLICATION TABLE; Schema: realtime; Owner: supabase_admin
--

ALTER PUBLICATION "supabase_realtime_messages_publication" ADD TABLE ONLY "realtime"."messages";


--
-- Name: SCHEMA "auth"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "auth" TO "anon";
GRANT USAGE ON SCHEMA "auth" TO "authenticated";
GRANT USAGE ON SCHEMA "auth" TO "service_role";
GRANT ALL ON SCHEMA "auth" TO "supabase_auth_admin";
GRANT ALL ON SCHEMA "auth" TO "dashboard_user";
GRANT USAGE ON SCHEMA "auth" TO "postgres";


--
-- Name: SCHEMA "extensions"; Type: ACL; Schema: -; Owner: postgres
--

GRANT USAGE ON SCHEMA "extensions" TO "anon";
GRANT USAGE ON SCHEMA "extensions" TO "authenticated";
GRANT USAGE ON SCHEMA "extensions" TO "service_role";
GRANT ALL ON SCHEMA "extensions" TO "dashboard_user";


--
-- Name: SCHEMA "public"; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";


--
-- Name: SCHEMA "realtime"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "realtime" TO "postgres";
GRANT USAGE ON SCHEMA "realtime" TO "anon";
GRANT USAGE ON SCHEMA "realtime" TO "authenticated";
GRANT USAGE ON SCHEMA "realtime" TO "service_role";
GRANT ALL ON SCHEMA "realtime" TO "supabase_realtime_admin";


--
-- Name: SCHEMA "storage"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "storage" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "storage" TO "anon";
GRANT USAGE ON SCHEMA "storage" TO "authenticated";
GRANT USAGE ON SCHEMA "storage" TO "service_role";
GRANT ALL ON SCHEMA "storage" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON SCHEMA "storage" TO "dashboard_user";


--
-- Name: SCHEMA "vault"; Type: ACL; Schema: -; Owner: supabase_admin
--

GRANT USAGE ON SCHEMA "vault" TO "postgres" WITH GRANT OPTION;
GRANT USAGE ON SCHEMA "vault" TO "service_role";


--
-- Name: FUNCTION "email"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."email"() TO "dashboard_user";


--
-- Name: FUNCTION "jwt"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."jwt"() TO "postgres";
GRANT ALL ON FUNCTION "auth"."jwt"() TO "dashboard_user";


--
-- Name: FUNCTION "role"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."role"() TO "dashboard_user";


--
-- Name: FUNCTION "uid"(); Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON FUNCTION "auth"."uid"() TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "armor"("bytea", "text"[], "text"[]); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."armor"("bytea", "text"[], "text"[]) TO "dashboard_user";


--
-- Name: FUNCTION "crypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."crypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."crypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "dearmor"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."dearmor"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."dearmor"("text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "decrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."decrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "digest"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."digest"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."digest"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "encrypt_iv"("bytea", "bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."encrypt_iv"("bytea", "bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_bytes"(integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_bytes"(integer) TO "dashboard_user";


--
-- Name: FUNCTION "gen_random_uuid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_random_uuid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_random_uuid"() TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text") TO "dashboard_user";


--
-- Name: FUNCTION "gen_salt"("text", integer); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."gen_salt"("text", integer) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."gen_salt"("text", integer) TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_cron_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_cron_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_cron_access"() TO "dashboard_user";


--
-- Name: FUNCTION "grant_pg_graphql_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."grant_pg_graphql_access"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "grant_pg_net_access"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "extensions"."grant_pg_net_access"() FROM "supabase_admin";
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "supabase_admin" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."grant_pg_net_access"() TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "hmac"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."hmac"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements"("showtext" boolean, OUT "userid" "oid", OUT "dbid" "oid", OUT "toplevel" boolean, OUT "queryid" bigint, OUT "query" "text", OUT "plans" bigint, OUT "total_plan_time" double precision, OUT "min_plan_time" double precision, OUT "max_plan_time" double precision, OUT "mean_plan_time" double precision, OUT "stddev_plan_time" double precision, OUT "calls" bigint, OUT "total_exec_time" double precision, OUT "min_exec_time" double precision, OUT "max_exec_time" double precision, OUT "mean_exec_time" double precision, OUT "stddev_exec_time" double precision, OUT "rows" bigint, OUT "shared_blks_hit" bigint, OUT "shared_blks_read" bigint, OUT "shared_blks_dirtied" bigint, OUT "shared_blks_written" bigint, OUT "local_blks_hit" bigint, OUT "local_blks_read" bigint, OUT "local_blks_dirtied" bigint, OUT "local_blks_written" bigint, OUT "temp_blks_read" bigint, OUT "temp_blks_written" bigint, OUT "shared_blk_read_time" double precision, OUT "shared_blk_write_time" double precision, OUT "local_blk_read_time" double precision, OUT "local_blk_write_time" double precision, OUT "temp_blk_read_time" double precision, OUT "temp_blk_write_time" double precision, OUT "wal_records" bigint, OUT "wal_fpi" bigint, OUT "wal_bytes" numeric, OUT "jit_functions" bigint, OUT "jit_generation_time" double precision, OUT "jit_inlining_count" bigint, OUT "jit_inlining_time" double precision, OUT "jit_optimization_count" bigint, OUT "jit_optimization_time" double precision, OUT "jit_emission_count" bigint, OUT "jit_emission_time" double precision, OUT "jit_deform_count" bigint, OUT "jit_deform_time" double precision, OUT "stats_since" timestamp with time zone, OUT "minmax_stats_since" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_info"(OUT "dealloc" bigint, OUT "stats_reset" timestamp with time zone) TO "dashboard_user";


--
-- Name: FUNCTION "pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pg_stat_statements_reset"("userid" "oid", "dbid" "oid", "queryid" bigint, "minmax_only" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_armor_headers"("text", OUT "key" "text", OUT "value" "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_key_id"("bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_key_id"("bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_decrypt_bytea"("bytea", "bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt"("text", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt"("text", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_pub_encrypt_bytea"("bytea", "bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_pub_encrypt_bytea"("bytea", "bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_decrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_decrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt"("text", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt"("text", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgp_sym_encrypt_bytea"("bytea", "text", "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."pgp_sym_encrypt_bytea"("bytea", "text", "text") TO "dashboard_user";


--
-- Name: FUNCTION "pgrst_ddl_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_ddl_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "pgrst_drop_watch"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."pgrst_drop_watch"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "set_graphql_placeholder"(); Type: ACL; Schema: extensions; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "extensions"."set_graphql_placeholder"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "uuid_generate_v1"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v1mc"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v1mc"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v3"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v3"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v4"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v4"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v4"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_generate_v5"("namespace" "uuid", "name" "text"); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_generate_v5"("namespace" "uuid", "name" "text") TO "dashboard_user";


--
-- Name: FUNCTION "uuid_nil"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_nil"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_nil"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_dns"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_dns"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_dns"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_oid"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_oid"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_oid"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_url"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_url"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_url"() TO "dashboard_user";


--
-- Name: FUNCTION "uuid_ns_x500"(); Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON FUNCTION "extensions"."uuid_ns_x500"() FROM "postgres";
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "extensions"."uuid_ns_x500"() TO "dashboard_user";


--
-- Name: FUNCTION "graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb"); Type: ACL; Schema: graphql_public; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "postgres";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "graphql_public"."graphql"("operationName" "text", "query" "text", "variables" "jsonb", "extensions" "jsonb") TO "service_role";


--
-- Name: FUNCTION "pg_reload_conf"(); Type: ACL; Schema: pg_catalog; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "pg_catalog"."pg_reload_conf"() TO "postgres" WITH GRANT OPTION;


--
-- Name: FUNCTION "get_auth"("p_usename" "text"); Type: ACL; Schema: pgbouncer; Owner: supabase_admin
--

REVOKE ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") FROM PUBLIC;
GRANT ALL ON FUNCTION "pgbouncer"."get_auth"("p_usename" "text") TO "pgbouncer";


--
-- Name: FUNCTION "apply_rls"("wal" "jsonb", "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."apply_rls"("wal" "jsonb", "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."broadcast_changes"("topic_name" "text", "event_name" "text", "operation" "text", "table_name" "text", "table_schema" "text", "new" "record", "old" "record", "level" "text") TO "dashboard_user";


--
-- Name: FUNCTION "build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."build_prepared_statement_sql"("prepared_statement_name" "text", "entity" "regclass", "columns" "realtime"."wal_column"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "cast"("val" "text", "type_" "regtype"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "anon";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."cast"("val" "text", "type_" "regtype") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."check_equality_op"("op" "realtime"."equality_op", "type_" "regtype", "val_1" "text", "val_2" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "anon";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."is_visible_through_filters"("columns" "realtime"."wal_column"[], "filters" "realtime"."user_defined_filter"[]) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "anon";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "service_role";
GRANT ALL ON FUNCTION "realtime"."list_changes"("publication" "name", "slot_name" "name", "max_changes" integer, "max_record_bytes" integer) TO "supabase_realtime_admin";


--
-- Name: FUNCTION "quote_wal2json"("entity" "regclass"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "anon";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."quote_wal2json"("entity" "regclass") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "postgres";
GRANT ALL ON FUNCTION "realtime"."send"("payload" "jsonb", "event" "text", "topic" "text", "private" boolean) TO "dashboard_user";


--
-- Name: FUNCTION "subscription_check_filters"(); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "anon";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "service_role";
GRANT ALL ON FUNCTION "realtime"."subscription_check_filters"() TO "supabase_realtime_admin";


--
-- Name: FUNCTION "to_regrole"("role_name" "text"); Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "postgres";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "dashboard_user";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "anon";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "authenticated";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "service_role";
GRANT ALL ON FUNCTION "realtime"."to_regrole"("role_name" "text") TO "supabase_realtime_admin";


--
-- Name: FUNCTION "topic"(); Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON FUNCTION "realtime"."topic"() TO "postgres";
GRANT ALL ON FUNCTION "realtime"."topic"() TO "dashboard_user";


--
-- Name: FUNCTION "_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."_crypto_aead_det_decrypt"("message" "bytea", "additional" "bytea", "key_id" bigint, "context" "bytea", "nonce" "bytea") TO "service_role";


--
-- Name: FUNCTION "create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."create_secret"("new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: FUNCTION "update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid"); Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "postgres" WITH GRANT OPTION;
GRANT ALL ON FUNCTION "vault"."update_secret"("secret_id" "uuid", "new_secret" "text", "new_name" "text", "new_description" "text", "new_key_id" "uuid") TO "service_role";


--
-- Name: TABLE "audit_log_entries"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."audit_log_entries" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."audit_log_entries" TO "postgres";
GRANT SELECT ON TABLE "auth"."audit_log_entries" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "custom_oauth_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "postgres";
GRANT ALL ON TABLE "auth"."custom_oauth_providers" TO "dashboard_user";


--
-- Name: TABLE "flow_state"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."flow_state" TO "postgres";
GRANT SELECT ON TABLE "auth"."flow_state" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."flow_state" TO "dashboard_user";


--
-- Name: TABLE "identities"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."identities" TO "postgres";
GRANT SELECT ON TABLE "auth"."identities" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."identities" TO "dashboard_user";


--
-- Name: TABLE "instances"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."instances" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."instances" TO "postgres";
GRANT SELECT ON TABLE "auth"."instances" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "mfa_amr_claims"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_amr_claims" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_amr_claims" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_amr_claims" TO "dashboard_user";


--
-- Name: TABLE "mfa_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_challenges" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_challenges" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_challenges" TO "dashboard_user";


--
-- Name: TABLE "mfa_factors"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."mfa_factors" TO "postgres";
GRANT SELECT ON TABLE "auth"."mfa_factors" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."mfa_factors" TO "dashboard_user";


--
-- Name: TABLE "oauth_authorizations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_authorizations" TO "dashboard_user";


--
-- Name: TABLE "oauth_client_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_client_states" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_client_states" TO "dashboard_user";


--
-- Name: TABLE "oauth_clients"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_clients" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_clients" TO "dashboard_user";


--
-- Name: TABLE "oauth_consents"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."oauth_consents" TO "postgres";
GRANT ALL ON TABLE "auth"."oauth_consents" TO "dashboard_user";


--
-- Name: TABLE "one_time_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."one_time_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."one_time_tokens" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."one_time_tokens" TO "dashboard_user";


--
-- Name: TABLE "refresh_tokens"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."refresh_tokens" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."refresh_tokens" TO "postgres";
GRANT SELECT ON TABLE "auth"."refresh_tokens" TO "postgres" WITH GRANT OPTION;


--
-- Name: SEQUENCE "refresh_tokens_id_seq"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "dashboard_user";
GRANT ALL ON SEQUENCE "auth"."refresh_tokens_id_seq" TO "postgres";


--
-- Name: TABLE "saml_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_providers" TO "dashboard_user";


--
-- Name: TABLE "saml_relay_states"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."saml_relay_states" TO "postgres";
GRANT SELECT ON TABLE "auth"."saml_relay_states" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."saml_relay_states" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT SELECT ON TABLE "auth"."schema_migrations" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "sessions"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sessions" TO "postgres";
GRANT SELECT ON TABLE "auth"."sessions" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sessions" TO "dashboard_user";


--
-- Name: TABLE "sso_domains"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_domains" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_domains" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_domains" TO "dashboard_user";


--
-- Name: TABLE "sso_providers"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."sso_providers" TO "postgres";
GRANT SELECT ON TABLE "auth"."sso_providers" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "auth"."sso_providers" TO "dashboard_user";


--
-- Name: TABLE "users"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."users" TO "dashboard_user";
GRANT INSERT,REFERENCES,DELETE,TRIGGER,TRUNCATE,MAINTAIN,UPDATE ON TABLE "auth"."users" TO "postgres";
GRANT SELECT ON TABLE "auth"."users" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "webauthn_challenges"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_challenges" TO "dashboard_user";


--
-- Name: TABLE "webauthn_credentials"; Type: ACL; Schema: auth; Owner: supabase_auth_admin
--

GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "postgres";
GRANT ALL ON TABLE "auth"."webauthn_credentials" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements" TO "dashboard_user";


--
-- Name: TABLE "pg_stat_statements_info"; Type: ACL; Schema: extensions; Owner: postgres
--

REVOKE ALL ON TABLE "extensions"."pg_stat_statements_info" FROM "postgres";
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "postgres" WITH GRANT OPTION;
GRANT ALL ON TABLE "extensions"."pg_stat_statements_info" TO "dashboard_user";


--
-- Name: TABLE "activity_logs"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."activity_logs" TO "anon";
GRANT ALL ON TABLE "public"."activity_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."activity_logs" TO "service_role";


--
-- Name: TABLE "chamdiem"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."chamdiem" TO "anon";
GRANT ALL ON TABLE "public"."chamdiem" TO "authenticated";
GRANT ALL ON TABLE "public"."chamdiem" TO "service_role";


--
-- Name: TABLE "doanvien"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."doanvien" TO "anon";
GRANT ALL ON TABLE "public"."doanvien" TO "authenticated";
GRANT ALL ON TABLE "public"."doanvien" TO "service_role";


--
-- Name: TABLE "namhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."namhoc" TO "anon";
GRANT ALL ON TABLE "public"."namhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."namhoc" TO "service_role";


--
-- Name: TABLE "phancong"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phancong" TO "anon";
GRANT ALL ON TABLE "public"."phancong" TO "authenticated";
GRANT ALL ON TABLE "public"."phancong" TO "service_role";


--
-- Name: TABLE "phanquyen"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."phanquyen" TO "anon";
GRANT ALL ON TABLE "public"."phanquyen" TO "authenticated";
GRANT ALL ON TABLE "public"."phanquyen" TO "service_role";


--
-- Name: SEQUENCE "phanquyen_id_seq"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."phanquyen_id_seq" TO "service_role";


--
-- Name: TABLE "qlchidoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."qlchidoan" TO "anon";
GRANT ALL ON TABLE "public"."qlchidoan" TO "authenticated";
GRANT ALL ON TABLE "public"."qlchidoan" TO "service_role";


--
-- Name: TABLE "settings"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."settings" TO "anon";
GRANT ALL ON TABLE "public"."settings" TO "authenticated";
GRANT ALL ON TABLE "public"."settings" TO "service_role";


--
-- Name: TABLE "taikhoan"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."taikhoan" TO "anon";
GRANT ALL ON TABLE "public"."taikhoan" TO "authenticated";
GRANT ALL ON TABLE "public"."taikhoan" TO "service_role";


--
-- Name: TABLE "tieuchitd"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tieuchitd" TO "anon";
GRANT ALL ON TABLE "public"."tieuchitd" TO "authenticated";
GRANT ALL ON TABLE "public"."tieuchitd" TO "service_role";


--
-- Name: TABLE "tuanhoc"; Type: ACL; Schema: public; Owner: postgres
--

GRANT ALL ON TABLE "public"."tuanhoc" TO "anon";
GRANT ALL ON TABLE "public"."tuanhoc" TO "authenticated";
GRANT ALL ON TABLE "public"."tuanhoc" TO "service_role";


--
-- Name: TABLE "messages"; Type: ACL; Schema: realtime; Owner: supabase_realtime_admin
--

GRANT ALL ON TABLE "realtime"."messages" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages" TO "dashboard_user";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "anon";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "authenticated";
GRANT SELECT,INSERT,UPDATE ON TABLE "realtime"."messages" TO "service_role";


--
-- Name: TABLE "messages_2026_03_28"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_03_28" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_03_28" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_03_29"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_03_29" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_03_29" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_03_30"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_03_30" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_03_30" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_03_31"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_03_31" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_03_31" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_04_01"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_04_01" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_04_01" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_04_02"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_04_02" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_04_02" TO "dashboard_user";


--
-- Name: TABLE "messages_2026_04_03"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."messages_2026_04_03" TO "postgres";
GRANT ALL ON TABLE "realtime"."messages_2026_04_03" TO "dashboard_user";


--
-- Name: TABLE "schema_migrations"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."schema_migrations" TO "postgres";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "anon";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."schema_migrations" TO "service_role";
GRANT ALL ON TABLE "realtime"."schema_migrations" TO "supabase_realtime_admin";


--
-- Name: TABLE "subscription"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON TABLE "realtime"."subscription" TO "postgres";
GRANT ALL ON TABLE "realtime"."subscription" TO "dashboard_user";
GRANT SELECT ON TABLE "realtime"."subscription" TO "anon";
GRANT SELECT ON TABLE "realtime"."subscription" TO "authenticated";
GRANT SELECT ON TABLE "realtime"."subscription" TO "service_role";
GRANT ALL ON TABLE "realtime"."subscription" TO "supabase_realtime_admin";


--
-- Name: SEQUENCE "subscription_id_seq"; Type: ACL; Schema: realtime; Owner: supabase_admin
--

GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "postgres";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "dashboard_user";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "anon";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "authenticated";
GRANT USAGE ON SEQUENCE "realtime"."subscription_id_seq" TO "service_role";
GRANT ALL ON SEQUENCE "realtime"."subscription_id_seq" TO "supabase_realtime_admin";


--
-- Name: TABLE "buckets"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."buckets" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."buckets" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."buckets" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets" TO "anon";
GRANT ALL ON TABLE "storage"."buckets" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "buckets_analytics"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."buckets_analytics" TO "service_role";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "authenticated";
GRANT ALL ON TABLE "storage"."buckets_analytics" TO "anon";


--
-- Name: TABLE "buckets_vectors"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "service_role";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "authenticated";
GRANT SELECT ON TABLE "storage"."buckets_vectors" TO "anon";


--
-- Name: TABLE "objects"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

REVOKE ALL ON TABLE "storage"."objects" FROM "supabase_storage_admin";
GRANT ALL ON TABLE "storage"."objects" TO "supabase_storage_admin" WITH GRANT OPTION;
GRANT ALL ON TABLE "storage"."objects" TO "service_role";
GRANT ALL ON TABLE "storage"."objects" TO "authenticated";
GRANT ALL ON TABLE "storage"."objects" TO "anon";
GRANT ALL ON TABLE "storage"."objects" TO "postgres" WITH GRANT OPTION;


--
-- Name: TABLE "s3_multipart_uploads"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads" TO "anon";


--
-- Name: TABLE "s3_multipart_uploads_parts"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT ALL ON TABLE "storage"."s3_multipart_uploads_parts" TO "service_role";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "authenticated";
GRANT SELECT ON TABLE "storage"."s3_multipart_uploads_parts" TO "anon";


--
-- Name: TABLE "vector_indexes"; Type: ACL; Schema: storage; Owner: supabase_storage_admin
--

GRANT SELECT ON TABLE "storage"."vector_indexes" TO "service_role";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "authenticated";
GRANT SELECT ON TABLE "storage"."vector_indexes" TO "anon";


--
-- Name: TABLE "secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."secrets" TO "service_role";


--
-- Name: TABLE "decrypted_secrets"; Type: ACL; Schema: vault; Owner: supabase_admin
--

GRANT SELECT,REFERENCES,DELETE,TRUNCATE ON TABLE "vault"."decrypted_secrets" TO "postgres" WITH GRANT OPTION;
GRANT SELECT,DELETE ON TABLE "vault"."decrypted_secrets" TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: auth; Owner: supabase_auth_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_auth_admin" IN SCHEMA "auth" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON SEQUENCES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON FUNCTIONS TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: extensions; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "extensions" GRANT ALL ON TABLES TO "postgres" WITH GRANT OPTION;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: graphql_public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "graphql_public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON SEQUENCES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON FUNCTIONS TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: realtime; Owner: supabase_admin
--

ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "supabase_admin" IN SCHEMA "realtime" GRANT ALL ON TABLES TO "dashboard_user";


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON SEQUENCES TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON FUNCTIONS TO "service_role";


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: storage; Owner: postgres
--

ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "storage" GRANT ALL ON TABLES TO "service_role";


--
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_graphql_placeholder" ON "sql_drop"
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION "extensions"."set_graphql_placeholder"();


ALTER EVENT TRIGGER "issue_graphql_placeholder" OWNER TO "supabase_admin";

--
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_cron_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_cron_access"();


ALTER EVENT TRIGGER "issue_pg_cron_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_graphql_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION "extensions"."grant_pg_graphql_access"();


ALTER EVENT TRIGGER "issue_pg_graphql_access" OWNER TO "supabase_admin";

--
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "issue_pg_net_access" ON "ddl_command_end"
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION "extensions"."grant_pg_net_access"();


ALTER EVENT TRIGGER "issue_pg_net_access" OWNER TO "supabase_admin";

--
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_ddl_watch" ON "ddl_command_end"
   EXECUTE FUNCTION "extensions"."pgrst_ddl_watch"();


ALTER EVENT TRIGGER "pgrst_ddl_watch" OWNER TO "supabase_admin";

--
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: supabase_admin
--

CREATE EVENT TRIGGER "pgrst_drop_watch" ON "sql_drop"
   EXECUTE FUNCTION "extensions"."pgrst_drop_watch"();


ALTER EVENT TRIGGER "pgrst_drop_watch" OWNER TO "supabase_admin";

--
-- PostgreSQL database dump complete
--

\unrestrict RAIoH2o1jmM8wzmXpFTMHqGQhVaiq6sKwIuTOk9ibgERgQg2sw5VZCnzgSIzeq8

